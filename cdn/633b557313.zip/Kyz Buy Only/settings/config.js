global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285864778968']
global.packname = "KyzCrashV2"
global.author = "KyzCrasV2"
global.mess = {
 owner: '*BUKAN OWNER BEGO 🥱*',
 premium: '*BUKAN PREM BEGO 🥱*'
}