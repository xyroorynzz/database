//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// module
process.on('uncaughtException', console.error)
require('./AliceSet')
require('./AliceLibray/AliceMenu')

const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageContent, makeWASocket, generateWAMessage, downloadContentFromMessage, areJidsSameUser, S_WHATSAPP_NET, getContentType, useMultiFileAuthState, PHONENUMBER_MCC, generateWAMessageFromContent, proto, prepareWAMessageMedia, getDevice  } =require("@aliceassistent/baileys")
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const os = require('os')
const fs = require('fs')
const ms = require("ms");
const dns = require('dns');
const path = require("path")
const util = require('util')
const jimp_1 = require('jimp')
const https = require('https')
const chalk = require('chalk')
const ds = require('d-scrape')
const axios = require('axios')
const mark = `0@s.whatsapp.net`
const msx = require('parse-ms')
const fg = require('api-dylux')
const fsx = require('fs-extra')
const crypto = require('crypto')
const fetch = require('node-fetch');
const cron = require('node-cron')
const gtts = require('node-gtts')
const yts = require ('yt-search');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid')
const nou = require("node-os-utils")
const FormData = require('form-data')
const genshindb = require("genshin-db")
const ffmpeg = require('fluent-ffmpeg');
const didyoumean = require('didyoumean');
const ffmpegStatic = require('ffmpeg-static');
const speed = require('performance-now')
const JsConfuser = require('js-confuser');
const similarity = require('similarity');
const sharp = require("sharp")
const moment = require('moment-timezone')
const PhoneNum = require('awesome-phonenumber')
const { Primbon } = require('scrape-primbon')
const { createCanvas, loadImage } = require('canvas');
const { spawn: spawn, exec, execSync } = require('child_process')
const { CNBCNews, DetikNews, KontanNews, iNews, Quotes, Couples, Darkjokes, DailyNews } = require("dhn-api")
const primbon = new Primbon()
const threshold = 0.72
let banNotifCooldown = {}
const DB_FILE = "./AliceDatabase/system-db/database.json";

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// mengambil semua database
global.db.data = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/database.json'))

if (global.db.data) global.db.data = {
  sticker: {},
  database: {}, 
  game: {},
  others: {},
  users: {},
  chats: {},
  settings: {
    register: false
  },
  ...(global.db.data || {})
}

if (!global.db.data.users) global.db.data.users = {}
if (!global.db.data.settings) global.db.data.settings = { register: false }
if (typeof global.db.data.settings.register !== 'boolean') { global.db.data.settings.register = false }
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const ownerNumber = global.owner;
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// premium
const {
addPremiumUser,
getPremiumExpired,
getPremiumPosition,
expiredCheck,
checkPremiumUser,
getAllPremiumUser,
} = require('./AliceLibray/premiun')

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Fungsi Untuk Memanggil Code Yang Ada Di File js Terpisah
const changelogs = global.db.data.changelog || []
const db_absen = JSON.parse(fs.readFileSync("./AliceSystem/AliceDatabase/Group/absen.json"));
const db_sider = JSON.parse(fs.readFileSync("./AliceSystem/AliceDatabase/Group/sider.json"));
const contacts = JSON.parse(fs.readFileSync("./AliceDatabase/users-db/contacts.json"));
const { qtoko, XR, xy, p, fkontak, al, ftroli, qlocJpm, xyyy, floc, K } = require('./AliceLibray/fakequoted')
let _cmd = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/command.json'));
const afk = require('./AliceLibray/afk')
const _afk = afk.loadAfk()
let mute = JSON.parse(fs.readFileSync('./AliceDatabase/group-db/mute.json'));
const timestampp = speed();
const latensi = speed() - timestampp
let reminders = {};
const { smsg, getGroupAdmins, formatp, h2k, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, toRupiah, getRandom, reSize, randomNumber, resize, monospace, randomKarakter, capital, encryptCode } = require('./AliceLibray/alice-function')
const { addList, delList, getList, findList, updateList } = require('./AliceSystem/AliceDatabase/Group/list')
// End

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Scraper
const ZAIClient = require('./AliceSystem/AliceScraper/alice-zai')
const igdl = require('./AliceSystem/AliceScraper/alice-igdl.js')
const CNNNews = require('./AliceSystem/AliceScraper/alice-cnnnews')
const animexin = require('./AliceSystem/AliceScraper/alice-animexin');
const convertToMorse = require('./AliceSystem/AliceScraper/alice-Morse.js')
const WikiMedia = require('./AliceSystem/AliceScraper/alice-wikimedia.js')
const FFW = require('./AliceSystem/AliceScraper/alice-FFW.js')
const Python = require('./AliceSystem/AliceScraper/alice-Python.js')
const Html = require('./AliceSystem/AliceScraper/alice-Html.js')
const BookSearch = require('./AliceSystem/AliceScraper/alice-caribuku.js')
const LirikLagu = require('./AliceSystem/AliceScraper/alice-lirik.js')
const Eai = require('./AliceSystem/AliceScraper/alice-eai.js')
const Yimg = require('./AliceSystem/AliceScraper/alice-yahooimg.js')
const txt2 = require('./AliceSystem/AliceScraper/alice-txt-to-image.js')
const JavaScript = require('./AliceSystem/AliceScraper/alice-Javascript.js')
const pinterest = require('./AliceSystem/AliceScraper/alice-pinterest.js')
const capcutDownloader = require('./AliceSystem/AliceScraper/alice-capcut.js')
const tiktokdl = require('./AliceSystem/AliceScraper/alice-tiktokdl.js')
const hdvideo = require('./AliceSystem/AliceScraper/alice-hdvideo')
const mediafiredl = require('./AliceSystem/AliceScraper/alice-mediafiredl')
const whatmusic = require('./AliceSystem/AliceScraper/alice-whatmusic')
const jadwalsholat = require('./AliceSystem/AliceScraper/alice-jadwalsholat')
const tiktokmp3 = require('./AliceSystem/AliceScraper/alice-tiktokmp3')
const nontonAnime = require('./AliceSystem/AliceScraper/alice-nontonanime')
const aliceHdImage = require('./AliceSystem/AliceScraper/alice-hdimage')
const reactionchannel = require('./AliceSystem/AliceScraper/alice-reactionch')
const hitungJarak = require('./AliceSystem/AliceScraper/alice-jarak');
const { kimiAI } = require('./AliceSystem/AliceScraper/alice-kimi.js')
const { deepseek } = require("./AliceSystem/AliceScraper/alice-deepseek")
const { gpt4o, imageToDataUrl } = require("./AliceSystem/AliceScraper/alice-gpt4o")
const { removeclothes } = require('./AliceSystem/AliceScraper/alice-removeclothes.js')
const { PlaystoreSearch } = require('./AliceSystem/AliceScraper/alice-playstoresearch')
const { SpotifyDl } = require('./AliceSystem/AliceScraper/alice-spotifydl')
const { SpotifySearch } = require('./AliceSystem/AliceScraper/alice-spotifysearch')
const { ytdl } = require('./AliceSystem/AliceScraper/alice-ytdl')
const { nglspam } = require('./AliceSystem/AliceScraper/alice-nglspam.js')
const { Smeme } = require('./AliceSystem/AliceScraper/alice-smeme')
const { douyindl } = require('./AliceSystem/AliceScraper/alice-douyindl');
const { DouyinSearchPage } = require('./AliceSystem/AliceScraper/alice-douyinsearch');
const { hadist, detail } = require('./AliceSystem/AliceScraper/alice-hadistid');
const { shortCloudku } = require('./AliceSystem/AliceScraper/alice-shortCloudku');
const { ringtone } = require("./AliceSystem/AliceScraper/alice-ringtone.js");
const { Felo } = require('./AliceSystem/AliceScraper/alice-Felo.js');
const { PinDL } = require('./AliceSystem/AliceScraper/alice-pindl.js')
const { imgToPrompt } = require('./AliceSystem/AliceScraper/alice-img2prompt.js');
const { wattpad } = require("./AliceSystem/AliceScraper/alice-wattpad.js")
const { SaveTube } = require('./AliceSystem/AliceScraper/alice-SaveTube.js')
const { komikindo } = require("./AliceSystem/AliceScraper/alice-komikindo.js")
const { muslimai } = require('./AliceSystem/AliceScraper/alice-MuslimAI.js')
const { convertTo } = require('./AliceSystem/AliceScraper/alice-convertto')
const { twitterDl } = require("./AliceSystem/AliceScraper/alice-twitterdl")
const { createQRIS, checkStatus } = require('./AliceSystem/AliceScraper/alice-orderkuota')
const { upScale, remini, Pxpic } = require('./AliceSystem/AliceScraper/alice-enhance')
const { xnxxDownloader, xnxxSearch } = require('./AliceSystem/AliceScraper/alice-xnxx')
const { generateAttp, generateTtp, generateAttp_v2, generateTtp_v2, generateAttp_v3, generateTtp_v3,  generateAttp_v4, generateTtp_v4, generateTtp_v5 } = require("./AliceSystem/AliceScraper/alice-generate-attp");
// End

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Reply Set
const modeFile = './AliceDatabase/system-db/replymode.json'

const replyModes = {
  1: { name: "Default AdReply" },
  2: { name: "Interactive Message" },
  3: { name: "Forwarded Style" },
  4: { name: "Simple Mention" }
}

if (!fs.existsSync(modeFile)) {
  fs.writeFileSync(modeFile, JSON.stringify({ mode: 1 }, null, 2))
}

const getMode = () => JSON.parse(fs.readFileSync(modeFile)).mode

//📈————————————————————————— [ © XyrooRynzz ] —————————————————————————📉
// setcmd sticker

const setcmdPath = './AliceDatabase/system-db/setcmd.json'

if (!fs.existsSync(setcmdPath)) {
  fs.writeFileSync(setcmdPath, JSON.stringify({}))
}

let setcmdDB = JSON.parse(fs.readFileSync(setcmdPath))

function saveSetcmd() {
  fs.writeFileSync(setcmdPath, JSON.stringify(setcmdDB, null, 2))
}

//📈————————————————————————— [ © XyrooRynzz ] —————————————————————————?
const limitFile = './AliceDatabase/users-db/limit.json'
if (!fs.existsSync(limitFile)) fs.writeFileSync(limitFile, JSON.stringify({}))

const limitModeFile = './AliceDatabase/system-db/limitmode.json'

if (!fs.existsSync(limitModeFile)) {
  fs.writeFileSync(limitModeFile, JSON.stringify({ enabled: false }))
}

global.limitSettings = JSON.parse(fs.readFileSync(limitModeFile))

global.saveLimitMode = function () {
  fs.writeFileSync(limitModeFile, JSON.stringify(global.limitSettings, null, 2))
}

global.limitDB = JSON.parse(fs.readFileSync(limitFile))

global.saveLimit = function () {
  fs.writeFileSync(limitFile, JSON.stringify(global.limitDB, null, 2))
}

function isLimitActive() {
  return global.limitSettings?.enabled
}

function getUserLimit(id) {
  if (!global.limitDB[id]) {
    global.limitDB[id] = {
      limit: 0,
      lastReset: Date.now()
    }
  }
  return global.limitDB[id]
}

function resetLimitIfNeeded(user, role) {
  let now = Date.now()
  let oneDay = 86400000

  if (user.limit >= 20) return

  if (now - user.lastReset > oneDay) {

    if (role === 'owner') {
      user.limit = global.limitawal.owner
    } else if (role === 'premium') {
      user.limit = global.limitawal.premium
    } else {
      user.limit = global.limitawal.free
    }

    user.lastReset = now
  }
}

function getNoLimitCmdAuto() {
  const code = fs.readFileSync('./Alice.js', 'utf-8')

  const regex = /case\s+'(.*?)'[\s\S]*?break/g
  let match
  let result = []

  while ((match = regex.exec(code)) !== null) {
    let fullCase = match[0]
    let cmd = match[1]

    if (fullCase.includes('sendBatenAlice')) {
      result.push(cmd)
    }
  }

  return result
}

let noLimitCmd = []
setTimeout(() => {
  noLimitCmd = getNoLimitCmdAuto()
}, 1000)
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
module.exports = Alice = async (Alice, m, chatUpdate, store) => {
 try {
var body = (
m.mtype === 'conversation' ? m.message.conversation :
m.mtype == 'imageMessage' ? m.message.imageMessage.caption :
m.mtype == 'videoMessage' ? m.message.videoMessage.caption :
m.mtype == 'stickerMessage' ? m.message.stickerMessage?.caption :
m.mtype == 'extendedTextMessage' ? m.message.extendedTextMessage.text :
m.mtype == 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype == 'listResponseMessage' ? m.message.listResponseMessage.singleSelectreply.selectedRowId :
m.mtype == 'templateButtonreplyMessage' ? m.message.templateButtonreplyMessage.selectedId :
m.mtype == 'interactiveResponseMessage' ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype == 'templateButtonreplyMessage' ? m.msg.selectedId :
m.mtype === 'messageContextInfo' ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectreply.selectedRowId || m.text) :
''
) || ''
var budy = (typeof m.text == 'string' ? m.text : '')
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

const pushname = m.pushName || "No Name"
    
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// read database chats
const cekpesan = true;
    
    if (cekpesan) {
      const chatId = m.key.remoteJid;
      const senderId = m.key.participant || m.key.remoteJid;
      if (!global.db.data.chats[chatId]) {
        global.db.data.chats[chatId] = {};
      }
      if (!global.db.data.chats[chatId].totalChat) {
        global.db.data.chats[chatId].totalChat = {};
       } 
      global.db.data.chats[chatId].totalChat[senderId] = (global.db.data.chats[chatId].totalChat[senderId] || 0) + 1;
      saveDB(global.db.data);
      const msgContent = m.message.conversation || m.message.extendedTextMessage && m.message.extendedTextMessage.text || "";
    }
    

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// hitung user
const usersFile = './AliceDatabase/users-db/users.json';
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, JSON.stringify([]));
let usersList = JSON.parse(fs.readFileSync(usersFile));
if (!usersList.includes(m.sender)) {
    usersList.push(m.sender);
    fs.writeFileSync(usersFile, JSON.stringify(usersList, null, 2));
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// ANTILINK Group
const ntilinkgc = JSON.parse(fs.readFileSync("./AliceSystem/AliceDatabase/Antilink/antilinkgc.json"))
let ntvirtex = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antivirus.json'))
let nttoxic = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antitoxic.json'))
let ntasing = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antiasing.json'))
let ntwame = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antiwame.json'))
let ntilinkall = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkall.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinktwitter.json'))
let ntilinktt =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinktiktok.json'))
let ntilinktg =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinktelegram.json'))
let ntilinkfb =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkfacebook.json'))
let ntilinkig =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkinstagram.json'))
let ntilinkytch =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkytchannel.json'))
let ntilinkytvid =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkytvideo.json'))
let ntilinktele =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinktelegram.json'))
let ntilinkdewasa =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkbokep.json'))
let ntilinkterabox =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkterabox.json'))
let ntilinkmediafire =JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Antilink/antilinkmediafire.json'))
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Anti In Group
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const chatsData = global.db.data.chats[m.chat] || {}

const AntiLink = m.isGroup ? ntilinkgc.includes(m.chat) : false 
const AntiVirtex = m.isGroup ? ntvirtex.includes(m.chat) : false
const AntiLinkYoutubeVid = m.isGroup ? ntilinkytvid.includes(m.chat) : false
const AntiLinkYoutubeChannel = m.isGroup ? ntilinkytch.includes(m.chat) : false
const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(m.chat) : false
const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(m.chat) : false
const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(m.chat) : false
const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(m.chat) : false
const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(m.chat) : false
const AntiLinkAll = m.isGroup ? ntilinkall.find(v => v.id === m.chat) : false
const AntiWame = m.isGroup ? ntwame.includes(m.chat) : false
const AntiToxic = m.isGroup ? nttoxic.includes(m.chat) : false
const AntiAsing = m.isGroup ? ntasing.includes(m.chat) : false
const AntiDewasa = m.isGroup ? ntilinkdewasa.includes(m.chat) : false
const AntiTerabox = m.isGroup ? ntilinkterabox.includes(m.chat) : false
const AntiMediafire = m.isGroup ? ntilinkmediafire.includes(m.chat) : false
const AntiTele = m.isGroup ? ntilinktele.includes(m.chat) : false
const AntiBot = m.isGroup ? !!chatsData.antibot         : false
const AntiCall = m.isGroup ? !!chatsData.anticall        : false
const AntiTagSw = m.isGroup ? !!chatsData.antitagsw       : false
const AntiSpam = m.isGroup ? !!chatsData.antispam        : false
const AntiMedia = m.isGroup ? !!chatsData.antimedia       : false
const AntiImage = m.isGroup ? !!chatsData.antiimage       : false
const AntiVideo = m.isGroup ? !!chatsData.antivideo       : false
const AntiAudio = m.isGroup ? !!chatsData.antiaudio       : false
const AntiSticker = m.isGroup ? !!chatsData.antisticker     : false
const AntiDocument = m.isGroup ? !!chatsData.antidocument    : false
const AntiContact = m.isGroup ? !!chatsData.anticontact     : false
const AntiLocation = m.isGroup ? !!chatsData.antilocation    : false
const AntiPoll = m.isGroup ? !!chatsData.antipoll        : false
const AntiViewOnce = m.isGroup ? !!chatsData.antiviewonce    : false
const AntiLinkGC = m.isGroup ? !!chatsData.antilinkgc      : false
const AntiLinkKick = m.isGroup ? !!chatsData.antilinkkick    : false
const AntiPromotion = m.isGroup ? !!chatsData.antipromotion   : false

function saveChat(key, val) {
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  global.db.data.chats[m.chat][key] = val
  saveDB(global.db.data)
}

const antiMap = {
antivirus: {
list: ntvirtex,
db: './AliceSystem/AliceDatabase/Antilink/antivirus.json',
status: AntiVirtex,
msg: 'Tidak ada yang diperbolehkan mengirim virus di grup ini, yang mengirim akan langsung ditendang!'
},

antilinkyoutubevideo: {
list: ntilinkytvid,
db: './AliceSystem/AliceDatabase/Antilink/antilinkytvideo.json',
status: AntiLinkYoutubeVid,
msg: 'Jangan kirim link video YouTube di grup ini atau kamu akan ditendang!'
},

antilinkyoutubechannel: {
list: ntilinkytch,
db: './AliceSystem/AliceDatabase/Antilink/antilinkytchannel.json',
status: AntiLinkYoutubeChannel,
msg: 'Jangan kirim link channel YouTube di grup ini atau kamu akan ditendang!'
},

antilinkinstagram: {
list: ntilinkig,
db: './AliceSystem/AliceDatabase/Antilink/antilinkinstagram.json',
status: AntiLinkInstagram,
msg: 'Jangan kirim link Instagram di grup ini atau kamu akan ditendang!'
},

antilinkfacebook: {
list: ntilinkfb,
db: './AliceSystem/AliceDatabase/Antilink/antilinkfacebook.json',
status: AntiLinkFacebook,
msg: 'Jangan kirim link Facebook di grup ini atau kamu akan ditendang!'
},

antilinktelegram: {
list: ntilinktg,
db: './AliceSystem/AliceDatabase/Antilink/antilinktelegram.json',
status: AntiLinkTelegram,
msg: 'Jangan kirim link Telegram di grup ini atau kamu akan ditendang!'
},

antilinktiktok: {
list: ntilinktt,
db: './AliceSystem/AliceDatabase/Antilink/antilinktiktok.json',
status: AntiLinkTiktok,
msg: 'Jangan kirim link TikTok di grup ini atau kamu akan ditendang!'
},

antilinktwitter: {
list: ntilinktwt,
db: './AliceSystem/AliceDatabase/Antilink/antilinktwitter.json',
status: AntiLinkTwitter,
msg: 'Jangan kirim link Twitter di grup ini atau kamu akan ditendang!'
},

antilinkbokep: {
list: ntilinkdewasa,
db: './AliceSystem/AliceDatabase/Antilink/antilinkbokep.json',
status: AntiDewasa,
msg: 'Jangan kirim link dewasa di grup ini atau kamu akan ditendang!'
},

antilinkterabox: {
list: ntilinkterabox,
db: './AliceSystem/AliceDatabase/Antilink/antilinkterabox.json',
status: AntiTerabox,
msg: 'Jangan kirim link Terabox di grup ini atau kamu akan ditendang!'
},

antilinkmediafire: {
list: ntilinkmediafire,
db: './AliceSystem/AliceDatabase/Antilink/antilinkmediafire.json',
status: AntiMediafire,
msg: 'Jangan kirim link Mediafire di grup ini atau kamu akan ditendang!'
},

antitoxic: {
list: nttoxic,
db: './AliceSystem/AliceDatabase/Antilink/antitoxic.json',
status: AntiToxic,
msg: 'Tidak boleh toxic di grup ini, yang melanggar akan ditendang!'
},

antiwame: {
list: ntwame,
db: './AliceSystem/AliceDatabase/Antilink/antiwame.json',
status: AntiWame,
msg: 'Tidak boleh kirim wame di grup ini, yang melanggar akan ditendang!'
},

antiasing: {
list: ntasing,
db: './AliceSystem/AliceDatabase/Antilink/antiasing.json',
status: AntiAsing
},
antibot: {
  dbKey: 'antibot',
  status: AntiBot,
  msg: 'Mode Anti Bot aktif! Bot lain yang masuk akan langsung ditendang!'
},
anticall: {
  dbKey: 'anticall',
  status: AntiCall,
  msg: 'Mode Anti Panggilan aktif! Yang melakukan panggilan akan ditendang!'
},
antitagsw: {
  dbKey: 'antitagsw',
  status: AntiTagSw,
  msg: 'Mode Anti Tag Status WA aktif! Yang mengirim tag SW akan ditendang!'
},
antispam: {
  dbKey: 'antispam',
  status: AntiSpam,
  msg: 'Mode Anti Spam aktif! Yang spam pesan akan ditendang!'
},
antimedia: {
  dbKey: 'antimedia',
  status: AntiMedia,
  msg: 'Mode Anti Media aktif! Semua media dilarang di grup ini!'
},
antiimage: {
  dbKey: 'antiimage',
  status: AntiImage,
  msg: 'Mode Anti Gambar aktif! Gambar dilarang di grup ini!'
},
antivideo: {
  dbKey: 'antivideo',
  status: AntiVideo,
  msg: 'Mode Anti Video aktif! Video dilarang di grup ini!'
},
antiaudio: {
  dbKey: 'antiaudio',
  status: AntiAudio,
  msg: 'Mode Anti Audio aktif! Audio/Voice note dilarang di grup ini!'
},
antisticker: {
  dbKey: 'antisticker',
  status: AntiSticker,
  msg: 'Mode Anti Stiker aktif! Stiker dilarang di grup ini!'
},
antidocument: {
  dbKey: 'antidocument',
  status: AntiDocument,
  msg: 'Mode Anti Dokumen aktif! Dokumen dilarang di grup ini!'
},
anticontact: {
  dbKey: 'anticontact',
  status: AntiContact,
  msg: 'Mode Anti Kontak aktif! Berbagi kontak dilarang di grup ini!'
},
antilocation: {
  dbKey: 'antilocation',
  status: AntiLocation,
  msg: 'Mode Anti Lokasi aktif! Berbagi lokasi dilarang di grup ini!'
},
antipoll: {
  dbKey: 'antipoll',
  status: AntiPoll,
  msg: 'Mode Anti Poll aktif! Membuat polling dilarang di grup ini!'
},
antiviewonce: {
  dbKey: 'antiviewonce',
  status: AntiViewOnce,
  msg: 'Mode Anti View Once aktif! Pesan sekali lihat dilarang di grup ini!'
},
antilinkgc: {
  dbKey: 'antilinkgc',
  status: AntiLinkGC,
  msg: 'Mode Anti Link Grup aktif! Link undangan grup dilarang!'
},
antilinkkick: {
  dbKey: 'antilinkkick',
  status: AntiLinkKick,
  msg: 'Mode Anti Link Kick aktif! Yang kirim link akan langsung ditendang!'
},
antipromotion: {
  dbKey: 'antipromotion',
  status: AntiPromotion,
  msg: 'Mode Anti Promosi aktif! Promosi dilarang di grup ini!'
}
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// SET OWNER,PREM,DLL DISINI!!!
//————————————————————————//
const senderr = m.key.fromMe
? Alice.user.id.split(":")[0] || Alice.user.id
: m.key.participant || m.key.remoteJid;
const senderNumber = senderr.split('@')[0];
const botNumber = Alice.user.id
const isReplyToBotMsg = m.message?.extendedTextMessage?.contextInfo?.participant === botNumber
if (m.key.fromMe && !isReplyToBotMsg) return
const owner = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/owner.json'))
const premium = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/premium.json'))
const args = (body || '').trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const isOwner = [botNumber, ...owner, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) //Set text owner
//————————————————————————//
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// SET PREFIX BISA DI ATUR DISINI JUGA
//————————————————————————//
const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/;
		if (Object.keys(db.data.settings).includes(botNumber) && Object.keys(db.data.settings[botNumber]).includes("setPrefix") && db.data.settings[botNumber].setPrefix == "one") {
			var thePrefix = "𝐌𝐔𝐋𝐓𝐈"
			var prefix = body.startsWith("#") ? "#" : body.startsWith("!") ? "!" : body.startsWith("/") ? "/" : body.startsWith("?") ? "?" : "."
			var isCmd = body.startsWith(prefix)
			var command = isCmd ? body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase() : ""
		} else if (Object.keys(db.data.settings).includes(botNumber) && Object.keys(db.data.settings[botNumber]).includes("setPrefix") && db.data.settings[botNumber].setPrefix == "no") {
			var thePrefix = "𝐍𝐎"
			var prefix = ""
			var isCmd = body.startsWith(prefix)
			var command = body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase()
		} else if (Object.keys(db.data.settings).includes(botNumber) && Object.keys(db.data.settings[botNumber]).includes("setPrefix") && db.data.settings[botNumber].setPrefix == "all") {
			var thePrefix = "𝐀𝐋𝐋"
			var prefix = body.startsWith("#") ? "#" : body.startsWith("!") ? "!" : body.startsWith("/") ? "/" : body.startsWith("?") ? "?" : "."
			var isCmd = body.startsWith(prefix)
			var command = body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase()
		} else {
			var thePrefix = "𝐌𝐔𝐋𝐓𝐈"
			var prefix = body.startsWith("#") ? "#" : body.startsWith("!") ? "!" : body.startsWith("/") ? "/" : body.startsWith("?") ? "?" : "."
			var isCmd = body.startsWith(prefix)
			var command = isCmd ? body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase() : ""
		}
//————————————————————————//
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
let mek = m;
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const mentionByreply = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const isImage = /image/.test(mime);
const isVideo = /video/.test(mime);
const isSticker = /sticker/.test(mime);
const isAudio = /audio/.test(mime);
const from = mek.key.remoteJid
const groupMetadata = m?.isGroup ? await Alice.groupMetadata(m.chat).catch(() => ({})) : {};
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const participants = m?.isGroup ? groupMetadata.participants?.map(p => {
let admin = null;
if (p.admin === 'superadmin') admin = 'superadmin';
if (p.admin === 'admin') admin = 'admin';
return {
jid: p.jid || null,
lid: p.id || null,
admin
};
}) || [] : [];

const groupOwner = m?.isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
const groupAdmins = participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .map(p => p.jid);

const isBotAdmins = m?.isGroup ? groupAdmins.includes(`${AliceBot}@s.whatsapp.net`) : false;
const isAdmins = m?.isGroup ? groupAdmins.includes(m.sender) : false;
const isGroupOwner = m?.isGroup ? groupOwner === m.sender : false;
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const isMute= mute.includes(m.chat) ? true : false
const isAfkOn = afk.checkAfkUser(m.chat, m.sender, _afk)
const isXMEDIA = m.mtype
const isBot = botNumber.includes(senderNumber)
const isPrivate = !m.key.remoteJid.includes('@g.us');
const qmsg = (quoted.msg || quoted)
const more = String.fromCharCode(8206)
const isPc = from.endsWith('@s.whatsapp.net')
const readmore = more.repeat(4001)
const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])] 
const isPrem = isOwner || checkPremiumUser(m.sender, premium);
const isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
 
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')  

if(time2 < "00:00:00"){
var stime = Styles(`Selamat Tengah Malam 👋🏻`)
 }
 if(time2 < "19:00:00"){
var stime = Styles(`Selamat Malam 👋🏻`)
 }
 if(time2 < "16:00:00"){
var stime = Styles(`Selamat Sore 👋🏻`)
 }
 if(time2 < "11:00:00"){
var stime = Styles(`Selamat Siang 👋🏻`)
 }
 if(time2 < "06:00:00"){
var stime = Styles(`Selamat Pagi 👋🏻`)
 }
 
const timee = moment().tz('Asia/Jakarta').format("HH:mm:ss");
const timestamp = moment().tz("Asia/Jakarta").valueOf();
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const tanggal2 = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const TypeMess = getContentType(m?.message);
let reactions = TypeMess == "reactionMessage" ? m?.message[TypeMess]?.text : false;
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// reply stc

if (m.mtype === 'stickerMessage') {

  let stickerId =
    m.msg?.fileSha256 ||
    m.message?.stickerMessage?.fileSha256

  if (stickerId) {
    stickerId = stickerId.toString('base64')

    if (setcmdDB[stickerId]) {

      const fakeCommand = setcmdDB[stickerId]

      body = prefix + fakeCommand
      command = fakeCommand
      isCmd = true

    }
  }
}

//📈————————————————————————— [ © XyrooRynzz ] —————————————————————————📉
async function uploadToAliceCdn(buffer, fileName) {
  const axios = require('axios')
  const FormData = require('form-data')

  if (!Buffer.isBuffer(buffer)) {
    throw new Error('File bukan buffer')
  }

  const form = new FormData()
  form.append('cdnFile', buffer, {
    filename: fileName,
    contentType: 'application/octet-stream'
  })

  try {
    const res = await axios.post(
      'https://aliceecdn.vercel.app/upload',
      form,
      {
        headers: {
          ...form.getHeaders(),
          'Content-Length': form.getLengthSync()
        }
      }
    )

    if (res.data?.url) return res.data.url
    throw new Error('Upload gagal: ' + JSON.stringify(res.data))

  } catch (err) {
    throw new Error(
      `Upload error: ${err.response?.data?.message || err.message}`
    )
  }
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

// monitor error
const errorPath = './AliceDatabase/system-db/error.json'

if (!fs.existsSync(errorPath)) {
    fs.writeFileSync(errorPath, JSON.stringify({}))
}

let errorDB = JSON.parse(fs.readFileSync(errorPath))

function saveErrorDB() {
    fs.writeFileSync(errorPath, JSON.stringify(errorDB, null, 2))
}

function addErrorToDB(cmd, err) {
    const commandName = cmd || "unknown"

    if (!errorDB[commandName]) {
        errorDB[commandName] = {
            total: 0,
            lastError: "",
            lastStack: "",
            lastTime: 0
        }
    }

    errorDB[commandName].total += 1
    errorDB[commandName].lastError = err.message || String(err)
    errorDB[commandName].lastStack = err.stack || "No stack"
    errorDB[commandName].lastTime = Date.now()

    saveErrorDB()
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Response

const { getRespon, addRespon, delRespon, listRespon, mediaDir } = require('./AliceSystem/AliceDatabase/Response/respon')

let bodyText = (m.text || '').toLowerCase().trim()
let cek = getRespon(bodyText)

if (cek && !isCmd) {

    const user = ensureUser(m.sender)

    // blok kalo belum register
    if (global.db.data.settings.register && !user.registered) return

    if (cek.type === 'text') {
        await reply(cek.content)
    }

    else if (cek.type === 'image') {
        await Alice.sendMessage(m.chat, {
            image: Buffer.from(cek.content, 'base64')
        }, { quoted: m })
    }

    else if (cek.type === 'video') {
        await Alice.sendMessage(m.chat, {
            video: Buffer.from(cek.content, 'base64')
        }, { quoted: m })
    }

    else if (cek.type === 'audio') {
        await Alice.sendMessage(m.chat, {
            audio: Buffer.from(cek.content, 'base64'),
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: m })
    }

    else if (cek.type === 'sticker') {
        await Alice.sendMessage(m.chat, {
            sticker: Buffer.from(cek.content, 'base64')
        }, { quoted: m })
    }

    return
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// warning
const warnPath = path.join(__dirname, 'AliceDatabase', 'warn.json');
if (!fs.existsSync(warnPath)) fs.writeFileSync(warnPath, JSON.stringify({}));

const warnData = JSON.parse(fs.readFileSync(warnPath, 'utf-8'));

function saveWarnData() {
  fs.writeFileSync(warnPath, JSON.stringify(warnData, null, 2));
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
let onlyadmin = []
try {
  onlyadmin = JSON.parse(fs.readFileSync('./AliceDatabase/group-db/onlyadmin.json'))
} catch {
  onlyadmin = []
}

if (!isCmd && !budy) return

if (m.isGroup && onlyadmin.includes(m.chat) && !isAdmins && !isOwner) {
  return
}

function ensureUser(id) {
  if (!global.db.data.users[id]) {
    global.db.data.users[id] = {
      registered: false,
      name: '',
      age: 0
    }
  }
  return global.db.data.users[id]
}

const allowed = ['register', 'unregister']

const skipCheck =
  isOwner ||
  isPrem ||
  isAdmins ||
  !m.isGroup

if (!skipCheck && global.db.data.settings.register && isCmd) {
  const user = ensureUser(m.sender)

  if (!user.registered && !allowed.includes(command)) {
    return reply('⚠️ kamu harus register dulu!\ngunakan: .register nama,umur')
  }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// get skrep
const Xscraper = `AliceSystem/AliceScraper/alice-${text}.js`
const listScraper = fs.readdirSync('./AliceSystem/AliceScraper').map((v, index) => `> ${index + 1}. ${v}`).join('\n')
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Getpp user
const cap = 'Alice'
try {
pplu = await Alice.profilePictureUrl(anu.id, 'image')
} catch {
pplu = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

const x = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `$${ownername}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${ownername},;;;\nFN: ${botname} v3.0\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': pplu,
                    thumbnail: pplu,
                    sendEphemeral: true
                }   
            }
        }
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// functions sendbuttonmenu alice
async function sendBatenAlice(m, Alice, text) {

let sections = [
{
title: "🔥 Special",
highlight_label: "",
rows: [
{ title: "📑 Menu All", description: "Lihat semua fitur lengkap", id: `${prefix}menuall` }
]
},
{
title: "🤖 AI & RPG",
highlight_label: "",
rows: [
{ title: "🤖 Menu AI", description: "Gunakan fitur kecerdasan buatan", id: `${prefix}menuai` },
{ title: "⚔️ Menu RPG", description: "Mainkan game roleplay RPG", id: `${prefix}menurpg` }
]
},
{
title: "🎮 Hiburan",
highlight_label: "",
rows: [
{ title: "🎮 Menu Game", description: "Fitur hiburan & mini game", id: `${prefix}menugame` },
{ title: "🎲 Menu Random", description: "Konten acak & hiburan", id: `${prefix}menurandom` },
{ title: "🎵 Menu Audio", description: "Fitur musik & audio", id: `${prefix}menuaudio` }
]
},
{
title: "🛠️ Tools & Utils",
highlight_label: "",
rows: [
{ title: "🛠️ Menu Tools", description: "Kumpulan peralatan", id: `${prefix}menutools` },
{ title: "🔄 Menu Convert", description: "Ubah format file", id: `${prefix}menuconvert` },
{ title: "🖼️ Menu Ephoto", description: "Edit foto", id: `${prefix}menuephoto` },
{ title: "🔎 Menu Search", description: "Cari informasi", id: `${prefix}menusearch` },
{ title: "📥 Menu Downloader", description: "Download media", id: `${prefix}menudownloader` }
]
},
{
title: "🎨 Canvas",
highlight_label: "",
rows: [
{ title: "🎨 Menu Canvas", description: "Fitur gambar & canvas", id: `${prefix}menucanvas` }
]
},
{
title: "👥 Group & Owner",
highlight_label: "",
rows: [
{ title: "👥 Menu Group", description: "Kelola grup", id: `${prefix}menugroup` },
{ title: "👑 Menu Owner", description: "Owner bot", id: `${prefix}menuowner` },
{ title: "🖥️ Menu Cpanel", description: "Control panel", id: `${prefix}menucpanel` }
]
},
{
title: "🏪 Store & Premium",
highlight_label: "",
rows: [
{ title: "🏪 Menu Store", description: "Jual beli", id: `${prefix}menustore` },
{ title: "💎 Menu Premium", description: "User premium", id: `${prefix}menupremium` }
]
},
{
title: "☪️ Islami & Ramalan",
highlight_label: "",
rows: [
{ title: "☪️ Menu Islami", description: "Fitur islami", id: `${prefix}menuislami` },
{ title: "📜 Menu Primbon", description: "Ramalan primbon", id: `${prefix}menuprimbon` }
]
},
{
title: "📰 Informasi",
highlight_label: "",
rows: [
{ title: "📰 Menu Berita", description: "Berita terbaru", id: `${prefix}menuberita` },
{ title: "📲 Menu Push", description: "Push kontak", id: `${prefix}menupush` },
{ title: "🎯 Menu Main", description: "Menu utama", id: `${prefix}menumain` }
]
},
{
title: "🍥 Anime & Manga",
highlight_label: "",
rows: [
{ title: "🍥 Menu Anime", description: "Anime & manga", id: `${prefix}menuanime` },
{ title: "🙈 Menu Anonymous", description: "Chat anonim", id: `${prefix}menuanonymous` }
]
},
{
title: "🕵️ Stalker",
highlight_label: "",
rows: [
{ title: "🕵️ Menu Stalker", description: "Cek info akun / target", id: `${prefix}menustalker` }
]
}
]

// cek type menu
let menuType = "list"
try {
let db = JSON.parse(fs.readFileSync("./AliceDatabase/system-db/setmenu.json"))
menuType = db.menu
} catch {
menuType = "list"
}

let buttons = []

// list
if (menuType == 1) {

buttons.push({
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "List Menu",
sections: sections
})
})

await Alice.sendMessage(m.chat, {
interactiveMessage: {
title: text,
footer: "-X Alice Assistant - 2026",
thumbnail: thumb,
nativeFlowMessage: {
buttons: buttons
}
}
}, { quoted: K })

}

// cta
else if (menuType == 2) {

buttons.push({
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "Channel WhatsApp",
url: channel
})
})

await Alice.sendMessage(m.chat, {
interactiveMessage: {
title: text,
footer: "-X Alice Assistant - 2026",
thumbnail: thumb,
nativeFlowMessage: {
buttons: buttons
}
}
}, { quoted: K })

}

// mix
else if (menuType == 3) {

buttons.push({
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "List Menu",
sections: sections
})
})

buttons.push({
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "Channel WhatsApp",
url: channel
})
})

await Alice.sendMessage(m.chat, {
interactiveMessage: {
title: text,
footer: "-X Alice Assistant - 2026",
thumbnail: thumb,
nativeFlowMessage: {
buttons: buttons
}
}
}, { quoted: K })

}

// media
else if (menuType == 4) {

const btns = [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "List Menu",
sections: sections
})
}
]

Alice.sendIAMessage(m.chat, btns, m, {
hydrated: true,
header: "",
content: text,
footer: "",
media: fs.readFileSync("./AliceMedia/image/Alice.jpg")
})

}

// full
else if (menuType == 5) {

const btns = [

{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "List Menu",
sections: sections
})
},

{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "Channel WhatsApp",
url: channel
})
},

{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "Owner Contact",
copy_code: "https://t.me/whiterascalls"
})
}

]

Alice.sendIAMessage(m.chat, btns, m, {
hydrated: true,
header: "",
content: text,
footer: "-X Alice Assistant - 2026",
media: fs.readFileSync("./AliceMedia/image/Alice.jpg")
})

}

}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const replymessage = require('./AliceLibray/replynya')
replymessage(Alice, m, XR, Styles)

// footer
const nwreply = (anu) => {
  const { message, key } = generateWAMessageFromContent(m.chat, {
    interactiveMessage: {
      body: { text: anu },
      footer: { text: `${packname}` },
      nativeFlowMessage: {
        buttons: [{ text: "2026" }],
      }
    },
  }, {
    quoted: {
      key: {
        participant: '0@s.whatsapp.net',
        remoteJid: "0@s.whatsapp.net"
      },
      message: { conversation: `${prefix + command}` }
    }
  })
  Alice.relayMessage(m.chat, { viewOnceMessage: { message } }, { messageId: key.id })
}

// simple
const replyk = async (teks) => {
  return Alice.sendMessage(m.chat, {
    text: teks,
    mentions: await ments(teks)
  }, { quoted: m })
}

// default
const replyx = async (teks) => {
  return Alice.sendMessage(m.chat, {
    text: teks
  }, { quoted: fkontak })
}

// forwarded
async function alicereply(teks) {
  const nedd = {
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterName: botname,
        newsletterJid: '',
      },
      externalAdReply: {
        showAdAttribution: true,
        title: `${hariini}`,
        body: `${packname}`,
        previewType: "IMAGE",
        thumbnailUrl: thumbnailReply,
        sourceUrl: global.sosialmedia.telegram,
      },
    },
    text: teks,
  }
  return Alice.sendMessage(m.chat, nedd, { quoted: XR })
}

// businnes
const replybusinnes = async (teks, mentions = [m.sender]) => {
  return Alice.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      mentionedJid: mentions,
      isForwarded: true,
      forwardingScore: 9999,
      businessMessageForwardInfo: {
        businessOwnerJid: global.owner[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
      },
      externalAdReply: {
        title: `- ${botname}`,
        body: `ׅ${author}`,
        thumbnailUrl: thumb,
        sourceUrl: sosialmedia.telegram,
        mediaType: 1
      }
    }
  }, { quoted: K })
}

async function reply(text) {
  try {
    if (text && typeof text === "string") {
      const t = text.toLowerCase()

      const errorKeywords = [
        "gagal",
        "error",
        "tidak ditemukan",
        "failed",
        "tidak dapat",
        "tidak bisa"
      ]

      if (errorKeywords.some(k => t.includes(k))) {
        const cmdName = typeof command !== "undefined" ? command : "unknown"
        addErrorToDB(cmdName, new Error(text))
      }
    }
  } catch (e) {
    console.log("Auto Error Detect Failed:", e)
  }

  let mode = getMode()

  // 1: default
  if (mode === 1) {
    return replyx(text)
  }

  // 2: interactive
  if (mode === 2) {
    return nwreply(text)
  }

  // 3: forwarded
  if (mode === 3) {
    return alicereply(text)
  }

  // 4: simple
  if (mode === 4) {
    return replyk(text)
  }

  // 5: businnes
  if (mode === 5) {
    return replybusinnes(text)
  }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// banned/blacklist

const bannedPath = './AliceDatabase/users-db/banned.json'

if (!fs.existsSync(bannedPath)) {
  fs.writeFileSync(bannedPath, JSON.stringify({}))
}

let bannedUsers = JSON.parse(fs.readFileSync(bannedPath))

function saveBanned() {
  fs.writeFileSync(bannedPath, JSON.stringify(bannedUsers, null, 2))
}

function isUserBanned(jid) {
  if (!bannedUsers[jid]) return false

  let data = bannedUsers[jid]
  if (data.permanent) return true
  if (Date.now() < data.expired) {
    return true
  } else {
    delete bannedUsers[jid]
    saveBanned()
    return false
  }
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// autoai
const autoAI = require('./AliceSystem/AliceDatabase/Autoai/autoai')

autoAI.autoAIReply(Alice, m, (t) => reply(t))
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const getAllCases = () => {
  var mytext = fs.readFileSync("./Alice.js").toString();
  var regex = /case\s+'(.*?)'/g;
  var cases = [];
  var match;
  while ((match = regex.exec(mytext)) !== null) {
      cases.push(match[1]);
  }
  return cases;
};

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Top Cmd
const topcmd = './AliceDatabase/system-db/AliceTop.json';

// cek dan load db
if (!fs.existsSync(topcmd)) {
    fs.writeFileSync(topcmd, JSON.stringify({}));
}
try {
    global.topcmd = JSON.parse(fs.readFileSync(topcmd));
} catch (err) {
    console.log("Database Rusak Atau Kosong! Reset Ulang");
    global.topcmd = {};
    fs.writeFileSync(topcmd, JSON.stringify(global.topcmd, null, 2));
}

// simpan data cmd
const saveTopCmd = () => {
  fs.writeFileSync(topcmd, JSON.stringify(global.topcmd, null, 2));
}; 

// top cmd list
const allCases = getAllCases();
if (allCases.includes(command)) {
    if (!global.topcmd[command]) {
        global.topcmd[command] = 1;
    } else {
        global.topcmd[command] += 1;
    }
    saveTopCmd();
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// susunkata
if (global.susunKata && global.susunKata[m.sender]) {
  const sesi = global.susunKata[m.sender];
  const jawabanBenar = sesi.jawaban;

  // kalau user kirim ".nyerah"
  if (body?.toLowerCase() === '.nyerah' || text?.toLowerCase() === '.nyerah') {
    delete global.susunKata[m.sender];
    return reply(
`😢 Kamu menyerah...

✅ Jawaban yang benar: *${jawabanBenar}*

Ketik *.susunkata* lagi untuk main lagi.`
    );
  }

  //ga respon kalau prefix
  if (body?.startsWith('.') || text?.startsWith('.')) {
  } else {
    const teksUser = (body || text || '').trim().toLowerCase();

    if (!teksUser) {
    } else if (teksUser === jawabanBenar.toLowerCase()) {
      delete global.susunKata[m.sender];
      return reply(
`🎉 *BENAR!*

Jawaban: *${jawabanBenar}* ✅

Ketik *.susunkata* lagi kalau mau main lagi.`
      );
    } else {
      return reply('❌ Masih salah kak, coba lagi ya...');
    }
  }
}

// asahotak
// CEK JAWABAN ASAH OTAK
if (global.asahOtak && global.asahOtak[m.sender]) {
  const sesi = global.asahOtak[m.sender];
  const teks = (text || '').trim().toLowerCase();

  // USER MENYERAH
  if (teks === '.nyerah') {
    delete global.asahOtak[m.sender];

    return reply(
`😢 Kamu menyerah...

🧠 Jawaban benar: *${sesi.jawaban}*

Ketik *.asahotak* untuk main lagi.`
    );
  }

  if (teks.startsWith('.')) return;

  // JAWABAN BENAR
  if (teks === sesi.jawaban) {
    delete global.asahOtak[m.sender];
    return reply(
`🎉 *BENAR!*  
Jawabannya: *${sesi.jawaban.toUpperCase()}* 🔥

Ketik *.asahotak* untuk bermain lagi.`
    );
  }

  // JAWABAN SALAH
  return reply("❌ Masih salah kak, coba lagi!");
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Catur
const caturData = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Game/catur.json'))
const caturPath = './AliceSystem/AliceDatabase/Game/catur.json'
const caturSkorPath = './AliceSystem/AliceDatabase/Game/caturSkor.json'
const dbCatur = JSON.parse(fs.readFileSync(caturPath))
const dbSkor = JSON.parse(fs.readFileSync(caturSkorPath))
function saveCatur() {
  fs.writeFileSync('./AliceSystem/AliceDatabase/Game/catur.json', JSON.stringify(caturData, null, 2))
}

function papanAwal() {
  return [
    ['♜','♞','♝','♛','♚','♝','♞','♜'],
    ['♟','♟','♟','♟','♟','♟','♟','♟'],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['♙','♙','♙','♙','♙','♙','♙','♙'],
    ['♖','♘','♗','♕','♔','♗','♘','♖']
  ]
}

function tampilkanPapan(board) {
  let str = ''
  for (let row = 0; row < 8; row++) {
    str += (8 - row) + ' '
    for (let col = 0; col < 8; col++) {
      str += board[row][col] || '⬛'
    }
    str += '\n'
  }
  str += '  A B C D E F G H'
  return str
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//RESET / KUDET PANEL 
let passwordaseli = '';

const generateRandomPassword = () => {
    passwordaseli = `${ownername}` + Math.random().toString(36).substring(7);
};

const PermenReset = async (apiKey, panelUrl, userIdToKeep) => {
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'Application/vnd.pterodactyl.v1+json',
        'Authorization': `Bearer ${apiKey}`
    };

    const fetchJson = async (url, options = {}) => {
        console.log(`Fetching URL: ${url}`);
        const response = await fetch(url, { headers, ...options });
        const text = await response.text();

        if (!response.ok) {
            if (response.status === 401) {
                throw new Error("\`Plta\` Nya \`Invalid\` Gblok");
            } else if (response.status === 403) {
                throw new Error("\`Plta\` Nya \`Gak Full Mid\` Ini Anjeng");
            } else if (response.status === 502) {
                throw new Error("Panel Mu \`Kena DDoS\` Kang Gabisa Di Akses Nih");
            }
        }

        try {
            return JSON.parse(text);
        } catch (error) {
            console.error(`Failed to parse JSON response from ${url}: ${text}`);
        }
    };

    const getAllItems = async (endpoint) => {
        const data = await fetchJson(`${panelUrl}/api/application/${endpoint}`);
        return data?.data || [];
    };

    const deleteServer = async (serverId) => {
        await fetchJson(`${panelUrl}/api/application/servers/${serverId}`, { method: 'DELETE' });
        console.log(`Deleted server ID: ${serverId}`);
    };

    const deleteUser = async (userId) => {
        await fetchJson(`${panelUrl}/api/application/users/${userId}`, { method: 'DELETE' });
        console.log(`Deleted user ID: ${userId}`);
    };

    const createAdminUser = async () => {
        const newUser = {
            username: `${ownername}`,
            email: 'xyro@reset.com',
            first_name: `${ownername}`,
            last_name: `${ownername}`,
            password: passwordaseli,
            root_admin: true,
            language: 'en'
        };
        return fetchJson(`${panelUrl}/api/application/users`, {
            method: 'POST',
            body: JSON.stringify(newUser)
        });
    };

    const servers = await getAllItems('servers');
    servers.forEach(async (server) => {
        if (server.attributes.user_id !== parseInt(userIdToKeep)) {
            await deleteServer(server.attributes.id);
        }
    });

    const users = await getAllItems('users');
    users.forEach(async (user) => {
        if (user.attributes.id !== parseInt(userIdToKeep)) {
            await deleteUser(user.attributes.id);
        }
    });

    const newAdminUser = await createAdminUser();
    return `Deleted all servers and users. Created new admin user: ${newAdminUser.attributes.username}, ID: ${newAdminUser.attributes.id}`;
};

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// FUNCTION ↓↓
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\		

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

    async function ephoto(url, texk) {
      let form = new FormData();
      let gT = await axios.get(url, {
        headers: {
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
        }
      });
      let $ = cheerio.load(gT.data);
      let text = texk;
      let token = $("input[name=token]").val();
      let build_server = $("input[name=build_server]").val();
      let build_server_id = $("input[name=build_server_id]").val();
      form.append("text[]", text);
      form.append("token", token);
      form.append("build_server", build_server);
      form.append("build_server_id", build_server_id);
      let res = await axios({
        url: url,
        method: "POST",
        data: form,
        headers: {
          Accept: "*/*",
          "Accept-Language": "en-US,en;q=0.9",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
          cookie: gT.headers["set-cookie"]?.join("; "),
          ...form.getHeaders()
        }
      });
      let $$ = cheerio.load(res.data);
      let json = JSON.parse($$("input[name=form_value_input]").val());
      json["text[]"] = json.text;
      delete json.text;
      let {
        data
      } = await axios.post("https://en.ephoto360.com/effect/create-image", new URLSearchParams(json), {
        headers: {
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
          cookie: gT.headers["set-cookie"].join("; ")
        }
      });
      return build_server + data.image;
    }
    
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\		

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Function Reaction 
const reaction = async (jidss, emoji) => {
    Alice.sendMessage(jidss, {
        react: { text: emoji,
                key: m.key 
               } 
            }
        );
    };

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function XReaction() {
    await Alice.sendMessage(m.chat, { react: { text: alicewait, key: m.key } });
    await delay(100)
    await Alice.sendMessage(m.chat, { react: { text: alicedone, key: m.key } });
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Function Send Music
async function sendMusic(teks) {
    let img = { url : thumb, 
               type : "image/jpeg"
              }
          
    let url = `${channel}`
    let contextInfo = {
        externalAdreply: {    
            showAdAttribution: true,    
            title: ownername,      
            body: `${botname} -`,     
            description: 'Now Playing ....',   
            mediaType: 2,     
            thumbnailUrl: img.url,
            mediaUrl: url   
        }
    }
    
    Alice.sendMessage(m.chat, { 
        contextInfo,
        mimetype: 'audio/mp4',
        audio: teks
    }, { quoted: m })
 }


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[arr[i], arr[j]] = [arr[j], arr[i]]
    }
    return arr
}
//————————————————————————//
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
/* =================| GC SIDER |==================== */
const GcSiderUpdate = (userId, serverId) => {
    if (db_sider[serverId]) {
        const userIndex = db_sider[serverId].findIndex(user => user.user_id === userId);
        if (userIndex !== -1) {
           db_sider[serverId][userIndex].timestamp = timestamp;
        } else {
            db_sider[serverId].push({
                user_id: userId,
                tanggal: hariini,
                timestamp: timestamp
            });
        }
    } else {
        db_sider[serverId] = [{
            user_id: userId,
            tanggal: hariini,
            timestamp: timestamp
        }];
    }
    try {
        fs.writeFileSync("./AliceSystem/AliceDatabase/Group/sider.json", JSON.stringify(db_sider, null, 2));
    } catch (error) {
        console.error("Error writing to file:", error);
    }
};

//————————————————————————//
function handleFeatureToggle(feature, command) {
    if (!m.isGroup) return XRG();
    if (!isAdmins && !isOwner) return XRA();
    if (args.length < 1) return reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan');

    if (args[0] === 'on') {
        db.data.chats[from][feature] = true;
        return reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[from][feature] = false;
        return reply(`${command} is disabled`);
    }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(' ')
  let line = ''
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' '
    const metrics = ctx.measureText(testLine)
    const testWidth = metrics.width
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line, x, y)
      line = words[n] + ' '
      y += lineHeight
    } else {
      line = testLine
    }
  }
  ctx.fillText(line, x, y)
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// GET GROUP NAME
async function getGcName(groupID) {
try {
let data_name = await Alice.groupMetadata(groupID)
return data_name.subject
} catch (err) {
return '-'
}
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// ADD COUNT COMMAND
async function addCountCmd(nama, sender, _db) {
addCountCmdUser(nama, m.sender, _cmdUser)
var posi = null
Object.keys(_db).forEach((i) => {
if (_db[i].nama === nama) {
posi = i
}
})
if (posi === null) {
_db.push({nama: nama, count: 1})
fs.writeFileSync('./AliceDatabase/system-db/command.json',JSON.stringify(_db, null, 2));
} else {
_db[posi].count += 1
fs.writeFileSync('./AliceDatabase/system-db/command.json',JSON.stringify(_db, null, 2));
}
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Resize
const resize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// PickRandom
		function pickRandom(list) {
			return list[Math.floor(list.length * Math.random())]
		}
	
		
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Altag Khusus Owner ( Group )
//————————————————————————//

if (budy.includes("@altag")) {
    if(!isOwner) return
    if (m.isGroup) {
        if (isAdmins || isBotAdmins) {
            return Alice.sendMessage(m.chat, {
                text: body.replace(/@altag/i, '@' + m.chat),
                contextInfo: {
                    mentionedJid: (await Alice.groupMetadata(m.chat)).participants.map(v => v.id),
                    groupMentions: [{
                        groupSubject: "altag",
                        groupJid: m.chat
                    }]
                }
            })
        }
    }
    }

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Respon List
try {
  const msgText = (m.text || '').trim().toLowerCase()
  const found = findList(m.chat, msgText)

  if (found) {
    if (found.type === 'text') {
      reply(found.text)
    } else if (found.type === 'image') {
      await Alice.sendMessage(m.chat, { image: { url: found.url }, caption: found.text })
    } else if (found.type === 'video') {
      await Alice.sendMessage(m.chat, { video: { url: found.url }, caption: found.text })
    } else if (found.type === 'document') {
      await Alice.sendMessage(m.chat, { document: { url: found.url }, caption: found.text })
    }
  }
} catch (err) {
  console.error('❌ Error saat auto respon list:', err)
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Sett Group
let chats = global.db.data.chats[from]
if (typeof chats !== 'object') global.db.data.chats[from] = {}

if (chats) {
  if (!('antibot' in chats)) chats.antibot = false
  if (!('antiviewonce' in chats)) chats.antiviewonce = false
  if (!('antimedia' in chats)) chats.antimedia = false
  if (!('antiimage' in chats)) chats.antiimage = false
  if (!('antivideo' in chats)) chats.antivideo = false
  if (!('antiaudio' in chats)) chats.antiaudio = false
  if (!('antipoll' in chats)) chats.antipoll = false
  if (!('antisticker' in chats)) chats.antisticker = false
  if (!('anticontact' in chats)) chats.anticontact = false
  if (!('antilocation' in chats)) chats.antilocation = false
  if (!('antidocument' in chats)) chats.antidocument = false
  if (!('antilinkgc' in chats)) chats.antilinkgc = false
  if (!('antilinkkick' in chats)) chats.antilinkkick = false
  if (!('antipromotion' in chats)) chats.antipromotion = false
} else global.db.data.chats[from] = {
  antibot: false,
  antiviewonce: false,
  antimedia: false,
  antiimage: false,
  antivideo: false,
  antiaudio: false,
  antipoll: false,
  antisticker: false,
  anticontact: false,
  antilocation: false,
  antidocument: false,
  antilinkgc: false,
  antilinkkick: false,
  antipromotion: false
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Get Suprise
if(!('hadiah' in db.data.settings)) db.data.settings.hadiah = []
if(!('hadiahkadaluwarsa' in db.data.settings)) db.data.settings.hadiahkadaluwarsa = []
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const user = global.db.data.users[m.sender] 
const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}

    const qevent = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
'message': {
  "eventMessage": {
    "isCanceled": false,
    "name": budy || m.mtype,
    "description": "Pe",
    "location": {
      "degreesLatitude": 0,
      "degreesLongitude": 0,
      "name": "Apakajajanabs"
    },
    "joinLink": "https://call.whatsapp.com/video/hMwVijMQtUb0qBJL3lf0rv",
    "startTime": "1713724680"
  }
}
}                
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// setwelcome/left
// DB Path
const WELCOME_DB_PATH = path.join(__dirname, "AliceDatabase", "groupWelcome.json");
if (!fs.existsSync(WELCOME_DB_PATH)) {
  fs.mkdirSync(path.dirname(WELCOME_DB_PATH), { recursive: true });
  fs.writeFileSync(WELCOME_DB_PATH, JSON.stringify({}, null, 2));
}

// Media Path
const WELCOME_MEDIA_DIR = path.join(__dirname, "AliceDatabase", "welcomeMedia");
const LEFT_MEDIA_DIR = path.join(__dirname, "AliceDatabase", "leftMedia");
if (!fs.existsSync(WELCOME_MEDIA_DIR)) fs.mkdirSync(WELCOME_MEDIA_DIR, { recursive: true });
if (!fs.existsSync(LEFT_MEDIA_DIR)) fs.mkdirSync(LEFT_MEDIA_DIR, { recursive: true });

// Helper DB
const readWelcomeDB = () => {
  try {
    return JSON.parse(fs.readFileSync(WELCOME_DB_PATH));
  } catch {
    return {};
  }
};
const writeWelcomeDB = (data) => {
  fs.writeFileSync(WELCOME_DB_PATH, JSON.stringify(data, null, 2));
};

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Get Total Fitur
let totalfitur = () => {
    const fs = require("fs")
    const path = require("path")

    try {
        let mytext = fs.readFileSync("./Alice.js", "utf8")
        let numUpper = (mytext.match(/case\s+['"`]/g) || []).length

        let pluginDir = "./AlicePlugins"
        let pluginFiles = fs.readdirSync(pluginDir).filter(v => v.endsWith(".js"))

        let totalPluginCommands = 0

        for (let file of pluginFiles) {
            try {
                let filePath = path.join(pluginDir, file)
                let content = fs.readFileSync(filePath, "utf8")

                let handlerMatch = content.match(/handler\.command\s*=\s*\[(.*?)\]/s)

                if (handlerMatch) {
                    let commands = handlerMatch[1].match(/['"`]([^'"`]+)['"`]/g) || []
                    totalPluginCommands += commands.length
                } else {
                    let caseMatch = content.match(/case\s+['"`]/g) || []
                    totalPluginCommands += caseMatch.length
                }
            } catch (e) {}
        }

        return numUpper + totalPluginCommands

    } catch (err) {
        return 0
    }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Listcase                
//————————————————————————//        
const listCase = () => {
const code = fs.readFileSync("./Alice.js", "utf8")
var regex = /case\s+'([^']+)':/g;
var matches = [];
var match;
while ((match = regex.exec(code))) {
matches.push(match[1]);
} 
let teks = Styles(`*Total Case*: ${matches.length} \n\n`)
matches.forEach(function (x) {
   teks += "  ◦  " + x + "\n"
})
return teks
}

function runtime(seconds) {
    seconds = Number(seconds);

    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);

    // Kalau lebih dari 1 hari → tampilkan detail hari, jam, menit, detik
    if (d > 0) {
        const dDisplay = d > 0 ? d + "d " : "";
        const hDisplay = h > 0 ? h + "h " : "";
        const mDisplay = m > 0 ? m + "m " : "";
        const sDisplay = s > 0 ? s + "s" : "";
        return (dDisplay + hDisplay + mDisplay + sDisplay).trim();
    }

    // Kalau < 1 jam → tampilkan mm:ss
    if (h === 0) {
        return [m, s]
            .map(v => v < 10 ? "0" + v : v)
            .join(":");
    }

    // Kalau < 24 jam → tampilkan hh:mm:ss
    const totalHours = d * 24 + h;
    return [totalHours, m, s]
        .map(v => v < 10 ? "0" + v : v)
        .join(":");
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Sessions Auto Ai
const SESSION_FILE = "./AliceDatabase/tmp-db/ai_sessions.json";
 
let sessions = fs.existsSync(SESSION_FILE) ? JSON.parse(fs.readFileSync(SESSION_FILE)) : {};
 
function saveSession() {
    fs.writeFileSync(SESSION_FILE, JSON.stringify(sessions, null, 2));
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Uno Game
const unoDatabasePath = './AliceDatabase/games-db/uno_games.json';

function readUnoGameData() {
    if (fs.existsSync(unoDatabasePath)) {
        const data = fs.readFileSync(unoDatabasePath);
        return JSON.parse(data);
    }
    return {};
}

function writeUnoGameData(data) {
    fs.writeFileSync(unoDatabasePath, JSON.stringify(data, null, 2));
}

const gamesFilePath = './AliceDatabase/games-db/games.json';

function readGamesData() {
    if (!fs.existsSync(gamesFilePath)) {
        fs.writeFileSync(gamesFilePath, JSON.stringify({}));
    }
    const data = fs.readFileSync(gamesFilePath);
    return JSON.parse(data);
}

function writeGamesData(data) {
    fs.writeFileSync(gamesFilePath, JSON.stringify(data, null, 2));
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
if (isCmd && isLimitActive()) {

  const noLimitExtra = [
    'register',
    'unregister',
    'ceklimit',
    'limit',
    'limitdaily',
    'claim'
  ]

  const skipLimit =
    !m.isGroup ||
    noLimitCmd.includes(command) ||
    noLimitExtra.includes(command)

  let role = 'free'
  if (isOwner) role = 'owner'
  else if (isPrem) role = 'premium'

  let user = getUserLimit(m.sender)

  resetLimitIfNeeded(user, role)

  if (role === 'free' && user.limit < 1 && !skipLimit) {
    return reply(`❌ Limit kamu habis!

🎯 Role: Free
💡 Tunggu reset atau upgrade ke premium`)
  }

  if (role === 'free' && !skipLimit) {
    user.limit -= 1
    global.saveLimit()

    if (user.limit % 5 === 0 && user.limit !== 0) {
      reply(`📊 Sisa limit kamu: ${user.limit}`)
    }

    if (user.limit <= 5 && user.limit > 0) {
      reply(`⚠️ Limit kamu hampir habis!
📊 Sisa: ${user.limit}`)
    }

    if (user.limit === 0) {
      reply(`❌ Limit kamu sudah habis!

💡 Tunggu reset atau upgrade premium`)
    }
  }

}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Badwords ( Group )
//————————————————————————//
const badwords = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/badwords.json'))
const addbadwords = async (kata) => {
let badwords=JSON.parse(fs.readFileSync('./AliceDatabase/system-db/badwords.json'))
badwords.push(kata)
fs.writeFileSync('./AliceDatabase/system-db/badwords.json',JSON.stringify(badwords))
reply(`Kata kasar "${kata}" berhasil ditambahkan.`)
}

const deletebadwords = async (kata) => {
let badwords=JSON.parse(fs.readFileSync('./AliceDatabase/system-db/badwords.json'))
badwords=badwords.filter(word=>word!==kata)
fs.writeFileSync('./AliceDatabase/system-db/badwords.json',JSON.stringify(badwords))
reply(`Kata kasar "${kata}" berhasil dihapus.`)
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
const selfPath = './AliceDatabase/system-db/selfpublic.json'
let selfStatus = { public: true }

if (fs.existsSync(selfPath)) {
  try {
    selfStatus = JSON.parse(fs.readFileSync(selfPath, 'utf-8'))
  } catch {}
}

if (!selfStatus.public) {
  if (!isOwner) return
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
const premPath = './AliceDatabase/system-db/premium.json';
if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, '[]');

function loadPremium() {
  return JSON.parse(fs.readFileSync(premPath));
}

function savePremium(premium) {
  fs.writeFileSync(premPath, JSON.stringify(premium, null, 2));
}

function parseTime(text) {
  if (!text) return null;
  const match = text.match(/^(\d+)(s|m|h|d|w|mo|y)$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  const now = Math.floor(Date.now() / 1000);

  let seconds = 0;
  switch (unit) {
    case 's': seconds = value; break;
    case 'm': seconds = value * 60; break;
    case 'h': seconds = value * 3600; break;
    case 'd': seconds = value * 86400; break;
    case 'w': seconds = value * 604800; break;
    case 'mo': seconds = value * 2592000; break;
    case 'y': seconds = value * 31536000; break;
    default: return null;
  }

  return now + seconds;
}

// 🔔 Cek expired hanya dipanggil kalau ada perubahan
function cekExpiredPremium() {
  let premium = loadPremium();
  const now = Math.floor(Date.now() / 1000);
  const expiredUsers = premium.filter(u => u.expired !== 0 && u.expired < now);

  if (expiredUsers.length > 0) {
    // Hapus user yang expired dari database
    premium = premium.filter(u => u.expired === 0 || u.expired >= now);
    savePremium(premium);

    // Kirim notifikasi ke owner
    for (let ownerNum of global.owner) {
      const nomor = typeof ownerNum === 'object' ? ownerNum[0] : ownerNum;
      Alice.sendMessage(nomor + '@s.whatsapp.net', {
        text: `📢 Notifikasi Premium:\nTerdapat ${expiredUsers.length} user premium yang telah *expired*:\n\n` +
          expiredUsers.map(u => `• wa.me/${u.id}`).join('\n'),
      });
    }
  }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Afk
if (m.isGroup && !m.key.fromMe) {
    let rawMention = [
        ...(m.mentionedJid || []),
        ...(m.quoted ? [m.quoted.sender] : [])
    ]

    let mentionUser = [...new Set(rawMention)]

    for (let ment of mentionUser) {
        let realJid = ment

        if (ment.endsWith("@lid")) {
            let f = participants.find(p => p.lid === ment)
            if (f && f.jid) realJid = f.jid
        }

        if (afk.checkAfkUser(m.chat, realJid, _afk)) {
            let d = afk.getAfkData(m.chat, realJid, _afk)
            let t = msx(Date.now() - d.time)

            reply(
                `Jangan tag @${realJid.split('@')[0]}!\n` +
                `Dia sedang AFK\n\n` +
                `Alasan: ${d.reason}\n` +
                `Sejak: ${t.hours} jam, ${t.minutes} menit, ${t.seconds} detik yang lalu`
            )
        }
    }
}

if (body && afk.checkAfkUser(m.chat, m.sender, _afk)) {
    let d = afk.getAfkData(m.chat, m.sender, _afk)
    let t = msx(Date.now() - d.time)

    afk.removeAfkUser(m.chat, m.sender, _afk)

    Alice.sendTextWithMentions(
      m.chat,
      `@${m.sender.split('@')[0]} telah kembali dari AFK\n\n` +
      `Alasan: ${d.reason}\n` +
      `Selama: ${t.hours} jam, ${t.minutes} menit, ${t.seconds} detik`,
      xy
    )
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Console Log Message
let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];

if (m.message) {
Alice.sendPresenceUpdate('available', m.chat)

const sender = m.sender.split("@")[0]
let b = body || ""
let type = m.mtype || Object.keys(m.message)[0]

// detect message type
if (type === "imageMessage") b = "📷 Image"
else if (type === "videoMessage") b = "🎥 Video"
else if (type === "stickerMessage") b = "🧩 Sticker"
else if (type === "audioMessage") b = "🎧 Audio"
else if (type === "documentMessage") b = "📄 Document"
else if (type === "pollCreationMessage") b = "📊 Poll"
else if (type === "reactionMessage") b = "❤️ Reaction"
else if (type === "viewOnceMessage") b = "👁️ View Once"

console.log(
`\x1b[1;31m~\x1b[1;37m> [\x1b[1;32m ▧ ᴍᴇssᴀɢᴇ ʟᴏɢ \x1b[1;37m]
│ » ᴛɪᴍᴇ ${chalk.yellow(time)}
│ » ғʀᴏᴍ ${chalk.red(pushname)} ${chalk.gray(`(${sender})`)}
│ » ᴀʀᴇ ᴀᴛ ${chalk.yellow(groupName ? groupName : "Pᴠ || ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ")}
│ » ᴀʀɢs : ${chalk.white(args.length)}
│ » ᴍᴇssᴀɢᴇ : ${chalk.green(b)}
└───···`
);
}
//————————————————————————//
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
userJid: Alice.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, Alice.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
Alice.ev.emit('messages.upsert', msg)
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// AMBIL PP USER
try {
    var ppuser = await Alice.profilePictureUrl(m.sender, 'image');
} catch (err) {
    var ppuser = 'https://telegra.ph/file/6880771a42bad09dd6087.jpg';
}

let ppnyauser = await getBuffer(ppuser);
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// plugins

const pluginsLoader = async (directory) => {
let plugins = []
const files = fs.readdirSync(directory)

for (let file of files) {

let filePath = path.join(directory, file)

if (filePath.endsWith(".js")) {

delete require.cache[require.resolve(filePath)]

let plugin = require(filePath)

plugins.push(plugin)

}

}

return plugins
}

const plugins = await pluginsLoader(path.resolve(__dirname, "./AlicePlugins"))

for (let plugin of plugins) {

if (!plugin.command) continue

let cmd = Array.isArray(plugin.command) ? plugin.command : [plugin.command]

if (!cmd.includes(command.toLowerCase())) continue

try {

if (plugin.owner && !isOwner) {
return reply("❌ Khusus Owner")
}

if (plugin.premium && !isPrem) {
return reply("❌ Khusus Premium User")
}

if (plugin.group && !m.isGroup) {
return reply("❌ Command hanya untuk group")
}

if (plugin.private && m.isGroup) {
return reply("❌ Command hanya untuk private chat")
}

if (plugin.admin && !isAdmins) {
return reply("❌ Khusus Admin Group")
}

if (plugin.botAdmin && !isBotAdmins) {
return reply("❌ Bot harus admin dulu")
}

await plugin(m, {
Alice,
reply,
text: q,
prefix,
command,
args,
isOwner,
isAdmins,
isBotAdmins,
isPrem,
XReaction
})

} catch (e) {

console.log("Plugin error:", e)

}

return
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//DB PREFIX
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
let isNumber = x => typeof x === 'number' && !isNaN(x)
let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!('autoread' in setting)) setting.autoread = false
				if (!("autoTyping" in setting)) setting.autoTyping = false
				if (!("autoRecord" in setting)) setting.autoRecord = true
				if (!("setPrefix" in setting)) setting.setPrefix = "one" //multi, no, all				
                if (!isNumber(setting.status)) setting.status = 0
            } else global.db.data.settings[botNumber] = {
                status: 0,
				autoTyping: false,
				autoRecord: false,
				setPrefix: "one", //multi, no, all
				autoread: false                
            }
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
if (!m.key.fromMe && db.data.settings[botNumber].autoread) {
await Alice.readMessages([{
remoteJid: m.chat,
id: m.key.id,
participant: m.isGroup ? m.key.participant : undefined
}])
}

const isFree = isOwner || isAdmins || !isBotAdmins || m.key.fromMe

const del = async () => {
await Alice.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.key.participant || m.sender
}
})
}

const send = async(text) => {
await Alice.sendMessage(m.chat, {
text,
contextInfo: {
mentionedJid: [m.sender]
}
}, { quoted: m })
}

if (db.data.chats[m.chat].antiviewonce && m.isGroup && m.mtype === 'viewOnceMessageV2') {
let val = { ...m }
let msg = val.message?.viewOnceMessage?.message || val.message?.viewOnceMessageV2?.message
delete msg[Object.keys(msg)[0]].viewOnce
val.message = msg
await Alice.sendMessage(m.chat, { forward: val }, { quoted: m })
}

if (db.data.chats[m.chat].antipromotion) {
let regex = /buy|promo|sell|panel|followers|booster|vps|push member|murbug|ready|open jasa|install/i

if (regex.test(budy) && !isFree) {
await del()
}
}

if (m.isBaileys && m.fromMe && isBotAdmins) {
reply('*Bot lain terdeteksi*')
await Alice.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
}

if (db.data.chats[m.chat].antimedia && isMedia && !isFree) {
await del()
}

if (db.data.chats[m.chat].antiimage && isXMEDIA === 'imageMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antivideo && isXMEDIA === 'videoMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antisticker && isXMEDIA === 'stickerMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antiaudio && isXMEDIA === 'audioMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antipoll && isXMEDIA === 'pollCreationMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antilocation && isXMEDIA === 'locationMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].antidocument && isXMEDIA === 'documentMessage' && !isFree) {
await del()
}

if (db.data.chats[m.chat].anticontact && isXMEDIA === 'contactMessage' && !isFree) {
await del()
}

if (global.autobio) {
let status = `${botname} Online ${runtime(process.uptime())}`
Alice.updateProfileStatus(status).catch(() => {})
}

if (db.data.chats[m.chat].antilinkkick && budy.includes('https://')) {
if (!isFree) {
await Alice.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
}
}

if (db.data.chats[m.chat].antilinkgc && budy.includes('chat.whatsapp.com')) {
if (!isFree) {
await del()
}
}

if (AntiLink && budy.toLowerCase().includes('chat.whatsapp.com/')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link grup`)
}
}

if (AntiWame && budy.toLowerCase().includes('wa.me')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link wame`)
}
}

if (AntiLinkYoutubeVid && budy.toLowerCase().includes('youtu.be')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link YouTube`)
}
}

if (AntiLinkYoutubeChannel && budy.toLowerCase().includes('youtube.com')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link YouTube`)
}
}

if (AntiLinkInstagram && budy.toLowerCase().includes('instagram.com')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Instagram`)
}
}

if (AntiLinkFacebook && budy.toLowerCase().includes('facebook.com')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Facebook`)
}
}

if (AntiLinkTelegram && budy.toLowerCase().includes('t.me')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Telegram`)
}
}

if (AntiLinkTiktok && budy.toLowerCase().includes('tiktok.com')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link TikTok`)
}
}

if (AntiLinkTwitter && budy.toLowerCase().includes('twitter.com')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Twitter`)
}
}

if (AntiDewasa && budy.toLowerCase().includes('doods')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link dewasa`)
}
}

if (AntiTerabox && budy.toLowerCase().includes('terabox')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Terabox`)
}
}

if (AntiMediafire && budy.toLowerCase().includes('mediafire')) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan kirim link Mediafire`)
}
}

if (AntiVirtex && budy.length > 3500) {
if (!isFree) {
await del()
await Alice.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
await send(`⚠️ @${m.sender.split('@')[0]} ditendang karena virtex`)
}
}

if (
AntiToxic &&
!budy.includes('deletebadwords') &&
!budy.includes('delbadwords') &&
badwords.some(v => budy.toLowerCase().includes(v))
) {
if (!isFree) {
await del()
await send(`⚠️ @${m.sender.split('@')[0]} jangan toxic`)
}
}

if (m.isGroup && isBotAdmins && AntiAsing) {
for (let user of participants.map(v => v.id)) {
if (
user &&
!user.startsWith('62') &&
!groupAdmins.includes(user) &&
!isOwner
) {
await Alice.groupParticipantsUpdate(m.chat, [user], 'remove')
await sleep(1000)
}
}
}

if (AntiLinkAll && budy.toLowerCase().includes('http')) {
if (!isFree) {

let mode = AntiLinkAll.mode || 'delete'

if (mode === 'delete') {
await del()
}

if (mode === 'kick') {
await Alice.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
}
}
}
			
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// AutoDownload

const autoDlPath = './AliceDatabase/group-db/autodownload.json'

if (!fs.existsSync(autoDlPath)) {
  fs.writeFileSync(autoDlPath, JSON.stringify({}))
}

let autoDlSettings = JSON.parse(fs.readFileSync(autoDlPath))

function saveAutoDl() {
  fs.writeFileSync(autoDlPath, JSON.stringify(autoDlSettings, null, 2))
}

// AUTODOWNLOAD TIKTOK
if (autoDlSettings[m.chat] && !m.key.fromMe && !isCmd) {
  if (/(tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com|ut\.tiktok\.com)/i.test(budy)) {
    try {
      await XReaction()

      let data = await fg.tiktok(budy)
      let json = data.result

      let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
      caption += `◦ *Id* : ${json.id}\n`
      caption += `◦ *Username* : ${json.author?.nickname}\n`
      caption += `◦ *Title* : ${json.title}\n`

      if (json.images) {
        for (let img of json.images) {
          await Alice.sendMessage(m.chat, { image: { url: img } }, { quoted: m })
        }
      } else {
        await Alice.sendMessage(m.chat, {
          video: { url: json.play },
          mimetype: 'video/mp4',
          caption,
          footer: 'Tiktok Downloader',
          buttons: [
            { buttonId: `${prefix}tiktokmp3 ${budy}`, buttonText: { displayText: '🎵 Audio' }, type: 1 }
          ],
          headerType: 4
        }, { quoted: m })
      }

    } catch (e) {
      try {
        let res = await tiktokdl(budy)
        if (!res || !res.video) return

        let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
        caption += `◦ *Title* : ${res.title || '-'}\n`
        caption += `◦ *Author* : ${res.author || '-'}\n`
        caption += `◦ *Status* : Fallback Scraper`

        await Alice.sendMessage(m.chat, {
          video: { url: res.video },
          mimetype: 'video/mp4',
          caption,
          footer: 'Tiktok Downloader',
          buttons: [
            { buttonId: `${prefix}tiktokmp3 ${budy}`, buttonText: { displayText: '🎵 Audio' }, type: 1 }
          ],
          headerType: 4
        }, { quoted: m })

      } catch (err) {
        console.error(err)
      }
    }
  }
}
    
if (autoDlSettings[m.chat] && !m.key.fromMe && !isCmd)
if (budy.match(/youtube\.com|youtu\.be/)) {
        await XReaction()
        try {
            let cari = await fetchJson(`${global.beta}/api/download/ytmp3?url=${budy}&apikey=${global.botz}`)
            let hasil = cari.result;
           await Alice.sendMessage(m.chat, { video: { url: hasil.mp4 }, caption: cari.title }, { quoted: m });
           await Alice.sendMessage(m.chat, { audio: { url: hasil.mp3 }, mimetype: 'audio/mpeg', ptt: false }, { quoted: m });
        } catch (e) {
            console.log(e)
            let response = await SaveTube.dl(budy, 2, 'video')
            await Alice.sendMessage(m.chat, { video: { url: response.link }, caption: `Succes\n© ${botname}` }, { quoted: m })
          }
    }

// AUTODOWNLOAD INSTAGRAM
if (autoDlSettings[m.chat] && !m.key.fromMe && !isCmd) {
    if (/instagram\.com/i.test(budy)) {
        try {

            await XReaction()

            const result = await igdl(budy)
            if (result.error) return

            // FOTO
            if (result.photos && result.photos.length > 0) {
                for (let photo of result.photos) {
                    await Alice.sendMessage(m.chat, {
                        image: { url: photo.url },
                        caption: `Succes\nSize: ${photo.fSize}\n© ${botname}`
                    }, { quoted: m })
                }
                return
            }

            // VIDEO
            if (result.videos && result.videos.length > 0) {
                for (let video of result.videos) {
                    await Alice.sendMessage(m.chat, {
                        video: { url: video.url },
                        caption: `Succes\nSize: ${video.fSize}\n© ${botname}`
                    }, { quoted: m })
                }
                return
            }

        } catch (error) {
            console.log(error)
        }
    }
}
    
// AUTODOWNLOAD FACEBOOK
if (autoDlSettings[m.chat] && !m.key.fromMe && !isCmd) {
  if (/(facebook|fb)\.com/i.test(budy)) {

    await XReaction()

    if (!/^https?:\/\/(www\.)?(facebook|fb)\.com\/.+/i.test(budy)) return

    try {

      let res = await fetchJson(
        `https://api.skyzopedia.web.id/download/facebook?apikey=skyy&url=${encodeURIComponent(budy)}`
      )

      if (!res.status || !res.result) return

      let data = res.result

      let videoUrl = data.video?.[0]?.url || data.media

      if (!videoUrl) return

      await Alice.sendMessage(
        m.chat,
        {
          video: { url: videoUrl },
          mimetype: 'video/mp4',
          caption: `*FACEBOOK DOWNLOADER*\n\n*Title:* ${data.title}\n*Duration:* ${data.duration}\n*Quality:* ${data.video?.[0]?.quality || 'HD'}`
        },
        { quoted: m }
      )

    } catch (e) {
      console.log('AUTO FB ERROR:', e)
    }

  }
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// antitagsw
const AT_FILE = './AliceSystem/AliceDatabase/Antilink/antitagsw.json'

// load db
function loadAT() {
  if (!fs.existsSync(AT_FILE)) {
    fs.writeFileSync(AT_FILE, JSON.stringify({ groups: {} }, null, 2))
  }

  let data
  try {
    data = JSON.parse(fs.readFileSync(AT_FILE))
  } catch {
    data = { groups: {} }
  }

  if (typeof data !== 'object' || Array.isArray(data)) {
    data = { groups: {} }
  }

  if (!data.groups) data.groups = {}

  return data
}

// save db
function saveAT(db) {
  fs.writeFileSync(AT_FILE, JSON.stringify(db, null, 2))
}

// global var
let antitagsw = loadAT()

function ensureGroup(id) {
  if (!antitagsw.groups[id]) antitagsw.groups[id] = { enabled: false }
  return antitagsw.groups[id]
}

if (m.mtype?.includes("groupStatusMentionMessage") && m.isGroup) {
  const idgc = m.key.remoteJid
  const group = ensureGroup(idgc)

  if (group.enabled && idgc.endsWith('@g.us')) {
    try {
      await Alice.sendMessage(idgc, { delete: m.key })
    } catch(e) {
      try {
        await Alice.deleteMessage(idgc, m.key)
      } catch(_) {}
    }
  }
}
           
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Batas Antilink
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
		
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

function formatmoney(amount, options = {}) {
  const {
    currency = "IDR",
    locale = "id",
    minimumFractionDigits = 0,
    maximumFractionDigits = 0,
    useSymbol = true
  } = options;

  const formattedAmount = amount.toLocaleString(locale, {
    style: "currency",
    currency,
    minimumFractionDigits,
    maximumFractionDigits,
  });

  return useSymbol ? formattedAmount : formattedAmount.replace(/[^\d.,]/g, '');
}

async (source, filename, options) => {
      try {
         if (Buffer.isBuffer(source)) {
            let ext, mime
            try {
               mime = await (await fromBuffer(source)).mime
               ext = await (await fromBuffer(source)).ext
            } catch {
               mime = require('mime-types').lookup(filename ? filename.split`.` [filename.split`.`.length - 1] : 'txt')
               ext = require('mime-types').extension(mime)
            }
            const extension = filename ? filename.split`.` [filename.split`.`.length - 1] : ext
            const size = Buffer.byteLength(source)
            const filepath = 'temp/' + (this.uuid() + '.' + ext)
            const file = fs.writeFileSync(filepath, source)
            const name = filename || path.basename(filepath)
            return new Promise(resolve => {
               const data = {
                  status: true,
                  file: filepath,
                  filename: name,
                  mime: mime,
                  extension: ext,
                  size: this.formatSize(size),
                  bytes: size
               }
               return resolve(data)
            })
         } else if (source.startsWith('./') || source.startsWith('/')) {
            const mime = require('mime-types').lookup(filename ? filename.split`.` [filename.split`.`.length - 1] : source.split`.` [source.split`.`.length - 1])
            const ext = require('mime-types').extension(mime)
            const extension = filename ? filename.split`.` [filename.split`.`.length - 1] : ext
            const size = fs.statSync(source).size
            const name = filename || path.basename(source)
            return new Promise(resolve => {
               const data = {
                  status: true,
                  file: source,
                  filename: name,
                  mime: mime,
                  extension: ext,
                  size: this.formatSize(size),
                  bytes: size
               }
               return resolve(data)
            })
         } else {
            return new Promise(resolve => {
               const mg = new Miniget(source, {
                  headers: {
                     "Accept": "*/*",
                     "User-Agent": "Mozilla/5.0 (Linux; Android 6.0.1; SM-J500G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36",
                     "Referrer-Policy": "strict-origin-when-cross-origin",
                     "sec-ch-ua": '"Chromium";v="107", "Not=A?Brand";v="24"',
                     "sec-ch-ua-platform": "Android",
                     "sec-fetch-dest": "empty",
                     "sec-fetch-mode": "cors",
                     "sec-fetch-site": "same-origin",
                     ...options
                  }
               })
               mg.on('response', (response) => {
                  if (response.statusCode !== 200) {
                     resolve({
                        status: false,
                        msg: `[${response.statusCode}] : Error while gwtting file`
                     })
                     return
                  }
                  const extension = filename ? filename.split`.` [filename.split`.`.length - 1] : mime.extension(response.headers['content-type'])
                  const file = fs.createWriteStream(`temp/${this.uuid() + '.' + extension}`)
                  const name = filename || path.basename(file.path)
                  const transformStream = new stream.Transform({
                     transform(chunk, encoding, callback) {
                        callback(null, chunk)
                     }
                  })
                  mg.pipe(transformStream).pipe(file)
                  file.on('finish', () => {
                     const data = {
                        status: true,
                        file: file.path,
                        filename: name,
                        mime: mime.lookup(file.path),
                        extension: extension,
                        size: this.formatSize(response.headers['content-length'] ? response.headers['content-length'] : 0),
                        bytes: response.headers['content-length'] ? parseInt(response.headers['content-length']) : 0,
                        headers: response.headers
                     }
                     resolve(data)
                  })
                  .on('error', (error) => {
                     resolve({
                        status: false,
                        msg: `Error when getting the file`
                     })
                  })
               })
            })
         }
      } catch (e) {
         return ({
            status: false,
            msg: e.message
         })
      }
   }

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Only Group
if (!m.isGroup && !isOwner && !isPrem && db.data.settings[botNumber].onlygrub) {
  if (command) {
    return
  }
}
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Mute Group
if (m.isGroup && isMute) {
if (!isOwner) return
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// banned

if (!isOwner && isUserBanned(m.sender)) {
  let data = bannedUsers[m.sender]
  let now = Date.now()

  let delay = 60 * 60 * 1000 // 1 jam

  if (!banNotifCooldown[m.sender] || now - banNotifCooldown[m.sender] > delay) {

    banNotifCooldown[m.sender] = now

    if (data.permanent) {
      return reply("🚫 Kamu diblacklist permanen dari bot.")
    }

    if (Date.now() < data.expired) {
      let sisa = data.expired - now
      let menit = Math.floor(sisa / 60000)
      return reply(`🚫 Kamu dibanned sementara.\nSisa waktu: ${menit} menit`)
    }
  }

  return
}

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Command No Prefix
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

if (m.isGroup) {
    if (body.includes(`@${owner}`)) {
        reaction(m.chat, "❌")
    }
 }

if ((budy.match) && ["ap", "Y", "y", "o", "O", "?",].includes(budy) && !isCmd) {
Alice.sendMessage(m.chat, { audio: { url: soundcool }, mimetype: 'audio/mpeg' }, { quoted: m })
}

if ((budy.match) && ["runtime"].includes(budy) && !isCmd) {
    reply(`${botname}\nRuntime : ${runtime(process.uptime())}`)
}

// Tes Command No Prefix		
if ((budy.match) && ["tes",].includes(budy) && !isCmd) {
reply(`${botname} A WhatsApp Bot`)
}	

// Toxic
if ((budy.match) && ["babi", "kntl", "kontol", "bujang", "mmq", "mmk", "memek", "iclik", "ktl", "anjing", "anj",].includes(budy)) {
reply(`
*مَا شَيْءٌ أَثْقَلُ فِيْ مِيْزَانِ الْمُؤْمِنِ يَوْمَ الْقِيَامَةِ مِنْ خُلُقٍ حَسَنٍ وَإِنَّ اللهَ لَيُبْغِضُ الْفَاحِشَ الْبَذِيْءَ*

_“Sesungguhnya tidak ada sesuatu apapun yang paling berat ditimbangan kebaikan seorang mu’min pada hari kiamat seperti akhlaq yang mulia, dan sungguh-sungguh (benar-benar) Allāh benci dengan orang yang lisānnya kotor dan kasar.”_

\`jangan toxic lagi ya kak\` *@${pushname}* ☺`)
}

// Sepuh Command No Prefix With Ptv 
if ((budy.match) && ["sepuh", "Sepuh", "puh", "Puh"].includes(budy) && !isCmd) {
 let msg = await generateWAMessageContent({
 video: { url: 'https://telegra.ph/file/2ff6d0005fc4a32f67f65.mp4' }
 }, {
 upload: Alice.waUploadToServer
 })
 let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: msg.videoMessage }), { userJid: m.chat, quoted: m })
 await Alice.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id })
} 

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

switch(command) {

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
case 'menu': {
try {

await XReaction()

    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

 — 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )`

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuall': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.allmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menustalker': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.stalkermenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menucanvas': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.canvasmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menucpanel': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.cpanelmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuanime': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.animemenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menupush': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.pushmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menumain': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.mainmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuberita': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.beritamenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuasupan': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.asupanmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuaudio': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.audiomenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuanonymous': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.anonymousmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuai': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.aimenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menustore': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.storemenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuconvert': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.convertmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menutools': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.toolsmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuislami': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.islamimenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menudownloader': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.downloadermenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menupremium': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.premiummenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menusearch': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.searchmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuephoto': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.ephotomenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuprimbon': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.primbonmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menurandom': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.randommenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menugroup': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.groupmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menuowner': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.ownermenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menugame': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.gamemenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break

case 'menurpg': {
  try {
await XReaction();


    const ciro = `hii *@${pushname}* 🪸, i am an automated system ( WhatsApp bot ) that can help to search and get data or information through WhatsApp

— 👤 User Information
┌  ◦ Name       : ${pushname}
│  ◦ Number     : @${senderNumber}
│  ◦ Role       : ${isOwner ? "Owner" : isPrem ? "Premium User" : "Free User"}
└  ◦ Total Chat : ${global.db.data.chats[m.chat]?.totalChat?.[m.sender] || 0}

— 🤖 Bot Information
┌  ◦ Version     : ${version}
│  ◦ Nama Bot    : ${botname}
│  ◦ Uptime      : ${runtime(process.uptime())}
│  ◦ Total Fitur : ${totalfitur()}
│  ◦ Total User  : ${usersList.length}
│  ◦ Total Hit   : ${Object.values(global.topcmd || {}).reduce((a,b)=>a+b,0)}
└  ◦ Type        : Case X Plugins ( CommonJS )

━━━━━━━━━━━━━━⬣
${global.rpgmenu}`;

await sendBatenAlice(m, Alice, ciro)

} catch (e) {
console.log(e)
reply("error menampilkan menu")
}
}
break
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Command Owner Prefix
case "owner":
case "creator": {
await XReaction();

    const fs = require("fs");

    let sm = global.sosialmedia || {};
    let nm = global.ownername || "Owner Bot";
    let gm = global.gmail || "-";
    let wb = global.web || "-";

    let ow = {
        name: nm,
        wa: sm.whatsapp ? `${sm.whatsapp}` : "",
        ig: sm.instagram || "",
        yt: sm.youtube || "",
        tt: sm.tiktok || "",
        tg: sm.telegram || "",
        mail: gm,
        site: wb
    };

    let img = "./AliceMedia/image/Alice.jpg";
    if (!fs.existsSync(img)) {
        return reply("foto owner ga ketemu, cek lagi ya.");
    }

    try {
        let up = await prepareWAMessageMedia(
            { image: fs.readFileSync(img) },
            { upload: Alice.waUploadToServer }
        );

        let txt = 
`– 👤 Owner Info

nama : ${ow.name}
tele : ${ow.tg}
web : ${ow.site}

source lain dibawah ya, langsung kunjungi saja 🔥`;

        let msg = await generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessageV2Extension: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            header: proto.Message.InteractiveMessage.Header.fromObject({
                                hasMediaAttachment: true,
                                ...up
                            }),
                            body: proto.Message.InteractiveMessage.Body.fromObject({
                                text: txt
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                text: botname
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: `{"display_text":"💬 WhatsApp","url":"${ow.wa}"}`
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: `{"display_text":"📷 Instagram","url":"${ow.ig}"}`
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: `{"display_text":"▶️ YouTube","url":"${ow.yt}"}`
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: `{"display_text":"📨 Telegram","url":"${ow.tg}"}`
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: `{"display_text":"🌐 Website","url":"${ow.site}"}`
                                    }
                                ]
                            })
                        })
                    }
                }
            },
            { userJid: m.sender, quoted: fkontak }
        );

        await Alice.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.log(e);
        reply("tadi error, coba ulang ya.");
    }
}
break;
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//Source Code
case 'script':
case 'sc': {
  try {
    let thumbPath = './AliceMedia/image/Alice.jpg'
let teks = `📌 SCRIPT INFO

Botname : ${botname}
Developer : ${ownername}
Type Script : Case × Plugins
License     : Personal / Reseller
• personal: Rp 60k/60.000 ( free update )
• reseller: Rp 120k/120.000 ( free update + reseller resmi legal )

━━━━━━━━━━━━━━━━━━━
✨ HIGHLIGHT:
━━━━━━━━━━━━━━━━━━━
✅ TOTAL FITUR: 1600+ (1300+ Case + 300+ Plugins)
✅ 20+ KATEGORI MENU:
   • Main, Anime, Random, Group, Game, RPG
   • AI, Tools, Downloader, Converter, Premium
   • Stalker, Search, Islami, Primbon, Berita
   • Store, Anonymous, Audio, Asupan, Canvas
   • Cpanel, Push, Ephoto, Owner

✅ FITUR UNGGULAN:
   • AI (ChatGPT, Gemini, Claude, Llama, MuslimAI)
   • Stalker (ML, WA, NPM, Github, TikTok, IG, YouTube)
   • Downloader (YT, TT, IG, FB, Mediafire, Capcut, Spotify)
   • Group (Tagall, AntiLink, Welcome, Warn, AFK)
   • Game (Catur, Werewolf, Gaple, Koboy, Tebak, Uno)
   • RPG (Hunt, Boss, Arena, Duel, Craft, Shop, Pet, Bank)

✅ KEUNGGULAN SCRIPT:
   • 5+ Apikey Premium (btch, termai, lolhuman, dll)
   • 50+ Scraper Include
   • Support WA Business & All Device
   • Custom Pairing Code & Full Button Support
   • Database Number Access
   • 95% No ENC → Open Source
   • Struktur Modular (Case + Plugin)
   • Size Script Ringan (1.2mb - average use url)

━━━━━━━━━━━━━━━━━━━
🚀 PREMIUM FEATURES:
━━━━━━━━━━━━━━━━━━━
🤖 AI GENERATION:
   • text2img, img2img, text2anime, text2ghibli
   • tofigure, toanime, toreal, tochibi, tojepang
   • tohijab, toblur, tomirror, tosexy, tovintage
   • removeclothes, telanjangin, deepfake
   • dalle3, animediff, img2video

🛡️ GROUP SECURITY:
   • AntiLink, AntiVirtex, AntiVideo, AntiImage
   • AutoKick, Welcome/Left, GroupAttack

🎮 RPG COMPLETE:
   • hunt, boss, arena, duel, craft, shop
   • pet, bank, market, lottery, gamble
   • dungeon, adventure, quest, achievement
   • guild, party, expedition, prestige

⬇️ DOWNLOADER FULL:
   • YouTube (mp3/mp4), TikTok (video/mp3)
   • Instagram, Facebook, Twitter, Pinterest
   • Mediafire, Capcut, Spotify, SoundCloud

🛠️ TOOLS LENGKAP:
   • Sticker Maker (smeme, wm, qc, brat)
   • Converter (toimg, tourl, tomp3, tovn)
   • Text2Img, Img2Img, RemoveBG, OCR

━━━━━━━━━━━━━━━━━━━
👑 RESELLER (120K):
━━━━━━━━━━━━━━━━━━━
• Free update tercepat
• Grup khusus reseller
• Name role reseller
• Resmi jual ulang script
• Free panel unlimited private (close)
• Akses web database:
   - createaccount
   - addnumber
   - deletenumber

Note: Script siap pakai, update rutin, support penuh! 🚀

━━━━━━━━━━━━━━━━━━━━━━━
📩 Mau Order?
━━━━━━━━━━━━━━━━━━━━━━━
🔗 Telegram : ${global.sosialmedia.telegram}
🔗 WhatsApp : ${global.sosialmedia.whatsapp}

📁 Cek Fitur Lengkap:
🔗 ${groupbot}
🔗 ${channel}
🔗 ${chtesti}

⚡ Jangan tunggu lama!
Harga bisa naik kapan saja, buruan amankan slotmu sekarang! 🔥`

    await Alice.sendMessage(m.chat, {
      image: { url: thumbPath },
      caption: teks
    }, { quoted: m })

  } catch (e) {
    console.error("Script promo error:", e)
    reply("❌ Gagal mengirim info script.")
  }
}
break
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Anime Features
// =============================
// 🎴 ANIME (waifu.pics API)
// =============================
case 'animeawoo':
case 'animemegumin':
case 'animeshinobu':
case 'animehandhold':
case 'animehighfive':
case 'animecringe':
case 'animedance':
case 'animehappy':
case 'animeglomp':
case 'animesmug':
case 'animeblush':
case 'animewave':
case 'animesmile':
case 'animepoke':
case 'animewink':
case 'animebonk':
case 'animebully':
case 'animeyeet':
case 'animebite':
case 'animelick':
case 'animekill':
case 'animecry':
case 'animeneko': {
await XReaction();
  
  const action = command.replace('anime', '').trim()
  const wibujir = await axios.get(`https://waifu.pics/api/sfw/${action}`)
  
  await Alice.sendMessage(m.chat, {
    image: { url: wibujir.data.url },
    caption: `${packname}`,
    quoted: m
  }).catch(() => 'Error!')
}
break

// =============================
// 💮 ANIME (nekos.life API)
// =============================
case 'animewlp':
case 'animekiss':
case 'animehug':
case 'animepat':
case 'animeslap':
case 'animecuddle':
case 'animewaifu':
case 'animenom':
case 'animefoxgirl':
case 'animetickle':
case 'animegecg': {
await XReaction();
  
  let action = command.replace('anime', '').trim()
  if (action === 'wlp') action = 'wallpaper'

  const wibujir = await axios.get(`https://nekos.life/api/v2/img/${action}`)
  
  await Alice.sendMessage(m.chat, {
    image: { url: wibujir.data.url },
    caption: `${packname}`,
    quoted: m
  }).catch(() => 'Error!')
}
break
case 'bluearchive':
case 'ba': {
await XReaction();

  const API = `https://aliceeapis.vercel.app/random/ba?apikey=${global.apikey.alice}`
  const MAX_IMG = 15 * 1024 * 1024

  const humanSize = (n=0) => { const u=['B','KB','MB','GB']; let i=0,v=+n; while(v>=1024&&i<u.length-1){v/=1024;i++} return `${v.toFixed(v>=100?0:v>=10?1:2)} ${u[i]}` }
  const extFromCtype = (t='') => (t.split('/')[1] || 'jpg').split(';')[0]

  const when = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
  const caption = `🎮 *Blue Archive Random*\n🕒 ${when}\n🔗 Sumber: https://aliceeapis.vercel.app\n\nKetik *.ba* lagi untuk next.`

  try {
    const res = await axios.get(API, {
      timeout: 20000,
      responseType: 'arraybuffer',
      validateStatus: s => s>=200 && s<400
    })
    const ctype = (res.headers['content-type'] || 'image/jpeg').toLowerCase()
    const length = parseInt(res.headers['content-length'] || '0', 10)
    const buff = Buffer.from(res.data)

    if (length && length > MAX_IMG) {
      await Alice.sendMessage(
        m.chat,
        { document: buff, mimetype: ctype, fileName: `bluearchive.${extFromCtype(ctype)}`, caption: `${caption}\n(📦 dokumen – ${humanSize(length)})` },
        { quoted: m }
      )
    } else {
      await Alice.sendMessage(
        m.chat,
        { image: buff, caption },
        { quoted: m }
      )
    }

  } catch (e) {
    console.error('bluearchive error:', e?.message || e)
    const msg =
      (e?.response?.status === 429) ? '⌛ Terlalu banyak permintaan. Coba sebentar lagi.' :
      (e?.code === 'ECONNABORTED') ? '⌛ Timeout koneksi ke API.' :
      '❌ Gagal mengambil gambar Blue Archive. Coba lagi.'
    return reply(msg)
  }
}
break
case 'otakudesu':
case 'otakud': {
await XReaction();

  try {
    const res = await axios.get('https://api.zenzxz.my.id/anime/otakudesu')
    const data = res.data.result
    if (!data || !data.length) return reply('⚠️ Tidak ada data.')

    let teks = '📺 *Otakudesu – Update Terbaru*\n\n'
    data.slice(0, 10).forEach((v, i) => {
      teks += `${i+1}. *${v.title}*\n📅 ${v.published}\n🔗 ${v.url}\n\n`
    })

    await Alice.sendMessage(m.chat, { image: { url: data[0].image }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('otakudesu error:', e.message)
    reply('❌ Gagal mengambil data Otakudesu.')
  }
}
break
case 'otakudesu-search':
case 'odsearch': {

  if (!text) return reply('⚠️ Contoh: *.otakudesu-search kimi no na wa*')

  try {
    const res = await axios.get(`https://api.zenzxz.my.id/anime/otakudesu/search?q=${encodeURIComponent(text)}`)
    const data = res.data.result
    if (!data || !data.length) return reply('🙅 Anime tidak ditemukan.')

    let teks = `🔍 *Hasil Pencarian*: ${text}\n\n`
    data.slice(0, 5).forEach((v, i) => {
      teks += `${i+1}. *${v.title}*\n⭐ Rating: ${v.rating}\n📌 Status: ${v.status}\n🎭 Genre: ${v.genres?.join(', ')}\n🔗 ${v.url}\n\n`
    })

    await Alice.sendMessage(m.chat, { image: { url: data[0].image }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('otakudesu-search error:', e.message)
    reply('❌ Gagal melakukan pencarian.')
  }
}
break
case 'otakudesu-detail':
case 'odetail': {

  if (!text) return reply('⚠️ Contoh: *.otakudesu-detail https://otakudesu.best/anime/xxxx*')

  try {
    const res = await axios.get(`https://api.zenzxz.my.id/anime/otakudesu/detail?url=${encodeURIComponent(text)}`)
    const v = res.data.result
    if (!v) return reply('🙅 Detail anime tidak ditemukan.')

    let teks = `📺 *${v.judul}*\n\n`
    teks += `🗾 Japanese: ${v.japanese}\n⭐ Skor: ${v.skor}\n🎬 Studio: ${v.studio}\n📌 Status: ${v.status}\n🎞️ Episode: ${v.total_episodes}\n⏰ Durasi: ${v.durasi}\n📅 Rilis: ${v.release_date}\n🎭 Genre: ${v.genre.join(', ')}\n\n`
    teks += `📂 Episode List:\n`
    v.episode_list.slice(0, 5).forEach((ep, i) => {
      teks += `${i+1}. ${ep.title}\n   🔗 ${ep.episode_url}\n   📅 ${ep.date}\n`
    })
    if (v.episode_list.length > 5) teks += `…dan ${v.episode_list.length-5} episode lainnya`

    await Alice.sendMessage(m.chat, { image: { url: v.image_url }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('otakudesu-detail error:', e.message)
    reply('❌ Gagal mengambil detail anime.')
  }
}
break
case 'komiku-search':
case 'komikusearch':
case 'ksearch': {

  if (!text) return reply('⚠️ Contoh: *.komiku-search solo leveling*')

  try {
    const res = await axios.get(`https://api.zenzxz.my.id/anime/komikusearch?q=${encodeURIComponent(text)}`)
    console.log('komiku-search result:', res.data)

    let data = []
    if (Array.isArray(res.data.result)) {
      data = res.data.result
    } else if (res.data.result && Array.isArray(res.data.result.result)) {
      data = res.data.result.result
    } else if (Array.isArray(res.data)) {
      data = res.data
    }

    if (!data || !data.length) return reply('🙅 Manga tidak ditemukan, coba pakai kata kunci lain.')

    let teks = `📚 *Hasil Pencarian Komiku* untuk: _${text}_\n\n`
    data.slice(0, 5).forEach((manga, i) => {
      teks += `${i+1}. *${manga.title}*\n🔗 ${manga.url}\n\n`
    })

    await Alice.sendMessage(m.chat, { image: { url: data[0].image }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('komiku-search error:', e.message)
    reply('❌ Gagal mencari manga di Komiku.')
  }
}
break
case 'komiku-detail':
case 'kdetail': {

  if (!text) return reply('⚠️ Contoh: *.komiku-detail https://komiku.id/manga/xxx*')

  try {
    const res = await axios.get(`https://api.zenzxz.my.id/anime/komikudetail?url=${encodeURIComponent(text)}`)
    const v = res.data
    if (!v.status) return reply('🙅 Detail manga tidak ditemukan.')

    let teks = `📖 *${v.manga_title}*\n`
    teks += `📌 Judul Chapter: ${v.title}\n`
    teks += `📅 Rilis: ${v.release_date}\n`
    teks += `📚 Arah Baca: ${v.read_direction}\n\n`
    teks += `📝 Deskripsi:\n${v.description}\n\n`
    teks += `📂 Total Halaman: ${v.baca_komik.length}\n`
    teks += `🔗 Manga URL: ${v.manga_url}`

    await Alice.sendMessage(m.chat, { image: { url: v.baca_komik[0] }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('komiku-detail error:', e.message)
    reply('❌ Gagal mengambil detail manga dari Komiku.')
  }
}
break
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// AI Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'kimi':
case 'kimi-ai':
case 'k2':
case 'kimi-thinking': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu black hole?*`);
    
    reply(`🧠 *Kimi (Mode Thinking)*\n⏳ Proses berpikir mendalam, mohon tunggu sekitar 2-4 menit...\n\n_⚠️ Makin panjang pertanyaan, makin lama prosesnya_`);
    
    try {
        const { kimiAI } = require('./AliceSystem/AliceScraper/alice-kimi.js');
        const hasil = await kimiAI(text);
        reply(`💭 *Kimi - Hasil Pemikiran:*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'Layanan Kimi sedang sibuk'}`);
    }
}
break;

case 'deepseek':
case 'deepseek-ai':
case 'ds': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} siapa einstein?*`);
    
    reply(`🤖 *DeepSeek (Mode Thinking v32)*\n⏳ Sedang menganalisis pertanyaan, mohon tunggu 2-4 menit...\n\n_⚠️ Hasil akan lebih akurat dengan waktu tunggu yang lebih lama_`);
    
    try {
        const hasil = await deepseek(text, "v32");
        reply(`💡 *DeepSeek - Jawaban:*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'DeepSeek sedang gangguan'}`);
    }
}
break;

case 'turnitin':
case 'cekai': {
    await XReaction();
    if (!text) return reply(`Mau cek teks apa? Ketik teksnya setelah *${prefix + command}*\nContoh: *${prefix + command} artificial intelligence adalah...*`);
    
    reply(`🔍 *Turnitin AI Checker*\n⏳ Sedang menganalisis teks, mohon tunggu sekitar 30 detik...`);
    
    try {
        const axios = require('axios');
        const res = await axios.post('https://reilaa.com/api/turnitin-match', { text }, {
            headers: { 'Content-Type': 'application/json' }
        });
        const data = res.data;
        if (!data || !data.reilaaResult?.value) return reply(`❌ Hmm, tidak ada hasil yang bisa ditampilkan saat ini.`);
        const result = data.reilaaResult.value;
        let hasil = `✨ *Turnitin AI Checker* ✨\n\n`;
        hasil += `🧠 *Classification* : ${result.classification}\n`;
        hasil += `🎯 *AI Score* : ${result.aiScore}%\n`;
        hasil += `⚠️ *Risk* : ${result.details?.analysis?.risk}\n`;
        hasil += `💡 *Suggestion* : ${result.details?.analysis?.suggestion}\n\n`;
        hasil += `📄 *Text* :\n"${result.inputText}"`;
        await Alice.sendMessage(m.chat, { text: hasil }, { quoted: m });
    } catch (err) {
        console.error(err);
        reply(`❌ *Error:* ${err.message || 'Layanan Turnitin sedang sibuk'}`);
    }
}
break;

case 'quantum-ai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu kuantum?*`);
    
    reply(`⚛️ *Quantum AI*\n⏳ Sedang memproses dengan komputasi kuantum, mohon tunggu sekitar 30 detik...`);
    
    try {
        const api = `https://zelapioffciall.vercel.app/ai/quantum?text=${encodeURIComponent(text)}`;
        const res = await fetch(api);
        if (!res.ok) throw await res.text();
        const json = await res.json();
        if (!json.result) return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        reply(`⚛️ *Quantum AI - Jawaban:*\n\n${json.result}`);
    } catch (e) {
        console.error('[QUANTUM AI ERROR]', e);
        reply(`❌ *Error:* ${e.message || 'Layanan Quantum AI sedang sibuk'}`);
    }
}
break;

case 'chatai': {
    await XReaction();
    if (!args.length) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan tentang blackhole*`);
    
    reply(`💬 *ChatAI*\n⏳ AI sedang berpikir, mohon tunggu sebentar...`);
    
    try {
        let payload = { messages: [{ role: 'user', content: args.join(' ') }] };
        let headers = { headers: { Origin: 'https://chatai.org', Referer: 'https://chatai.org/' } };
        let { data } = await axios.post('https://chatai.org/api/chat', payload, headers);
        reply(`💬 *ChatAI - Jawaban:*\n\n${data?.content || '❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.'}`);
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan ChatAI sedang sibuk'}`);
    }
}
break;

case 'conciseai': {
    await XReaction();
    if (!args.length) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu AI?*`);
    
    reply(`📝 *ConciseAI*\n⏳ Sedang merangkum jawaban, mohon tunggu sebentar...`);
    
    const chatAI = async text => {
        let user_id = uuidv4().replace(/-/g, '');
        let lastMsg = `USER: ${text}`;
        let signature = crypto.createHmac('sha256', 'CONSICESIGAIMOVIESkjkjs32120djwejk2372kjsajs3u293829323dkjd8238293938wweiuwe')
            .update(user_id + lastMsg + 'normal')
            .digest('hex');
        let form = new URLSearchParams({
            question: lastMsg,
            conciseaiUserId: user_id,
            signature,
            previousChats: JSON.stringify([{ a: '', b: lastMsg, c: false }]),
            model: 'normal'
        });
        let { data } = await axios.post('https://toki-41b08d0904ce.herokuapp.com/api/conciseai/chat', form.toString(), {
            headers: {
                'User-Agent': 'okhttp/4.10.0',
                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'gzip',
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        return data.answer;
    };
    
    try {
        const hasil = await chatAI(args.join(' '));
        reply(`📝 *ConciseAI - Jawaban Ringkas:*\n\n${hasil}`);
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan ConciseAI sedang sibuk'}`);
    }
}
break;

case 'claudeai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan teori relativitas*`);
    
    reply(`🤖 *ClaudeAI*\n⏳ Claude sedang berpikir, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        const headers = {
            'Accept': '*/*',
            'Referer': 'https://claudeai.one/',
            'Origin': 'https://claudeai.one',
            'User-Agent': 'Mozilla/5.0'
        };
        const res = await fetch('https://claudeai.one/', { headers });
        const html = await res.text();
        const dom = new JSDOM(html);
        const doc = dom.window.document;
        const nonce = doc.querySelector('[data-nonce]')?.getAttribute('data-nonce') || '';
        const postId = doc.querySelector('[data-post-id]')?.getAttribute('data-post-id') || '';
        const botId = doc.querySelector('[data-bot-id]')?.getAttribute('data-bot-id') || '';
        const clientId = html.match(/localStorage\.setItem['"]wpaicg_chat_client_id['"],\s*['"](.+?)['"]/)?.[1] ||
            'JHFiony-' + Math.random().toString(36).substring(2, 12);
        const form = new FormData();
        form.append('_wpnonce', nonce);
        form.append('post_id', postId);
        form.append('url', 'https://claudeai.one');
        form.append('action', 'wpaicg_chat_shortcode_message');
        form.append('message', text);
        form.append('bot_id', botId);
        form.append('chatbot_identity', 'shortcode');
        form.append('wpaicg_chat_history', '[]');
        form.append('wpaicg_chat_client_id', clientId);
        const resPost = await fetch('https://claudeai.one/wp-admin/admin-ajax.php', {
            method: 'POST',
            headers: { ...headers, ...form.getHeaders() },
            body: form
        });
        const json = await resPost.json();
        if (!json?.data) return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        await reply(`🤖 *ClaudeAI - Jawaban:*\n\n${json.data}`);
    } catch (e) {
        await reply(`❌ *Error:* ${e.message || 'Layanan ClaudeAI sedang sibuk'}`);
    }
}
break;

case 'chatgpt': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu machine learning?*`);
    
    reply(`🤖 *ChatGPT*\n⏳ ChatGPT sedang memproses, mohon tunggu sekitar 30 detik...`);
    
    const model_list = {
        chatgpt4: { api: 'https://stablediffusion.fr/gpt4/predict2', referer: 'https://stablediffusion.fr/chatgpt4' },
        chatgpt3: { api: 'https://stablediffusion.fr/gpt3/predict', referer: 'https://stablediffusion.fr/chatgpt3' }
    };
    
    try {
        let results = [];
        for (const [model, config] of Object.entries(model_list)) {
            try {
                const axios = require('axios');
                const hmm = await axios.get(config.referer);
                const { data } = await axios.post(config.api, { prompt: text }, {
                    headers: {
                        accept: '*/*',
                        'content-type': 'application/json',
                        origin: 'https://stablediffusion.fr',
                        referer: config.referer,
                        cookie: hmm.headers['set-cookie'].join('; '),
                        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36'
                    }
                });
                results.push(`*${model.toUpperCase()}*:\n${data.message || '❌ Gagal mengambil jawaban.'}`);
            } catch (err) {
                results.push(`*${model.toUpperCase()}*:\n❌ Gagal mengambil jawaban.`);
                console.error(`Error on ${model}:`, err.message);
            }
        }
        reply(`🤖 *ChatGPT - Jawaban:*\n\n${results.join('\n\n')}`);
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'Layanan ChatGPT sedang sibuk'}`);
    }
}
break;

case 'venice':
case 'veniceai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan tentang alam semesta*`);
    
    reply(`🌊 *Venice AI*\n⏳ Venice sedang memproses, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        const axios = require('axios');
        const { data } = await axios.request({
            method: 'POST',
            url: 'https://outerface.venice.ai/api/inference/chat',
            headers: {
                accept: '*/*',
                'content-type': 'application/json',
                origin: 'https://venice.ai',
                referer: 'https://venice.ai/',
                'user-agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'x-venice-version': 'interface@20260523.214528+393d253'
            },
            data: JSON.stringify({
                requestId: 'nekorinn',
                modelId: 'dolphin-3.0-mistral-24b',
                prompt: [{ content: text, role: 'user' }],
                systemPrompt: '',
                conversationType: 'text',
                temperature: 0.8,
                webEnabled: true,
                topP: 0.9,
                isCharacter: false,
                clientProcessingTime: 15
            })
        });
        const chunks = data.split('\n').filter(v => v).map(v => JSON.parse(v));
        const hasil = chunks.map(v => v.content).join('');
        Alice.sendMessage(m.chat, { text: `🌊 *Venice AI - Jawaban:*\n\n${hasil}` }, { quoted: m });
    } catch (e) {
        console.error(e.message);
        reply(`❌ *Error:* ${e.message || 'Layanan Venice AI sedang sibuk'}`);
    }
}
break;

case 'logic-eai': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu logika?*`);
    
    reply(`🧠 *Logic EAI*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    const customName = "logic-eai";
    const creator = `${global.ownername}`;
    const systemMessage = `Nama kamu sekarang adalah ${customName} dan kamu diciptakan oleh ${creator}`;
    const url = "https://velyn.biz.id/api/ai/aicustom";
    
    try {
        const response = await axios.get(url, { params: { prompt: q, system: systemMessage } });
        if (response.data && response.data.data) {
            Alice.sendMessage(m.chat, { text: `🧠 *Logic EAI - Jawaban:*\n\n${response.data.data}` }, { quoted: m });
        } else {
            reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        }
    } catch (error) {
        console.error("Error AI:", error);
        reply(`❌ *Error:* ${error.message || 'Layanan Logic EAI sedang sibuk'}`);
    }
}
break;

case 'gpt4o-mini':
case 'gpt4o':
case 'gpt-4o': {
    await XReaction();
    if (!text && !quoted) return reply(`Mau tanya apa? Saya juga bisa menganalisis gambar yang kamu kirim.\nContoh: *${prefix + command} siapa einstein?*\nAtau kirim gambar dengan caption *${prefix + command}*`);
    
    try {
        let imageDataUrl = "";
        if (/image/.test(mime || "")) {
            const media = await quoted.download();
            imageDataUrl = await imageToDataUrl(media, mime);
            reply(`🖼️ *GPT-4O (Mode Vision)*\n⏳ Sedang menganalisis gambar, mohon tunggu sekitar 30 detik...`);
        } else {
            reply(`🤖 *GPT-4O*\n⏳ OpenAI GPT-4O sedang berpikir, mohon tunggu sekitar 30 detik...`);
        }
        const hasil = await gpt4o(text || "Jelaskan gambar ini", imageDataUrl);
        reply(`🤖 *GPT-4O - Jawaban:*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'Layanan GPT-4O sedang sibuk'}`);
    }
}
break;

case 'openai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} siapa penemu listrik?*`);
    
    reply(`🔓 *OpenAI GPT-4.1*\n⏳ Model terbaru sedang memproses, mohon tunggu sekitar 30-60 detik...`);
    
    const OpenAIPrompt = `hallo ${pushname} Ayo perkenalkan dirimu, saya adalah ${botname} dan Model saya Adalah OpenAI GPT - 4.1 ini, sekaligus saya bukan dep ke orang-orang. Maaf puh`;
    const OpenAI = require("openai");
    const token = "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";
    const endpoint = "https://models.github.ai/inference";
    const model = "openai/gpt-4.1";
    
    async function openai(userPrompt) {
        const client = new OpenAI({ baseURL: endpoint, apiKey: token });
        const response = await client.chat.completions.create({
            messages: [
                { role: "system", content: OpenAIPrompt.trim() },
                { role: "user", content: userPrompt }
            ],
            temperature: 1,
            top_p: 1,
            model: model
        });
        return response.choices[0].message.content.replace(/\*\*(.*?)\*\*/g, '*$1*');
    }
    
    try {
        const hasil = await openai(text);
        reply(`🔓 *OpenAI GPT-4.1 - Jawaban:*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'Layanan OpenAI sedang sibuk'}`);
    }
}
break;

case 'metaai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} siapa penemu sepak bola?*`);
    
    reply(`📘 *Meta AI (Llama 3.1)*\n⏳ Meta Llama sedang berpikir, mohon tunggu sekitar 1-2 menit...`);
    
    const MetaAi = {
        chat: async (question) => {
            let d = new FormData();
            d.append("content", `User: ${question}`);
            d.append("model", "@groq/llama-3.1-8b-instant");
            try {
                let { data } = await axios.post("https://mind.hydrooo.web.id/v1/chat", d, { headers: { ...d.getHeaders() } });
                return data.result || data.full_result || JSON.stringify(data);
            } catch (error) {
                console.error("API Error:", error.response?.data || error.message);
                throw new Error("Gagal mengambil jawaban dari AI.");
            }
        }
    };
    
    try {
        const result = await MetaAi.chat(text);
        await Alice.sendMessage(m.chat, { text: `📘 *Meta AI (Llama 3.1) - Jawaban:*\n\n${result}` }, { quoted: m });
    } catch (error) {
        console.error("Error:", error);
        reply(`❌ *Error:* ${error.message || 'Layanan Meta AI sedang sibuk'}`);
    }
}
break;

case 'gptlogic': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu internet?*`);
    
    reply(`🧠 *GPT Logic*\n⏳ AI Logika sedang memproses, mohon tunggu sebentar...`);
    
    try {
        let response = await axios.post("https://chateverywhere.app/api/chat/", {
            model: { id: "gpt-3.5-turbo-0613", name: "GPT-3.5", maxLength: 12000, tokenLimit: 4000, completionTokenLimit: 2500, deploymentName: "gpt-35" },
            messages: [{ pluginId: null, content: text, role: "user" }],
            prompt: "Kamu adalah AI yang membantu pengguna dalam menjawab pertanyaan dengan akurat.",
            temperature: 0.5
        }, {
            headers: {
                "Accept": "/*/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });
        Alice.sendMessage(m.chat, { text: `🧠 *GPT Logic - Jawaban:*\n\n${response.data}` }, { quoted: m });
    } catch (error) {
        console.error("Error fetching data:", error);
        reply(`❌ *Error:* ${error.message || 'Layanan GPT Logic sedang sibuk'}`);
    }
}
break;

case 'aoyoai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu blockchain?*`);
    
    reply(`🤖 *Aoyo AI*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    try {
        let { data } = await axios.get(`https://www.abella.icu/aoyoai?q=${encodeURIComponent(text)}`);
        if (data?.status !== 'success') return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        let res = data?.data?.response;
        if (!res) return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        reply(`🤖 *Aoyo AI - Jawaban:*\n\n${res}`);
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan Aoyo AI sedang sibuk'}`);
    }
}
break;

case 'chatbotai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} kenapa langit berwarna biru?*`);
    
    reply(`💬 *Chatbot AI*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    try {
        let { data } = await axios.get(`https://www.abella.icu/onlinechatbot?q=${encodeURIComponent(text)}`);
        if (data?.data?.answer?.data) {
            reply(`💬 *Chatbot AI - Jawaban:*\n\n${data.data.answer.data}`);
        } else {
            reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        }
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan Chatbot AI sedang sibuk'}`);
    }
}
break;

case 'blackbox-pro': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} cara kerja neural network?*`);
    
    reply(`📦 *Blackbox Pro AI*\n⏳ AI coding sedang memproses, mohon tunggu sebentar...`);
    
    try {
        let { data } = await axios.get('https://www.abella.icu/blackbox-pro?q=' + encodeURIComponent(text));
        if (data?.status !== 'success') return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        reply(`📦 *Blackbox Pro - Jawaban:*\n\n${data.data.answer.result}`);
    } catch {
        reply(`❌ *Error:* Layanan Blackbox Pro sedang sibuk`);
    }
}
break;

case 'zerogpt': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan tentang GPT*`);
    
    reply(`🔍 *ZeroGPT*\n⏳ Sedang menganalisis teks, mohon tunggu sebentar...`);
    
    try {
        const axios = require('axios');
        const id = () => Math.random().toString(36).slice(2, 18);
        const res = await axios.post('https://zerogptai.org/wp-json/mwai-ui/v1/chats/submit', {
            botId: "default", customId: null, session: "N/A", chatId: id(),
            contextId: 39, messages: [], newMessage: q, newFileId: null, stream: true
        }, {
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': 'e7b64e1953', 'Accept': 'text/event-stream' },
            responseType: 'stream'
        });
        let out = '';
        res.data.on('data', chunk => {
            chunk.toString().split('\n').forEach(line => {
                if (line.startsWith('data: ')) {
                    const data = JSON.parse(line.slice(6));
                    if (data.type === 'live') out += data.data;
                    if (data.type === 'end') reply(`🔍 *ZeroGPT - Hasil Analisis:*\n\n${out.trim()}`);
                }
            });
        });
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan ZeroGPT sedang sibuk'}`);
    }
}
break;

case 'writecream': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa dengan persona tertentu? Gunakan format berikut:\n*${prefix + command} persona|pertanyaan*\nContoh: *${prefix + command} kamu psikolog|aku sering gelisah malam hari, kenapa ya?*`);
    
    const [logic, question] = text.split('|').map(v => v.trim());
    if (!logic || !question) return reply(`❌ Format salah, gunakan:\n*${prefix + command} persona|pertanyaan*`);
    
    reply(`✍️ *WriteCream AI (Persona: ${logic})*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    async function writecream(logic, question) {
        const url = "https://8pe3nv3qha.execute-api.us-east-1.amazonaws.com/default/llm_chat";
        const query = [{ role: "system", content: logic }, { role: "user", content: question }];
        const params = new URLSearchParams({ query: JSON.stringify(query), link: "writecream.com" });
        try {
            const response = await fetch(`${url}?${params.toString()}`);
            const data = await response.json();
            let raw = data.response_content || data.reply || data.result || data.text || '';
            return raw.replace(/\\n/g, '\n').replace(/\n{2,}/g, '\n\n').replace(/\*\*(.*?)\*\*/g, '*$1*').trim();
        } catch (error) {
            return null;
        }
    }
    
    const response = await writecream(logic, question);
    reply(`✍️ *WriteCream AI - Jawaban:*\n\n${response || '❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.'}`);
}
break;

case 'yupraai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu quantum computing?*`);
    
    reply(`🤖 *Yupra AI*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    const timestamp = Date.now();
    const sessionId = m.chat;
    const url = `https://api.yupradev.biz.id/ai/ypai?text=${encodeURIComponent(text)}&t=${timestamp}&session=${sessionId}`;
    
    try {
        const res = await axios.get(url, {
            headers: {
                authority: 'api.yupradev.biz.id', accept: '*/*',
                origin: 'https://ai.yupradev.biz.id', referer: 'https://ai.yupradev.biz.id/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
            }
        });
        const data = res.data;
        const replyText = data.response || data.result || JSON.stringify(data);
        await reply(`🤖 *Yupra AI - Jawaban:*\n\n${replyText.trim()}`);
    } catch (err) {
        console.error(err);
        reply(`❌ *Error:* ${err.message || 'Layanan Yupra AI sedang sibuk'}`);
    }
}
break;

case 'feloai': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} berita terbaru hari ini*`);
    
    reply(`🔍 *Felo AI (Search & Answer)*\n⏳ AI sedang mencari dan merangkum informasi, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        const licefelo = await Felo(q);
        if (licefelo.error) return reply(`❌ Maaf, lagi ada gangguan. Coba beberapa saat lagi ya.`);
        let answer = licefelo.answer || `Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`;
        let sources = licefelo.source.length > 0
            ? `📚 *Sumber Yang Saya Gunakan*:\n${licefelo.source.filter(src => src.link).slice(0, 5).map(src => `_${src.link}_`).join("\n\n")}`
            : "-";
        await Alice.sendMessage(m.chat, { text: `🔍 *Felo AI - Jawaban:*\n\n${answer}\n\n${sources}` });
    } catch (error) {
        console.error(error);
        reply(`❌ *Error:* ${error.message || 'Layanan Felo AI sedang sibuk'}`);
    }
}
break;

case 'aliceai': {
    await XReaction();
    try {
        if (!text) return reply(`Mau tanya apa? Saya bisa menjawab pertanyaan, download media (TikTok/IG/FB/X), search Pinterest, atau buatkan gambar.\nContoh:\n*${prefix + command} apa itu AI?*\n*${prefix + command} https://vt.tiktok.com/xxx*\n*${prefix + command} buatkan gambar pemandangan gunung*\n*${prefix + command} cari gambar pemandangan*`);
        
        let regexTikTok = /(tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com|ut\.tiktok\.com)/i;
        let regexInstagram = /(instagram\.com|instagr\.am)/i;
        let regexFacebook = /(facebook\.com|fb\.com)/i;
        let regexTwitter = /(x\.com|twitter\.com)/i;
        
        let isTikTok = regexTikTok.test(text);
        let isInstagram = regexInstagram.test(text);
        let isFacebook = regexFacebook.test(text);
        let isTwitter = regexTwitter.test(text);
        let isImageReq = /(buatkan gambar|bikin gambar|buat gambar|generate gambar)/i.test(text);
        let isPinterest = /(cari gambar|search gambar|pinterest|pin|gambar|foto)/i.test(text) && !isImageReq;
        let isAnalisisGambar = (quoted && /image/.test(mime || "")) || m.mtype === 'imageMessage';
        
        if (isTikTok) {
            reply(`📹 *Download TikTok*\n⏳ Sedang mengunduh video...`);
            let link = text.match(/(https?:\/\/)?(www\.|vm\.|vt\.)?tiktok\.com\/[^\s]+/i)[0];
            
            try {
                let data = await fg.tiktok(link);
                let json = data.result;
                let caption = `*TIKTOK DOWNLOADER*\n\n◦ ID: ${json.id}\n◦ Author: ${json.author?.nickname}\n◦ Title: ${json.title}`;
                
                if (json.images) {
                    for (let img of json.images) {
                        await Alice.sendMessage(m.chat, { image: { url: img } }, { quoted: m });
                    }
                } else {
                    await Alice.sendMessage(m.chat, { video: { url: json.play }, caption: caption }, { quoted: m });
                }
            } catch (e) {
                let res = await tiktokdl(link);
                if (!res?.video) return reply(`❌ Gagal download TikTok`);
                await Alice.sendMessage(m.chat, { video: { url: res.video }, caption: `*TIKTOK DOWNLOADER*\n\nTitle: ${res.title || '-'}` }, { quoted: m });
            }
        }
        
        else if (isInstagram) {
            reply(`📸 *Download Instagram*\n⏳ Sedang mengunduh media...`);
            let link = text.match(/(https?:\/\/)?(www\.)?instagram\.com\/[^\s]+/i)[0];
            
            try {
                const result = await igdl(link);
                if (result.error) return reply(`❌ Gagal download Instagram`);
                
                if (result.photos?.length) {
                    for (let photo of result.photos) {
                        await Alice.sendMessage(m.chat, { image: { url: photo.url } }, { quoted: m });
                    }
                } else if (result.videos?.length) {
                    for (let video of result.videos) {
                        await Alice.sendMessage(m.chat, { video: { url: video.url } }, { quoted: m });
                    }
                }
            } catch (e) {
                reply(`❌ Gagal download Instagram`);
            }
        }
        
        else if (isFacebook) {
            reply(`📘 *Download Facebook*\n⏳ Sedang mengunduh video...`);
            let link = text.match(/(https?:\/\/)?(www\.)?(facebook|fb)\.com\/[^\s]+/i)[0];
            
            try {
                let res = await fetchJson(`https://api.skyzopedia.web.id/download/facebook?apikey=skyy&url=${encodeURIComponent(link)}`);
                if (!res?.result) return reply(`❌ Gagal download Facebook`);
                let videoUrl = res.result.video?.[0]?.url || res.result.media;
                if (!videoUrl) return reply(`❌ Gagal download Facebook`);
                await Alice.sendMessage(m.chat, { video: { url: videoUrl }, caption: `*FACEBOOK DOWNLOADER*\n\nTitle: ${res.result.title}` }, { quoted: m });
            } catch (e) {
                reply(`❌ Gagal download Facebook`);
            }
        }
        
        else if (isTwitter) {
            reply(`🐦 *Download Twitter/X*\n⏳ Sedang mengunduh video...`);
            let link = text.match(/(https?:\/\/)?(www\.)?(x\.com|twitter\.com)\/[^\s]+/i)[0];
            
            try {
                const res = await twitterDl(link);
                if (res.error || !res.videos?.length) return reply(`❌ Gagal download Twitter`);
                await Alice.sendMessage(m.chat, { video: { url: res.videos[0].url }, caption: `*TWITTER DOWNLOADER*\n\nDurasi: ${res.metadata?.duration}` }, { quoted: m });
            } catch (e) {
                reply(`❌ Gagal download Twitter`);
            }
        }
        
        else if (isImageReq) {
            reply(`🎨 *Generate Gambar*\n⏳ AI sedang membuat gambar, mohon tunggu...`);
            
            try {
                let prompt = text.replace(/buatkan gambar|bikin gambar|buat gambar|generate gambar/gi, '').trim();
                let url = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(prompt)}`;
                let res = await fetch(url);
                let buff = await res.arrayBuffer();
                let ct = res.headers.get("content-type") || "";
                
                if (ct.includes("image")) {
                    return await Alice.sendMessage(m.chat, { image: Buffer.from(buff), caption: `🎨 *Hasil Gambar*\n\nPrompt: ${prompt}` }, { quoted: m });
                }
                
                let json = JSON.parse(Buffer.from(buff).toString());
                let img = json.url || json.result || json.image || json.data;
                if (!img) return reply(`❌ Gagal membuat gambar`);
                
                await Alice.sendMessage(m.chat, { image: { url: img }, caption: `🎨 *Hasil Gambar*\n\nPrompt: ${prompt}` }, { quoted: m });
            } catch (e) {
                reply(`❌ Gagal membuat gambar: ${e.message}`);
            }
        }
        
        else if (isPinterest) {
            reply(`🔍 *Pinterest Search*\n⏳ Sedang mencari gambar, mohon tunggu sebentar...`);
            
            try {
                let keyword = text.replace(/cari gambar|search gambar|pinterest|pin|gambar|foto/gi, '').trim();
                if (!keyword) return reply(`Contoh: *${prefix + command} cari gambar pemandangan*`);
                
                let results = [];
                
                try {
                    let r = await axios.get(`https://api-faa.my.id/faa/pinterest?q=${encodeURIComponent(keyword)}`);
                    if (r.data?.result?.length) results = r.data.result;
                } catch {}
                
                if (!results.length) {
                    let r = await axios.get(`https://api.zenzzx.my.id/api/search/pinterest?query=${encodeURIComponent(keyword)}`);
                    if (r.data?.data?.length) results = r.data.data.map(v => v.directLink);
                }
                
                if (!results.length) return reply("❌ Tidak ditemukan hasil.");
                
                let img = results[Math.floor(Math.random() * results.length)];
                
                await Alice.sendMessage(m.chat, {
                    image: { url: img },
                    caption: `📌 *Hasil Pinterest*\n\n✨ Keyword: *${keyword}*`,
                    footer: 'Pinterest Search',
                    buttons: [
                        { buttonId: `${prefix}aliceai cari gambar ${keyword}`, buttonText: { displayText: '🔄 Next' }, type: 1 }
                    ],
                    headerType: 4
                }, { quoted: m });
            } catch (e) {
                reply(`❌ Gagal mencari gambar: ${e.message}`);
            }
        }
        
        else if (isAnalisisGambar) {
    reply(`🖼️ *AI Vision (GPT-4O)*\n⏳ Menganalisis gambar, mohon tunggu sebentar...`);

    try {
        let imageDataUrl = "";
        let userPrompt = text && text.trim() !== "" ? text : "Jelaskan gambar ini secara detail";

        const media = (quoted && /image/.test(mime || "")) ? await quoted.download() : await m.download();
        imageDataUrl = await imageToDataUrl(media, mime);

        const hasil = await gpt4o(userPrompt, imageDataUrl);
        reply(`💭 *Hasil Analisis Gambar (GPT-4O):*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        reply(`❌ Gagal menganalisis gambar: ${e.message}`);
    }
}
        
        else {
            reply(`🤖 *Alice AI*\n⏳ Sedang berpikir, mohon tunggu sebentar...`);
            
            try {
                let url = `https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(text)}`;
                let r = await fetch(url);
                let j = await r.json();
                let hasil = j?.result || j?.data?.result || j?.response || 'Hmm, aku belum nemu jawabannya';
                reply(`💭 *Jawaban:*\n\n${hasil}`);
            } catch (e) {
                reply(`❌ Gagal mendapatkan jawaban: ${e.message}`);
            }
        }
    } catch (e) {
        console.error(e);
        reply(`❌ Error: ${e.message || 'Layanan sibuk'}`);
    }
}
break;

case 'magicstudio': {
    await XReaction();
    if (!args[0]) return reply(`Mau bikin gambar apa? Ketik deskripsinya setelah *${prefix + command}*\nContoh: *${prefix + command} wanita sedang memegang botol cocacola*`);
    
    let prompt = encodeURIComponent(args.join(' '));
    const fs = require('fs');
    
    reply(`✨ *MagicStudio - Generate Gambar*\n⏳ AI sedang membuat gambar, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        let res = await fetch(`https://api.siputzx.my.id/api/ai/magicstudio?prompt=${prompt}`);
        let contentType = res.headers.get('content-type');
        if (contentType && contentType.startsWith('image')) {
            let buffer = await res.buffer();
            if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');
            let filePath = `./tmp/${Date.now()}.jpg`;
            fs.writeFileSync(filePath, buffer);
            await Alice.sendFile(m.chat, filePath, 'magicStudio.jpg', `✨ *Hasil Gambar*\n\nPrompt: ${args.join(' ')}`, xy);
            fs.unlinkSync(filePath);
        } else {
            reply(`❌ Hmm, tidak ada hasil gambar saat ini.`);
        }
    } catch (e) {
        console.error('Fetch Error:', e);
        reply(`❌ *Error:* ${e.message || 'Layanan MagicStudio sedang sibuk'}`);
    }
}
break;

case 'gemmaai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan cara kerja komputer*`);
    
    reply(`🔬 *Gemma AI (Google)*\n⏳ Gemma 2 9B sedang berpikir, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        const res = await fetch(`https://www.velyn.biz.id/api/ai/gemma-2-9b-it?prompt=${encodeURIComponent(text)}`);
        if (res.ok) {
            const json = await res.json();
            if (json.status) {
                await Alice.sendMessage(m.chat, { text: `🔬 *Gemma AI - Jawaban:*\n\n${json.data}` }, { quoted: m });
            } else {
                reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
            }
        } else {
            reply(`❌ Maaf, lagi ada gangguan.`);
        }
    } catch (e) {
        reply(`❌ *Error:* ${e.message || 'Layanan Gemma AI sedang sibuk'}`);
        console.error(e);
    }
}
break;

case 'muslimai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa seputar Islam? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa hukum sholat jumat?*`);
    
    reply(`🕌 *Muslim AI*\n⏳ AI berbasis Islam sedang mencari jawaban, mohon tunggu sebentar...`);
    
    try {
        const result = await muslimai(text);
        if (result.error) return reply(`❌ Maaf, lagi ada gangguan.`);
        reply(`🕌 *Muslim AI - Jawaban:*\n\n${result.answer}`);
    } catch (error) {
        console.error("⚠ *Error* :", error);
        reply(`❌ *Error:* ${error.message || 'Layanan Muslim AI sedang sibuk'}`);
    }
}
break;

case 'llama-ai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu llama AI?*`);
    
    reply(`🦙 *Llama AI (Meta)*\n⏳ Llama sedang berpikir, mohon tunggu sekitar 1-2 menit...`);
    
    try {
        let response = await fetch(`https://restapii.rioooxdzz.web.id/api/llama?message=${encodeURIComponent(text)}`);
        if (!response.ok) throw new Error("Request to API failed");
        let result = await response.json();
        await Alice.sendMessage(m.chat, { text: `🦙 *Llama AI - Jawaban:*\n\n${result.data.response}` });
    } catch (error) {
        await Alice.sendMessage(m.chat, { text: `❌ *Error:* ${error.message || 'Layanan Llama AI sedang sibuk'}` });
    }
}
break;

case 'gptturbo': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu GPT Turbo?*`);
    
    reply(`⚡ *GPT Turbo*\n⏳ GPT versi turbo sedang memproses, mohon tunggu sebentar...`);
    
    async function gptturbo(query) {
        const apiUrl = `https://restapii.rioooxdzz.web.id/api/gptturbo?message=${encodeURIComponent(query)}`;
        try {
            const response = await fetch(apiUrl, {
                method: 'GET',
                headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36" }
            });
            if (!response.ok) throw new Error(`Error: ${response.status}`);
            const responseJson = await response.json();
            return responseJson?.data?.response || `❌ Hmm, tidak ada jawaban.`;
        } catch (error) {
            console.error("Terjadi kesalahan:", error.message);
            return null;
        }
    }
    
    const gpiti = await gptturbo(text);
    if (!gpiti) return reply(`❌ Maaf, lagi ada gangguan.`);
    
    await Alice.sendMessage(m.chat, {
        text: `⚡ *GPT Turbo - Jawaban:*\n\n${gpiti}`,
        contextInfo: {
            externalAdreply: {
                title: "GPT - TURBO", body: '',
                thumbnailUrl: "https://pomf2.lain.la/f/jzv6iqu.jpg",
                sourceUrl: null, mediaType: 1, renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
}
break;

case 'gemini-ai': {
    await XReaction();
    const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
    const isImage = m.mtype === 'imageMessage';
    const quoted = m.quoted ? m.quoted : m;
    
    if (isImage || isQuotedImage) {
        reply(`🖼️ *Gemini AI (Mode Vision)*\n⏳ Menganalisis gambar, mohon tunggu sekitar 30 detik...`);
        try {
            let buffer = await quoted.download();
            let url = await uploadToAliceCdn(buffer, `gemini_${Date.now()}.jpg`);
            const response = await axios.get('https://gemini-api-5k0h.onrender.com/gemini/image', {
                params: { q: 'What is this picture? Please describe it.', url: url }
            });
            const description = response.data?.content || `❌ Hmm, tidak ada deskripsi yang bisa diberikan.`;
            await Alice.sendMessage(m.chat, { text: `🖼️ *Gemini AI - Deskripsi Gambar:*\n${description}` }, { quoted: m });
        } catch (error) {
            console.error(error);
            reply(`❌ *Error:* ${error.message || 'Layanan Gemini AI sedang sibuk'}`);
        }
    } else {
        if (!text) return reply(`Mau tanya apa? Saya juga bisa menganalisis gambar yang kamu kirim.\nContoh: *${prefix + command} siapa jokowi?*`);
        
        reply(`🤖 *Gemini AI (Google)*\n⏳ Gemini Pro sedang berpikir, mohon tunggu sekitar 30-60 detik...`);
        
        try {
            const response = await axios.get('https://gemini-api-5k0h.onrender.com/gemini/chat', { params: { q: text } });
            const replyText = response.data?.content || `❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`;
            await Alice.sendMessage(m.chat, { text: `🤖 *Gemini AI - Jawaban:*\n${replyText}` }, { quoted: m });
        } catch (error) {
            console.error(error);
            reply(`❌ *Error:* ${error.message || 'Layanan Gemini AI sedang sibuk'}`);
        }
    }
}
break;

case 'lumin-ai': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu dark matter?*`);
    
    reply(`✨ *Lumin AI*\n⏳ AI sedang memproses, mohon tunggu sebentar...`);
    
    try {
        const aliceeai = await Eai(q);
        if (!aliceeai) return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        await reply(`✨ *Lumin AI - Jawaban:*\n\n${aliceeai}`);
    } catch (error) {
        console.error("Error Saat Mendapatkan Data :", error.message);
        reply(`❌ *Error:* ${error.message || 'Layanan Lumin AI sedang sibuk'}`);
    }
}
break;

case 'typli-ai': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} jelaskan tentang fotosintesis*`);
    
    reply(`✍️ *Typli AI (Content Writer)*\n⏳ AI penulis sedang memproses, mohon tunggu sekitar 30-60 detik...`);
    
    const avz = async (prompt) => {
        const config = {
            method: 'post',
            url: 'https://typli.ai/api/generators/completion',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            data: JSON.stringify({ prompt: prompt, temperature: 1.2 })
        };
        try {
            const response = await axios(config);
            return response.data;
        } catch (error) {
            console.error("Fetch error:", error.response ? error.response.data : error.message);
            throw error;
        }
    };
    
    try {
        const answer = await avz(q);
        reply(`✍️ *Typli AI - Jawaban:*\n\n${answer}`);
    } catch (error) {
        reply(`❌ *Error:* ${error.message || 'Layanan Typli AI sedang sibuk'}`);
    }
}
break;

case 'poly-ai': {
    await XReaction();
    if (!q) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} ceritakan tentang luar angkasa*`);
    
    reply(`🎭 *Poly AI (Character Chat)*\n⏳ Karakter AI sedang merespon, mohon tunggu sebentar...`);
    
    async function polybuzzAi(prompt) {
        let data = new URLSearchParams();
        data.append('currentChatStyleId', '1');
        data.append('mediaType', '2');
        data.append('needLive2D', '2');
        data.append('secretSceneId', 'wHp7z');
        data.append('selectId', '209837277');
        data.append('speechText', prompt);
        let headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            'Cookie': 'session=9997156d23496b9ff96fc09d162191f74821790eaa4ecc52096273a60f517ad3',
        };
        try {
            let { data: respon } = await axios.post('https://api.polybuzz.ai/api/conversation/msgbystream', data, { headers });
            return respon.split('\n').filter(line => line.trim()).map(line => {
                try { return JSON.parse(line.trim()).content || '' } catch (e) { return '' }
            }).join('');
        } catch (e) {
            console.error(e);
            return null;
        }
    }
    
    try {
        const answer = await polybuzzAi(q);
        if (!answer) return reply(`❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`);
        reply(`🎭 *Poly AI - Respon Karakter:*\n\n${answer}`);
    } catch (error) {
        reply(`❌ *Error:* ${error.message || 'Layanan Poly AI sedang sibuk'}`);
    }
}
break;

case 'chatevery-where': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu axios?*`);
    
    reply(`💬 *ChatEveryWhere AI*\n⏳ GPT-3.5 Turbo sedang memproses, mohon tunggu sebentar...`);
    
    async function sanzmd(prompt) {
        const response = await axios({
            method: "POST",
            url: "https://chateverywhere.app/api/chat",
            headers: {
                "Content-Type": "application/json",
                "Cookie": "_ga=GA1.1.34196701.1707462626;",
                Origin: "https://chateverywhere.app",
                Referer: "https://chateverywhere.app/id",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
            },
            data: {
                model: { id: "gpt-3.5-turbo-0613", name: "GPT-3.5", maxLength: 12000, tokenLimit: 4000 },
                prompt: prompt,
                messages: [
                    { pluginId: null, content: prompt, role: "user" },
                    { pluginId: null, content: `${botname} adalah programmer yang berasal dari Sumatera Selatan, Indonesia.`, role: "assistant" }
                ]
            }
        });
        return response.data;
    }
    
    try {
        let jut = await sanzmd(text);
        reply(`💬 *ChatEveryWhere AI - Jawaban:*\n\n${jut}`);
    } catch (error) {
        reply(`❌ *Error:* ${error.message || 'Layanan ChatEveryWhere sedang sibuk'}`);
    }
}
break;

case 'gemini-pro': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} apa itu chatgpt?*`);
    
    reply(`🤖 *Gemini Pro AI*\n⏳ Gemini Pro sedang berpikir, mohon tunggu sebentar...`);
    
    async function fetchWithModel(content, model, token) {
        try {
            const response = await axios.post('https://luminai.my.id/', { content, model, headers: { 'Authorization': `Bearer ${token}` } });
            return response.data;
        } catch (error) {
            console.error(error);
            throw error;
        }
    }
    
    fetchWithModel(text, 'gemini-pro', '8be9e34764cd2fc4e6bcfb1bf6a945efe30406573a92d8ef0ec1613dc0e54876')
        .then(data => reply(`🤖 *Gemini Pro - Jawaban:*\n\n${data.result}`))
        .catch(() => reply(`❌ *Error:* Layanan Gemini Pro sedang sibuk`));
}
break;

case 'ai': {
    await XReaction();
    if (!text && !quoted) return reply(`Mau tanya apa? Saya juga bisa menganalisis gambar yang kamu kirim.\nContoh: *${prefix + command} siapa einstein?*`);
    
    try {
        let isImage = false;
        let imageDataUrl = "";
        
        if (quoted && /image/.test(mime || "")) {
            isImage = true;
            const media = await quoted.download();
            imageDataUrl = await imageToDataUrl(media, mime);
            reply(`🖼️ *AI Vision Mode*\n⏳ Menganalisis gambar, mohon tunggu sebentar...`);
        } else if (m.mtype === 'imageMessage') {
            isImage = true;
            const media = await m.download();
            imageDataUrl = await imageToDataUrl(media, mime);
            reply(`🖼️ *AI Vision Mode*\n⏳ Menganalisis gambar, mohon tunggu sebentar...`);
        } else {
            if (!text) return reply(`Mau tanya apa?`);
            reply(`🤖 *AI Mode*\n⏳ AI sedang berpikir, mohon tunggu sebentar...`);
        }
        
        let hasil;
        
        if (isImage) {
            hasil = await gpt4o(text || "Jelaskan gambar ini", imageDataUrl);
            reply(`💭 *AI - Hasil Analisis Gambar:*\n\n${hasil}`);
        } else {
            let url = `https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(text)}`;
            let r = await fetch(url);
            let j = await r.json();
            hasil = j?.result || j?.data?.result || j?.response || 'Hmm, aku belum nemu jawabannya';
            reply(`💭 *AI - Jawaban:*\n\n${hasil}`);
        }
    } catch (e) {
        console.error(e);
        reply(`❌ *Error:* ${e.message || 'Layanan AI sedang sibuk'}`);
    }
}
break;

case 'allam-ai': {
    await XReaction();
    if (!text) return reply(`Mau tanya apa? Ketik pertanyaanmu setelah *${prefix + command}*\nContoh: *${prefix + command} siapa prabowo?*`);
    
    reply(`📚 *Allam AI 2.7B*\n⏳ Model sedang memproses, mohon tunggu sebentar...`);
    
    try {
        const response = await axios.get(`https://www.velyn.mom/api/ai/allam-2-7b`, {
            params: { apikey: global.apikey.velyn, prompt: text }
        });
        const hasil = response.data?.data?.result || response.data?.result || `❌ Hmm, tidak ada jawaban yang bisa saya berikan saat ini.`;
        await Alice.sendMessage(m.chat, { text: `📚 *Allam AI - Jawaban:*\n\n${hasil}` }, { quoted: m });
    } catch (error) {
        console.error(error);
        reply(`❌ *Error:* ${error.message || 'Layanan Allam AI sedang sibuk'}`);
    }
}
break;

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Ai Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Berita Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'berita-bola':
case 'vivagoal': {
await XReaction();

  try {
    const res = await axios.get('https://api.zenzxz.my.id/berita/berita-bola')
    const data = res.data.result
    if (!data || !data.length) return reply('🙅 Tidak ada berita ditemukan.')

    let teks = `⚽ *Berita Bola Terbaru (Vivagoal)*\n\n`
    data.slice(0, 5).forEach((v, i) => {
      teks += `${i+1}. *${v.title}*\n🕒 ${v.published}\n🔗 ${v.link}\n\n`
    })

    await Alice.sendMessage(m.chat, { text: teks }, { quoted: m })
  } catch (e) {
    console.error('berita-bola error:', e.message)
    reply('❌ Gagal mengambil berita bola.')
  }
}
break
case 'vivagoal-detail': {

  if (!text) return reply('⚠️ Contoh: *.vivagoal-detail https://vivagoal.com/...*')

  try {
    const res = await axios.get(`https://api.zenzxz.my.id/berita/vivagoal/detail?url=${encodeURIComponent(text)}`)
    const v = res.data.result
    if (!v) return reply('🙅 Detail berita tidak ditemukan.')

    let teks = `📰 *${v.title}*\n\n`
    teks += `${v.content?.slice(0, 500)}...\n\n`
    teks += `📅 ${v.date}\n👤 Penulis: ${v.author || '-'}\n🔗 ${text}`

    await Alice.sendMessage(m.chat, { image: { url: v.thumbnail }, caption: teks }, { quoted: m })
  } catch (e) {
    console.error('vivagoal-detail error:', e.message)
    reply('❌ Gagal ambil detail berita Vivagoal.')
  }
}
break
case 'cnnindonesia':
case 'cnn': {
await XReaction();

  try {
    const scraper = new CNNNews()

    const data = await scraper.scrape()
    if (!data || !data.length)
      return reply('🙅 Tidak ada berita CNN.')

    let teks = `📰 *Berita CNN Indonesia*\n\n`

    data.slice(0, 5).forEach((v, i) => {
      teks += `${i + 1}. *${v.title}*\n`
      teks += `📂 ${v.category}\n`
      teks += `🔗 ${v.url}\n\n`
    })

    await Alice.sendMessage(
      m.chat,
      {
        image: { url: data[0].image },
        caption: teks
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('cnn error:', e.message)
    reply('❌ Gagal mengambil berita CNN Indonesia.')
  }
}
break
case 'cnnindonesia-detail':
case 'cnn-detail': {

  if (!text)
    return reply(
      '⚠️ Contoh: *.cnn-detail nomor*\n' +
      'Ambil nomor dari .cnn'
    )

  try {
    const scraper = new CNNNews()

    const data = await scraper.scrape()
    const index = parseInt(text) - 1

    if (!data[index])
      return reply('🙅 Berita tidak ditemukan.')

    const v = data[index]

    let teks = `📰 *${v.title}*\n\n`

    teks += `${v.content.join('\n\n')}\n\n`
    teks += `📅 ${v.date}\n`
    teks += `👤 Penulis: ${v.author || '-'}\n`
    teks += `🔗 ${v.url}`

    await Alice.sendMessage(
      m.chat,
      {
        image: { url: v.image },
        caption: teks
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(
      'cnn-detail error:',
      e.message
    )
    reply('❌ Gagal ambil detail berita.')
  }
}
break
case "nasa": {
await XReaction();
async function nasaNews() {
try {
const anu = await axios.get("https://www.nasa.gov/news/releases/latest/index.html")
const $ = cheerio.load(anu.data)
const dbres = []

$(".hds-content-item").each((a, b) => {
const judul = $(b).find(".hds-a11y-heading-22").text()
const desc = $(b).find("p").text()
const link = $(b).find(".hds-content-item-inner a").attr("href")
dbres.push({ judul, desc, link })
})

return dbres
} catch (err) {
console.log(err)
}
}
const res = await nasaNews()
if (res.length === 0) return Alice.sendMessage(m.chat, { text: "Gagal Mengambil Berita" }, { quoted:m })
await Alice.sendMessage(m.chat, { text: "HASIL SEARCH\n\n"+res.map(a => `> JUDUL: ${a.judul}\n> DESCRIPTION: ${a.desc}\n> LINK: ${a.link}`).join("\n\n") }, { quoted: m})
}
break
case 'metrotv': {
await XReaction();
  try {
    const axios = require('axios')
    const cheerio = require('cheerio')
    const baseURL = 'https://www.metrotvnews.com'
    const { data } = await axios.get(baseURL)
    const $ = cheerio.load(data) 
    const terbaru = []
    const detailList = []
    const links = []
    $('.main-news .big-news-carousel .news-item, .main-news .small-news .news-item').each((i, el) => {
      const title = $(el).find('h1 a, h2 a').text().trim()
      const url = $(el).find('h1 a, h2 a').attr('href')
      const img = $(el).find('img').attr('src') || ''
      const kategori = $(el).find('.news-category').text().trim()
      if (title && url) {
        const fullUrl = url.startsWith('http') ? url : baseURL + url
        terbaru.push({
          title,
          url: fullUrl,
          thumbnail: img.startsWith('http') ? img : baseURL + img,
          kategori
        })
        links.push(fullUrl)
      }
    })
    const url = links[0]
    const detailRes = await axios.get(url)
    const _$ = cheerio.load(detailRes.data)
    let scriptData = ''
    _$('script').each((i, el) => {
      const html = _$(el).html()
      if (html.includes('dimension6')) scriptData = html
    })
    const detail = {
      title: _$('meta[property="og:title"]').attr('content') || '',
      description: _$('meta[property="og:description"]').attr('content') || '',
      image: _$('meta[property="og:image"]').attr('content') || '',
      publishedAt: scriptData.match(/'dimension6':\s*'([^']+)'/)?.[1] || '',
      author: scriptData.match(/'dimension5':\s*'([^']+)'/)?.[1] || '',
      category: scriptData.match(/'dimension7':\s*'([^']+)'/)?.[1] || '',
      content: []
    }
    _$('.news > p').each((i, el) => {
      const text = _$(el).text().trim()
      if (text) detail.content.push(text)
    })
    let teks = `*Berita Terbaru MetroTV*\n\n`
    for (let i = 0; i < terbaru.length; i++) {
      teks += `*${i + 1}. ${terbaru[i].title}*\n`
      teks += `Kategori: ${terbaru[i].kategori}\n`
      teks += `Link: ${terbaru[i].url}\n\n`
    }

    await Alice.sendMessage(m.chat, {
      text: teks,
      contextInfo: {
        externalAdreply: {
          title: "Berita MetroTV",
          body: "Klik untuk baca selengkapnya",
          thumbnailUrl: terbaru[0].thumbnail,
          sourceUrl: terbaru[0].url,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })
    let teksDetail = `*${detail.title}*\n\n`
    teksDetail += `${detail.description}\n\n`
    teksDetail += `Kategori: ${detail.category}\nPenulis: ${detail.author}\nTanggal: ${detail.publishedAt}\n\n`
    teksDetail += detail.content.slice(0, 5).join('\n\n') + '\n\n_Selengkapnya di link berita._'

    await Alice.sendMessage(m.chat, {
      image: { url: detail.image },
      caption: teksDetail
    }, { quoted: m })
    } catch (error) {
        reply(`eror`);
    }
}
break
case 'liputan6': {
await XReaction();
    const axios = require('axios');
    const cheerio = require('cheerio');

    async function avzz() {
        try {
// wm avs                  
            const AvoskyBaik = await axios.get('https://www.liputan6.com/');
            const $ = cheerio.load(AvoskyBaik.data);
// wm avs
            const latestNews = $('.articles--iridescent-list').eq(2).find('article');
// wm avs
            const results = [];
            latestNews.each(function () {
                try {
                    const title = $(this).find('figure a').attr('title');
                    const link = $(this).find('figure a').attr('href');
                    const image = $(this).find('figure a picture img').attr('data-src');
                    const tag = $(this).find('aside header a').text();
// wm avs
                    results.push({ title, link, tag, image, source: 'liputan6' });
                } catch (e) {
// wm avs
                    console.error('Error scraping article:', e);
                }
            });
// wm avs
            return results;
        } catch (error) {
            console.error('Error fetching:', error);
            return [];
        }
    }
// wm avs
    avzz()
        .then(results => {
            if (results.length === 0) {
                reply('Tidak ada berita terbaru yang ditemukan.');
            } else {
                let message = 'Berita Terbaru dari Liputan6:\n\n';
                results.forEach((news, index) => {
                    message += `${index + 1}. ${news.title}\n`;
                    message += `Tag: ${news.tag}\n`;
                    message += `Link: ${news.link}\n`;
                    message += `Gambar: ${news.image}\n\n`;
                });
                reply(message);
            }
        })
        .catch(error => {
            console.error('ada bug:', error.message);
            reply('Terjadi kesalahan...');
        });
}
    break    
    
case 'merdekanews': {
await XReaction();
const fetch = require('node-fetch');
const cheerio = require('cheerio');
async function merdekaavs() {
  try {
    const res = await fetch('https://www.merdeka.com/rss');
    const $ = cheerio.load(await res.text(), { xmlMode: true });
    const channel = {
      title: $('channel > title').text(),
      description: $('channel > description').text(),
      link: $('channel > link').text(),
      image: $('channel > image > url').text(),
    };
    const items = $('item').map((_, el) => ({
      title: 'Title:'+ $(el).find('title').text(),
      link: 'Link:'+ $(el).find('link').text(),
      description: 'Deskripsi:'+ $(el).find('description').text(),
      pubDate: 'Post'+ $(el).find('pubDate').text(),
      image: $(el).find('enclosure').attr('url') || null
    })).get();
    return { channel, total: items.length, data: items };
  } catch {
    return { message: 'Something went wrong' };
  }
}
let lily = await merdekaavs()
      let results = lily.data 
        if (results.length > 0) {
        let message = `Hasil dari pencarian merdeka.com :\n\n`;
        results.forEach((result, index) => {
        message += `${result.title}${result.description}${result.link}\n\n`;
        });
    reply(message)
 } else {
reply('Tidak Ada Hasil.');
}
}
break

case 'malaymail': {
await XReaction();
    reply('_Mencari berita terkini di Malay Mail_');

    try {
        const { data } = await axios.get('https://www.malaymail.com/');
        const $ = cheerio.load(data);

        const newsItems = [];
        $('.article-title a').each((index, element) => {
            const title = $(element).text().trim();
            const link = $(element).attr('href');
            newsItems.push({ title, link });
        });

        if (newsItems.length === 0) {
            throw new Error('Gada Berita Baru');
        }

        let beritaText = 'Berita Terkini dari Malay Mail:\n\n';
        newsItems.forEach((item, index) => {
            beritaText += `${index + 1}. ${item.title}\n`;
            beritaText += `Link: ${item.link}\n\n`;
        });

        reply(beritaText);
    } catch (error) {
        reply(`${error.message}`);
    }
}
break;

case 'vietnamnews': {
await XReaction();
    reply('_Mencari berita terkini di Vietnam News..._'); 
    try {
        const { data } = await axios.get('https://vietnamnews.vn/');
        const $ = cheerio.load(data);
        const newsItems = [];
        $('h3 a').each((index, element) => {
            const title = $(element).text().trim();
            const link = $(element).attr('href');
            if (title && link) {
                newsItems.push({ title, link: `${link}` });
            }
        });
        if (newsItems.length === 0) {
            throw new Error('Tidak ad..');
        }
        let beritaText = 'Berita Terkini dari Vietnam News:\n\n';
        newsItems.forEach((item, index) => {
            beritaText += `${index + 1}. ${item.title}\n`;
            beritaText += `Link: ${item.link}\n\n`;
        });        
        reply(beritaText);
    } catch (error) {
        reply(`Error: ${error.message}`);
    }
}
break;

case 'kontan': {
await XReaction();
if (!q) return reply(`_cari berita apa_`)
const axios = require('axios');
const cheerio = require('cheerio');
async function avzzzzz(text, m) {
    const maxRetries = 3;
    let attempts = 0;

    while (attempts < maxRetries) {
        try {
            const { data } = await axios.get(`https://www.kontan.co.id/search?search=${encodeURIComponent(text)}`, {
                timeout: 2000,
            });

            const $ = cheerio.load(data);
            const results = [];

            $('.list-berita ul li').each((index, element) => {
                const titleElement = $(element).find('h1 a');
                const title = titleElement.text().trim();
                const link = titleElement.attr('href');

                if (title && link) {
                    results.push({ title, link: `https:${link}` });
                }
            });

            if (results.length > 0) {
                let message = 'Hasil pencarian:\n\n';
                results.forEach((result, index) => {
                    message += `${index + 1}. ${result.title}\n${result.link}\n\n`;
                });
                reply(message);
            } else {
                reply('Tidak Ada Hasil.');
            }

            return;
        } catch (error) {
            attempts++;
            if (attempts >= maxRetries) {
                reply(`Error: ${error.message}`);
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
}
avzzzzz(`${encodeURIComponent(text)}`, m);
}
break

case 'indozone': {
await XReaction();
    if (!q) return reply(`_cari berita apa_`);
    const axios = require('axios');
    const cheerio = require('cheerio');
    async function fadami(query, m) {
        const maxRetries = 3;
        let attempts = 0;
        while (attempts < maxRetries) {
            try {
                const { data } = await axios.get(`https://fadami.indozone.id/search?q=${encodeURIComponent(query)}`, {
                    timeout: 2000,
                });
                const $ = cheerio.load(data);
                const results = [];
                $('.latest__item').each((index, element) => {
                    const titleElement = $(element).find('.latest__title a');
                    const title = titleElement.text().trim();
                    const link = titleElement.attr('href');
                    const imgElement = $(element).find('.latest__img img');
                    const imgSrc = imgElement.data('src');
                    
                    if (title && link && imgSrc) {
                        results.push({ title, link: `${link}`, imgSrc });
                    }
                });
                if (results.length > 0) {
                    let message = 'Hasil pencarian:\n\n';
                    results.forEach((result, index) => {
                        message += `${index + 1}. ${result.title}\nLink: ${result.link}\nJpg: ${result.imgSrc}\n\n`;
                    });
                    reply(message);
                } else {
                    reply('Tidak Ada Hasil.');
                }
                return;
            } catch (error) {
                attempts++;
                if (attempts >= maxRetries) {
                    reply(`Error: ${error.message}`);
                }
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    }
    fadami(q, m);
}
break
                
case 'detik': {
await XReaction();

DetikNews().then(async(res) => {
let no = 0
let teks_berita = ""
for (let i of res) {
no += 1
teks_berita += `\n• ${no.toString()} •\n`
teks_berita += `Berita: ${i.berita}\n`
teks_berita += `Upload: ${i.berita_diupload}\n`
teks_berita += `Link: ${i.berita_url}\n`
}
teks_berita += ""
Alice.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks_berita }, { quoted: m })
})
}
break
case 'cnbc': {
await XReaction();

CNBCNews().then(async(res) => {
let no = 0
teks_berita = ""
for (let i of res) {
no += 1
teks_berita += `\n• ${no.toString()} •\n`
teks_berita += `Berita: ${i.berita}\n`
teks_berita += `Upload: ${i.berita_diupload}\n`
teks_berita += `Link: ${i.berita_url}\n`
}
teks_berita += ""
Alice.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks_berita }, { quoted: m })
})
}
break
case 'cnn': {
await XReaction();

CNNNews().then(res => {
let no = 0
teks_berita = ""
for (let i of res) {
no += 1
teks_berita += `\n• ${no.toString()} •\n`
teks_berita += `Berita: ${i.berita}\n`
teks_berita += `Link: ${i.berita_url}\n`
}
teks_berita += ""
reply(teks_berita) 
})
}
break
case 'inews': {
await XReaction();
if (!q) return reply(`_penculikan anak/berita lainnya_`)
    const query = args.join(" ");
  await aviz(query).then(results => {
        if (results.length === 0) {
            reply("Tidak ada hasil ditemukan.");
        } else {
            let avosky = "Hasil pencarian berita iNews:\n\n";
            results.forEach((result, index) => {
                avosky += `${index + 1}. *${result.title}*\n`;
                avosky += `📅 ${result.date}\n`;
                avosky += `🔗 [Baca lebih lanjut](${result.url})\n`;
                avosky += `🖼️ Gambar: ${result.imgUrl}\n\n`;
            });
            reply(avosky);
        }
    });
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Berita Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Push Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'pushkontak': {
await XReaction();
if (!isOwner) return XRO()
if (!m.isGroup) return XRG()
if (!text) return reply("PESAN PUSHKON NYA?")
var teks = text
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup Dengan Delay 6 Detik/Chat`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./AliceDatabase/users-db/contacts.json', JSON.stringify(contacts))
await Alice.sendMessage(mem, {text: teks}, {quoted: fkontak})
await sleep(6000)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER [ ${global.ownername} ] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await Alice.sendMessage(m.sender, { document: fs.readFileSync("./AliceDatabase/users-db/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./AliceDatabase/users-db/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", "")
}}
break
case 'pushkontak2': {
await XReaction();
    if (!isOwner) return XRO();
    
    if (!text) {
        return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1000 = 1 Detik\nketik *.getidgc* untuk melihat id grup");
    }

    const parts = text.split("|");
    if (parts.length < 3) {
        return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1000 = 1 Detik\nketik *.getidgc* untuk melihat id grup");
    }

    const idnya = parts[0];
    const delay = Number(parts[1]);
    const teks = parts[2];

    if (!idnya.endsWith("@g.us")) {
        return reply("Format ID Grup Tidak Valid");
    }

    if (isNaN(delay)) {
        return reply("Format Delay Tidak Valid");
    }

    if (!teks) {
        return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1000 = 1 Detik\nketik *.getidgc* untuk melihat id grup");
    }

    let groupMetadataa;
    try {
        groupMetadataa = await Alice.groupMetadata(idnya);
    } catch (e) {
        return reply("*ID Grup* tidak valid!");
    }

    const participants = groupMetadataa.participants;
    const halls = participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
    
    reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`);

    const contacts = [];
    for (let mem of halls) {
        if (mem !== m.sender) {
            contacts.push(mem);
            await fs.writeFileSync('./AliceDatabase/users-db/contacts.json', JSON.stringify(contacts));
            await Alice.sendMessage(mem, { text: teks }, { quoted: fkontak });
            await sleep(delay);
        }
    }

    try {
        const uniqueContacts = [...new Set(contacts)];
        const vcardContent = uniqueContacts.map(contact => {
            return [
                "BEGIN:VCARD",
                "VERSION:3.0",
                `FN:BUYER [ ${global.ownername} ] ${contact.split("@")[0]}`,
                `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
                "END:VCARD",
                ""
            ].join("\n");
        }).join("");

        fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", vcardContent, "utf8");
    } catch (err) {
        return reply(err.toString());
    } finally {
        if (m.chat !== m.sender) {
            await reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`);
        }
        await Alice.sendMessage(m.sender, {
            document: fs.readFileSync("./AliceDatabase/users-db/contacts.vcf"),
            fileName: "contacts.vcf",
            caption: "File Contact Berhasil Di Buat✅",
            mimetype: "text/vcard"
        }, { quoted: m });

        contacts.splice(0, contacts.length);
        await fs.writeFileSync("./AliceDatabase/users-db/contacts.json", JSON.stringify(contacts));
        await fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", "");
    }
}
break;
case 'savekontak': {
await XReaction();
if (!isOwner) return XRO()
if (!m.isGroup) return XRG()
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./AliceDatabase/users-db/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER [ ${global.ownername} ] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat`)
await Alice.sendMessage(m.sender, { document: fs.readFileSync("./AliceDatabase/users-db/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./AliceDatabase/users-db/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", "")
}}
break
case 'savekontak2': {
await XReaction();
if (!isOwner) return XRO()
if (!text) return reply("idgrupnya\n\nketik *.getidgc* untuk melihat id grup")
var idnya = text
var groupMetadataa
try {
groupMetadataa = await Alice.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./AliceDatabase/users-db/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER [ ${global.ownername} ] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat`)
await Alice.sendMessage(m.sender, { document: fs.readFileSync("./AliceDatabase/users-db/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./AliceDatabase/users-db/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./AliceDatabase/users-db/contacts.vcf", "")
}}
break


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Push Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\



//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Audio Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'music1':
case 'music2':
case 'music3':
case 'music4':
case 'music5':
case 'music6':
case 'music7':
case 'music8':
case 'music9':
case 'music10':
case 'music11':
case 'music12':
case 'music13':
case 'music14':
case 'music15':
case 'music16':
case 'music17':
case 'music18':
case 'music19':
case 'music20':
case 'music21':
case 'music22':
case 'music23':
case 'music24':
case 'music25':
case 'music26':
case 'music27':
case 'music28':
case 'music29':
case 'music30':
case 'music31':
case 'music32':
case 'music33':
case 'music34':
case 'music35':
case 'music36':
case 'music37':
case 'music38':
case 'music39':
case 'music40':
case 'music41':
case 'music42':
case 'music43':
case 'music44':
case 'music45':
case 'music46':
case 'music47':
case 'music48':
case 'music49':
case 'music50':
case 'music51':
case 'music52':
case 'music53':
case 'music54':
case 'music55':
case 'music56':
case 'music57':
case 'music58':
case 'music59':
case 'music60':
case 'music61':
case 'music62':
case 'music63':
case 'music64':
case 'music65': {
await XReaction();

  // Ambil file musik dari repo GitHub
  const sisiro = await (await fetch(`https://github.com/Rez4-3yz/Music-rd/raw/master/music/${prefix + command}.mp3`)).buffer()

  // Kirim audio sebagai voice note
  await Alice.sendMessage(m.chat, {
    audio: sisiro,
    mimetype: 'audio/mp4',
    ptt: false,
    quoted: m
  }).catch(() => {
    return ('Error!')
  })
}
break

    case 'mangkane1':
    case 'mangkane2':
    case 'mangkane3':
    case 'mangkane4':
    case 'mangkane5':
    case 'mangkane6':
    case 'mangkane7':
    case 'mangkane8':
    case 'mangkane9':
    case 'mangkane10':
    case 'mangkane11':
    case 'mangkane12':
    case 'mangkane13':
    case 'mangkane14':
    case 'mangkane15':
    case 'mangkane16':
    case 'mangkane17':
    case 'mangkane18':
    case 'mangkane19':
    case 'mangkane20':
    case 'mangkane21':
    case 'mangkane22':
    case 'mangkane23':
    case 'mangkane24':
    case 'mangkane25':
    case 'mangkane26':
    case 'mangkane27':
    case 'mangkane28':
    case 'mangkane29':
    case 'mangkane30':
    case 'mangkane31':
    case 'mangkane32':
    case 'mangkane33':
    case 'mangkane34':
    case 'mangkane35':
    case 'mangkane36':
    case 'mangkane37':
    case 'mangkane38':
    case 'mangkane39':
    case 'mangkane40':
    case 'mangkane41':
    case 'mangkane42':
    case 'mangkane43':
    case 'mangkane44':
    case 'mangkane45':
    case 'mangkane46':
    case 'mangkane47':
    case 'mangkane48':
    case 'mangkane49':
    case 'mangkane50':
    case 'mangkane51':
    case 'mangkane52':
    case 'mangkane53':
    case 'mangkane54':
      viot = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
      thumb = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
      let sound
      if (/sound/.test(command)) sound = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${prefix + command}.mp3`
      if (/mangkane/.test(command) && command.replace('mangkane', '') < 25) sound = `https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane/${prefix + command}.mp3`
      if (/mangkane/.test(command) && command.replace('mangkane', '') > 24) sound = `https://raw.githubusercontent.com/aisyah-rest/mangkane/main/mangkanenya/${prefix + command}.mp3`
      if (/acumalaka|reza-kecap|farhan-kebab|omaga|omaga|kamu-nanya|anjay|siuu/.test(command)) sound = `https://github.com/FahriAdison/Base-Sound/raw/main/audio/${prefix + command}.mp3`
      if (text.toLowerCase() === 'thumb') {
        await Alice.sendMessage(m.chat, {
          audio: {
            url: sound
          },
          mimetype: 'audio/mpeg',
          ptt: false,
          contextInfo: {
            externalAdReply: {
              mediaUrl: groupbot,
              mediaType: 2,
              title: '  ⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻  ',
              body: '  ━━━━⬤──────────  ',
              description: 'Now Playing...',
              mediaType: 2,
              sourceUrl: groupbot,
              thumbnail: await (await fetch(viot)).buffer(),
              renderLargerThumbnail: true
            }
          }
        }, {
          quoted: m
        })
      } else await Alice.sendMessage(m.chat, {
        audio: {
          url: sound
        },
        mimetype: 'audio/mpeg',
        ptt: false
      }, {
        quoted: m
      })
      break
      case "ringtone":
await XReaction();      
        {
          if (!text) {
            return reply(`Contoh : ${prefix + command} black rover`);
          }
          let anutone2 = await ringtone(text);
          let result = anutone2[Math.floor(Math.random() * anutone2.length)];
          Alice.sendMessage(m.chat, {
            audio: {
              url: result.audio
            },
            fileName: result.title + ".mp3",
            mimetype: "audio/mpeg"
          }, {
            quoted: m
          });
        }
        break;
case 'tts': {
await XReaction();
if (!text) return reply("masukkan text\nExample: ahh ah ah ahhh")
const API_BASE_URL = 'https://flowfalcon.dpdns.org/tools/text-to-speech';

  try {
    const res = await fetch(`${API_BASE_URL}?text=${encodeURIComponent(text)}`);
    const json = await res.json();

    if (!json.status || !json.result || !Array.isArray(json.result) || json.result.length === 0) {
      return reply('Gagal generate suara atau tidak ada suara yang ditemukan.');
    }

    let allButtons = [];

    for (const voice of json.result) {
      const name = voice.voice_name;
      const url = Object.values(voice).find(v => typeof v === 'string' && v.startsWith('https'));

      if (url) {
        allButtons.push({
          buttonId: `.getaudio ${url}`,
          buttonText: { displayText: `Voice: ${name}`},
          type: 1
        });
      }
    }

    if (allButtons.length === 0) {
        return reply('Tidak ada suara yang valid ditemukan untuk dibuatkan tombol.');
    }

    const buttonMessage = {
        text: `Pilih jenis suara untuk "${text}":`,
        footer: "Klik tombol di bawah untuk mendengarkan suara.",
        buttons: allButtons,
        headerType: 1,
        viewOnce: true
    };

    await Alice.sendMessage(m.chat, buttonMessage, { quoted: m });

  } catch (err) {
    console.error(err);
    reply('Terjadi kesalahan saat memproses audio.');
  }
}
break;

case "getaudio": case "gtmp3": {
await XReaction();
try {
if (!text) return reply("https://example.com")
Alice.sendMessage(m.chat, {audio: {url: `${text}`}, mimetype: 'audio/mpeg'}, { quoted : m })
} catch (e) {
console.error(e)
reply(`Failed to download video because:${e}`)
}
}
break
case 'voice': {
  
    await XReaction()

    const voices = [
        global.botname,
        "michie",
        "adam",
        "prabowo",
        "thomas_shelby",
        "jokowi",
        "megawati",
        "echilling",
        "nokotan",
        "boboiboy",
        "yanzgpt",
        "keqing",
        "yanami_anna"
    ]

    if (!text) {
        let s=""
        for (let i=0;i<voices.length;i++) s+=`${i+1}. ${voices[i]}\n`
        return reply(`contoh:\n${prefix+command} 1 halo\n\n${s}`)
    }

    let arr = text.split(" ")
    let num = parseInt(arr.shift())
    let msg = arr.join(" ")

    if (!num || num < 1 || num > voices.length)
        return reply("nomor salah kak")

    let nama = voices[num-1]
    let nick = nama
    let role = "Temen Deket"

    let custom = `- Kamu ${nama}. Bicara natural seperti manusia.`

    if (nama === global.botname) {
        custom = `- Nama kamu ${global.botname}. Lembut, perhatian, manis.
- Bicara seperti cewek beneran, natural dan hangat.`
    }

    try {
        let sessionId = `${m.chat}_${m.sender}`.replace(/[^0-9A-Za-z_-]/g,'')

        let body = {
            text: msg,
            id: sessionId,         // <= sesi per user / per chat
            fullainame: nama,
            nickainame: nick,
            senderName: m.pushName,
            ownerName: "owner",
            date: new Date(),
            role,
            msgtype: "text",
            custom_profile: custom,
            commands: []
        }

        let ai = await fetch(`https://api.termai.cc/api/chat/logic-bell?key=${global.apikey.xtermai}`, {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body: JSON.stringify(body)
        })

        let js = await ai.json()

        if (!js?.status) {
            console.log("AI ERROR:", js)
            return reply(
                `❌ AI gagal memproses\n`+
                `• status: ${js?.status}\n`+
                `• msg: ${js?.msg}\n`+
                `cek console`
            )
        }

        let out = js.data.msg
        let voice = nama

        if (nama === global.botname) voice = "bella"
        if (nama === "michie") voice = "michi_jkt48"

        let tts = `https://api.termai.cc/api/text2speech/elevenlabs?text=${encodeURIComponent(out)}&voice=${voice}&key=${global.apikey.xtermai}`

        let au = await fetch(tts)
        if (!au.ok) return reply(`TTS gagal: ${au.status}`)

        let buf = Buffer.from(await au.arrayBuffer())

        Alice.sendMessage(m.chat, {
            audio: buf,
            mimetype: "audio/mpeg",
            ptt: true
        }, { quoted: m })

    } catch (e) {
        console.log("VOICE ERROR:", e)
        return reply(`Error: ${e.message}`)
    }
}
break
case 'bass': 
  case 'blown': 
    case 'deep': 
      case 'earrape': 
      case 'fast': 
      case 'fat': 
      case 'nightcore': 
      case 'reverse': 
      case 'robot': 
      case 'slow': 
      case 'smooth': 
      case 'tupai': {
await XReaction();
          if (!/audio/.test(mime)) return reply(`reply audio, dengan caption *${prefix + command}*`);
          let set;
          if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';      
          if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';       
          if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';     
          if (/earrape/.test(command)) set = '-af volume=12';      
          if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';      
          if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';     
          if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';        
          if (/reverse/.test(command)) set = '-filter_complex "areverse"';      
          if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';   
          if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'; 
          if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';    
          if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
          if (/audio/.test(mime)) {
              let media = await Alice.downloadAndSaveMediaMessage(quoted);
              await reaction(m.chat, "⚡")
              let ran = getRandomFile('.mp3');
              exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                  fs.unlinkSync(media);
                  if (err) return reply(err);
                  let buff = fs.readFileSync(ran);        
                  sendMusic(buff);
                  fs.unlinkSync(ran);
              });
          }
      }
      break;


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Audio Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Primbon Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'ramalanjodohweton': {
await XReaction();
let [weton1, weton2] = text.split('|').map(v => v.trim());
if (!weton1 || !weton2) return reply(`Contoh: ${prefix + command} SeninLegi|RabuPon`);
let neptu = { seninlegi:9, seninpahing:13, seninpon:11, seninwage:8, seninkliwon:12, selasalegi:8, selasapahing:12, selasapon:10, selasawage:7, selasakliwon:11, rabulegi:12, rabupahing:16, rabupon:14, rabuwage:11, rubukliwon:15, kamislegi:12, kamispahing:16, kamispon:14, kamiswage:11, kamiskliwon:15, jumatlegi:11, jumatpahing:15, jumatpon:13, jumatwage:10, jumatkliwon:14, sabtulegi:13, sabtupahing:17, sabtupon:15, sabtuwage:12, sabtukliwon:16, minggulegi:10, minggupahing:14, minggupon:12, mingguwage:9, minggukliwon:13 };
let total = (neptu[weton1.toLowerCase()] || 0) + (neptu[weton2.toLowerCase()] || 0);
if (!total) return reply('Weton tidak valid! Contoh: SeninLegi, SelasaPahing');
let hasil = total < 14 ? "Tidak Cocok" : total < 21 ? "Cukup Cocok" : "Sangat Cocok";
reply(`🔮 RAMALAN JODOH WETON\n\n📌 Weton 1: ${weton1}\n📌 Weton 2: ${weton2}\n📊 Total Neptu: ${total}\n💕 Hasil: ${hasil}`);
}
break

case 'haribagus': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2025`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 7;
let bagus = jumlah === 0 || jumlah === 3 || jumlah === 5;
reply(`📅 CEK HARI BAGUS\n\n📅 Tanggal: ${tgl}/${bln}/${thn}\n${bagus ? "✅ HARI BAGUS untuk memulai sesuatu!" : "⚠️ HARI KURANG BAGUS, sebaiknya hati-hati"}`);
}
break

case 'jamkeberuntungan': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 24;
reply(`🕐 JAM KEBERUNTUNGAN\n\n📅 Lahir: ${tgl}/${bln}\n⏰ Jam Hoki: ${jumlah}:00 - ${(jumlah+2)%24}:00\n✨ Lakukan hal penting di jam tersebut.`);
}
break

case 'tanggaljadian': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2025`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 9 + 1;
let prediksi = ["Awet", "Harmonis", "Banyak Cobaan", "Berkah", "Langka", "Cekcok", "Romantis", "Setia", "Beruntung"];
reply(`💍 RAMALAN TANGGAL JADIAN\n\n📅 Tanggal: ${tgl}/${bln}/${thn}\n🎯 Prediksi: ${prediksi[jumlah-1]}\n✨ ${jumlah>5?"Hari baik untuk memulai hubungan":"Hati-hati dalam hubungan"}.`);
}
break

case 'ramalananak': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 10;
let jumlahAnak = jumlah > 7 ? 2 : jumlah > 3 ? 1 : 0;
reply(`👶 RAMALAN KETURUNAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n👼 Prediksi anak: ${jumlahAnak} orang\n✨ ${jumlahAnak>0?"Keluarga kecil bahagia menanti":"Fokus karir dulu ya"}.`);
}
break

case 'ramalansaudara': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 8;
let hubungan = ["Rukun", "Bersaing", "Akrab", "Jauh", "Dekat", "Cekcok", "Saling mendukung", "Mandiri"];
reply(`👨‍👩‍👧 RAMALAN HUBUNGAN SAUDARA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💕 Hubungan: ${hubungan[jumlah]}\n✨ Jaga silaturahmi dengan saudara.`);
}
break

case 'ramalanorangtua': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 6;
let kondisi = ["Baik", "Sehat", "Perlu perhatian", "Harmonis", "Bijaksana", "Mandiri"];
reply(`👵 RAMALAN ORANG TUA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💖 Kondisi: ${kondisi[jumlah]}\n✨ Hormati dan sayangi orang tua.`);
}
break

case 'ramalanpasanganbaru': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let bulan = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
reply(`💑 RAMALAN PASANGAN BARU\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📅 Akan bertemu: Bulan ${bulan[jumlah]}\n✨ Siapkan hati, jodoh mendekat!`);
}
break

case 'ramalanstatus': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let status = ["Jomblo bahagia", "Lagi PDKT", "Sedang deket", "Pacaran", "Siap nikah"];
reply(`💘 RAMALAN STATUS CINTA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💑 Status sekarang: ${status[jumlah]}\n✨ Nikmati setiap fase kehidupan.`);
}
break

case 'ramalanuang': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let kondisi = ["Melimpah", "Cukup", "Pas-pasan", "Bertambah", "Berkah"];
reply(`💰 RAMALAN KEUANGAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💵 Kondisi: ${kondisi[jumlah]}\n✨ ${jumlah<2?"Rezeki mengalir lancar":"Hemat dan bijak dalam belanja"}.`);
}
break

case 'ramalanhutang': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let prediksi = ["Hindari hutang", "Secepatnya lunasi", "Jangan berhutang", "Waspada", "Aman terkendali"];
reply(`💸 RAMALAN HUTANG\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⚠️ Saran: ${prediksi[jumlah]}\n✨ Kelola keuangan dengan bijak.`);
}
break

case 'ramalaninvestasi': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let jenis = ["Emas", "Tanah", "Saham", "Deposito", "Reksadana"];
let risiko = ["Aman", "Rendah", "Tinggi", "Sedang", "Ringan"];
reply(`📈 RAMALAN INVESTASI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💎 Investasi: ${jenis[jumlah]}\n⚡ Risiko: ${risiko[jumlah]}\n✨ ${jumlah<2?"Cocok untuk investasi jangka panjang" : "Konsultasi dengan ahlinya dulu"}.`);
}
break

case 'ramalanbisnisonline': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 6;
let platform = ["Shopee", "Tokopedia", "TikTok Shop", "Instagram", "Facebook", "Website"];
let prospek = ["Bagus", "Cerlang", "Menjanjikan", "Meningkat", "Laris", "Cemerlang"];
reply(`📱 RAMALAN BISNIS ONLINE\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🛒 Platform: ${platform[jumlah]}\n📈 Prospek: ${prospek[jumlah]}\n✨ Usaha online akan sukses.`);
}
break

case 'ramalanbaranghilang': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 5;
let arah = ["Utara", "Timur", "Selatan", "Barat", "Dekat"];
reply(`🔍 RAMALAN BARANG HILANG\n\n📅 Hari ini: ${tgl}/${bln}\n🧭 Cari di arah: ${arah[jumlah]}\n✨ Tenang, barang akan segera ditemukan.`);
}
break

case 'ramalanperjalanan': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 5;
let prediksi = ["Lancar", "Aman", "Hati-hati", "Berkesan", "Seru"];
reply(`✈️ RAMALAN PERJALANAN\n\n📅 Tanggal: ${tgl}/${bln}\n🛣️ Prediksi: ${prediksi[jumlah]}\n✨ ${jumlah<2?"Perjalanan menyenangkan":"Perhatikan barang bawaan"}.`);
}
break

case 'ramalanwawancara': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2025`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let hasil = ["Diterima", "Cadangan", "Coba lagi", "Sukses", "Panggilan kedua"];
reply(`💼 RAMALAN WAWANCARA KERJA\n\n📅 Tanggal: ${tgl}/${bln}/${thn}\n🎯 Hasil: ${hasil[jumlah]}\n✨ ${jumlah===0?"Persiapan matang kunci sukses":"Tetap semangat!"}.`);
}
break

case 'ramalanpromosi': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let bulan = ["1", "3", "6", "9", "12"];
reply(`📈 RAMALAN PROMOSI JABATAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📅 Prediksi promosi: ${bulan[jumlah]} bulan lagi\n✨ Tunjukkan kinerja terbaik Anda.`);
}
break

case 'ramalangaji': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let gaji = ["Naik", "Bonus", "Tetap", "Insentif", "Tunjangan"];
reply(`💵 RAMALAN GAJI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📊 Prediksi: ${gaji[jumlah]}\n✨ ${jumlah<2?"Akan ada tambahan penghasilan":"Semoga cukup untuk kebutuhan"}.`);
}
break

case 'ramalankosong': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let energi = ["Penuh", "Lelah", "Semangat", "Menguras", "Stabil"];
reply(`⚡ RAMALAN TENAGA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🔋 Energi hari ini: ${energi[jumlah]}\n✨ ${jumlah===0?" produktif!" : "Istirahat yang cukup"}.`);
}
break

case 'ramalanumur': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 30 + 70;
reply(`👴 RAMALAN PANJANG UMUR\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⏳ Prediksi: ${jumlah} tahun\n🌿 Kunci: ${jumlah>85?"Pola hidup sehat":"Olahraga teratur dan hindari stres"}.`);
}
break

case 'ramalanpenyakitturun': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let penyakit = ["Diabetes", "Jantung", "Asam urat", "Kolesterol", "Maag"];
let pencegahan = ["Kurangi gula", "Olahraga", "Banyak air putih", "Kurangi gorengan", "Makan teratur"];
reply(`🏥 RAMALAN PENYAKIT TURUNAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⚠️ Waspada: ${penyakit[jumlah]}\n💊 Pencegahan: ${pencegahan[jumlah]}`);
}
break

case 'ramalanalergi': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let alergi = ["Debu", "Makanan laut", "Udara dingin", "Bulu hewan", "Serbuk sari"];
reply(`🤧 RAMALAN ALERGI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⚠️ Waspada: ${alergi[jumlah]}\n✨ Hindari pemicu alergi.`);
}
break

case 'ramalanobat': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let obat = ["Jahe", "Madu", "Kunyit", "Temulawak", "Sambiloto"];
let khasiat = ["Hangat badan", "Batuk & flu", "Antiinflamasi", "Maag", "Demam"];
reply(`💊 RAMALAN OBAT HERBAL COCOK\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🌿 Obat: ${obat[jumlah]}\n💚 Khasiat: ${khasiat[jumlah]}`);
}
break

case 'ramalandiet': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let diet = ["Rendah karbo", "Rendah lemak", "Tinggi protein", "Vegetarian", "Intermitten"];
reply(`🥗 RAMALAN DIET COCOK\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🍽️ Diet: ${diet[jumlah]}\n✨ Konsultasikan dengan ahli gizi.`);
}
break

case 'ramalanolahragadiri': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 6;
let olahraga = ["Lari pagi", "Yoga", "Bersepeda", "Renang", "Push up", "Sit up"];
reply(`🏋️ RAMALAN OLAHRAGA MANDIRI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💪 Olahraga: ${olahraga[jumlah]}\n✨ Lakukan rutin 30 menit/hari.`);
}
break

case 'ramalanmeditasi': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let waktu = ["Pagi 5-6", "Siang 12-13", "Sore 16-17", "Malam 19-20", "Subuh 3-4"];
let durasi = [10, 15, 20, 25, 30];
reply(`🧘 RAMALAN WAKTU MEDITASI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🕐 Waktu terbaik: ${waktu[jumlah]}\n⏱️ Durasi: ${durasi[jumlah]} menit`);
}
break

case 'ramalanhariraya': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 5;
let warna = ["Kuning", "Putih", "Hijau", "Biru", "Merah Muda"];
reply(`🎊 RAMALAN WARNA HARI RAYA\n\n📅 Tanggal: ${tgl}/${bln}\n🎨 Warna keberuntungan: ${warna[jumlah]}\n✨ Pakai warna ini saat merayakan.`);
}
break

case 'ramalanpindahan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let arah = ["Utara", "Timur", "Selatan", "Barat", "Tenggara"];
reply(`🏠 RAMALAN ARAH PINDAH RUMAH\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🧭 Arah baik: ${arah[jumlah]}\n✨ Rumah di arah tersebut membawa keberuntungan.`);
}
break

case 'ramalantanamanhias': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let tanaman = ["Lidah mertua", "Sirih gading", "Kaktus", "Lili Paris", "Aglaonema", "Monstera"];
let fungsi = ["Penyerap racun", "Pembersih udara", "Pembawa hoki", "Menenangkan", "Cantik", "Estetik"];
reply(`🌿 RAMALAN TANAMAN HIAS\n\n📅 Lahir: ${tgl}/${bln}\n🪴 Tanaman: ${tanaman[jumlah]}\n💚 Manfaat: ${fungsi[jumlah]}`);
}
break

case 'ramalanwarnabaju': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let warna = ["Merah", "Kuning", "Hijau", "Biru", "Ungu", "Putih", "Hitam", "Coklat"];
let suasana = ["Berani", "Ceria", "Segar", "Tenang", "Elegan", "Suci", "Kuat", "Alami"];
reply(`👕 RAMALAN WARNA BAJU\n\n📅 Lahir: ${tgl}/${bln}\n👔 Warna: ${warna[jumlah]}\n😊 Suasana: ${suasana[jumlah]}`);
}
break

case 'ramalanwarnasepatu': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let warna = ["Hitam", "Putih", "Coklat", "Biru", "Abu-abu", "Merah"];
let karir = ["Profesional", "Santai", "Alami", "Kreatif", "Netral", "Berani"];
reply(`👟 RAMALAN WARNA SEPATU\n\n📅 Lahir: ${tgl}/${bln}\n👞 Warna: ${warna[jumlah]}\n💼 Kesan: ${karir[jumlah]}`);
}
break

case 'ramalanwarnatopi': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 5;
let warna = ["Hitam", "Putih", "Navy", "Khaki", "Merah"];
let gaya = ["Keren", "Terang", "Klasik", "Natural", "Menyala"];
reply(`🧢 RAMALAN WARNA TOPI\n\n📅 Lahir: ${tgl}/${bln}\n🧢 Warna: ${warna[jumlah]}\n✨ Gaya: ${gaya[jumlah]}`);
}
break

case 'ramalanaksesoris': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let aksesoris = ["Kalung", "Gelang", "Cincin", "Anting", "Jam tangan", "Kacamata"];
let makna = ["Perlindungan", "Ikatan", "Komitmen", "Kecantikan", "Keberuntungan", "Kewibawaan"];
reply(`💍 RAMALAN AKSESORIS\n\n📅 Lahir: ${tgl}/${bln}\n💎 Aksesoris: ${aksesoris[jumlah]}\n💫 Makna: ${makna[jumlah]}`);
}
break

case 'ramalanparfum': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let aroma = ["Vanilla", "Musk", "Citrus", "Floral", "Woody", "Ocean"];
let kesan = ["Manis", "Maskulin", "Segar", "Romantis", "Alami", "Bersih"];
reply(`👃 RAMALAN PARFUM COCOK\n\n📅 Lahir: ${tgl}/${bln}\n🌺 Aroma: ${aroma[jumlah]}\n😍 Kesan: ${kesan[jumlah]}`);
}
break

case 'ramalanpakaian': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let gaya = ["Casual", "Formal", "Sporty", "Etnik", "Modern", "Retro"];
let acara = ["Sehari-hari", "Kantor", "Olahraga", "Tradisional", "Pesta", "Vintage"];
reply(`👗 RAMALAN GAYA PAKAIAN\n\n📅 Lahir: ${tgl}/${bln}\n👘 Gaya: ${gaya[jumlah]}\n🎉 Cocok untuk: ${acara[jumlah]}`);
}
break
case 'primbonjodoh2':
case 'hitunganjodoh2': {
await XReaction();
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split(',').map(v => v.trim());
if (!nama1 || !tgl1 || !bln1 || !thn1 || !nama2 || !tgl2 || !bln2 || !thn2) return reply(`Contoh: ${prefix + command} Andi,15,8,2005,Siti,10,5,2006`);
let angka1 = (parseInt(tgl1)+parseInt(bln1)+parseInt(thn1)) % 9 + 1;
let angka2 = (parseInt(tgl2)+parseInt(bln2)+parseInt(thn2)) % 9 + 1;
let total = angka1 + angka2;
let hasil = total > 12 ? "Cocok 👍" : total > 7 ? "Cukup 🤔" : "Kurang Cocok ⚠️";
reply(`🔮 PERHITUNGAN JODOH 2\n\n👤 ${nama1}: ${tgl1}/${bln1}/${thn1} (${angka1})\n👤 ${nama2}: ${tgl2}/${bln2}/${thn2} (${angka2})\n📊 Total: ${total}\n🎯 Hasil: ${hasil}`);
}
break

case 'tanggalbaik': {
await XReaction();
let [bln, thn] = text.split(',').map(v => v.trim());
if (!bln || !thn) return reply(`Contoh: ${prefix + command} 8,2025\nMencari tanggal baik di bulan Agustus 2025`);
let tglBaik = [];
for (let i = 1; i <= 31; i++) {
let jumlah = (i + parseInt(bln) + parseInt(thn)) % 7;
if (jumlah === 0 || jumlah === 3 || jumlah === 5) tglBaik.push(i);
}
reply(`📅 TANGGAL BAIK BULAN ${bln}/${thn}\n\n📌 Tanggal: ${tglBaik.join(', ')}\n✨ Cocok untuk memulai usaha, pindah rumah, atau pernikahan.`);
}
break

case 'harilarangan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let larangan = ["Jangan bepergian jauh", "Hindari bertengkar", "Jangan meminjam uang", "Hati-hati bicara", "Jangan memulai proyek baru"];
reply(`🚫 HARI LARANGAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⚠️ ${larangan[jumlah]}\n✨ Hari ini sebaiknya istirahat dan refleksi diri.`);
}
break

case 'waktubahagia': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 24;
reply(`⏰ WAKTU BAHAGIA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🕐 Jam keberuntungan: ${jumlah}:00 - ${(jumlah+2)%24}:00\n✨ Lakukan hal penting di jam tersebut.`);
}
break

case 'elemenalam': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 5;
let elemen = ["Api 🔥", "Air 💧", "Tanah 🌍", "Udara 🌬️", "Kayu 🌳"];
let sifat = ["Bersemangat", "Tenang", "Stabil", "Bebas", "Tumbuh"];
reply(`🌪️ ELEMEN ALAM\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎯 Elemen: ${elemen[jumlah]}\n💫 Sifat: ${sifat[jumlah]}\n✨ Elemen ini membawa keberuntungan Anda.`);
}
break

case 'binatangtotem': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let binatang = ["Serigala", "Elang", "Beruang", "Harimau", "Lumba-lumba", "Kupu-kupu", "Ular", "Singa", "Kura-kura", "Gajah", "Rubah", "Kuda"];
let arti = ["Loyalitas", "Visi jauh", "Kekuatan", "Keberanian", "Kebahagiaan", "Transformasi", "Kebijaksanaan", "Kewibawaan", "Panjang umur", "Kebijaksanaan", "Cerdik", "Kebebasan"];
let idx = (parseInt(tgl)+parseInt(bln)) % 12;
reply(`🦅 BINATANG TOTEM\n\n📅 Lahir: ${tgl}/${bln}\n🦁 Binatang: ${binatang[idx]}\n💭 Makna: ${arti[idx]}\n✨ Roh binatang ini melindungi Anda.`);
}
break

case 'warna aura': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 7;
let warna = ["Merah", "Jingga", "Kuning", "Hijau", "Biru", "Nila", "Ungu"];
let arti = ["Semangat", "Optimisme", "Kecerdasan", "Kedamaian", "Ketenangan", "Intuisi", "Spiritualitas"];
reply(`🌈 WARNA AURA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎨 Aura: ${warna[jumlah]}\n💫 Arti: ${arti[jumlah]}\n✨ Aura Anda saat ini penuh energi positif.`);
}
break

case 'angka gaib': {
await XReaction();
let [nama, tgl, bln] = text.split(',').map(v => v.trim());
if (!nama || !tgl || !bln) return reply(`Contoh: ${prefix + command} Budi,15,8`);
let jumlahNama = nama.length;
let jumlahTgl = parseInt(tgl) + parseInt(bln);
let angkaGaib = (jumlahNama + jumlahTgl) % 9 + 1;
reply(`🔢 ANGKA GAIB\n\n👤 Nama: ${nama}\n📅 Lahir: ${tgl}/${bln}\n🔮 Angka Gaib: ${angkaGaib}\n✨ Angka ini membawa keberuntungan dalam hidup Anda.`);
}
break

case 'ramalanrezeki': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let bulan = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
let rezeki = ["Meningkat", "Stabil", "Berlimpah", "Bertambah", "Cukup", "Melimpah", "Bertahap", "Besar", "Lancar", "Mengalir", "Terkirim", "Datang"];
reply(`💰 RAMALAN REZEKI BULAN ${bulan[new Date().getMonth()]}\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💵 Prediksi: ${rezeki[jumlah]}\n✨ Bulan ini ${jumlah<6?"waktunya investasi":"waktunya bersedekah"}.`);
}
break

case 'karir masa depan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 10;
let karir = ["Manajer", "Pengusaha", "Dokter", "Insinyur", "Guru", "Seniman", "Politisi", "Peneliti", "Konsultan", "Penulis"];
let perusahaan = ["Startup", "Korporasi", "Rumah Sakit", "Kontraktor", "Sekolah", "Studio", "Kantor", "Lab", "Firma", "Penerbit"];
reply(`💼 KARIR MASA DEPAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎯 Karir: ${karir[jumlah]}\n🏢 Tempat: ${perusahaan[jumlah]}\n✨ Kejar karir ini untuk kesuksesan.`);
}
break

case 'cinta sejati': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let bulanKetemu = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
let ciri = ["Berambut gelap", "Berkacamata", "Tinggi", "Pendiam", "Ramah", "Lucu", "Pintar", "Penyayang", "Mandiri", "Romantis", "Setia", "Optimis"];
reply(`💕 CINTA SEJATI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📅 Bertemu: ${bulanKetemu[jumlah]} mendatang\n👤 Ciri: ${ciri[jumlah]}\n✨ Jangan lewatkan kesempatan.`);
}
break

case 'umur panjang': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 30 + 70;
reply(`👴 PREDIKSI UMUR PANJANG\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⏳ Prediksi Umur: ${jumlah} tahun\n🌿 Kunci: ${jumlah>85?"Pola hidup sehat":"Kurangi stres dan olahraga teratur"}`);
}
break

case 'ramalanrumah': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 8;
let arah = ["Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"];
let unsur = ["Air", "Kayu", "Api", "Tanah", "Logam", "Udara", "Ether", "Batu"];
reply(`🏠 RAMALAN RUMAH IDEAL\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🧭 Arah rumah: ${arah[jumlah]}\n🌪️ Unsur: ${unsur[jumlah]}\n✨ Rumah menghadap arah tersebut membawa keberuntungan.`);
}
break

case 'ramalankendaraan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 6;
let warna = ["Merah", "Hitam", "Putih", "Silver", "Biru", "Hijau"];
let arti = ["Keberanian", "Kekuatan", "Kesucian", "Modern", "Ketenangan", "Alam"];
reply(`🚗 RAMALAN WARNA KENDARAAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎨 Warna hoki: ${warna[jumlah]}\n💫 Makna: ${arti[jumlah]}\n✨ Kendaraan warna ini membawa keselamatan.`);
}
break

case 'ramalanhewanpeliharaan': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 6;
let hewan = ["Kucing", "Anjing", "Burung", "Ikan", "Kelinci", "Hamster"];
let manfaat = ["Menenteramkan", "Melindungi", "Menghibur", "Menenangkan", "Menggemaskan", "Mengurangi stres"];
reply(`🐾 RAMALAN HEWAN PELIHARAAN\n\n📅 Lahir: ${tgl}/${bln}\n🐕 Hewan: ${hewan[jumlah]}\n💖 Manfaat: ${manfaat[jumlah]}\n✨ Piara hewan ini untuk keberuntungan.`);
}
break

case 'ramalantanaman': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let tanaman = ["Mawar", "Melati", "Anggrek", "Lili", "Kamboja", "Bonsai", "Lidah mertua", "Sirih"];
let khasiat = ["Cinta", "Ketenangan", "Kemewahan", "Kesucian", "Kenangan", "Kesabaran", "Perlindungan", "Kesehatan"];
reply(`🌱 RAMALAN TANAMAN PEMBAWA HOKI\n\n📅 Lahir: ${tgl}/${bln}\n🌻 Tanaman: ${tanaman[jumlah]}\n✨ Khasiat: ${khasiat[jumlah]}\n🌿 Tanam di rumah untuk energi positif.`);
}
break

case 'ramalanliburan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 10;
let tujuan = ["Bali", "Jogja", "Bandung", "Lombok", "Raja Ampat", "Malang", "Semarang", "Surabaya", "Medan", "Makassar"];
let aktivitas = ["Bersantai", "Berpetualang", "Kulineran", "Snorkeling", "Mendaki", "Belanja", "Wisata sejarah", "City tour", "Budaya", "Pantai"];
reply(`✈️ RAMALAN TEMPAT LIBURAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🏝️ Destinasi: ${tujuan[jumlah]}\n🎯 Aktivitas: ${aktivitas[jumlah]}\n✨ Liburan ke sana tahun ini membawa kebahagiaan.`);
}
break

case 'ramalanolahraga': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let olahraga = ["Renang", "Lari", "Yoga", "Bersepeda", "Badminton", "Futsal", "Basket", "Senam"];
let manfaat = ["Kebugaran", "Kesehatan jantung", "Fleksibilitas", "Kekuatan kaki", "Refleks", "Kerja tim", "Kelincahan", "Kelenturan"];
reply(`🏃 RAMALAN OLAHRAGA COCOK\n\n📅 Lahir: ${tgl}/${bln}\n⚽ Olahraga: ${olahraga[jumlah]}\n💪 Manfaat: ${manfaat[jumlah]}\n✨ Olahraga ini cocok untuk tubuh Anda.`);
}
break

case 'ramalanmakanan': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 10;
let makanan = ["Sate", "Bakso", "Nasi goreng", "Gado-gado", "Rendang", "Soto", "Pempek", "Mie ayam", "Ayam geprek", "Seblak"];
let unsur = ["Api", "Tanah", "Udara", "Air", "Api", "Tanah", "Udara", "Air", "Api", "Tanah"];
reply(`🍜 RAMALAN MAKANAN PEMBAWA HOKI\n\n📅 Lahir: ${tgl}/${bln}\n🍽️ Makanan: ${makanan[jumlah]}\n🌪️ Unsur: ${unsur[jumlah]}\n✨ Makanan ini membawa energi positif.`);
}
break

case 'ramalanminuman': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let minuman = ["Jamu", "Teh", "Kopi", "Jus buah", "Air kelapa", "Susu", "Cokelat panas", "Wedang jahe"];
let khasiat = ["Sehat", "Relaksasi", "Semangat", "Vitamin", "Segar", "Tulang kuat", "Mood booster", "Hangat badan"];
reply(`🥤 RAMALAN MINUMAN PEMBAWA HOKI\n\n📅 Lahir: ${tgl}/${bln}\n🥛 Minuman: ${minuman[jumlah]}\n💊 Khasiat: ${khasiat[jumlah]}\n✨ Rutin minum ini untuk kesehatan.`);
}
break

case 'ramalanmusik': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let genre = ["Pop", "Rock", "Jazz", "Klasik", "EDM", "Dangdut", "Kpop", "R&B"];
let suasana = ["Ceria", "Energik", "Santai", "Tenang", "Semangat", "Menggoyang", "Mood booster", "Romantis"];
reply(`🎵 RAMALAN GENRE MUSIK COCOK\n\n📅 Lahir: ${tgl}/${bln}\n🎧 Genre: ${genre[jumlah]}\n🎶 Suasana: ${suasana[jumlah]}\n✨ Dengarkan genre ini untuk meningkatkan mood.`);
}
break

case 'ramalanfilm': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let genre = ["Action", "Komedi", "Romantis", "Horor", "Drama", "Petualangan", "Fiksi ilmiah", "Animasi"];
let rekomendasi = ["Laga seru", "Menghibur", "Baper", "Menegangkan", "Menyentuh", "Seru", "Mengagumkan", "Lucu"];
reply(`🎬 RAMALAN FILM COCOK\n\n📅 Lahir: ${tgl}/${bln}\n🎥 Genre: ${genre[jumlah]}\n📽️ Suasana: ${rekomendasi[jumlah]}\n✨ Tonton film genre ini untuk hiburan maksimal.`);
}
break

case 'ramalanbuku': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let genre = ["Novel", "Komik", "Biografi", "Self-help", "Sejarah", "Filsafat", "Sains", "Puisi"];
let penulis = ["Tere Liye", "Raditya Dika", "Habibie", "Dale Carnegie", "Matahari", "Socrates", "Hawking", "Chairil"];
reply(`📚 RAMALAN BUKU COCOK\n\n📅 Lahir: ${tgl}/${bln}\n📖 Genre: ${genre[jumlah]}\n✍️ Penulis: ${penulis[jumlah]}\n✨ Baca buku genre ini untuk wawasan.`);
}
break

case 'ramalangayabelajar': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 5;
let gaya = ["Visual", "Auditori", "Kinestetik", "Membaca/Menulis", "Logis"];
let metode = ["Gambar/diagram", "Mendengar", "Praktik langsung", "Catatan/buku", "Analisis/logika"];
reply(`📖 RAMALAN GAYA BELAJAR\n\n📅 Lahir: ${tgl}/${bln}\n🎯 Gaya: ${gaya[jumlah]}\n📝 Metode: ${metode[jumlah]}\n✨ Belajar dengan metode ini lebih efektif.`);
}
break

case 'ramalantidur': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 8;
let jam = [21, 22, 23, 20, 21, 22, 23, 20];
let kualitas = ["Sangat Baik", "Baik", "Cukup", "Baik", "Sangat Baik", "Baik", "Cukup", "Baik"];
reply(`😴 RAMALAN WAKTU TIDUR IDEAL\n\n📅 Lahir: ${tgl}/${bln}\n🕙 Waktu tidur: ${jam[jumlah]}:00\n💤 Kualitas: ${kualitas[jumlah]}\n✨ Tidur di jam ini untuk kesehatan optimal.`);
}
break

case 'ramalanmimpi': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl)+parseInt(bln)) % 10;
let mimpi = ["Air", "Api", "Tanah", "Udara", "Bulan", "Matahari", "Bintang", "Hujan", "Angin", "Petir"];
let arti = ["Kesuburan", "Semangat", "Stabilitas", "Kebebasan", "Intuisi", "Kekuatan", "Harapan", "Kesegaran", "Perubahan", "Kejutan"];
reply(`🌙 RAMALAN ARTI MIMPI\n\n📅 Lahir: ${tgl}/${bln}\n💭 Mimpi: ${mimpi[jumlah]}\n📖 Arti: ${arti[jumlah]}\n✨ Mimpi ini pertanda baik untuk Anda.`);
}
break
case 'kecocokanweton':
case 'cocokweton': {
await XReaction();
let [weton1, weton2] = text.split('|').map(v => v.trim());
if (!weton1 || !weton2) return reply(`Contoh: ${prefix + command} Senin,Legi|Rabu,Pon\n\nNeptu Hari: Senin=4, Selasa=3, Rabu=7, Kamis=8, Jumat=6, Sabtu=9, Minggu=5\nNeptu Pasaran: Legi=5, Pahing=9, Pon=7, Wage=4, Kliwon=8`);
let neptuHari = { senin:4, selasa:3, rabu:7, kamis:8, jumat:6, sabtu:9, minggu:5 };
let neptuPasaran = { legi:5, pahing:9, pon:7, wage:4, kliwon:8 };
let [hari1, pasaran1] = weton1.split(',').map(v => v.trim().toLowerCase());
let [hari2, pasaran2] = weton2.split(',').map(v => v.trim().toLowerCase());
if (!neptuHari[hari1] || !neptuPasaran[pasaran1] || !neptuHari[hari2] || !neptuPasaran[pasaran2]) return reply('Hari atau pasaran tidak valid!');
let neptu1 = neptuHari[hari1] + neptuPasaran[pasaran1];
let neptu2 = neptuHari[hari2] + neptuPasaran[pasaran2];
let total = neptu1 + neptu2;
let hasil, kategori;
if (total <= 7) { hasil = "Sangat Buruk ❌"; kategori = "Pesthi"; }
else if (total <= 12) { hasil = "Kurang Baik ⚠️"; kategori = "Pegat"; }
else if (total <= 17) { hasil = "Cukup Baik 👍"; kategori = "Ratu"; }
else if (total <= 22) { hasil = "Baik ✅"; kategori = "Jodoh"; }
else if (total <= 27) { hasil = "Sangat Baik 💯"; kategori = "Topo"; }
else { hasil = "Luar Biasa 🌟"; kategori = "Tinari"; }
reply(`🔮 KECOCOKAN WETON 🔮\n\n👤 Weton1: ${hari1.toUpperCase()} ${pasaran1.toUpperCase()} (Neptu ${neptu1})\n👤 Weton2: ${hari2.toUpperCase()} ${pasaran2.toUpperCase()} (Neptu ${neptu2})\n📊 Total Neptu: ${total}\n🏷️ Kategori: ${kategori}\n🎯 Hasil: ${hasil}`);
}
break

case 'harisial':
case 'harinaas': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let tglLahir = new Date(thn, bln-1, tgl);
let now = new Date();
let hariNaas = [];
for (let i = -3; i <= 3; i++) {
let tglNaas = new Date(now.getFullYear(), bln-1, tgl);
tglNaas.setDate(tglNaas.getDate() + i);
if (tglNaas >= now) hariNaas.push(tglNaas.toLocaleDateString('id-ID', { weekday:'long', day:'numeric', month:'long' }));
}
reply(`📅 HARI NAAS ANDA\n\n🎂 Lahir: ${tgl}/${bln}/${thn}\n⚠️ Waspada di hari:\n${hariNaas.map((h,i)=>`${i+1}. ${h}`).join('\n')}\n\nTips: Hindari memulai usaha besar di hari tersebut.`);
}
break

case 'ramalannama':
case 'ramalnama': {
await XReaction();
let [nama, tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!nama || !tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} Budi,15,8,2005`);
let angkaNama = nama.toLowerCase().replace(/[^a-z]/g, '').split('').reduce((s,c) => s + (c.charCodeAt(0)-96), 0);
while (angkaNama > 9) angkaNama = angkaNama.toString().split('').reduce((a,b) => a + parseInt(b), 0);
let angkaTgl = (parseInt(tgl)+parseInt(bln)+parseInt(thn)).toString().split('').reduce((a,b) => a + parseInt(b), 0);
while (angkaTgl > 9) angkaTgl = angkaTgl.toString().split('').reduce((a,b) => a + parseInt(b), 0);
let angkaGab = angkaNama + angkaTgl;
while (angkaGab > 9) angkaGab = angkaGab.toString().split('').reduce((a,b) => a + parseInt(b), 0);
let karakter = {1:"Pemimpin",2:"Diplomat",3:"Ekspresif",4:"Disiplin",5:"Petualang",6:"Romantis",7:"Analitis",8:"Ambisi",9:"Humanis"};
reply(`🔢 RAMALAN NAMA\n\n👤 Nama: ${nama}\n📅 Lahir: ${tgl}/${bln}/${thn}\n🔢 Angka Nama: ${angkaNama} (${karakter[angkaNama]})\n🔢 Angka Lahir: ${angkaTgl}\n🎯 Angka Tujuan: ${angkaGab}\n✨ Prediksi: ${angkaGab>=7?"Keberuntungan besar menanti!":"Tetap semangat, rezeki di depan mata!"}`);
}
break

case 'wataklahir':
case 'watakkelahiran': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let tglNum = parseInt(tgl);
let watak = [
{ range: [1,5], sifat: "Pemimpin", positif: "Berani, mandiri", negatif: "Egois" },
{ range: [6,10], sifat: "Kreatif", positif: "Imajinatif, cerdas", negatif: "Moody" },
{ range: [11,15], sifat: "Petualang", positif: "Berani, optimis", negatif: "Impulsif" },
{ range: [16,20], sifat: "Setia", positif: "Jujur, bertanggung jawab", negatif: "Cemburuan" },
{ range: [21,25], sifat: "Bijaksana", positif: "Penyabar, dewasa", negatif: "Pendiam" },
{ range: [26,31], sifat: "Karismatik", positivo: "Menawan, percaya diri", negatif: "Manipulatif" }
];
let w = watak.find(w => tglNum >= w.range[0] && tglNum <= w.range[1]) || watak[0];
reply(`🎭 WATAK KELAHIRAN\n\n📅 Tanggal: ${tgl}/${bln}\n🎯 Sifat: ${w.sifat}\n✅ Kelebihan: ${w.positif}\n❌ Kekurangan: ${w.negatif}`);
}
break

case 'arahkeberuntungan':
case 'arahhoki': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 8;
let arah = ["Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"];
let elemen = ["Air", "Kayu", "Api", "Tanah", "Logam", "Udara", "Ether", "Batu"];
reply(`🧭 ARAH KEBERUNTUNGAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🧭 Arah Hoki: ${arah[jumlah]}\n🌪️ Elemen: ${elemen[jumlah]}\n💡 Tips: Hadap ke arah tersebut saat bekerja atau berdoa.`);
}
break

case 'warnapilihan':
case 'warnakeberuntungan': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let jumlah = (parseInt(tgl) + parseInt(bln)) % 7;
let warna = ["Merah", "Kuning", "Hijau", "Biru", "Ungu", "Putih", "Hitam"];
let arti = ["Keberanian", "Optimisme", "Kesuburan", "Ketenangan", "Misteri", "Kesucian", "Kekuatan"];
reply(`🎨 WARNA KEBERUNTUNGAN\n\n📅 Lahir: ${tgl}/${bln}\n🎨 Warna: ${warna[jumlah]}\n💫 Makna: ${arti[jumlah]}\n✨ Gunakan warna ini untuk menarik keberuntungan.`);
}
break

case 'batupermata':
case 'batuhoki': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let zodiak = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];
let batu = ["Berlian","Ruby","Zamrud","Batu Bulan","Topaz","Safir","Opal","Batu Darah","Biru Safir","Garnet","Amethyst","Aquamarine"];
let idx = (parseInt(bln)-1) % 12;
reply(`💎 BATU PERMATA HOKI\n\n📅 Lahir: ${tgl}/${bln}\n♈ Zodiak: ${zodiak[idx]}\n💎 Batu: ${batu[idx]}\n✨ Gunakan sebagai perhiasan untuk keberuntungan.`);
}
break

case 'tanggalpernikahan':
case 'tglnikah': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 31 + 1;
let bulan = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
let bulanHoki = bulan[(parseInt(bln)+5) % 12];
reply(`💍 TANGGAL PERNIKAHAN IDEAL\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💒 Tanggal Hoki: ${jumlah} ${bulanHoki}\n✨ Tanggal tersebut membawa keharmonisan rumah tangga.`);
}
break

case 'nomborshio': {
await XReaction();
let thn = parseInt(text);
if (!thn || thn < 1900 || thn > 2026) return reply(`Contoh: ${prefix + command} 2005\nMasukkan tahun lahir (1900-2026)`);
let shio = ["Tikus","Kerbau","Macan","Kelinci","Naga","Ular","Kuda","Kambing","Monyet","Ayam","Anjing","Babi"];
let nomor = [2,3,1,4,5,6,7,8,9,10,11,12];
let idx = (thn - 1900) % 12;
let angka = (thn % 9) + 1;
reply(`🐉 SHIO & NOMOR KEBERUNTUNGAN\n\n📅 Tahun: ${thn}\n🐅 Shio: ${shio[idx]}\n🔢 Nomor Hoki: ${nomor[idx]}, ${angka}, ${angka*2}\n💫 Gunakan untuk taruhan atau usaha.`);
}
break

case 'pasanganideal': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let pasangan = ["Pemimpin","Penurut","Kreatif","Setia","Romantis","Bijaksana","Petualang","Penyabar","Optimis","Mandiri","Lembut","Tegas"];
let cocok = ["Sapi/Sagitarius","Gemini/Virgo","Leo/Aquarius","Cancer/Pisces","Libra/Aquarius","Taurus/Virgo","Aries/Sagitarius","Capricorn/Taurus","Gemini/Libra","Scorpio/Pisces","Cancer/Virgo","Aries/Leo"];
reply(`💑 PASANGAN IDEAL\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💕 Karakter Pasangan: ${pasangan[jumlah]}\n♈ Zodiak Cocok: ${cocok[jumlah]}\n✨ Carilah pasangan dengan karakter tersebut.`);
}
break

case 'kariersukses': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 10;
let karier = ["Teknologi","Kesehatan","Pendidikan","Bisnis","Seni","Hukum","Keuangan","Pemasaran","Teknik","Pelayanan"];
let gaji = ["Rp 5-10 Jt","Rp 10-20 Jt","Rp 8-15 Jt","Rp 15-30 Jt","Rp 5-12 Jt","Rp 10-25 Jt","Rp 12-28 Jt","Rp 8-18 Jt","Rp 10-22 Jt","Rp 6-14 Jt"];
reply(`💼 KARIER SUKSES\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎯 Bidang: ${karier[jumlah]}\n💰 Potensi Gaji: ${gaji[jumlah]}\n✨ Tekuni bidang tersebut untuk meraih sukses.`);
}
break

case 'kesehatanprediksi': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 6;
let penyakit = ["Pencernaan","Pernapasan","Jantung","Sendi/Kepala","Stres/Kulit","Mata/Telinga"];
let solusi = ["Kurangi pedas","Olahraga teratur","Hindari lemak","Istirahat cukup","Meditasi","Jaga kebersihan"];
reply(`🏥 PREDIKSI KESEHATAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n⚠️ Rawan: ${penyakit[jumlah]}\n💊 Solusi: ${solusi[jumlah]}\n✨ Lakukan pencegahan sejak dini.`);
}
break

case 'bisnisusaha': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let usaha = ["Kuliner","Fashion","Properti","Digital","Agrobisnis","Kecantikan","Otomotif","Travel","Konsultan","Kerajinan","Peternakan","Perikanan"];
let modal = ["Rp 5-10 Jt","Rp 10-20 Jt","Rp 50-100 Jt","Rp 3-8 Jt","Rp 15-30 Jt","Rp 8-15 Jt","Rp 25-50 Jt","Rp 10-20 Jt","Rp 5-15 Jt","Rp 3-7 Jt","Rp 10-25 Jt","Rp 8-18 Jt"];
reply(`🏪 BISNIS & USAHA\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📌 Bidang: ${usaha[jumlah]}\n💰 Estimasi Modal: ${modal[jumlah]}\n✨ Peluang besar di bidang tersebut.`);
}
break

case 'pendidikanjalan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 8;
let jurusan = ["Kedokteran","Teknik","Ekonomi","Hukum","Seni","Pendidikan","Psikologi","IT"];
let prospek = ["Rumah Sakit","Industri","Perbankan","Pengadilan","Studio","Sekolah","Klinik","Startup"];
reply(`🎓 PENDIDIKAN & JURUSAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📚 Jurusan Cocok: ${jurusan[jumlah]}\n🏢 Prospek: ${prospek[jumlah]}\n✨ Raih kesuksesan di bidang tersebut.`);
}
break

case 'perjalananhidup': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let usiaSekarang = new Date().getFullYear() - parseInt(thn);
let fase = Math.floor(usiaSekarang / 12);
let faseHidup = ["Masa emas","Pendidikan","Karir awal","Pernikahan","Puncak karir","Settledown","Wisata","Purna tugas","Damai","Bijaksana","Spiritual","Akhir hayat"];
reply(`🌈 PERJALANAN HIDUP\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📌 Fase saat ini (${usiaSekarang}th): ${faseHidup[fase % 12]}\n✨ Nikmati setiap fase kehidupan.`);
}
break

case 'cocokbisnis': {
await XReaction();
let [nama, tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!nama || !tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} Budi,15,8,2005`);
let jumlahNama = nama.toLowerCase().replace(/[^a-z]/g, '').length;
let jumlahLahir = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 9 + 1;
let bisnis = ["Online shop","Katering","Jasa desain","Konsultan","Dropship","Laundry","Catering","Fotografi","Tutor"];
reply(`🤝 KECOCOKAN BISNIS\n\n👤 Nama: ${nama} (${jumlahNama})\n📅 Lahir: ${tgl}/${bln}/${thn} (${jumlahLahir})\n🏪 Bisnis Cocok: ${bisnis[(jumlahNama+jumlahLahir)%9]}\n✨ Kerja sama dengan mitra yang tepat.`);
}
break

case 'rumahtangga': {
await XReaction();
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split(',').map(v => v.trim());
if (!nama1 || !tgl1 || !bln1 || !thn1 || !nama2 || !tgl2 || !bln2 || !thn2) return reply(`Contoh: ${prefix + command} Budi,15,8,2005,Siti,10,5,2006`);
let jumlah = (parseInt(tgl1)+parseInt(bln1)+parseInt(thn1)+parseInt(tgl2)+parseInt(bln2)+parseInt(thn2)) % 5;
let harmoni = ["Sangat Harmonis 🌟","Harmonis 👍","Cukup 🤔","Kurang Harmonis ⚠️","Perlu Usaha 💪"];
let saran = ["Pertahankan komunikasi","Saling menghargai","Luangkan waktu bersama","Hindari konflik","Konsultasi ahli"];
reply(`🏠 KEHARMONISAN RUMAH TANGGA\n\n👤 ${nama1}: ${tgl1}/${bln1}/${thn1}\n👤 ${nama2}: ${tgl2}/${bln2}/${thn2}\n💕 Hasil: ${harmoni[jumlah]}\n💡 Saran: ${saran[jumlah]}`);
}
break

case 'keuanganmasa': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 12;
let bulan = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
let kondisi = ["Berlimpah","Stabil","Meningkat","Hati-hati","Cukup","Berkah","Boncos","Untung","Rugi","Investasi","Hemat","Kaya"];
reply(`💰 KEUANGAN MASA DEPAN\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📆 Bulan ${bulan[jumlah]}: ${kondisi[jumlah]}\n✨ ${jumlah<5?"Waktu tepat investasi":"Sebaiknya hemat pengeluaran"}`);
}
break

case 'ramalanbatu':
case 'batulahir': {
await XReaction();
let [tgl, bln] = text.split(',').map(v => v.trim());
if (!tgl || !bln) return reply(`Contoh: ${prefix + command} 15,8`);
let bulanNum = parseInt(bln);
let batu = ["Kecubung","Akik","Giok","Biduri","Yakut","Topaz","Safir","Opal","Kristal","Pirus","Garnet","Batu Bulan"];
let khasiat = ["Ketenangan","Keberanian","Kekayaan","Kebijaksanaan","Cinta","Sukses","Sembuh","Kreatif","Proteksi","Karisma","Rezeki","Kedamaian"];
reply(`💎 RAMALAN BATU LAHIR\n\n📅 Lahir: ${tgl}/${bln}\n💎 Batu: ${batu[bulanNum-1]}\n✨ Khasiat: ${khasiat[bulanNum-1]}\n🔮 Kenakan sebagai jimat keberuntungan.`);
}
break

case 'haritinggal':
case 'tglpindah': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 10;
let tanggal = [1,2,3,4,5,6,7,8,9,10];
let hasil = ["Kurang Baik","Baik","Sangat Baik","Buruk","Cukup","Baik","Sangat Baik","Kurang","Baik","Luar Biasa"];
reply(`📅 HARI BAIK PINDAH RUMAH\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n📌 Tanggal Hoki: ${tanggal[jumlah]}\n🎯 Prediksi: ${hasil[jumlah]}\n✨ Pilih tanggal tersebut untuk pindahan.`);
}
break

case 'ramalancintabulan': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)) % 7;
let kondisi = ["Bertemu jodoh","Hubungan memanas","Cinta baru datang","Harmonis","Masa tenang","Konflik reda","Percintaan seru"];
reply(`💖 RAMALAN CINTA BULAN INI\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n💕 Kondisi: ${kondisi[jumlah]}\n✨ Bulan ini ${jumlah<3?"waktunya move on":"waktunya seriusin hubungan"}`);
}
break

case 'nasibtahun': {
await XReaction();
let [tgl, bln, thn] = text.split(',').map(v => v.trim());
if (!tgl || !bln || !thn) return reply(`Contoh: ${prefix + command} 15,8,2005`);
let thnSekarang = new Date().getFullYear();
let jumlah = (parseInt(tgl)+parseInt(bln)+parseInt(thn)+thnSekarang) % 8;
let nasib = ["Keberuntungan","Perjuangan","Istirahat","Pengembangan","Puncak","Evaluasi","Transformasi","Ketenangan"];
reply(`🌟 NASIB DI TAHUN ${thnSekarang}\n\n📅 Lahir: ${tgl}/${bln}/${thn}\n🎯 Tema: ${nasib[jumlah]}\n✨ ${jumlah<4?"Tahun ini penuh kesempatan!":"Tahun untuk refleksi diri"}`);
}
break
case 'ultahku': {
  if (!text) return reply(`Kirim dengan format: .ultahku DD/MM/YYYY\nContoh: .ultahku 15/08/2005`)

  let args = text.split('/')
  if (args.length !== 3) {
    reply(`Format salah!\nGunakan: .ultahku DD/MM/YYYY`)
    break
  }

  let [day, month, year] = args.map(x => parseInt(x))
  if (!day || !month || !year) {
    reply(`Tanggal tidak valid. Gunakan format DD/MM/YYYY.`)
    break
  }

  let now = new Date()
  let birthDate = new Date(year, month - 1, day)
  let age = now.getFullYear() - birthDate.getFullYear()

  let nextBirthday = new Date(now.getFullYear(), month - 1, day)
  if (now > nextBirthday) {
    nextBirthday.setFullYear(now.getFullYear() + 1)
    age++
  }

  let diff = Math.ceil((nextBirthday - now) / (1000 * 60 * 60 * 24))

  reply(`📅 Tanggal lahir: *${day}/${month}/${year}*
🎂 Umur sekarang: *${age} tahun*
⏳ Ulang tahun berikutnya dalam: *${diff} hari*`)
}
break
case 'cekumur': {
await XReaction();
            if (!q) return reply('⚠️ Masukkan tanggal lahir dengan format: *YYYY-MM-DD*');

            const isValidFormat = /^\d{4}-\d{2}-\d{2}$/.test(q);
            if (!isValidFormat) {
                return reply('❌ Format tanggal salah!\nGunakan format: *YYYY-MM-DD*\nContoh: *2002-05-27*');
            }

            const tanggalLahir = new Date(q);
            if (isNaN(tanggalLahir.getTime())) {
                return reply('❌ Tanggal tidak valid. Pastikan kamu memasukkan tanggal lahir yang benar.');
            }

            const sekarang = new Date();

            let tahun = sekarang.getFullYear() - tanggalLahir.getFullYear();
            let bulan = sekarang.getMonth() - tanggalLahir.getMonth();
            let hari = sekarang.getDate() - tanggalLahir.getDate();

            if (hari < 0) {
                bulan--;
                const bulanSebelumnya = new Date(sekarang.getFullYear(), sekarang.getMonth(), 0).getDate();
                hari += bulanSebelumnya;
            }

            if (bulan < 0) {
                tahun--;
                bulan += 12;
            }

            let selisihMs = sekarang - tanggalLahir;

            const msPerDetik = 1000;
            const msPerMenit = msPerDetik * 60;
            const msPerJam = msPerMenit * 60;
            const msPerHari = msPerJam * 24;
            const msPerTahun = msPerHari * 365.25;

            const totalTahun = Math.floor(selisihMs / msPerTahun);
            selisihMs %= msPerTahun;

            const totalHari = Math.floor(selisihMs / msPerHari);
            selisihMs %= msPerHari;

            const totalJam = Math.floor(selisihMs / msPerJam);
            selisihMs %= msPerJam;

            const totalMenit = Math.floor(selisihMs / msPerMenit);
            selisihMs %= msPerMenit;

            const totalDetik = Math.floor(selisihMs / msPerDetik);

            const isUlangTahun = sekarang.getDate() === tanggalLahir.getDate() &&
                sekarang.getMonth() === tanggalLahir.getMonth();

            const ucapanUlangTahun = isUlangTahun ?
                '\n🎉 *Selamat ulang tahun!* Semoga panjang umur, sehat selalu, dan tercapai segala cita-cita! 🎂' :
                '';

            await reply(
                `📅 Umur kamu saat ini:\n` +
                `*${tahun} tahun, ${bulan} bulan, ${hari} hari*\n\n` +
                `⏳ Total waktu hidup:\n` +
                `*${totalTahun} tahun, ${totalHari} hari, ${totalJam} jam, ${totalMenit} menit, ${totalDetik} detik*` +
                `${ucapanUlangTahun}`, {
                    quoted: m
                }
            );
        }
        break
case 'nomerhoki': case 'nomorhoki': {
await XReaction();
if (!Number(text)) return reply(`Contoh : ${prefix + command} 6288292024190`)
let anu = await primbon.nomer_hoki(Number(text))
if (anu.status == false) return reply(anu.message)
reply(`• *Nomor HP :* ${anu.message.nomer_hp}\n• *Angka Shuzi :* ${anu.message.angka_shuzi}\n• *Energi Positif :*\n- Kekayaan : ${anu.message.energi_positif.kekayaan}\n- Kesehatan : ${anu.message.energi_positif.kesehatan}\n- Cinta : ${anu.message.energi_positif.cinta}\n- Kestabilan : ${anu.message.energi_positif.kestabilan}\n- Persentase : ${anu.message.energi_positif.persentase}\n• *Energi Negatif :*\n- Perselisihan : ${anu.message.energi_negatif.perselisihan}\n- Kehilangan : ${anu.message.energi_negatif.kehilangan}\n- Malapetaka : ${anu.message.energi_negatif.malapetaka}\n- Kehancuran : ${anu.message.energi_negatif.kehancuran}\n- Persentase : ${anu.message.energi_negatif.persentase}`)
}
break
case 'artimimpi': case 'tafsirmimpi': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} belanja`)
let anu = await primbon.tafsir_mimpi(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Mimpi :* ${anu.message.mimpi}\n• *Arti :* ${anu.message.arti}\n• *Solusi :* ${anu.message.solusi}`)
}
break
case 'ramalanjodoh': case 'ramaljodoh': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalanjodohbali': case 'ramaljodohbali': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'suamiistri': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Suami :* ${anu.message.suami.nama}\n• *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n• *Nama Istri :* ${anu.message.istri.nama}\n• *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalancinta': case 'ramalcinta': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'artinama': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika Ardianta`)
let anu = await primbon.arti_nama(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'kecocokannama': case 'cocoknama': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Life Path :* ${anu.message.life_path}\n• *Destiny :* ${anu.message.destiny}\n• *Destiny Desire :* ${anu.message.destiny_desire}\n• *Personality :* ${anu.message.personality}\n• *Persentase :* ${anu.message.persentase_kecocokan}`)
}
break
case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika|Novia`)
let [nama1, nama2] = text.split`|`
let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
if (anu.status == false) return reply(anu.message)
Alice.sendImage(m.chat,  anu.message.gambar, `• *Nama Anda :* ${anu.message.nama_anda}\n• *Nama Pasangan :* ${anu.message.nama_pasangan}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}`)
}
break
case 'jadianpernikahan': case 'jadiannikah': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 6, 12, 2020`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal Pernikahan :* ${anu.message.tanggal}\n• *karakteristik :* ${anu.message.karakteristik}`)
}
break
case 'sifatusaha': {
await XReaction();
if (!text)return reply(`Contoh : ${prefix + command} 28, 12, 2021`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Usaha :* ${anu.message.usaha}`)
}
break
case 'rejeki': case 'rezeki': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Rezeki :* ${anu.message.rejeki}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'pekerjaan': case 'kerja': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Pekerjaan :* ${anu.message.pekerjaan}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalannasib': case 'ramalnasib': case 'nasib': {
await XReaction();
if (!text) return reply(`Contoh : 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.ramalan_nasib(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Analisa :* ${anu.message.analisa}\n• *Angka Akar :* ${anu.message.angka_akar}\n• *Sifat :* ${anu.message.sifat}\n• *Elemen :* ${anu.message.elemen}\n• *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`)
}
break
case 'potensipenyakit': case 'penyakit': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Analisa :* ${anu.message.analisa}\n• *Sektor :* ${anu.message.sektor}\n• *Elemen :* ${anu.message.elemen}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'artitarot': case 'tarot': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
Alice.sendImage(m.chat, anu.message.image, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Simbol Tarot :* ${anu.message.simbol_tarot}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'fengshui': {
await XReaction();
if (!text) return `Contoh : ${prefix + command} Dika, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
let [nama, gender, tahun] = text.split`,`
let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tahun_lahir}\n• *Gender :* ${anu.message.jenis_kelamin}\n• *Angka Kua :* ${anu.message.angka_kua}\n• *Kelompok :* ${anu.message.kelompok}\n• *Karakter :* ${anu.message.karakter}\n• *Sektor Baik :* ${anu.message.sektor_baik}\n• *Sektor Buruk :* ${anu.message.sektor_buruk}`)
}
break
case 'haribaik': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.petung_hari_baik(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.tgl_lahir}\n• *Kala Tinantang :* ${anu.message.kala_tinantang}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'harisangar': case 'taliwangke': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'harinaas': case 'harisial': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Hari Naas :* ${anu.message.hari_naas}\n• *Info :* ${anu.message.catatan}\n• *Catatan :* ${anu.message.info}`)
}
break
case 'nagahari': case 'harinaga': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'arahrejeki': case 'arahrezeki': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Rezeki :* ${anu.message.arah_rejeki}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'peruntungan': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} DIka, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`)
let [nama, tgl, bln, thn, untuk] = text.split`,`
let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'weton': case 'wetonjawa': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.weton_jawa(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal :* ${anu.message.tanggal}\n• *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n• *Watak Hari :* ${anu.message.watak_hari}\n• *Naga Hari :* ${anu.message.naga_hari}\n• *Jam Baik :* ${anu.message.jam_baik}\n• *Watak Kelahiran :* ${anu.message.watak_kelahiran}`)
}
break
case 'sifat': case 'karakter': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Garis Hidup :* ${anu.message.garis_hidup}`)
}
break
case 'keberuntungan': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}`)
}
break
case 'memancing': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 12, 1, 2022`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal :* ${anu.message.tgl_memancing}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'masasubur': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`)
let [tgl, bln, thn, siklus] = text.split`,`
let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
if (anu.status == false) return reply(anu.message)
reply(`• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'zodiak': case 'zodiac': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} 7 7 2005`)
let zodiak = [
["capricorn", new Date(1970, 0, 1)],
["aquarius", new Date(1970, 0, 20)],
["pisces", new Date(1970, 1, 19)],
["aries", new Date(1970, 2, 21)],
["taurus", new Date(1970, 3, 21)],
["gemini", new Date(1970, 4, 21)],
["cancer", new Date(1970, 5, 22)],
["leo", new Date(1970, 6, 23)],
["virgo", new Date(1970, 7, 23)],
["libra", new Date(1970, 8, 23)],
["scorpio", new Date(1970, 9, 23)],
["sagittarius", new Date(1970, 10, 22)],
["capricorn", new Date(1970, 11, 22)]
].reverse()

function getZodiac(month, day) {
let d = new Date(1970, month - 1, day)
return zodiak.find(([_,_d]) => d >= _d)[0]
}
let date = new Date(text)
if (date == 'Invalid Date') return date
let d = new Date()
let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

let zodiac = await getZodiac(birth[1], birth[2])

let anu = await primbon.zodiak(zodiac)
if (anu.status == false) return reply(anu.message)
reply(`• *Zodiak :* ${anu.message.zodiak}\n• *Nomor :* ${anu.message.nomor_keberuntungan}\n• *Aroma :* ${anu.message.aroma_keberuntungan}\n• *Planet :* ${anu.message.planet_yang_mengitari}\n• *Bunga :* ${anu.message.bunga_keberuntungan}\n• *Warna :* ${anu.message.warna_keberuntungan}\n• *Batu :* ${anu.message.batu_keberuntungan}\n• *Elemen :* ${anu.message.elemen_keberuntungan}\n• *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'shio': {
await XReaction();
if (!text) return reply(`Contoh : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`)
let anu = await primbon.shio(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Hasil :* ${anu.message}`)
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Primbon Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Owner Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case "sendptv": {
  if (!isOwner) return XRO()

  let q = m.quoted || m
  let msgContent = q.msg || q
  let mime = msgContent.mimetype || ""

  if (!/video|image|gif|webp|viewOnce/.test(mime)) {
    return reply(`*• Example :* ${prefix + command} 628xxx / @tag *[reply media]*`)
  }

  let target = m.mentionedJid[0] 
      || (m.quoted ? m.quoted.sender : null) 
      || (text ? text.replace(/[^0-9]/g, '') + "@s.whatsapp.net" : null)

  if (!target) return reply("Tag / reply / masukkan nomor target!")

  let media = await q.download?.() || null
  if (!media) return reply("Media tidak bisa diunduh.")

  await Alice.sendMessage(m.chat, {
    react: {
      text: "⏳",
      key: m.key
    }
  })

  await Alice.sendMessage(target, {
    video: media,
    ptv: true
  })

  await Alice.sendMessage(m.chat, {
    react: {
      text: "✅",
      key: m.key
    }
  })

  reply("Done kak, PTV berhasil dikirim ✔️")
}
break
case 'clearregister': {
  if (!isOwner) return reply('❌ Khusus owner')

  let users = global.db.data.users

  if (text === 'all') {
    let total = 0
    for (let id in users) {
      if (users[id].registered) {
        users[id].registered = false
        users[id].name = ''
        users[id].age = 0
        users[id].regTime = null
        total++
      }
    }
    return reply(`🗑️ ${total} user direset`)
  }

  let target = null

  if (m.mentionedJid && m.mentionedJid[0]) {
    target = m.mentionedJid[0]
  } else if (m.quoted && m.quoted.sender) {
    target = m.quoted.sender
  } else if (text && /^[0-9]+$/.test(text)) {
    target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  } else if (text) {
    let found = Object.entries(users).find(([id, data]) =>
      data.name && data.name.toLowerCase() === text.toLowerCase()
    )
    if (found) target = found[0]
  }

  if (!target) return reply('❌ User tidak ditemukan')

  let user = users[target]
  if (!user || !user.registered) return reply('❌ User belum register')

  user.registered = false
  user.name = ''
  user.age = 0
  user.regTime = null

  reply(`🗑️ @${target.split('@')[0]}`, { mentions: [target] })
}
break
case 'clearuser': {
  if (!isOwner) return reply('❌ Khusus owner')

  if (text !== 'yakin') {
    return reply('⚠️ Ketik:\n.clearuser yakin\nuntuk konfirmasi')
  }

  const usersFile = './AliceDatabase/users-db/users.json'

  if (!fs.existsSync(usersFile)) {
    return reply('❌ File users.json tidak ditemukan')
  }

  let usersList = JSON.parse(fs.readFileSync(usersFile))
  let total = usersList.length

  fs.writeFileSync(usersFile, JSON.stringify([], null, 2))

  reply(`🗑️ users.json berhasil dikosongkan

👥 Total user dihapus: ${total}`)
}
break
case 'listregister': {
  let users = global.db.data.users

  let registeredUsers = Object.entries(users)
    .filter(([id, data]) => data.registered)

  if (registeredUsers.length === 0) {
    return reply('❌ Belum ada user yang register')
  }

  let teks = `📋 *LIST USER REGISTER*\n`
  teks += `━━━━━━━━━━━━━━━━━━\n`
  teks += `👥 Total User: ${registeredUsers.length}\n\n`

  // list owner
  let ownerList = [...global.owner, botNumber]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')

  registeredUsers.forEach(([id, data], i) => {
    let number = id.split('@')[0]

    // cek premium
    let isUserPremium = Array.isArray(premium)
      ? premium.includes(id)
      : false

    // cek owner
    let isUserOwner = ownerList.includes(id)

let waktu = data.regTime
  ? new Date(data.regTime).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  : 'Tidak diketahui'

    teks += `👤 *User ${i + 1}*\n`
    teks += `• Tag: @${number}\n`
    teks += `• Nama: ${data.name || '-'}\n`
    teks += `• Umur: ${data.age || '-'}\n`
    teks += `• Premium: ${isUserPremium ? '💎 Yes' : 'Free'}\n`
    teks += `• Owner: ${isUserOwner ? '👑 Yes' : 'No'}\n`
    teks += `• Register: ${waktu}\n`
    teks += `━━━━━━━━━━━━━━━━━━\n`
  })

  Alice.sendMessage(m.chat, {
    text: teks,
    mentions: registeredUsers.map(v => v[0])
  }, { quoted: m })
}
break
case 'regmode': {
if (!isOwner) return XRO()

  let arg = (args[0] || '').toLowerCase()

  if (arg === 'on') {
    global.db.data.settings.register = true
    reply('✅ Register mode ON')
  } else if (arg === 'off') {
    global.db.data.settings.register = false
    reply('✅ Register mode OFF')
  } else {
    reply(`Status: ${global.db.data.settings.register ? 'ON' : 'OFF'}`)
  }
}
break
case "setmenu": {
if (!isOwner) return XRO()

const path = "./AliceDatabase/system-db/setmenu.json"
let db = JSON.parse(fs.readFileSync(path))

if (!text) {
return reply(`*SET MENU BOT*

1. List Menu
2. CTA Button
3. List + CTA
4. Image Menu
5. Full Menu

contoh:
.setmenu 1`)
}

if (text == "1") {
db.menu = 1
}
else if (text == "2") {
db.menu = 2
}
else if (text == "3") {
db.menu = 3
}
else if (text == "4") {
db.menu = 4
}
else if (text == "5") {
db.menu = 5
}
else {
return reply("pilihan hanya 1 sampai 5")
}

fs.writeFileSync(path, JSON.stringify(db, null, 2))

reply(`✅ menu berhasil diubah ke *${db.menu}*`)
}
break
case 'botstats': {
if (!isOwner) return XRO()
try {

let groups = Object.values(await Alice.groupFetchAllParticipating().catch(_=> []))

let totalGroup = groups.length
let totalMembers = 0
let totalAdmins = 0

groups.forEach(g => {
totalMembers += g.participants.length
g.participants.forEach(p=>{
if(p.admin) totalAdmins++
})
})

let biggestGroup = groups.sort((a,b)=>b.participants.length-a.participants.length)[0]
let smallestGroup = groups.sort((a,b)=>a.participants.length-b.participants.length)[0]

let biggestName = biggestGroup ? biggestGroup.subject : "-"
let biggestSize = biggestGroup ? biggestGroup.participants.length : 0

let smallestName = smallestGroup ? smallestGroup.subject : "-"
let smallestSize = smallestGroup ? smallestGroup.participants.length : 0

let avgMembers = totalGroup ? Math.floor(totalMembers / totalGroup) : 0

let users = Object.keys(global.db.data.users || {})
let chats = Object.keys(global.db.data.chats || {})

let totalUsers = users.length
let totalChats = chats.length
let totalPrivate = chats.filter(v=>v.endsWith('@s.whatsapp.net')).length

let premium = []
try {
premium = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/premium.json'))
} catch {}

let totalPremium = premium.length

let banned = {}
try {
banned = JSON.parse(fs.readFileSync('./AliceDatabase/users-db/banned.json'))
} catch {}

let totalBanned = Object.keys(banned).length

let setcmd = {}
try {
setcmd = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/setcmd.json'))
} catch {}

let totalSetcmd = Object.keys(setcmd).length

let errorData = {}
try {
errorData = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/error.json'))
} catch {}

let totalErrorCmd = Object.keys(errorData).length

let totalError = 0
let lastErrorCmd = "-"
let lastErrorTime = 0

Object.entries(errorData).forEach(([cmd,data])=>{
totalError += data.total
if(data.lastTime > lastErrorTime){
lastErrorTime = data.lastTime
lastErrorCmd = cmd
}
})

let sewaData = {}
try {
sewaData = JSON.parse(fs.readFileSync('./AliceDatabase/users-db/sewa.json'))
} catch {}

let totalSewa = Object.keys(sewaData).length

let replyMode = "-"
try {
let rm = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/replymode.json'))
replyMode = rm.mode
} catch {}

let topCmdData = {}
try {
topCmdData = JSON.parse(fs.readFileSync('./AliceDatabase/system-db/AliceTop.json'))
} catch {}

let totalCmd = Object.keys(topCmdData).length
let totalCmdUsed = Object.values(topCmdData).reduce((a,b)=>a+b,0)

let top5 = Object.entries(topCmdData)
.sort((a,b)=>b[1]-a[1])
.slice(0,5)

let timestamp = speed()
let latency = speed() - timestamp

let code = fs.readFileSync("./Alice.js").toString()

let totalFeature = (code.match(/case\s+'|case\s+"/g) || []).length

let totalModule = 0
try {
totalModule = fs.readdirSync("./node_modules")
.filter(v => !v.startsWith(".")).length
} catch {}

let totalScraper = 0
try {
totalScraper = fs.readdirSync("./AliceSystem/AliceScraper")
.filter(v => v.endsWith(".js")).length
} catch {}

let totalFile = 0
let totalFolder = 0

function scan(dir){
let files = fs.readdirSync(dir)
for (let file of files){

let full = dir + "/" + file
let stat = fs.statSync(full)

if(stat.isDirectory()){
totalFolder++
scan(full)
}else{
totalFile++
}

}
}

scan("./")

function getSize(dir){
let size = 0
let files = fs.readdirSync(dir)

for (let file of files){

let full = dir + "/" + file
let stat = fs.statSync(full)

if(stat.isDirectory()){
size += getSize(full)
}else{
size += stat.size
}

}

return size
}

let projectSize = (getSize("./") / 1024 / 1024).toFixed(2)

let cpuModel = os.cpus()[0].model
let cpuCore = os.cpus().length
let cpuSpeed = os.cpus()[0].speed

let ramUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)
let ramTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2)
let ramFree = (os.freemem() / 1024 / 1024 / 1024).toFixed(2)

function runtime(seconds){
seconds = Number(seconds)
let d = Math.floor(seconds / (3600*24))
let h = Math.floor(seconds % (3600*24) / 3600)
let m = Math.floor(seconds % 3600 / 60)
let s = Math.floor(seconds % 60)
return `${d}d ${h}h ${m}m ${s}s`
}

let topCmdText = top5.map(v=>`│ ${v[0]} : ${v[1]}x`).join('\n')

let teks = `
╭───〔 ALICE BOT STATS 〕

🤖 BOT INFO
│ Name : ${botname}
│ Owner : ${ownername}
│ Prefix : ${prefa}
│ Mode : ${global.self ? "Self" : "Public"}
│ Runtime : ${runtime(process.uptime())}
│ Speed : ${latency.toFixed(4)} ms

📊 DATABASE
│ Users : ${totalUsers}
│ Premium : ${totalPremium}
│ Banned : ${totalBanned}
│ Chats : ${totalChats}
│ Private Chat : ${totalPrivate}
│ Sticker Cmd : ${totalSetcmd}

👥 GROUP (Realtime)
│ Bot Join : ${totalGroup} Groups
│ Total Member : ${totalMembers}
│ Total Admin : ${totalAdmins}
│ Avg Member : ${avgMembers}
│ Biggest : ${biggestName} (${biggestSize})
│ Smallest : ${smallestName} (${smallestSize})

📦 PROJECT
│ Feature : ${totalFeature}
│ Module : ${totalModule}
│ Scraper : ${totalScraper}
│ Files : ${totalFile}
│ Folder : ${totalFolder}
│ Size : ${projectSize} MB

📦 SEWA SYSTEM
│ Total Sewa : ${totalSewa}

⚙️ SYSTEM REPLY
│ Reply Mode : ${replyMode}

🚨 ERROR LOG
│ Error Cmd : ${totalErrorCmd}
│ Total Error : ${totalError}
│ Last Error Cmd : ${lastErrorCmd}
│ Last Error Time : ${lastErrorTime ? moment(lastErrorTime).tz('Asia/Jakarta').format('DD/MM HH:mm') : '-'}

📈 COMMAND STATS
│ Total Cmd : ${totalCmd}
│ Cmd Used : ${totalCmdUsed}

🏆 TOP COMMAND
${topCmdText}

🖥 SERVER
│ Platform : ${os.platform()}
│ Hostname : ${os.hostname()}
│ NodeJS : ${process.version}
│ CPU : ${cpuModel}
│ Core : ${cpuCore}
│ Speed : ${cpuSpeed} MHz

🧠 MEMORY
│ RAM Used : ${ramUsed} MB
│ RAM Free : ${ramFree} GB
│ RAM Total : ${ramTotal} GB

⏱ SYSTEM
│ System Uptime : ${runtime(os.uptime())}
│ Time : ${moment().tz('Asia/Jakarta').format('HH:mm:ss')}
│ Date : ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY')}
│ Zone : Asia/Jakarta

╰─────────────────
`

reply(teks)

} catch (err) {
console.log(err)
reply("Error mengambil botstats")
}
}
break
case 'setstc': {
if (!isOwner) return XRO()
  if (!m.quoted) return reply('reply stickernya')

  const q = m.quoted
  const mime  = (q.msg || q).mimetype || ''
  const mtype = q.mtype || ''

  const isSticker = /sticker/i.test(mtype) || /webp/i.test(mime)

  if (!isSticker)
    return reply('itu bukan sticker')

  if (!text)
    return reply('masukkan commandnya\ncontoh: .setstc .ping')

  let stickerId =
    (q.msg || q).fileSha256 ||
    q.message?.stickerMessage?.fileSha256

  if (!stickerId)
    return reply('sticker tidak valid')

  stickerId = stickerId.toString('base64')

  setcmdDB[stickerId] = text.replace(prefix, '').trim()

  saveSetcmd()

  reply('command berhasil diset ke sticker')
}
break
case 'delstc': {
if (!isOwner) return XRO()
  if (!m.quoted) return reply('reply stickernya')

  const q = m.quoted

  let stickerId =
    (q.msg || q).fileSha256 ||
    q.message?.stickerMessage?.fileSha256

  if (!stickerId)
    return reply('sticker tidak valid')

  stickerId = stickerId.toString('base64')

  if (!setcmdDB[stickerId])
    return reply('sticker tidak terdaftar')

  delete setcmdDB[stickerId]
  saveSetcmd()

  reply('command sticker berhasil dihapus')
}
break
case 'liststc': {
if (!isOwner) return XRO()

  const keys = Object.keys(setcmdDB)

  if (!keys.length)
    return reply('belum ada sticker yang diset')

  let teks = 'list sticker command\n\n'

  keys.forEach((id, i) => {
    teks += `${i+1}. ${setcmdDB[id]}\n`
  })

  reply(teks)
}
break
case 'listerror': {
if (!isOwner) return XRO()

    if (Object.keys(errorDB).length === 0)
        return reply("✅ Tidak ada error tercatat.")

    let teks = "📛 *LIST ERROR FITUR*\n\n"

    for (let cmd in errorDB) {
        let data = errorDB[cmd]
        let waktu = moment(data.lastTime).tz('Asia/Jakarta').format('DD/MM HH:mm')

        teks += `• ${cmd}\n`
        teks += `   Total  : ${data.total}\n`
        teks += `   Last   : ${waktu}\n`
        teks += `   Msg    : ${data.lastError}\n\n`
    }

    reply(teks)
}
break
case 'cekerror': {
if (!isOwner) return XRO()
    if (!text) return reply("Contoh: .error play")

    if (!errorDB[text])
        return reply("Command tidak ditemukan dalam error log.")

    let data = errorDB[text]

    let waktu = moment(data.lastTime).tz('Asia/Jakarta')
        .format('DD/MM/YYYY HH:mm:ss')

    reply(
`📛 DETAIL ERROR

• Command : ${text}
• Total   : ${data.total}
• Waktu   : ${waktu}

• Message :
${data.lastError}

• Stack :
${data.lastStack}`
    )
}
break
case 'clearerror': {
if (!isOwner) return XRO()

    errorDB = {}
    saveErrorDB()

    reply("✅ Semua data error berhasil direset.")
}
break
case 'ban': {
if (!isOwner) return XRO()

  let args = text.split(" ")
  let nomor = args[0]
  let waktu = args[1]

  let target = m.quoted 
      ? m.quoted.sender 
      : nomor 
        ? nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        : null

  if (!target) {
    return reply(`⚠️ reply pesan user atau ketik nomor!

Contoh:
.ban (reply pesan)
.ban 628xxxx
.ban 628xxxx 1h`)
  }

  if (!waktu) {
    bannedUsers[target] = {
      permanent: true
    }
    saveBanned()
    return reply(`🚫 ${target.split('@')[0]} diban PERMANEN`)
  }

  const ms = require('ms')
  let duration = ms(waktu)

  if (!duration) return reply('format waktu salah! Contoh: 10m / 1h / 1d')

  bannedUsers[target] = {
    permanent: false,
    expired: Date.now() + duration
  }

  saveBanned()

  reply(`⏳ ${target.split('@')[0]} dibanned selama ${waktu}`)
}
break
case 'unban': {
if (!isOwner) return XRO()

  let nomor = text
  let target = m.quoted 
      ? m.quoted.sender 
      : nomor 
        ? nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        : null

  if (!target) return reply('reply pesan user atau ketik nomor!')

  if (!bannedUsers[target]) {
    return reply('user tidak dibanned.')
  }

  delete bannedUsers[target]
  saveBanned()

  reply(`✅ ${target.split('@')[0]} berhasil diunban`)
}
break
case 'listban': {
if (!isOwner) return XRO()

  let users = Object.keys(bannedUsers)

  if (users.length === 0) {
    return reply('📭 tidak ada user yang dibanned.')
  }

  let teks = `📜 *LIST USER BANNED*\n\n`

  for (let jid of users) {
    let data = bannedUsers[jid]
    let nomor = jid.split('@')[0]

    if (data.permanent) {
      teks += `• ${nomor}\n  status: Permanent\n\n`
    } else {
      let sisa = data.expired - Date.now()

      if (sisa <= 0) {
        delete bannedUsers[jid]
        saveBanned()
        continue
      }

      let menit = Math.floor(sisa / 60000)
      teks += `• ${nomor}\n  status: ${menit} menit lagi\n\n`
    }
  }

  reply(teks)
}
break
case 'cekban': {
if (!isOwner) return XRO()

  let nomor = text
  let target = m.quoted 
      ? m.quoted.sender 
      : nomor 
        ? nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        : null

  if (!target) return reply('reply pesan user atau ketik nomor!')

  let data = bannedUsers[target]

  if (!data) {
    return reply('✅ user tidak dibanned.')
  }

  if (data.permanent) {
    return reply(`🚫 ${target.split('@')[0]} diban PERMANEN`)
  }

  let sisa = data.expired - Date.now()

  if (sisa <= 0) {
    delete bannedUsers[target]
    saveBanned()
    return reply('✅ ban sudah expired.')
  }

  let menit = Math.floor(sisa / 60000)

  reply(`⏳ ${target.split('@')[0]} masih dibanned.\nsisa waktu: ${menit} menit`)
}
break
case 'autoaiset': {
if (!isOwner) return XRO()

    let groups = await Alice.groupFetchAllParticipating()

    let groupList = Object.entries(groups).map(([id, data]) => ({
        id,
        subject: data.subject,
        members: data.participants.length,
        admins: data.participants.filter(p => p.admin).length,
        open: data.announce ? 'Tertutup' : 'Terbuka'
    }))

    if (!groupList.length)
        return reply('Bot tidak ada di group manapun')

    let autoGroups = autoAI.getAutoAIGroup()

    if (!args[0]) {

        let teks = '📋 *AUTO AI GROUP SETTING*\n\n'

        groupList.forEach((gc, i) => {

            let status = autoGroups.includes(gc.id) ? '🟢 Aktif' : '🔴 Nonaktif'

            teks += `${i + 1}. ${gc.subject}\n`
            teks += `   🆔 ${gc.id}\n`
            teks += `   👥 Member: ${gc.members}\n`
            teks += `   👑 Admin: ${gc.admins}\n`
            teks += `   🔓 Group: ${gc.open}\n`
            teks += `   ⚙️ AutoAI: ${status}\n\n`
        })

        teks += `Cara pakai:\n.autoaiset <nomor> on/off`

        return reply(teks)
    }

    let nomor = parseInt(args[0])
    let action = args[1]

    if (isNaN(nomor) || nomor < 1 || nomor > groupList.length)
        return reply('❌ Nomor tidak valid')

    let groupId = groupList[nomor - 1].id
    let groupName = groupList[nomor - 1].subject

    if (action === 'on') {

        if (autoGroups.includes(groupId))
            return reply(`AutoAI sudah aktif di ${groupName}`)

        autoGroups.push(groupId)
        autoAI.saveAutoAIGroup(autoGroups)

        return reply(`✅ AutoAI berhasil diaktifkan di ${groupName}`)
    }

    if (action === 'off') {

        if (!autoGroups.includes(groupId))
            return reply(`AutoAI belum aktif di ${groupName}`)

        autoGroups = autoGroups.filter(id => id !== groupId)
        autoAI.saveAutoAIGroup(autoGroups)

        return reply(`❌ AutoAI dimatikan di ${groupName}`)
    }

    reply('Format salah\n.autoaiset <nomor> on/off')
}
break
case 'setreply': {
  if (!isOwner) return XRO()

  let nomor = parseInt(args[0])

  if (!nomor || nomor < 1 || nomor > 5) {
    return reply(`📌 Mode tersedia:

1. Default
2. Interactive
3. Forwarded
4. Simple
5. Business

Contoh:
${prefix + command} 3`)
  }

  if (!fs.existsSync('./AliceDatabase')) {
    fs.mkdirSync('./AliceDatabase')
  }

  fs.writeFileSync(modeFile, JSON.stringify({ mode: nomor }, null, 2))

  reply(`✅ Mode reply diganti ke ${nomor}`)
}
break
case 'addrespon': {
    if (!isOwner) return XRO()
    if (!text) return reply('Contoh:\n.addrespon hai\n\nReply pesan.')

    let key = text.toLowerCase().trim()
    if (getRespon(key)) return reply('Key sudah ada')
    if (!m.quoted) return reply('Reply pesan media / text')

    let quoted = m.quoted
    let type = ''
    let content = ''

    if (quoted.mtype === 'imageMessage') {
        type = 'image'
        content = (await quoted.download()).toString('base64')
    } else if (quoted.mtype === 'videoMessage') {
        type = 'video'
        content = (await quoted.download()).toString('base64')
    } else if (quoted.mtype === 'audioMessage') {
        type = 'audio'
        content = (await quoted.download()).toString('base64')
    } else if (quoted.mtype === 'stickerMessage') {
        type = 'sticker'
        content = (await quoted.download()).toString('base64')
    } else if (quoted.text) {
        type = 'text'
        content = quoted.text
    } else {
        return reply('Tipe tidak didukung')
    }

    addRespon(key, type, content)
    reply(`Respon "${key}" berhasil ditambahkan (${type})`)
}
break
case 'listrespon': {
    let data = listRespon()
    if (!data.length) return reply('Belum ada respon')

    let teks = '*LIST RESPONSE*\n\n'
    data.forEach((v, i) => {
        teks += `${i+1}. ${v.key} (${v.type})\n`
    })

    reply(teks)
}
break
case 'delrespon': {
    if (!isOwner) return XRO()
    if (!text) return reply('Masukkan key')

    if (!getRespon(text.toLowerCase()))
        return reply('Key tidak ditemukan')

    delRespon(text.toLowerCase())
    reply('Respon berhasil dihapus')
}
break
case 'setpayment': {
    if (!isOwner) return XRO()

    if (!text) {
        return reply(
`Format:
.setpayment <field> <value>

Field:
qris
qris_an
dana
dana_an
gopay
gopay_an

Contoh:
.setpayment dana 0857xxxx`
        )
    }

    const fs = require('fs')
    const path = './AliceSet.js'

    let args = text.split(' ')
    let field = args.shift().toLowerCase()
    let value = args.join(' ')

    if (!value) return reply('❌ Value kosong')

    let allowed = [
        'qris',
        'qris_an',
        'dana',
        'dana_an',
        'gopay',
        'gopay_an'
    ]

    if (!allowed.includes(field))
        return reply('❌ Field tidak valid')

    let file = fs.readFileSync(path, 'utf8')

    let regex = new RegExp(`${field}:\\s*['"\`].*?['"\`]`)

    let newLine = `${field}: '${value}'`

    if (!regex.test(file))
        return reply('❌ Field tidak ditemukan di AliceSet.js')

    file = file.replace(regex, newLine)

    fs.writeFileSync(path, file)

    reply(`✅ Payment ${field} berhasil diubah`)
}
break
case "ptvch": {
  if (!isOwner) return XRO()
  let q = m.quoted || m
  let msgContent = q.msg || q
  let mime = msgContent.mimetype || ""

  if (!/webp|image|video|gif|viewOnce/g.test(mime)) {
    reply(`*• Example :* ${prefix + command} *[reply/send media]*`)
    break
  }

  let media = await q.download?.() || q.download?.media || null
  if (!media) {
    reply("Media tidak bisa diunduh.")
    break
  }

  // react proses
  await Alice.sendMessage(m.chat, {
    react: {
      text: "⏳",
      key: m.key
    }
  })

  await Alice.sendMessage(idch, {
    video: media,
    ptv: true
  })

  // react done
  await Alice.sendMessage(m.chat, {
    react: {
      text: "✅",
      key: m.key
    }
  })

  reply("Done kak, PTV berhasil dikirim ✔️")
}
break
case 'playch': {
    if (!isOwner) return XRO()
    if (!text) return reply('🎵 Masukkan judul lagu!\n\nContoh: *.playch Jakarta Hari Ini*')

    await Alice.sendMessage(m.chat, { react: { text: '🕐', key: m.key } })

    const fs = require('fs')
    const path = require('path')
    const axios = require('axios')
    const { exec } = require('child_process')
    const { promisify } = require('util')
    const execPromise = promisify(exec)

    try {

        let ytsSearch = await yts(text)
        let ytRes = ytsSearch.videos[0]

        if (!ytRes) return reply('❌ Lagu tidak ditemukan.')

        let data = await ytdl(ytRes.url, 'mp3')

        let tmpDir = path.join(__dirname, 'tmp')
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

        let inputPath = path.join(tmpDir, `dl_${Date.now()}.mp3`)
        let outputPath = path.join(tmpDir, `dl_${Date.now()}.opus`)

        let response = await axios({
            url: data.download,
            method: 'GET',
            responseType: 'stream'
        })

        let writer = fs.createWriteStream(inputPath)
        response.data.pipe(writer)

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve)
            writer.on('error', reject)
        })

        await execPromise(
            `ffmpeg -i "${inputPath}" -c:a libopus -b:a 48k -vbr on "${outputPath}"`
        )

        let buffer = fs.readFileSync(outputPath)

        await Alice.sendMessage(idch, {
            audio: buffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    thumbnailUrl: ytRes.thumbnail,
                    title: data.title,
                    body: `Duration: ${ytRes.timestamp}`,
                    sourceUrl: ytRes.url,
                    renderLargerThumbnail: true,
                    mediaType: 1
                }
            }
        }, { quoted: m })

        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath)
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath)

        reply(`✅ *Berhasil dikirim ke channel!* 🎵 ${data.title}\n🔗 ${global.channel}`)

    } catch (e) {
        console.error(e)
        reply('❌ Terjadi kesalahan saat proses.')
    }
}
break
case 'p2': {
    if (!isOwner) return XRO()
    if (!text) return reply('🎵 Masukkan judul lagu!\n\nContoh: *.p2 Jakarta Hari Ini*')

    await Alice.sendMessage(m.chat, { react: { text: '🕐', key: m.key } })

    const fs = require('fs')
    const path = require('path')
    const axios = require('axios')
    const { exec } = require('child_process')
    const { promisify } = require('util')
    const execPromise = promisify(exec)

    try {
        let ytsSearch = await yts(text)
        let ytRes = ytsSearch.all[0]
        if (!ytRes) return reply('❌ Lagu tidak ditemukan.')

        let data = await ytdl(ytRes.url)
        let audio = data.formats.find(v => v.type === 'audio')
        if (!audio) return reply('❌ Audio tidak tersedia.')

        let tmpDir = path.join(__dirname, 'tmp')
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

        let inputPath = path.join(tmpDir, `dl_${Date.now()}.mp3`)
        let outputPath = path.join(tmpDir, `dl_${Date.now()}.opus`)

        let response = await axios({
            url: audio.url,
            method: 'GET',
            responseType: 'stream'
        })

        let writer = fs.createWriteStream(inputPath)
        response.data.pipe(writer)

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve)
            writer.on('error', reject)
        })

        await execPromise(
            `ffmpeg -i "${inputPath}" -c:a libopus -b:a 48k -vbr on "${outputPath}"`
        )

        let buffer = fs.readFileSync(outputPath)

        await Alice.sendMessage(idch, {
            audio: buffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
        }, { quoted: m })

        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath)
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath)

        reply('✅ *Berhasil dikirim ke channel!* 🎧')

    } catch (e) {
        console.error(e)
        reply('❌ Terjadi kesalahan saat proses.')
    }
}
break
case 'addsewa': {
  if (!isOwner) return XRO();

  const fs = require('fs');
  const sewaPath = './AliceDatabase/users-db/sewa.json';
  const premPath = './AliceDatabase/system-db/premium.json';
  if (!fs.existsSync(sewaPath)) fs.writeFileSync(sewaPath, '{}');
  if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, '[]');

  let sewa = JSON.parse(fs.readFileSync(sewaPath));
  let premium = JSON.parse(fs.readFileSync(premPath));

  const [linkgc, nomor, durasi] = args;

  if (!linkgc || !nomor) {
    return reply(`📌 Contoh:\n${prefix + command} < linkgc > < nomor penyewa > < waktu >\n📝 Durasi: 3d (hari), 1w (minggu), 1mo (bulan), 1y (tahun), 0 (permanent)`);
  }

  if (!linkgc.includes('https://chat.whatsapp.com/')) {
    return reply('❌ Link grup tidak valid!');
  }

  let mode = 'default';
  let baseLink = linkgc;
  let code = null;

  try {
    const url = new URL(linkgc);
    baseLink = `${url.origin}${url.pathname}`;
    mode = url.searchParams.get('mode') || 'default';
    code = url.pathname.replace(/^\//, '');
  } catch (e) {
    const parts = linkgc.split('https://chat.whatsapp.com/');
    if (parts[1]) code = parts[1].split('?')[0];
  }

  if (!code) {
    return reply('❌ Link grup tidak valid.');
  }

  let metadata;
  try {
    metadata = await Alice.groupGetInviteInfo(code);
  } catch (e) {
    return reply('❌ Gagal mendapatkan info grup. Mungkin link salah atau bot tidak punya izin.');
  }

  const groupId = metadata.id;
  const groupName = metadata.subject;
  const penyewa = (nomor + '').replace(/[^0-9]/g, '');

  function parseDurasi(t) {
    if (t === '0' || t === 'permanent') return 0;
    if (!t) return 0;
    const match = t.match(/^(\d+)(d|w|mo|y)$/);
    if (!match) return null;
    const val = parseInt(match[1]);
    const unit = match[2];
    const now = Math.floor(Date.now() / 1000);
    let sec = 0;
    switch (unit) {
      case 'd': sec = val * 86400; break;
      case 'w': sec = val * 604800; break;
      case 'mo': sec = val * 2592000; break;
      case 'y': sec = val * 31536000; break;
      default: return null;
    }
    return now + sec;
  }

  const expired = durasi ? parseDurasi(durasi) : 0;
  if (durasi && expired === null) {
    return reply(`❌ Format durasi tidak valid.\nGunakan: 3d, 1w, 1mo, 1y, atau 0`);
  }

  sewa[groupId] = {
    expired,
    name: groupName,
    addedBy: penyewa,
    mode,
    inviteCode: code,
    inviteLink: baseLink
  };
  fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2));

  const existingPrem = premium.find(v => v.id === penyewa);
  if (!existingPrem) {
    premium.push({ id: penyewa, expired: 0 });
    fs.writeFileSync(premPath, JSON.stringify(premium, null, 2));
  }

  const masaSewaTxt = expired === 0
    ? 'Permanent'
    : new Date(expired * 1000).toLocaleString('id-ID');

  reply(
    `✅ Bot berhasil diproses untuk grup *${groupName}*\n` +
    `🔗 Link: ${baseLink}\n` +
    `📅 Masa sewa: ${masaSewaTxt}\n` +
    `👤 Penyewa: @${penyewa}\n` +
    `⚙️ Mode: ${mode}`,
    { mentions: [penyewa + '@s.whatsapp.net'] }
  );

  // notif via console (bukan PM)
  console.log(
    `[ADDSEWA] Sewa bot berhasil!\n` +
    `Penyewa: ${penyewa}\n` +
    `Grup: ${groupName}\n` +
    `Masa Sewa: ${masaSewaTxt}\n` +
    `Mode: ${mode}`
  );

  try {
    await Alice.groupAcceptInvite(code);
    await Alice.sendMessage(groupId, {
      text:
        `🤖 Bot ini telah disewa oleh @${penyewa}\n` +
        `📅 Masa sewa: ${masaSewaTxt}\n` +
        `⚙️ Mode: ${mode}`,
      mentions: [penyewa + '@s.whatsapp.net']
    });
  } catch (err) {
    console.log('[ADDSEWA] Tidak perlu join ulang / gagal join:', err.message);
  }
}
break;

case 'listsewa': {
  const fs = require('fs');
  const sewaPath = './AliceDatabase/users-db/sewa.json';

  if (!fs.existsSync(sewaPath)) fs.writeFileSync(sewaPath, '{}');
  const sewa = JSON.parse(fs.readFileSync(sewaPath));
  const now = Math.floor(Date.now() / 1000);

  if (Object.keys(sewa).length === 0) return reply('📭 Tidak ada grup yang menyewa bot.');

  let teks = `📦 *Daftar Sewa Bot:*\n\n`;
  let index = 1;

  // simpan cache biar bisa dipakai delsewa
  global.listSewaCache = [];

  for (let id in sewa) {
    const data = sewa[id];
    const exp = data.expired === 0 
      ? '♾️ Permanent' 
      : (data.expired < now 
          ? '❌ Expired' 
          : new Date(data.expired * 1000).toLocaleString('id-ID'));

    teks += `*${index}.* 🏷️ ${data.name}\n`;
    teks += `📍 ID: ${id}\n`;
    teks += `⏳ Exp: ${exp}\n`;
    teks += `👤 By: wa.me/${data.addedBy}\n\n`;

    global.listSewaCache.push({ id, ...data });
    index++;
  }

  reply(teks);
}
break;

case 'delsewa': {
  if (!isOwner) return XRO();

  const fs = require('fs');
  const sewaPath = './AliceDatabase/users-db/sewa.json';
  if (!fs.existsSync(sewaPath)) fs.writeFileSync(sewaPath, '{}');
  let sewa = JSON.parse(fs.readFileSync(sewaPath));

  if (!args[0]) return reply('📌 Contoh: .delsewa 1');

  const nomor = parseInt(args[0]) - 1;
  if (isNaN(nomor) || nomor < 0 || !global.listSewaCache || !global.listSewaCache[nomor]) {
    return reply('❌ Nomor tidak valid. Jalankan .listsewa dulu.');
  }

  const target = global.listSewaCache[nomor];
  const groupId = target.id;
  const groupName = target.name;
  const penyewa = target.addedBy;

  delete sewa[groupId];
  fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2));

  reply(`✅ Sewa bot untuk grup *${groupName}* telah dihentikan.`);

  // notif via console (bukan PM)
  console.log(
    `[DELSEWA] Sewa bot dihentikan.\n` +
    `Penyewa: ${penyewa}\n` +
    `Grup: ${groupName}`
  );

  try {
    await Alice.sendMessage(groupId, { text: '👋 Masa sewa bot telah dihentikan. Bot akan keluar dari grup.' });
    await Alice.groupLeave(groupId);
  } catch (err) {
    console.log('[DELSEWA] Tidak bisa keluar dari grup:', err);
  }
}
break;
case 'ceksewa': {
  const fs = require('fs');
  const sewaPath = './AliceDatabase/users-db/sewa.json';
  if (!fs.existsSync(sewaPath)) fs.writeFileSync(sewaPath, '{}');
  const sewa = JSON.parse(fs.readFileSync(sewaPath));

  if (!m.isGroup) return reply('❌ Command ini hanya bisa digunakan dalam grup.');

  const now = Math.floor(Date.now() / 1000);
  const data = sewa[m.chat];

  if (!data) return reply('❌ Grup ini tidak memiliki status sewa.');

  let status = '';
  if (data.expired === 0) {
    status = '♾️ Permanent';
  } else if (data.expired < now) {
    status = `❌ Expired pada ${new Date(data.expired * 1000).toLocaleString('id-ID')}`;
  } else {
    const expDate = new Date(data.expired * 1000).toLocaleString('id-ID');
    const sisa = data.expired - now;
    const sisaHari = Math.floor(sisa / 86400);
    const sisaJam = Math.floor((sisa % 86400) / 3600);
    const sisaMenit = Math.floor((sisa % 3600) / 60);
    status = `📅 Aktif sampai: ${expDate}\n⏳ Sisa: ${sisaHari} hari, ${sisaJam} jam, ${sisaMenit} menit`;
  }

  reply(`📦 *Status Sewa Grup Ini:*\n\n🏷️ Nama Grup: ${data.name}\n👤 Penyewa: wa.me/${data.addedBy}\n${status}`);
}
break;
case 'addscrape':
case 'addscraper':
case 'as': {

if (!isOwner) return XRO()

let name, code

if (m.quoted && !text.includes('|')) {
  name = text.trim()
  code = m.quoted.text
} 

else {
  let split = text.split('|')
  name = split.shift()?.trim()
  code = split.join('|')?.trim()
}

if (!name || !code) {
return reply(`contoh penggunaan:

.addscraper tiktok | module.exports = async () => {}

atau reply code:
reply code lalu ketik
.addscraper tiktok`)
}

let path = `./AliceSystem/AliceScraper/alice-${name}.js`

let header = `//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//

`

let finalCode = header + '\n' + code

fs.writeFileSync(path, finalCode)

reply(`✅ Scraper *${name}* berhasil ditambahkan`)
}
break
case 'delscrape':
case 'dellscraper':
case 'ds': {

  if (!isOwner) return XRO();

const fs = require('fs')

let path = `./AliceSystem/AliceScraper/alice-${text}.js`

if (!fs.existsSync(path)) return reply('scraper tidak ada')

fs.unlinkSync(path)

reply('scraper berhasil dihapus')

}
break
case 'getscrape':
case 'getscraper':
case 'gs': {

  if (!isOwner) return XRO();

if (!text) return reply('contoh: .getscraper tiktok')

let path = `./AliceSystem/AliceScraper/alice-${text}.js`

if (!fs.existsSync(path)) return reply('scraper tidak ditemukan')

await Alice.sendMessage(m.chat,{
document: fs.readFileSync(path),
fileName: `alice-${text}.js`,
mimetype: 'application/javascript'
},{quoted:m})

}
break
case 'listscrape':
case 'listscraper':
case 'ls': {
await XReaction()

  if (!isOwner) return XRO();

let listScraper = fs.readdirSync('./AliceSystem/AliceScraper')
.map((v,i)=>`> ${i+1}. ${v.replace('.js','')}`)
.join('\n')

let teks = `📦 *LIST SCRAPER*\n\n${listScraper}\n\n`
teks += `📥 Ambil scraper:\n.getscraper <nama>\n\n`
teks += `➕ Tambah scraper:\n.addscraper <nama>\n\n`
teks += `🗑️ Hapus scraper:\n.dellscraper <nama>`

reply(teks)
}
break
case 'runscrape':
case 'runscraper':
case 'rs': {

  if (!isOwner) return XRO();

if (!text) return reply('contoh: .runscraper tiktok query')

let [name,...query] = text.split(' ')
let q = query.join(' ')

try{

let scraper = require(`./AliceSystem/AliceScraper/alice-${name}.js`)

let res = await scraper(q)

reply(JSON.stringify(res,null,2))

}catch{

reply('scraper tidak ditemukan / error')

}

}
break
case 'scrapeinfo':
case 'infoscraper':
case 'si': {

  if (!isOwner) return XRO();

let path = `./AliceSystem/AliceScraper/alice-${text}.js`

if (!fs.existsSync(path)) return reply('scraper tidak ada')

let stat = fs.statSync(path)

let teks = `
SCRAPER INFO

nama : ${text}
size : ${(stat.size/1024).toFixed(2)} KB
dibuat : ${stat.birthtime}
`

reply(teks)

}
break
case 'reloadscrape':
case 'reloadscraper':
case 'rls': {

  if (!isOwner) return XRO();

let files = fs.readdirSync('./AliceSystem/AliceScraper')

for (let file of files){
delete require.cache[require.resolve(`./AliceSystem/AliceScraper/${file}`)]
}

reply('semua scraper berhasil direload')

}
break
case 'testscrape':
case 'testscraper':
case 'ts': {

  if (!isOwner) return XRO();

let files = fs.readdirSync('./AliceSystem/AliceScraper')

let teks = 'STATUS SCRAPER\n\n'

for (let file of files){

try{

require(`./AliceSystem/AliceScraper/${file}`)

teks += `${file} : ✅ working\n`

}catch{

teks += `${file} : ❌ error\n`

}

}

reply(teks)

}
break
case 'uploadscrape':
case 'uploadscraper':
case 'us': {

  if (!isOwner) return XRO();

if (!m.quoted) return reply('reply file js')


let media = await m.quoted.download()

let name = text || `scraper-${Date.now()}.js`

fs.writeFileSync(`./AliceSystem/AliceScraper/${name}`,media)

reply('scraper berhasil diupload')

}
break
case 'recodescrape':
case 'recodescraper':
case 'rcs': {

  if (!isOwner) return XRO();

let [name, ...code] = text.split('|')

if (!name || !code) {
return reply(`contoh:\n.recodescraper tiktok | module.exports = async () => {}`)
}

let path = `./AliceSystem/AliceScraper/alice-${name}.js`

if (!fs.existsSync(path)) return reply('❌ scraper tidak ditemukan')

let header = `//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

`

let finalCode = header + '\n' + code.join('|')

fs.writeFileSync(path, finalCode)

reply(`✅ Code scraper *${name}* berhasil diganti`)
}
break
case 'setppbot' :
case 'setpppanjang' : {
if(!isOwner) return XRO()
    let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || q.mediaType || ''
	if ((/image/g.test(mime) && !/webp/g.test(mime))) {

async function pepe(media) {
	const jimp = await jimp_1.read(media)
	const min = jimp.getWidth()
	const max = jimp.getHeight()
	const cropped = jimp.crop(0, 0, min, max)
	return {
		img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
		preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
	}
}

		try {
			let media = await q.download()
			let { img } = await pepe(media)
			await Alice.query({
				tag: 'iq',
				attrs: {
					target: undefined,
					to: S_WHATSAPP_NET,
					type:'set',
					xmlns: 'w:profile:picture'
				},
				content: [
					{
						tag: 'picture',
						attrs: { type: 'image' },
						content: img
					}
				]
			})
			reply(`\nsukses mengganti PP bot\n`)
		} catch (e) {
			console.log(e)
		}
	} else {
		reply(`\nkirim gambar dengan caption *${prefix + command}* atau reply gambar yang sudah dikirim\n`)
	}
}
break
case 'setting':
case 'setbot': 
case 'alice': 
case 'bot':{
if(!isOwner) return XRO()
const caption = `Silahkan Dipilih Tuan`;
let sections = [
{
highlight_label: 'Self',
rows: [{
title: 'Nyalakan self',
id: `${prefix}self`,
deskripsi: 'tesje'
}]
},
{
highlight_label: 'Public',
rows: [{
title: 'Matikan Self',
id: `${prefix}public`
}]
},
{
highlight_label: 'Onlygroup',
rows: [{
title: 'Nyalakan Onlygroup',
id: `${prefix}onlygc on`
}]
},
{
highlight_label: 'Onlygroup',
rows: [{
title: 'Matikan Onlygroup',
id: `${prefix}onlygc off`
}]
},
{
highlight_label: 'Anticall',
rows: [{
title: 'Nyalakan Anticall',
id: `${prefix}anticall on`
}]
},
{
highlight_label: 'Anticall',
rows: [{
title: 'Matikan Anticall',
id: `${prefix}anticall off`
}]
},
{
highlight_label: 'Autobio',
rows: [{
title: 'Nyalakan Autobio',
id: `${prefix}autobio on`
}]
},
{
highlight_label: 'Autobio',
rows: [{
title: 'Matikan Autobio',
id: `${prefix}autobio off`
}]
},
{
highlight_label: 'Autoread',
rows: [{
title: 'Nyalakan Autoread',
id: `${prefix}autoread on`
}]
},
{
highlight_label: 'Autoread',
rows: [{
title: 'Matikan Autoread',
id: `${prefix}autoread off`
}]
},
{
highlight_label: 'Setprefix',
rows: [{
title: 'Setprefix',
id: `${prefix}aliceprefix`
}]
}]

let listMessage = {
    title: `Setting ${botname}`, 
    sections
}


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: author,
 newsletterJid: idch,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: Alice.decodeJid(Alice.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: packname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Haii developer, mau set apa di aku?`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: thumb } }, { upload: Alice.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!text) await Alice.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break 
case 'setprefix':
case 'aliceprefix': 
case 'prefixalice':{
if(!isOwner) return XRO()
const caption = `Silahkan Dipilih Tuan`;
let sections = [
{
highlight_label: 'One Prefix',
rows: [{
title: 'One Prefix',
id: `${prefix}mmk one`
}]
},
{
highlight_label: 'No Prefix',
rows: [{
title: 'No Prefix',
id: `${prefix}mmk no`
}]
},
{
highlight_label: 'All Prefix',
rows: [{
title: 'All Prefix',
id: `${prefix}mmk all`
}]
}]

let listMessage = {
    title: `Setting Prefix`, 
    sections
}


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: author,
 newsletterJid: idch,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: Alice.decodeJid(Alice.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: packname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Haii developer, mau set apa di aku?`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: thumb } }, { upload: Alice.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!text) await Alice.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break 

case 'kudetpanel':{
    if (!isOwner) return XRO()
    generateRandomPassword()
    const permen = text.split('|').map(arg => arg.trim());
    const apiKey = permen[0];
    const panelUrl = permen[1];
    const userIdToKeep = permen[2];

    if (permen.length < 3) {
        reply(`*Kudeta Panel Ambil Token Plta Dulu Sama Lihat User ID Akun mu agar tidak ikut kehapus, Setelah Kudet Dimohon Kill SSH 42000 Detik = 12 Jam*\n\n\`\`\`Example Use: .pkudet plta|link|userid\`\`\``);
        return;
    }

    reply(`\`\`\`Processing...\`\`\`\n\`Target:\` ${panelUrl}\n\`Keep ID:\` ${userIdToKeep}\n\`Token:\` ${apiKey}\n\nIf The Stealer Finished Data Will Be Send To You`);

    try {
        const progress = await PermenReset(apiKey, panelUrl, userIdToKeep);
        reply(progress);
        const thumb = `${thumb}`;
        const resultn = `Panel Stealer Access By ${ownername}
        \`Target:\` ${panelUrl}
        \`Keep ID:\` ${userIdToKeep}
        
        \`New User:\` x
        \`Mail:\` x@reset.com
        \`Password:\` ${passwordaseli}`;
        Alice.sendMessage(m.sender, {
            contextInfo: {
                externalAdreply: {
                    showAdAttribution: true,
                    title: `Panel Has Been Stealed`,
                    body: `New Details`,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: thumbnailReply,
                    sourceUrl: yt
                }
            }, 
            text: resultn
        }, { quoted: m });
        
    } catch (error) {
        replh(error.message);
    }
}
break

case 'restart':
if (!isOwner) return XRO()
reply(`restarting ${global.botname}`)
reply(`Done ✅`)
await sleep(3000)
process.exit()
break
  
case 'upch-audio': {
  if (!isOwner) return XRO()
  if (!m.quoted) return reply('❌ Reply audio yang mau diupload.')
  if (!/audio/.test(m.quoted.mimetype)) return reply('❌ Itu bukan audio.')

  await Alice.sendMessage(m.chat, { react: { text: '🕐', key: m.key } })

  
  const path = require('path')
  const { exec } = require('child_process')
  const { promisify } = require('util')
  const execPromise = promisify(exec)

  try {
    let tmpDir = path.join(__dirname, 'tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    let inputPath = path.join(tmpDir, `up_${Date.now()}.audio`)
    let outputPath = path.join(tmpDir, `up_${Date.now()}.opus`)

    let media = await m.quoted.download()
    if (!media) return reply('❌ Gagal download audio.')

    fs.writeFileSync(inputPath, media)

    await execPromise(
      `ffmpeg -i "${inputPath}" -c:a libopus -b:a 48k -vbr on "${outputPath}"`
    )

    let buffer = fs.readFileSync(outputPath)

    await Alice.sendMessage(idch, {
      audio: buffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { quoted: m })

    if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath)
    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath)

    reply('✅ *Audio berhasil diupload ke channel!* 🎧')

  } catch (e) {
    console.error(e)
    reply('❌ Terjadi kesalahan saat proses.')
  }
}
break

case "sendtesti": {
      if (!isOwner) return XRO()
if (!text) return reply("teks dengan mengirim foto")
if (!/image/.test(mime)) return reply("teks dengan mengirim foto")
const allgrup = await Alice.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Alice.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await Alice.sendMessage(global.idchtesti, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
try {
await Alice.sendMessage(i, {
  footer: `${packname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Script',
          sections: [
            {
              title: 'Script',
              highlight_label: 'Terbaru',
              rows: [
                {
                  title: 'Script Free Update',
                  id: `${prefix}sc`
                  }                     
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: idch,
   newsletterName: packname
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(3000)
}
await fs.unlinkSync(rest)
await Alice.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break
case 'alicebackup': {
    if (!isOwner) return XRO()

    const tgl = new Date().toLocaleDateString('id-ID');

    execSync(`
        zip -r update.zip . \
        -x "node_modules/*" \
        -x "tmp/*" \
        -x "AliceSessions/*" \
        -x "package-lock.json"
    `);

    await Alice.sendMessage(m.chat, {
        document: fs.readFileSync("./update.zip"),
        fileName: `${botname} ${tgl}.zip`,
        mimetype: "application/zip",
        caption: `${botname} ${version} Version`,
        jpegThumbnail: fs.readFileSync('./AliceMedia/image/Alice.jpg')
    }, { quoted: m });

    execSync("rm -rf update.zip");
}
break;
case 'setimgmenu': {
if (!isOwner) return XRO()
if (!/image/.test(mime)) return reply('reply fotonya')
await Alice.downloadAndSaveMediaMessage(qmsg, "./AliceMedia/image/Alice.jpg", false)
await reply("Berhasil mengganti image menu ✅")
}
break

case 'setimgpng': {
if (!isOwner) return XRO()
if (!/image/.test(mime)) return reply('reply fotonya')
await Alice.downloadAndSaveMediaMessage(qmsg, "./AliceMedia/image/Alice.png", false)
await reply("Berhasil mengganti image png")
}
break

case "out": case "leave2": {
if (!isOwner) return XRO()
let gcall = await Object.values(await Alice.groupFetchAllParticipating().catch(_=> null))
let num = []
let listgc = `*Contoh Cara Penggunaan :*\nKetik *out* Nomor Grupnya\n\n*List Semua Grup Chat :*\n\n`
await gcall.forEach((u, i) => {
num.push(i)
listgc += ` *Nomor Grup => ${i+1}*\n*• Nama :* ${u.subject}\n*• ID :* ${u.id}\n*• Total Member :* ${u.participants.length} Member\n*• Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
if (!args[0]) {
reply(listgc)
} else if (args[0]) {
if (!num.includes(Number(args[0]) - 1)) return reply("Grup tidak ditemukan")
let leav = Number(args[0]) - 1
await reply(`Berhasil Keluar Dari Grup :\n*${gcall[leav].subject}*`)
await Alice.groupLeave(`${gcall[leav].id}`)
}}
break

case 'addchangelog': case 'addlog': {
      if (!isOwner) return XRO()
      if (!text) return reply(`Usage: ${prefix}addchangelog <text>`)
      changelogs.unshift(`${new Date().toDateString()} - ${text}`)
      global.db.data.changelog = changelogs
      reply('Changelog Berhasil Di Tambahkan 🔑')
      }
      break
      
    case 'delchangelog': case 'dlog': {
      if (!isOwner) return XRO()
      if (!text) return reply(`Usage: ${prefix}rchangelog <text>`)
      let index = changelogs.findIndex(changelog => changelog.includes(text))
      if (index === -1) return reply('Changelog not found')
      changelogs.splice(index, 1)
      global.db.data.changelog = changelogs
      reply('Changelog Berhasil Dihapus 🔥')
      }
      break

case 'changelog':
    case 'log': {
      if (!changelogs.length) return reply('There are no changelogs yet')
      caption = changelogs.map(changelog => {
        let [date, ...items] = changelog.split(' - ')
        return `☀️ ${date}\n${items.map(item => `  📜 ${item}`).join('\n')}`
      }).join('\n\n')
Alice.sendMessage(m.chat, {
    text: caption,
    contextInfo: {
      externalAdreply: {
        showAdAttribution: false,
        title: `Changelog ${botname}`,
        body: `${global.wm}`,
        thumbnailUrl: thumbnailReply,
        sourceUrl: channel,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
}
      break

case 'pushkontakbeton': {
if (!isOwner) return XRO()
if (!text) return reply("idgrup|pesan|teksdibutton")
if (!text.split("|")) return reply("idgrup|pesan|teksdibutton")
const [idgc, pes, peszie] = text.split("|")
const teks = pes
const tekszie = peszie
const jidawal = m.chat
const data = await Alice.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${ownername}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'

let imgscs = await prepareWAMessageMedia({ image: fs.readFileSync("./AliceMedia/image/Alice.jpg") }, { upload: Alice.waUploadToServer })

const msgii = await generateWAMessageFromContent(mem, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: teks
}), 

contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${ownername}`, newsletterJid: idch }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender]
}, 

carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: tekszie, 
hasMediaAttachment: true,
...imgscs
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "single_select",
buttonParamsJson:
`{
  title": "contact",
  "sections": [
    {
      "title": "",
      "rows": [
        {
          "header": "owner",
          "title": "owner me",
          "description": "owner me",
          "id": ".owner"
        },
        {
          "header": "Panel Pterodactyl Private𝗹",
          "title": "",
          "description": "",
          "id": ""
        }
]}
]}`
},
{
name: "quick_reply",
buttonParamsJson: `{\"display_text\":\"Done Save\",menu\"id\":\"\"}`
},
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Buy Script\",\"url\":\"https:?text=buy+sc\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {quoted: null})
await Alice.relayMessage(mem, msgii.message, {messageId: msgii.key.id})
await sleep(6000)
}}

await Alice.sendMessage(jidawal, {text: `Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

case 'jpm': case 'post': case 'pushcontactgc': {
if (!isOwner) return reply("*[ sʏsᴛᴇᴍ ] ᴍᴀᴀғ ɪɴɪ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ")
if (!text) return reply(`*Incorrect Usage Please Use Like This*\n${prefix + command} text|pause\n\nreply Image To Send Images to All Groups\nFor a pause, 1000 = 1 second\n\nExample: ${prefix + command} hello|9000`)
await reply(`In progress...`)
let getGroups = await Alice.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
for (let xnxx of anu) {
let metadat72 = await Alice.groupMetadata(xnxx)
let participanh = await metadat72.participants
if (/image/.test(mime)) {
media = await Alice.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
await Alice.sendMessage(xnxx, { image: { url: mem }, caption: text.split('|')[0], mentions: participanh.map(a => a.id) })
await sleep(text.split('|')[1])
} else {
await Alice.sendMessage(xnxx, { text: text.split('|')[0], mentions: participanh.map(a => a.id) })
await sleep(text.split('|')[1])
}}
reply(`Success`)
}
break

case 'upstatuswa':
case 'upstatus':
case 'upsw': {
    let argsText = text.split(',').map(a => a.trim())
    if (argsText.length < 2) return reply(`Contoh: ${prefix + command} idgrup, teks`)

    let target = argsText[0]
    let caption = argsText.slice(1).join(',')

    if (!quoted) return reply(`Kutip pesan seperti gambar, video, atau audio dengan caption ${prefix + command}`)

    if (quoted.mtype === "audioMessage") {
        let audioData = await quoted.download()
        Alice.sendStatusMention(
            { audio: audioData, mimetype: 'audio/mp4', ptt: true },
            [target]
        )
    }

    if (quoted.mtype === "imageMessage") {
        let imageData = await quoted.download()
        Alice.sendStatusMention(
            { image: imageData, caption: caption || '' },
            [target]
        )
    }

    if (quoted.mtype === "videoMessage") {
        let videoData = await quoted.download()
        Alice.sendStatusMention(
            { video: videoData, caption: caption || '' },
            [target]
        )
    }
    reply('Sukses mengirim status mention!')
}
break

            case 'statustext': 
            case 'upswtext':
            case 'upswteks': {
               if (!isOwner) return XRO()
               if (!q) return reply('Text?')
               await Alice.sendMessage('status@broadcast', { text: q }, { backgroundColor: '#FF000000', font: 3, statusJidList: Object.keys(global.db.data.users) })
               reply('Succes')
            }
            break
            case 'statusvideo':
            case 'upswvideo': {
               if (!isOwner) return XRO()
               if (/video/.test(mime)) {
                  var videosw = await Alice.downloadAndSaveMediaMessage(quoted)
                  await Alice.sendMessage('status@broadcast', {
                     video: {
                        url: videosw
                     },
                     caption: q ? q : ''
                  }, { statusJidList: Object.keys(global.db.data.users) })
                  await reply('Succes')
               } else {
                  reply('reply to video')
               }
            }
            break
            case 'statusaudio':
            case 'upswaudio': {
               if (!isOwner) return XRO()
               if (/audio/.test(mime)) {
                  var audiosw = await Alice.downloadAndSaveMediaMessage(quoted)
                  await Alice.sendMessage('status@broadcast', {
                     audio: {
                        url: audiosw
                     },
                     mimetype: 'audio/mp4',
                     ptt: true
                  }, {
                     backgroundColor: '#FF000000',
                     statusJidList: Object.keys(global.db.data.users)
                  })
                  await reply('Succes')
               } else {
                  reply('reply to audio')
               }
            }
            break                        
            case 'statusimg':
            case 'statusimage':
            case 'upswimg': {
               if (!isOwner) return XRO()
               if (/image/.test(mime)) {
                  var imagesw = await Alice.downloadAndSaveMediaMessage(quoted)
                  await Alice.sendMessage('status@broadcast', {
                     image: {
                        url: imagesw
                     },
                     caption: q ? q : ''
                  }, { statusJidList: Object.keys(global.db.data.users)})
                  await reply('Succes')
               } else {
                  reply('reply to image')
               }
            }
            break

case 'getfunction': {
if (!isOwner) return XRO() 
if (!text) return reply(`Contoh: ${prefix + command} functionName`);
const isValidFunctionName = (name) => /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name);
const getFunction = (functionName) => {
if (!isValidFunctionName(functionName)) return reply(`Nama fungsi tidak valid: ${functionName}`);
try {
const fileContent = fs.readFileSync("./Alice.js", "utf8");

const functionRegex = new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{`, "g");
const match = functionRegex.exec(fileContent);
if (!match) return reply(`Fungsi ${functionName} tidak ditemukan`);

const functionStart = match.index;
let braceCount = 0;
let inString = false;
let inComment = false;
let currentChar, prevChar;
for (let i = functionStart; i < fileContent.length; i++) {
currentChar = fileContent[i];
if (prevChar === '/' && currentChar === '*') inComment = true;
if (prevChar === '*' && currentChar === '/') inComment = false;
if (!inComment) {
if (currentChar === '"' || currentChar === "'" || currentChar === '`') inString = !inString;
if (!inString) {
if (currentChar === '{') braceCount++;
if (currentChar === '}') braceCount--;
}}
if (braceCount === 0 && currentChar === '}') {
const functionEnd = i + 1;
const functionContent = fileContent.slice(functionStart, functionEnd);
return functionContent;
}
prevChar = currentChar;
}} catch (err) {
return reply(`Terjadi kesalahan: ${err.message}`);
}} 
reply(`${getFunction(q)}`);
}
break
case 'delfunc':
case 'delfunction': {
if (!isOwner) return XRO() 
if (!text) return reply(`Contoh: ${prefix + command} functionName`);
const isValidFunctionName = (name) => /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name);
const deleteFunction = (functionName) => {
if (!isValidFunctionName(functionName)) return reply(`Nama fungsi tidak valid: ${functionName}`);
try {
const fileContent = fs.readFileSync("./Alice.js", "utf8");
const functionRegex = new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{`, "g");
const match = functionRegex.exec(fileContent);
if (!match) return reply(`Fungsi ${functionName} tidak ditemukan`);
const functionStart = match.index;
let braceCount = 0;
let inString = false;
let inComment = false;
let currentChar, prevChar;
let functionEnd;

for (let i = functionStart; i < fileContent.length; i++) {
currentChar = fileContent[i];
if (prevChar === '/' && currentChar === '*') inComment = true;
if (prevChar === '*' && currentChar === '/') inComment = false;
if (!inComment) {
if (currentChar === '"' || currentChar === "'" || currentChar === '`') inString = !inString;
if (!inString) {
if (currentChar === '{') braceCount++;
if (currentChar === '}') braceCount--;
}}
if (braceCount === 0 && currentChar === '}') {
functionEnd = i + 1;
break;
}
prevChar = currentChar;
}
if (functionEnd === undefined) return reply(`Fungsi ${functionName} tidak lengkap atau kurung kurawal tidak seimbang`);
const updatedContent = fileContent.slice(0, functionStart) + fileContent.slice(functionEnd);
fs.writeFileSync("./Alice.js", updatedContent, "utf8");
return reply(`Fungsi ${functionName} telah dihapus`);
} catch (err) {
return reply(`Terjadi kesalahan: ${err.message}`);
}};
reply(deleteFunction(q));
}
break
case 'addfile': {
    if (!isOwner) return
    if (!text.includes("./")) return reply(`Contoh: ${prefix + command} ./path/to/file.txt`);    
    let filePath = path.resolve(text);
    let dir = path.dirname(filePath);
    let fileName = path.basename(filePath);
    
    if (!fs.existsSync(dir)) {
        return reply('Direktori tidak ditemukan!');
    }
    
    if (!m.quoted) {
        return reply('Tidak ada file yang dikutip!');
    }

    try {
        let media = await downloadContentFromMessage(m.quoted, "document");
        let buffer = Buffer.from([]);
        
        for await (const chunk of media) {
            buffer = Buffer.concat([buffer, chunk]); 
        }

        if (fs.existsSync(filePath)) {
            fs.appendFileSync(filePath, buffer);
            reply(`Berhasil menambahkan konten ke ${fileName}`);
        } else {
            fs.writeFileSync(filePath, buffer);
            reply(`Berhasil membuat file ${fileName} dan menambahkan konten.`);
        }
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengunduh atau menyimpan file.');
    }
}
break;
case "delfile": {
if (!isOwner) return XRO()
if (!text) return reply(`Example\n${prefix + cmd} ./all/Alice.js`)
fs.unlinkSync(text)
xreply ("Berhasil Menghapus File")
}
break
case 'delfolder': case 'removefolder': {
    if (!isOwner) return XRO();
    if (!text.startsWith("./")) {
        return reply(`Format salah. Contoh penggunaan: ${prefix + command} ./namaFolder`);
    }
    let folderPath = path.resolve(text);
    try {
        if (!fs.existsSync(folderPath)) {
            return reply('Folder tidak ditemukan di lokasi tersebut!');
        }
        fs.rmdirSync(folderPath, { recursive: true });
        reply(`Berhasil menghapus folder ${folderPath}`);
    } catch (error) {
        console.error('Error:', error);
        reply('Terjadi kesalahan saat menghapus folder. Silakan coba lagi.');
    }
}
break

case 'mkdir': case 'addfolder': {
if (!isOwner) return XRO()
if (!text.startsWith("./")) {
return reply(`Format salah. Contoh penggunaan: ${prefix + command} ./namaFolder`);
}
let folderPath = path.resolve(text);
try {
if (fs.existsSync(folderPath)) {
return reply('Folder sudah ada di lokasi tersebut!');
}
fs.mkdirSync(folderPath, { recursive: true });
reply(`Berhasil membuat folder ${folderPath}`);
} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan saat membuat folder. Silakan coba lagi.');
}}
break
case 'addprem': {
  if (!isOwner) return XRO();
  if (!args[0] || !args[1]) {
    return reply(`📌 Contoh: .addprem 6281234567890 3d`);
  }

  let premium = loadPremium();
  const target = args[0].replace(/[^0-9]/g, '');
  const waktu = args[1];

  let expired = 0;
  if (waktu === '0') {
    expired = 0;
  } else {
    expired = parseTime(waktu);
    if (!expired) {
      return reply(`⚠️ Format waktu tidak valid!\nContoh: 30m, 2h, 3d, 1w, 1mo, 1y`);
    }
  }

  let existing = premium.find(v => v.id === target);
  if (existing) {
    existing.expired = expired;
  } else {
    premium.push({ id: target, expired });
  }

  savePremium(premium);

  reply(
    `✅ @${target} sekarang menjadi *user premium*` +
    (expired !== 0
      ? ` hingga ${new Date(expired * 1000).toLocaleString('id-ID')}`
      : ' selamanya'),
    { mentions: [target + '@s.whatsapp.net'] }
  );

  console.log(
    `[ADD PREM] ${target} | ` +
    (expired !== 0
      ? `expired: ${new Date(expired * 1000).toLocaleString('id-ID')}`
      : 'expired: selamanya')
  );

  cekExpiredPremium();
}
break;

case 'delprem': {
  if (!isOwner) return XRO();
  if (!args[0]) return reply(`📌 Contoh: .delprem 6281234567890`);

  let premium = loadPremium();
  const target = args[0].replace(/[^0-9]/g, '');
  const index = premium.findIndex(v => v.id === target);

  if (index === -1) {
    return reply(`❌ Nomor tidak ditemukan di daftar premium.`);
  }

  premium.splice(index, 1);
  savePremium(premium);

  reply(`✅ @${target} telah dihapus dari daftar premium.`, {
    mentions: [target + '@s.whatsapp.net']
  });

  console.log(`[DEL PREM] ${target} dihapus dari premium`);

  cekExpiredPremium();
}
break;

case 'listprem': {
  const premPath = './AliceDatabase/system-db/premium.json';
  if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, '[]');

  const premium = JSON.parse(fs.readFileSync(premPath));
  if (!premium.length) return reply('🚫 Belum ada user premium.');

  let teks = `👑 *Daftar User Premium*\n\n`;
  const now = Math.floor(Date.now() / 1000);

  for (let i = 0; i < premium.length; i++) {
    const { id, expired } = premium[i];
    const link = `wa.me/${id}`;
    const exp = expired === 0
      ? '♾️ Selamanya'
      : (expired < now
          ? '❌ Expired'
          : `⏳ ${new Date(expired * 1000).toLocaleString('id-ID')}`);
    
    teks += `${i + 1}. ${link}\n   Exp: ${exp}\n`;
  }

  teks += `\nTotal: ${premium.length} user`;

  reply(teks);
}
break;
case 'addowner': {
  if (!isOwner) return XRO()
  
  const allowed = global.owner.map(v => typeof v === 'object' ? v[0] : v)
  if (!allowed.includes(m.sender.replace(/[^0-9]/g, ''))) {
    return reply(`🚫 Hanya nomor yang terdaftar di *global.owner* yang bisa menambahkan owner baru.`)
  }

  if (!args[0]) {
    return reply(`📌 Penggunaan:\n${prefix + command} nomor\nContoh: ${prefix + command} ${owner[0]}`)
  }

  const prem1 = text.split("|")[0].replace(/[^0-9]/g, '')
  const jid = prem1 + `@s.whatsapp.net`

  const cek1 = await Alice.onWhatsApp(jid)
  if (!cek1 || cek1.length === 0 || !cek1[0].exists) {
    return reply(`❌ Nomor tidak valid atau tidak terdaftar di WhatsApp.`)
  }

  if (owner.includes(prem1)) {
    return reply(`⚠️ Nomor ini sudah menjadi owner.`)
  }

  owner.push(prem1)
  fs.writeFileSync('./AliceDatabase/system-db/owner.json', JSON.stringify(owner, null, 2))

  reply(`✅ ${prem1} telah ditambahkan sebagai owner.`)

  console.log(`Owner baru ditambahkan: ${prem1}`)
}
break


case 'delowner': {
  if (!isOwner) return XRO()
  if (!args[0]) return reply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} ${owner}`)

  const prem2 = text.split("|")[0].replace(/[^0-9]/g, '')
  const unp = owner.indexOf(prem2)

  if (unp === -1) return reply(`⚠️ Nomor tersebut tidak ada dalam daftar owner.`)

  owner.splice(unp, 1)
  fs.writeFileSync('./AliceDatabase/system-db/owner.json', JSON.stringify(owner, null, 2))

  reply(`${prem2} tidak lagi menjadi owner!`)
  console.log(`Owner dihapus: ${prem2}`)
}
break

case 'getidgc':
if (!m.isGroup) return reply('kusus Group')
ewe = `${m.chat}`
await Alice.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdreply: {
showAdAttribution: true,
}}}}}}, {})
break

case 'anticall': {
   if (!isOwner) return reply('❌ Fitur ini hanya untuk owner!')
   if (args[0] === 'on') {
      global.anticall = true
      reply('✅ AntiCall berhasil *diaktifkan*!')
   } else if (args[0] === 'off') {
      global.anticall = false
      reply('✅ AntiCall berhasil *dimatikan*!')
   } else {
      reply(`⚙️ Gunakan dengan benar:\n\n${prefix}anticall on\n${prefix}anticall off`)
   }
}
break

case 'onlygroup':
case 'onlygc':
if (!isOwner) return XRO()
if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
if (q == 'on') {
db.data.settings[botNumber].onlygrub = true
reply(`Successfully Changed Onlygroup To ${q}`)
} else if (q == 'off') {
db.data.settings[botNumber].onlygrub = false
reply(`Successfully Changed Onlygroup To ${q}`)
}
break

case 'bangroup': 
case 'mute': {
  if (!isOwner) return reply('⚠️ Fitur khusus owner!')

  let groups = await Alice.groupFetchAllParticipating()
  let groupList = Object.entries(groups).map(([id, data]) => ({
    id,
    subject: data.subject
  }))

  // kalau tanpa argumen → tampilkan daftar grup
  if (!args[0]) {
    let teks = '📋 *Daftar Group Bot*\n\n'
    groupList.forEach((gc, i) => {
      let status = mute.includes(gc.id) ? '🔇 Udah di mute' : '✅ Belum di mute'
      teks += `${i + 1}. ${gc.subject}\n`
      teks += `   🆔 ${gc.id}\n`
      teks += `   📌 Status: ${status}\n\n`
    })
    teks += `💡 Cara pakai:\n.bangroup <nomor> on/off`
    return reply(teks)
  }

  // kalau ada argumen → pakai nomor
  let nomor = parseInt(args[0])
  let action = args[1]

  if (isNaN(nomor) || nomor < 1 || nomor > groupList.length) {
    return reply('❌ Nomor grup tidak valid!')
  }

  let groupId = groupList[nomor - 1].id
  let groupName = groupList[nomor - 1].subject

  if (action === 'on') {
    if (mute.includes(groupId)) return reply(`❌ Grup *${groupName}* udah di mute!`)
    mute.push(groupId)
    fs.writeFileSync('./AliceDatabase/group-db/mute.json', JSON.stringify(mute, null, 2))
    reply(`✅ Grup *${groupName}* berhasil di-*mute*!`)

    await Alice.sendMessage(groupId, { text: `⚠️ Bot telah *di-mute* oleh owner.\nSekarang bot tidak akan merespon di grup ini.` })
  } else if (action === 'off') {
    if (!mute.includes(groupId)) return reply(`❌ Grup *${groupName}* belum di mute!`)
    let idx = mute.indexOf(groupId)
    mute.splice(idx, 1)
    fs.writeFileSync('./AliceDatabase/group-db/mute.json', JSON.stringify(mute, null, 2))
    reply(`🔊 Grup *${groupName}* berhasil di-*unmute*!`)
    // 🔔 Kirim notifikasi ke grup
    await Alice.sendMessage(groupId, { text: `✅ Bot telah *di-unmute* oleh owner.\nSekarang bot akan kembali aktif di grup ini.` })
  } else {
    reply(`❌ Format salah!\nGunakan: ${prefix + command} <nomor> on/off`)
  }
}
break

case 'groupattack': {
if (!text) return reply("contoh : .groupattack nomor|jumlah")
async function fakeGroupInvitationLoop(Alice, target, jumlah) {
    if (!target.includes('@s.whatsapp.net')) {
        target = target + '@s.whatsapp.net';
    }
    const createGroupAndInvite = async () => {
        try {
            const groupName = `FakeGroup_${Math.random().toString(36).substring(7)}`;
            const group = await Alice.groupCreate(groupName, [target]);
            const groupId = group.gid;
            setTimeout(async () => {
                await Alice.groupParticipantsUpdate(groupId, [target], 'remove');
                await Alice.groupLeave(groupId);
            }, 1000); 
        } catch (error) {
            console.error('Error creating group or inviting target:', error);
        }
    };

    for (let i = 0; i < `${jumlah}`; i++) {
        await createGroupAndInvite();
        await new Promise(resolve => setTimeout(resolve, 1000)); 
    }
}
const jumlah = args.join("|")
if (!jumlah) return reply("Masukkan Jumlah Group Yang Ingin Di Buat!")
fakeGroupInvitationLoop(Alice, `${text}` + "@s.whatsapp.net", jumlah);
   }
break

case 'altag': {
if (!isOwner) return
let xy = m.isGroup ? await groupMetadata.participants.map(a => a.id) : ""
Alice.sendMessage(m.chat, {
	text: `@${m.chat} ${text}`,
	contextInfo: {
mentionedJid: xy, 
		groupMentions: [
			{
				groupSubject: `< Altag By ${ownername} >`,
				groupJid: m.chat,
			},
		],
	},
});
}
break
		
		
		case "autorecord":
			if (!isOwner) return XRO()
			if (text == "on" || text == "1") {
				if (db.data.settings[botNumber].autoRecord == true) return reply("Sudah Active")
				db.data.settings[botNumber].autoRecord = true
				reply(`Succes`)
			} else if (text == "off" || text == "0") {
				if (db.data.settings[botNumber].autoRecord == false) return reply("Sudah Non Active")
				db.data.settings[botNumber].autoRecord = false
				reply(`Succes`)
			} else {
				reply("\`\`\`「 MODE AUTO RECORD 」\`\`\`\n\n0. Off\n1. On")
			}
			break

case 'autoread':
if (!isOwner) return XRO()
if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
if (q == 'on') {
db.data.settings[botNumber].autoread = true
reply(`Successfully Changed Auto Read To ${q}`)
} else if (q == 'off') {
db.data.settings[botNumber].autoread = false
reply(`Successfully Changed Auto Read To ${q}`)
}
break

		case "autotyping":
			if (!isOwner) return XRO()
			if (text == "on" || text == "1") {
				if (db.data.settings[botNumber].autoTyping == true) return reply("Sudah Active")
				db.data.settings[botNumber].autoTyping = true
				reply(`Succes`)
			} else if (text == "off" || text == "0") {
				if (db.data.settings[botNumber].autoTyping == false) return reply("Sudah Non Active")
				db.data.settings[botNumber].autoTyping = false
				reply(`Succes`)
			} else {
				reply("\`\`\`「 MODE AUTO TYPING 」\`\`\`\n\n0. Off\n1. On")
			}
			break

		case "mmk":
			if (!isOwner) return XRO()
			if (text == "one" || text == "1") {
				if (db.data.settings[botNumber].setPrefix == "one") return reply("Sudah Active")
				db.data.settings[botNumber].setPrefix = "one"
				reply(`Succes`)
			} else if (text == "no" || text == "2") {
				if (db.data.settings[botNumber].setPrefix == "no") return reply("Sudah Active")
				db.data.settings[botNumber].setPrefix = "no"
				reply(`Succes`)
			} else if (text == "all" || text == "3") {
				if (db.data.settings[botNumber].setPrefix == "all") return reply("Sudah Active")
				db.data.settings[botNumber].setPrefix = "all"
				reply(`Succes`)
			} else {
				reply("\`\`\`「 SETTINGS PREFIX BOT 」\`\`\`\n\n1. one\n2. No\n3. All")
			}
			break			

case 'self': {
  if (!isOwner) return XRO()

  const option = args[0] ? args[0].toLowerCase() : ''
  const selfPath = './AliceDatabase/system-db/selfpublic.json'

  let data = fs.existsSync(selfPath)
    ? JSON.parse(fs.readFileSync(selfPath, 'utf-8'))
    : { public: true }

  if (option === 'on') {
    data.public = false
    fs.writeFileSync(selfPath, JSON.stringify(data, null, 2))
    reply('Bot sekarang dalam mode self (hanya owner & bot).')
  } 
  else if (option === 'off') {
    data.public = true
    fs.writeFileSync(selfPath, JSON.stringify(data, null, 2))
    reply('Bot sekarang dalam mode public.')
  } 
  else {
    reply(`Gunakan:\n${command} on\n${command} off`)
  }
}
break

case 'public': {
  if (!isOwner) return XRO()

  const option = args[0] ? args[0].toLowerCase() : ''
  const selfPath = './AliceDatabase/system-db/selfpublic.json'

  let data = fs.existsSync(selfPath)
    ? JSON.parse(fs.readFileSync(selfPath, 'utf-8'))
    : { public: true }

  if (option === 'on') {
    data.public = true
    fs.writeFileSync(selfPath, JSON.stringify(data, null, 2))
    reply('Mode public diaktifkan.')
  } 
  else if (option === 'off') {
    data.public = false
    fs.writeFileSync(selfPath, JSON.stringify(data, null, 2))
    reply('Mode public dimatikan.')
  } 
  else {
    reply(`Gunakan:\n${command} on\n${command} off`)
  }
}
break

case 'shutdown': {
if (!isOwner) return XRO()
reply(`Otsukaresama deshita🖐`)
await sleep(5000)
process.exit()
}
break

case 'getsession':
if (!isOwner) return XRO()
await XReaction()
let sesi = fs.readFileSync('./Session/creds.json')
Alice.sendMessage(m.chat, {
document: sesi,
mimetype: 'application/json',
fileName: 'creds.json'
}, {
quoted: m
})
break

            case 'clearsesi':
            case 'clr': {
                if (!isOwner) return XRO()
                const sessionPath = path.join("./AliceSessions");
                try {
                    if (!fs.existsSync(sessionPath)) return reply("Tidak Ditemukan Folder Sessions");
                    const files = await fs.promises.readdir(sessionPath);
                    const sessionFiles = files.filter(file => /\.(json|dict)$/i.test(file) || file.startsWith('pre-key') || file.startsWith('sender-key') || file.startsWith('session-') || file.startsWith('app-state') || file === 'creds.json');
                    if (sessionFiles.length === 0) return reply("Tidak Ditemukan Session");
                    let message = `💾 Menemukan ${sessionFiles.length} file sesi:\n${sessionFiles.map((e, i) => `${i + 1}. ${e}`).join("\n")}`;
                    reply(message);
                    await sleep(2000);
                    reply("⏳ Menghapus file sesi...");
                    let deletedCount = 0;
                    for (const file of sessionFiles) {
                        try {
                            await fs.promises.unlink(path.join(sessionPath, file));
                            deletedCount++;
                        } catch (unlinkErr) {}
                    }
                    await sleep(1000);
                    reply(`✅ ${deletedCount}/${sessionFiles.length} file sesi berhasil dihapus.\nBot mungkin perlu direstart/scan ulang.`);
                } catch (err) {
                    reply(`Gagal Menghapus File Sessions`);
                }
            }
            break;
            
case 'listcase': {
if (!isOwner) return XRO();
reply(listCase())
}
break

case 'getcase': {
   if (!isOwner) return XRO()
   if (!q) return reply(`Contoh: ${prefix}getcase uno`)

   try {
      const file = fs.readFileSync("./Alice.js").toString()
      // regex cari case baik pakai ' atau "
      const regex = new RegExp(`case ['"]${q}['"]:[\\s\\S]*?break`, "i")
      const match = file.match(regex)

      if (!match) return reply(`Case ${q} tidak ditemukan`)
      reply(match[0])
   } catch (err) {
      console.log(err)
      reply(`❌ Error membaca case: ${err}`)
   }
}
break  

case 'addcase': {
  if (!isOwner) return XRO()
  if (!text) return reply(`Example : ${prefix + command} case 'halo': { reply("ok") } break`)

  
  const namaFile = 'Alice.js'
  const caseBaru = `\n${text}\n`

  fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) return reply('❌ Error membaca file: ' + err)

    // cari posisi sebelum "default:"
    const posisiDefault = data.lastIndexOf("default:")
    if (posisiDefault === -1) return reply("❌ Tidak menemukan block switch default")

    const kodeBaruLengkap =
      data.slice(0, posisiDefault) + caseBaru + '\n' + data.slice(posisiDefault)

    fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
      if (err) return reply('❌ Error menulis file: ' + err)
      reply('✅ Successfully add case')
    })
  })
}
break

case 'sendcase':
case 'sendfitur': {   
   if (!isOwner) return XRO()
   if (!m.quoted) return reply('❌ Kutip pesan seseorang untuk menentukan penerima!')
   if (!text) return reply(`❗ Contoh: ${prefix + command} uno`)

   

   // fungsi ambil case dari Alice.js
   const getCase = async (caseName) => {
      try {
         const fileContent = await fs.promises.readFile("./Alice.js", "utf-8")
         // regex lebih fleksibel (bisa ' " atau tanpa tanda kutip)
         const caseRegex = new RegExp(`case\\s+['"]?${caseName}['"]?\\s*:[\\s\\S]*?break`, "i")
         const match = fileContent.match(caseRegex)
         if (!match) return null
         return match[0]
      } catch (error) {
         throw new Error(error.message)
      }
   }

   const caseName = text.trim()
   try {
      const caseCode = await getCase(caseName)
      if (!caseCode) return reply(`❌ Case '${caseName}' tidak ditemukan di Alice.js.`)

      // ambil penerima dari pesan yang dikutip
      const recipient = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0])
      if (!recipient || !recipient.includes('@s.whatsapp.net')) {
         return reply('❌ Format target tidak valid (gunakan reply pesan atau mention user).')
      }

      // kirim kode case ke target
      const message = `📦 *Kamu dapat kiriman fitur baru!*\n\n${caseCode}`
      await Alice.sendMessage(recipient, { text: message }, { quoted: m })
      reply(`✅ Fitur '${caseName}' berhasil dikirim ke @${recipient.split('@')[0]}`, {
         contextInfo: { mentionedJid: [recipient] }
      })
   } catch (err) {
      console.error(err)
      reply(`❌ Error: ${err.message}`)
   }
}
break

case 'editcase': {
  if (!isOwner) return XRO()
  if (!text) return reply(`❗ Contoh: ${prefix + command} halo | case 'halo': {\n reply("Halo edit")\n } break`)

  let [caseName, ...newCaseArr] = text.split('|')
  caseName = caseName.trim()
  let newCaseBlock = newCaseArr.join('|').trim()

  if (!caseName || !newCaseBlock) {
    return reply('❌ Format salah!\nGunakan: .editcase <nama_case> | <kode_case_baru>')
  }

  
  const filePath = './Alice.js'

  try {
    let fileContent = fs.readFileSync(filePath, 'utf-8')

    // regex tangkap seluruh case lama (case ... sampai break)
    const regex = new RegExp(
      `case\\s+['"]?${caseName}['"]?\\s*:[\\s\\S]*?break`,
      'i'
    )

    if (!regex.test(fileContent)) {
      return reply(`❌ Case *${caseName}* tidak ditemukan.`)
    }

    // replace dengan block case baru utuh
    let updatedFileContent = fileContent.replace(regex, newCaseBlock)

    fs.writeFileSync(filePath, updatedFileContent, 'utf-8')
    reply(`✅ Case *${caseName}* berhasil diganti dengan block baru.`)
  } catch (error) {
    console.error(error)
    reply('❌ Terjadi kesalahan saat mengedit case.')
  }
}
break

case "delcase": {
  if (!isOwner) return XRO()
  if (!q) return reply("❗ Masukkan nama case yang ingin dihapus.\nContoh: delcase gpt4")

  const caseName = q.trim()
  

  let fileContent = fs.readFileSync("./Alice.js", "utf-8")

  // regex hapus case fleksibel
  const regex = new RegExp(
    `case\\s+['"]?${caseName}['"]?\\s*:\\s*{[\\s\\S]*?}\\s*break`,
    "i"
  )

  if (!regex.test(fileContent)) {
    return reply(`❌ Tidak menemukan case "${caseName}" untuk dihapus.`)
  }

  fileContent = fileContent.replace(regex, "")
  fs.writeFileSync("./Alice.js", fileContent, "utf-8")

  reply(`🗑️ Case "${caseName}" berhasil dihapus!`)
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Owner Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Convert Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'img2prompt':
case 'imagetoprompt': {
    await XReaction();
    
    let imageBuffer = null;
    
    if (m.quoted && /image/.test(m.quoted.mimetype || '')) {
        imageBuffer = await m.quoted.download();
    } else if (m.mtype === 'imageMessage') {
        imageBuffer = await m.download();
    } else if (text && (text.match(/\.(jpg|jpeg|png|gif|webp)$/i) || text.startsWith('http'))) {
        try {
            let res = await axios.get(text, { responseType: 'arraybuffer' });
            imageBuffer = Buffer.from(res.data);
        } catch {
            return reply('gagal download gambar dari link kak');
        }
    }
    
    if (!imageBuffer) return reply('reply gambar atau kirim link gambarnya kak');
    
    let w = await reply('tunggu bentar kak, lagi baca gambar…');
    
    try {              
        let result = await imgToPrompt(imageBuffer);
        
        if (!result.status) return reply('gagal kak: ' + result.error);
        
        await Alice.sendMessage(m.chat, {
            text: '📝 *Hasil Prompt:*\n\n' + result.prompt + '\n\n💡 prompt diatas bisa langsung dipake buat generate gambar lagi kak',
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m });
        
        await Alice.sendMessage(m.chat, { delete: w.key });
        
    } catch (e) {
        reply("error kak: " + e.message);
    }
}
break;
case 'faceblur':
case 'blurface': {
  await XReaction()

  if (!quoted) return reply(`Fotonya mana?`)
  if (!/image/.test(mime)) return reply(`Send/reply foto dengan caption ${prefix + command}`)

  try {
    let buffer = await quoted.download()
    let ext = mime.split('/')[1] || 'jpg'
    let fileName = `faceblur_${Date.now()}.${ext}`

    let url = await uploadToAliceCdn(buffer, fileName)

    let api = `https://api.siputzx.my.id/api/iloveimg/blurface?image=${encodeURIComponent(url)}`

    await Alice.sendMessage(
      m.chat,
      {
        image: { url: api },
        caption: packname
      },
      { quoted: m }
    )

  } catch (e) {
    console.log(e)
    reply('Terjadi error saat proses blur wajah')
  }
}
break
case 'attp':
case 'attp2':
case 'attp3':
case 'attp4':
case 'ttp':
case 'ttp2':
case 'ttp3':
case 'ttp4':
case 'ttp5': {
await XReaction();
  if (!text) return reply(`Contoh: ${prefix + command} tes`)

  try {
    let buffer

    if (command.startsWith('attp')) {
      switch (command) {
        case 'attp':
          buffer = await generateAttp(text)
          break
        case 'attp2':
          buffer = await generateAttp_v2(text)
          break
        case 'attp3':
          buffer = await generateAttp_v3(text)
          break
        case 'attp4':
          buffer = await generateAttp_v4(text)
          break
      }
    } else if (command.startsWith('ttp')) {
      switch (command) {
        case 'ttp':
          buffer = await generateTtp(text)
          break
        case 'ttp2':
          buffer = await generateTtp_v2(text)
          break
        case 'ttp3':
          buffer = await generateTtp_v3(text)
          break
        case 'ttp4':
          buffer = await generateTtp_v4(text)
          break
        case 'ttp5':
          buffer = await generateTtp_v5(text)
          break
      }
    }

    await Alice.sendImageAsSticker(m.chat, buffer, m, {
      packname: '',
      author: `${author}`,
    })
  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan')
  }
}
break
case 'iqc':
case 'iphonechat':
case 'ipchat': {
  
    await XReaction()

    if (!text)
        return reply(
`Masukkan teks iMessage!

Contoh:
${prefix + command} Halo, apa kabar?`
        )

    try {
        let now = new Date()
        let time = now.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'Asia/Jakarta'
        })

        let battery = Math.floor(Math.random() * 100) + 1

        let url = `https://api-faa.my.id/faa/iqcv2?prompt=${encodeURIComponent(text.trim())}&jam=${encodeURIComponent(time)}&batre=${battery}`

        await Alice.sendMessage(
            m.chat,
            {
                image: { url: url },
                caption: `📱 iPhone Chat\n\n"${text}"\n🕒 ${time}\n🔋 ${battery}%`
            },
            { quoted: m }
        )
    } catch (e) {
        console.error(e)
        reply('❌ Gagal membuat iPhone chat')
    }
}
break
case 'quotesimg': {
await XReaction();
  if (!text) return reply(`Kirim teks quotesnya!\nContoh: ${prefix + command} Jangan pernah menyerah, bro.`);
  function wrapText(ctx, text, maxWidth) {
    const words = text.split(' ');
    let lines = [];
    let currentLine = words[0];
    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + ' ' + word).width;
      if (width < maxWidth) {
        currentLine += ' ' + word;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);
    return lines;
  }
  async function generateQuoteImage(ppUrl, username, quoteText) {
    const width = 1000;
    const height = 500;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);
    const avatar = await loadImage(ppUrl);
    ctx.save();
    ctx.beginPath();
    ctx.arc(180, 250, 120, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, 60, 130, 240, 240);
    ctx.restore();
    ctx.fillStyle = '#ffffff';
    ctx.font = '28px sans-serif';
    let lines = wrapText(ctx, quoteText, 600);
    lines.forEach((line, i) => {
      ctx.fillText(line, 350, 180 + i * 35);
    });
    ctx.fillStyle = '#aaaaaa';
    ctx.font = '22px italic';
    ctx.fillText(`- ${username}`, 350, 180 + lines.length * 35 + 10);
    return canvas.toBuffer();
  }
  let pushname = m.pushName || m.sender.split('@')[0];
  let ppUrl = await Alice.profilePictureUrl(m.sender, 'image').catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60');
  let buffer = await generateQuoteImage(ppUrl, pushname, text);

  await Alice.sendMessage(m.chat, {
    image: buffer,
    caption: `📝 Quote dari *${pushname}*`,
    contextInfo: { mentionedJid: [m.sender] }
  }, { quoted: m });
}
break
      case "shortlink":
      case "shorturl": {
await XReaction();      
          if (!text) return reply(`Example: ${prefix + command} https://xyroorinzi.net`);
          if (!isUrl(text)) return reply(`Example: ${prefix + command} https://xyroorinzi.net`);
          var res = await axios.get(
            "https://tinyurl.com/api-create.php?url=" + encodeURIComponent(text)
          );
          var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`;
          return reply(link);
        }
        break;
case 'short-cloudku': {
await XReaction();      
  if (!text) return reply(`❌ Link tidak boleh kosong!\n\nContoh:\n.short-cloudku https://google.com\n.short-cloudku https://link.com custom123`)

  let [url, customCode] = text.split(' ')

  if (!/^https?:\/\//.test(url)) return reply('❌ Format link tidak valid! Harus diawali http:// atau https://')

  try {
    const res = await shortCloudku(url, customCode)

    if (!res.status) return reply(`❌ Gagal membuat shortlink:\n${res.error}`)

    let teks = `🔗 *SHORTLINK BERHASIL!*\n\n`
    teks += `🌐 Original : ${res.originalUrl}\n`
    teks += `🔗 Short    : ${res.shortUrl}\n`
    teks += `🆔 Kode     : ${res.key}`

    reply(teks)
  } catch (e) {
    reply('⚠️ Terjadi kesalahan: ' + e.message)
  }

  break
}
case 'morse': {
await XReaction();
  if (!text) return reply('Masukkan Teks Yang Ingin Diubah Menjadi Sandi Morse');
  try {
      const morseCode = await convertToMorse(text);
      let responseMessage = `*Teks Asli :*\n_${q}_\n\n*Sandi Morse:*\n${morseCode}`;
      reply(responseMessage);
  } catch (err) {
      console.error(err);
      reply('Terjadi Kesalahan Saat Mengonversi Teks Menjadi Sandi Morse!');
  }
}
break

case 'bratvid':
case 'bratvidio':
case 'bratvideo': {

  if (!text) return reply(`Contoh: ${prefix + command} hai bang`)
  await XReaction()
  if (text.length > 250) return reply(`Karakter terbatas, max 250!`)

  try {
    let res = await axios.get(`https://api.yupra.my.id/api/video/bratv?text=${encodeURIComponent(text)}`, {
      responseType: "arraybuffer"
    })

    const tmp = path.join(process.cwd(),'tmp')
    if (!fs.existsSync(tmp)) fs.mkdirSync(tmp)
    const vid = path.join(tmp, `brat-${Date.now()}.mp4`)
    fs.writeFileSync(vid, res.data)

    await Alice.sendImageAsSticker(m.chat, vid, m, {
      packname: 'AliceBot',
      author: 'BratV Maker'
    })

    setTimeout(()=>{
      if (fs.existsSync(vid)) fs.unlinkSync(vid)
    },4000)

  } catch(e){
    reply('Gagal membuat Brat Video.')
  }
}
break

case 'brat': {

  await XReaction()
  if (!q) return reply(`Masukkan teks\n\nContoh: ${prefix + command} hai`)

  let url = `https://api-faa.my.id/faa/brathd?text=${encodeURIComponent(q)}`

  try {
    let res = await axios.get(url, {
      responseType: 'arraybuffer'
    })

    let buffer = Buffer.from(res.data)

    await Alice.sendImageAsSticker(m.chat, buffer, m, {
      packname: '',
      author: author
    })

  } catch (e) {
    console.log(e)
    reply('❌ API brat HD lagi error / maintenance.')
  }
}
break

case 'emojimix': {
await XReaction();
    if (!text) return reply(`Example : 😎+😂 atau 😎|😂`);

    const emojis = text.split(/[\+\|]/);
    if (emojis.length !== 2) return reply('Silakan masukkan dua emoji yang valid, example: 😎+😂 atau 😎|😂');

    const text1 = emojis[0].trim();
    const text2 = emojis[1].trim();
 
    let api = `https://fastrestapis.fasturl.cloud/maker/emojimix?emoji1=${text1}&emoji2=${text2}`;
    await Alice.sendImageAsSticker(m.chat, api, xy, { packname: '', author: `${packname}` });
}
break;
case 'qc': {
await XReaction();
    const { quote } = require('./AliceLibray/quote.js');
    const axios = require('axios')
    let text;

    if (args.length >= 1) {
        text = args.slice(0).join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return reply("Input teks atau reply teks yang ingin di jadikan quote!");
    }

    if (!text) return reply('masukan text');
    if (text.length > 200) return reply('Maksimal 200 Teks!');

    let ppnyauser = await Alice.profilePictureUrl(m.sender, 'image').catch(_ => 'https://files.catbox.moe/nwvkbt.png');
    const rest = await quote(text, pushname, ppnyauser);
    Alice.sendImageAsSticker(m.chat, rest.result, m, {
        packname: ``,
        author: `${global.author}`
    });
}
break

case 'tr':
case 'translate': {
await XReaction();
    let translate = require('translate-google-api');
    let defaultLang = 'en';
    let tld = 'cn';
    let toks = `
Contoh:
${prefix + command} <lang> [text]
${prefix + command} id your messages
Daftar bahasa yang didukung: https://cloud.google.com/translate/docs/languages
`.trim();

    let lang = args[0];
    let text = args.slice(1).join(' ');

    if ((args[0] || '').length !== 2) {
        lang = defaultLang;
        text = args.join(' ');
    }

    if (!text && m.quoted && m.quoted.text) {
        text = m.quoted.text;
    }

    let result;
    try {
        result = await translate(`${text}`, { to: lang });
    } catch (e) {
        result = await translate(`${text}`, { to: defaultLang });
        reply(`Contoh:
${prefix + command} <lang> [text]
${prefix + command} id your messages
Daftar bahasa yang didukung: https://cloud.google.com/translate/docs/languages
`);
    } finally {
        reply(result[0]);
    }
}
break;
case 'togift':
case 'togif': {
await XReaction();
    if (!isMedia) {
        return reply(`Contoh Pengguna\n${prefix + command} *dengan reply sticker/gif*`);
    }
    await XReaction();
    try {
        let media = await Alice.downloadAndSaveMediaMessage(quoted);
        await Alice.sendMessage(m.chat, {
            video: media,
            mimetype: 'video/mp4',
            gifPlayback: true
        }, { quoted: m });
    } catch (e) {
       let media = await Alice.downloadAndSaveMediaMessage(quoted)
       let Xyroo = await uploadToAliceCdn(media)
       let jembut = Xyroo.result.url;
       let memek = await Webp2Mp4(jembut); 
        let kontol = memek.convertUrl;
        await Alice.sendMessage(m.chat, { video: { url: kontol }, gifPlayback: true }, { quoted: m });
    }
}
break;
case 'tomp4':
case 'tovideo':
case 'tovid': {
await XReaction()

if (!quoted) {
    return reply(`Contoh Pengguna\n${prefix + command} *dengan reply sticker bergerak*`)
}

let mime = (quoted.msg || quoted).mimetype || ''
if (!/webp/.test(mime)) return reply('Reply sticker bergerak!')

try {

    let media = await Alice.downloadAndSaveMediaMessage(quoted)

    let upload = await uploadToAliceCdn(media)
    let cdnUrl = upload.result

    if (!cdnUrl.startsWith('http')) throw new Error("Upload CDN gagal")

    let ezPage = await axios.get(`https://ezgif.com/webp-to-mp4?url=${cdnUrl}`)
    let $1 = cheerio.load(ezPage.data)

    let fileValue = $1('input[name="file"]').attr('value')
    let rawAction = $1('form.ajax-form').attr('action')

    if (!fileValue || !rawAction) throw new Error("EZGIF gagal membaca file")

    let actionUrl = rawAction.startsWith('http')
        ? rawAction
        : `https://ezgif.com${rawAction}`

    let form = new FormData()
    form.append('file', fileValue)
    form.append('convert', "Convert WebP to MP4!")

    let resConvert = await axios.post(actionUrl, form, {
        headers: { ...form.getHeaders() }
    })

    let $2 = cheerio.load(resConvert.data)
    let videoPart = $2('div#output > p.outfile > video > source').attr('src')

    if (!videoPart) throw new Error("Gagal mendapatkan video")

    let finalVideo = videoPart.startsWith('http')
        ? videoPart
        : `https:${videoPart}`

    await Alice.sendMessage(
        m.chat,
        { video: { url: finalVideo }, caption: 'donee' },
        { quoted: m }
    )

    if (fs.existsSync(media)) fs.unlinkSync(media)

} catch (err) {
    console.log(err)
    return XRR()
}
}
break
case 'tovn': {
await XReaction();
if (!isMedia) throw reply(`reply video/audio dengan caption ${prefix + command}`)
if (!quoted) throw reply(`reply video/audio dengan caption ${prefix + command}`)
await XReaction()
try {
var dl = await m.quoted.download()
Alice.sendMessage(m.chat, {audio: dl, mimetype:'audio/mpeg', ptt:true, contextInfo:{  externalAdreply: { showAdAttribution: false,
mediaType:  1,
mediaUrl: channel,
title: `${global.botname} `,
body: `$${ownername}`,
sourceUrl: `${global.channel}`,
thumbnail: ppnyauser
}
}}, { quoted: m })
} catch (error) {
  return XRR()
}
}
break

case 'tomp3':
case 'toaudio': {
await XReaction();
if (!isMedia) throw reply(`reply video/audio dengan caption ${prefix + command}`)
if (!quoted) throw reply(`reply video/audio dengan caption ${prefix + command}`)
await XReaction()
try {
var dl = await m.quoted.download()
Alice.sendMessage(m.chat, {audio: dl, mimetype:'audio/mpeg', ptt:false, contextInfo:{  externalAdreply: { showAdAttribution: false,
mediaType:  1,
mediaUrl: channel,
title: `${global.botname}`,
body: `Hai ${pushname}`,
sourceUrl: `${global.channel}`,
thumbnail: ppnyauser
}
}}, { quoted: m })
} catch (error) {
  return XRR()
}
}
break
            
case 'toimage': case 'toimg': {
await XReaction();
if (!quoted) reply('reply Image')
if (!/webp/.test(mime)) reply(`Balas sticker dengan caption *${prefix + command}*`)
let media = await Alice.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
let buffer = fs.readFileSync(ran)
Alice.sendMessage(m.chat, { image: buffer }, {quoted: m})
fs.unlinkSync(ran)
})
}
break

case 'toptv': {
    await XReaction()
    if (!quoted) return reply('reply video')
    if (!m.quoted) return reply(`Balas Video Dengan Caption ${prefix + command}`)

    if (/video/.test(mime)) {
        var ppt = m.quoted
        var ptv = generateWAMessageFromContent(
            m.chat,
            proto.Message.fromObject({
                ptvMessage: ppt
            }),
            { userJid: m.chat, quoted: m }
        )

        Alice.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id })
    }
}
break

case 'tourl': {
await XReaction()

try {
const targetMsg = m.quoted ? m.quoted : m
const mimeType = targetMsg.mimetype || ''

if (!mimeType) {
return reply(`❌ Reply/kirim media dengan caption *${prefix + command}*`)
}

if (!/image|video|audio/.test(mimeType)) {
return reply('❌ Hanya gambar, video, atau audio.')
}

let mediaBuffer = await targetMsg.download()

if (!Buffer.isBuffer(mediaBuffer)) {
if (mediaBuffer?.buffer && Buffer.isBuffer(mediaBuffer.buffer)) {
mediaBuffer = mediaBuffer.buffer
} else {
return reply('❌ Media tidak valid')
}
}

const axios = require('axios')
const FormData = require('form-data')

async function uploadToAliceCdn(buffer, fileName) {
const form = new FormData()

form.append('cdnFile', buffer, {
filename: fileName,
contentType: mimeType
})

const res = await axios.post(
'https://aliceecdn.vercel.app/upload',
form,
{
headers: form.getHeaders(),
maxBodyLength: Infinity
}
)

return res.data
}

const extMap = {
'image/jpeg': 'jpg',
'image/jpg': 'jpg',
'image/png': 'png',
'image/webp': 'webp',
'image/gif': 'gif',
'video/mp4': 'mp4',
'video/mpeg': 'mpeg',
'video/quicktime': 'mov',
'video/webm': 'webm',
'audio/mpeg': 'mp3',
'audio/mp3': 'mp3',
'audio/ogg': 'ogg',
'audio/wav': 'wav',
'audio/aac': 'aac',
'audio/mp4': 'm4a'
}

const ext = extMap[mimeType] || mimeType.split('/')[1] || 'bin'
const fileName = `${Date.now()}.${ext}`

const result = await uploadToAliceCdn(mediaBuffer, fileName)

if (!result?.url) {
return reply('❌ Upload gagal')
}

const caption =
`✅ *UPLOAD BERHASIL*\n\n` +
`🌐 URL:\n${result.url}\n\n` +
`📦 Type: ${mimeType}\n` +
`⏳ Expired: Permanent`

const buttons = [
{
name: "cta_copy",
buttonParamsJson: JSON.stringify({
display_text: "📋 Copy URL",
id: result.url,
copy_code: result.url
})
}
]

if (/image/.test(mimeType)) {

await Alice.sendInteractive(
m.chat,
buttons,
result.url,
packname,
caption,
m
)

} else if (/video/.test(mimeType)) {

await Alice.sendMessage(m.chat, {
video: { url: result.url },
caption
}, { quoted: m })

await Alice.sendButtonProto(
m.chat,
'📋 Copy URL di bawah ini',
packname,
buttons,
m
)

} else if (/audio/.test(mimeType)) {

await Alice.sendMessage(m.chat, {
audio: { url: result.url },
mimetype: mimeType,
ptt: false
}, { quoted: m })

await Alice.sendButtonProto(
m.chat,
caption,
packname,
buttons,
m
)

}

} catch (err) {
reply(`⚠️ Error: ${err.message || err}`)
}
}
break

case 'wm': {
  try {
  
    if (!text) return reply('Reply gambar/video/stiker dengan caption: *.wm <packname>*')
    await XReaction()

const tmpDir = path.join(__dirname, 'tmp')
fs.mkdirSync(tmpDir, { recursive: true })

const bufferToTemp = (buf, ext) => {
  const p = path.join(tmpDir, `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`)
  fs.writeFileSync(p, buf)
  return p
}

const ffmpegOnce = (inPath, args, outPath) => new Promise((res, rej) => {
  const p = spawn('ffmpeg', ['-y', '-i', inPath, ...args, outPath])
  let err = ''
  p.stderr.on('data', d => err += d.toString())
  p.on('close', c => c === 0 ? res() : rej(new Error(err || ('ffmpeg exit ' + c))))
})

const isAnimatedWebp = (buf) => {

  const s = buf.toString('binary')
  return s.includes('ANIM') || s.includes('ANMF')
}

const injectExifWebp = async (inputBuf, packname, author) => {
  const img = new WebpMux.Image()
  await img.load(inputBuf)
  const exifObj = {
    'sticker-pack-id': 'com.alice.wm',
    'sticker-pack-name': String(packname || 'Alice'),
    'sticker-pack-publisher': String(author || ''),
    'emojis': ['🙂']
  }
  const exifBuf = Buffer.concat([
    Buffer.from([0x45,0x78,0x69,0x66,0x00,0x00]),
    Buffer.from([0x4D,0x4D,0x00,0x2A,0x00,0x00,0x00,0x08]),
    Buffer.from(JSON.stringify(exifObj), 'utf8')
  ])
  img.exif = exifBuf
  return await img.save(null) 
}

const webpToPng = async (buf) => {
  const inPath  = bufferToTemp(buf, 'webp')
  const outPath = inPath.replace(/\.webp$/, '.png')
  await ffmpegOnce(inPath, [], outPath)
  const out = fs.readFileSync(outPath)
  try { fs.unlinkSync(inPath); fs.unlinkSync(outPath) } catch {}
  return out
}

const videoToWebp = async (buf) => {
  const inPath  = bufferToTemp(buf, 'mp4')
  const outPath = inPath.replace(/\.mp4$/, '.webp')
  const vf = 'scale=512:512:force_original_aspect_ratio=decrease,fps=15,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=ffffff@0'
  await ffmpegOnce(inPath, ['-vf', vf, '-loop','0','-lossless','1','-an','-vsync','0','-preset','picture','-qscale','50'], outPath)
  const out = fs.readFileSync(outPath)
  try { fs.unlinkSync(inPath); fs.unlinkSync(outPath) } catch {}
  return out
}

    const q = m.quoted ? m.quoted : m
    const mime  = (q.msg || q).mimetype || ''
    const mtype = q.mtype || ''
    const packname = text.trim()
    const author   = ''

    const media = await Alice.downloadMediaMessage(q).catch(() => null)
    if (!media) return reply('⚠️ Media tidak ditemukan / gagal diunduh.')

    const isSticker = /sticker/i.test(mtype) || /webp/i.test(mime)
    const isImage   = /image/i.test(mime) && !isSticker
    const isVideo   = /video/i.test(mime)

    if (isSticker) {
      if (isAnimatedWebp(media)) {
        try {
          const withExif = await injectExifWebp(media, packname, author)
          await Alice.sendMessage(m.chat, { sticker: withExif }, { quoted: m })
        } catch (e) {
          await Alice.sendMessage(m.chat, { sticker: media }, { quoted: m })
        }
      } else {
        const png = await webpToPng(media)
        await Alice.sendImageAsSticker(m.chat, png, m, { packname, author })
      }
      return
    }

    if (isImage) {
      await Alice.sendImageAsSticker(m.chat, media, m, { packname, author })
      return
    }

    if (isVideo) {
      const sec =
        (q.msg && (q.msg.seconds || q.msg.duration)) ||
        q.seconds || q.duration || 0
      if (Number(sec) > 10) return reply('Maksimal 10 detik!')

      try {
        await Alice.sendVideoAsSticker(m.chat, media, m, { packname, author })
      } catch {
        const webp = await videoToWebp(media)
        await Alice.sendMessage(m.chat, { sticker: webp }, { quoted: m })
      }
      return
    }

    return reply('Reply gambar/video/stiker dengan caption *.wm <packname>*')

  } catch (e) {
    console.error('wm error:', e)
    return reply('❌ Error saat memproses WM (pure-JS). Coba kirim ulang medianya.')
  }
}
break
case 'sticker':
case 'stiker':
case 's':{
await XReaction();
if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
await XReaction()
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await Alice.sendImageAsSticker(m.chat, media, m, {
packname: global.packname,
author: global.author
})
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 31) return reply('Maksimal 30 detik!')
let media = await quoted.download()
let encmedia = await Alice.sendVideoAsSticker(m.chat, media, m, {
packname: global.packname,
author: global.author
})
} else {
return reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}
break

case 'smeme': {
await XReaction();
  if (quoted) {
    let msg = quoted
    let type = Object.keys(msg)[0]
    if (msg[type].viewOnce && /image/.test(type)) {
      let media = await downloadContentFromMessage(msg[type], 'image')
      let buffer = Buffer.from([])
      for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
      }

      let awal = text.split('|')[0] || ''
      let akhir = text.split('|')[1] || ''
      const tempFile = `./temp_${Date.now()}.jpg`
      await fs.writeFileSync(tempFile, buffer)

      let hasil = await Smeme(awal, akhir, tempFile)

      await Alice.sendImageAsSticker(m.chat, hasil, xy, {
      packname: `${pushname}`,
      author: `${author}`
      })

      await fs.unlinkSync(tempFile)
      return
    }
  }

  if (!/webp/.test(mime) && /image/.test(mime)) {
    let awal = text.split('|')[0] || ''
    let akhir = text.split('|')[1] || ''
    let mee = await Alice.downloadAndSaveMediaMessage(quoted)
    
    let hasil = await Smeme(awal, akhir, mee)

    await Alice.sendImageAsSticker(m.chat, hasil, xy, {
      packname: `${pushname}`,
      author: `${author}`
    })
    await fs.unlinkSync(mee)
  } else {
    reply(`Kirim/kutip gambar dengan caption ${prefix + command} memek|xyroo`)
  }
}
break

case 'hd':
case 'hdr':
case 'remini':
case 'enhanced': {
await XReaction();
  if (!isImage) return reply(`Balas ${prefix + command} dengan gambar`)

  const buffer = await quoted.download()
  if (!buffer) return reply('Gagal ambil gambar')

  const res = await aliceHdImage(buffer, 4)
  if (!res.status) return reply(res.msg)

  await Alice.sendMessage(
    m.chat,
    {
      image: fs.readFileSync(res.output),
      caption: `✨ Image Enhanced\n© ${ownername}`
    },
    { quoted: m }
  )

  fs.unlinkSync(res.output)
}
break
            
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Convert Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Tools Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'mbg': {
    await XReaction()

    if (!text) {
        return reply(`Contoh:
${prefix + command} 120000000000000
${prefix + command} elon musk`)
    }

    try {

        let nominal = Number(
            text.replace(/[^0-9]/g, '')
        )

        if (!nominal || nominal <= 0) {

            let url =
`https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(
`Berapa total kekayaan ${text} sekarang dalam rupiah? Jawab format rupiah saja`
)}`

            let r = await fetch(url)
            let j = await r.json()

            let ai =
                j?.result ||
                j?.data?.result ||
                j?.response ||
                ''

            nominal = Number(
                ai.replace(/[^0-9]/g, '')
            )

            if (!nominal || nominal <= 0) {
                return reply('Gagal mendapatkan data kekayaan')
            }

        }

        const perHari = 1200000000000

        let totalHari = nominal / perHari

        let tahun = Math.floor(totalHari / 365)
        let sisaHari = totalHari % 365

        let bulan = Math.floor(sisaHari / 30)
        let hari = Math.floor(sisaHari % 30)

        let jam = totalHari * 24
        let menit = jam * 60
        let detik = menit * 60

        reply(
`🍱 *Makan Bergizi Gratis Calculator*

💸 Budget :
Rp ${nominal.toLocaleString('id-ID')}

📊 Estimasi MBG :
${tahun} Tahun ${bulan} Bulan ${hari} Hari

⏱️ Detail :
• ${jam.toFixed(2)} Jam
• ${menit.toFixed(2)} Menit
• ${detik.toFixed(0)} Detik`
        )

    } catch (e) {
        console.log(e)
        reply('error bang')
    }

    break
}
case 'rekap': {
    if (!text) return reply(`⚠️ Format:\n.rekap\nteam1: nama 50\nteam2: nama 70`)

    let lines = text.split('\n')
    let hasil = []
    let total = 0
    let numbers = []

    for (let line of lines) {
        let match = line.match(/(\d+)/)
        if (match) {
            let angka = parseInt(match[1])
            numbers.push(angka)
 
            let nama = line.replace(/[:\d]/g, '').trim()
            hasil.push(`${nama}: [${angka}] = ${angka}`)
            total += angka
        }
    }

    if (hasil.length < 2) {
        return reply('⚠️ Minimal 2 data untuk rekap.')
    }

    let selisih = Math.max(...numbers) - Math.min(...numbers)

    let teks = hasil.join('\n') + `\n\nTOTAL: ${total}\nSELISIH: ${selisih}`
    reply(teks)
}
break
case 'vocalremover':
case 'instrumenremover': {
  await XReaction()

  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''

  if (!/audio/.test(mime)) return reply(`Reply *audio* dengan perintah ${prefix + command}`)

  try {
    let buffer = await q.download()

    let fileSizeLimit = 5 * 1024 * 1024
    if (buffer.length > fileSizeLimit) {
      return reply('Ukuran audio terlalu besar, maksimal 5MB.')
    }

    let ext = mime.split('/')[1] || 'mp3'
    let fileName = `audio_${Date.now()}.${ext}`

    let media = await uploadToAliceCdn(buffer, fileName)
    if (!media) throw new Error('Gagal upload')

    let response = await fetch(`https://api.betabotz.eu.org/api/tools/voiceremover?url=${encodeURIComponent(media)}&apikey=beta-gilang`)
    let res = await response.json()

    if (!res.status) throw 'Gagal memproses audio dari API.'

    if (command === 'vocalremover') {
      await Alice.sendMessage(m.chat, {
        audio: { url: res.result.instrumental_path },
        mimetype: 'audio/mpeg',
        fileName: 'instrumental.mp3'
      }, { quoted: m })
    } else if (command === 'instrumenremover') {
      await Alice.sendMessage(m.chat, {
        audio: { url: res.result.vocal_path },
        mimetype: 'audio/mpeg',
        fileName: 'vocal.mp3'
      }, { quoted: m })
    }

  } catch (e) {
    console.error(e)
    await reply('*[INTERNAL SERVER ERROR!]*\nTerjadi kesalahan, coba lagi nanti.')
  }
}
break
case 'skiplink':
case 'skiplinksub4unlock': {
await XReaction();
    if (!text) {
        reply(`Contoh : .skiplink https://sub4unlock.co/S9oU0`);
        break;
    }
    
    try {
        let api = `https://fgsi.koyeb.app/api/tools/skip/sub4unlock?apikey=APIKEY&url=${encodeURIComponent(text)}`;
        let { data: json } = await axios.get(api);

        if (!json.status || !json.data?.linkGo) {
            reply('Lu masukin url apa tu woy 😂');
            break;
        }

        reply(`${json.data.linkGo}`);
    } catch (err) {
        reply(`Eror kak : ${err.message}`);
    }
    break;
}

case 'toplugins': {
const path = require('path')
const fs = require('fs')

if (!quoted || !quoted.text) {
return reply(`Contoh:\n${prefix + command} search\n${prefix + command} downloader,owner\n${prefix + command} tools,premium,group`)
}

try {

const input = text.split(',').map(v => v.trim())

const tag = input[0] || 'tools'
const flags = text.toLowerCase()

const owner = flags.includes('owner')
const premium = flags.includes('premium')
const group = flags.includes('group')
const privatee = flags.includes('private')
const admin = flags.includes('admin')
const botadmin = flags.includes('botadmin')

const code = quoted.text.trim()

const caseMatch = code.match(/case\s+['"`](.*?)['"`]\s*:/)
if (!caseMatch) return reply('❌ Case tidak ditemukan')

const cmdName = caseMatch[1]

const bodyMatch = code.match(/case\s+['"`](.*?)['"`]\s*:\s*{([\s\S]*?)}\s*break/)
if (!bodyMatch) return reply('❌ Isi case tidak ditemukan')

let body = bodyMatch[2].trim()

const plugin = `let handler = async (m, { Alice, text, args, reply, XReaction, prefix, command, isOwner, isAdmins, isBotAdmins, isPrem }) => {

${body}

}

handler.help = ['${cmdName}']
handler.tags = ['${tag}']
handler.command = ['${cmdName}']
${owner ? 'handler.owner = true' : ''}
${premium ? 'handler.premium = true' : ''}
${group ? 'handler.group = true' : ''}
${privatee ? 'handler.private = true' : ''}
${admin ? 'handler.admin = true' : ''}
${botadmin ? 'handler.botAdmin = true' : ''}
module.exports = handler`

const filename = `plugin_${Date.now()}.js`
const filepath = path.join(__dirname, filename)

fs.writeFileSync(filepath, plugin)

await Alice.sendMessage(m.chat, {
document: fs.readFileSync(filepath),
mimetype: 'application/javascript',
fileName: filename,
caption: plugin
}, { quoted: m })

fs.unlinkSync(filepath)

} catch (e) {
console.log(e)
reply('❌ Gagal convert ke plugins')
}
}
break;

case 'tocase': {
  
  const path = require('path')
  if (!quoted || !quoted.text) return reply('❌ Reply ke plugin handler (ESM/CJS) yang mau diubah jadi case.');

  const code = quoted.text.trim();

  try {
    const cmdMatch = code.match(/handler\.command\s*=\s*\[(.*?)\]/);
    const bodyMatch = code.match(/let handler\s*=\s*async\s*\(.*?\)\s*=>\s*{([\s\S]+?)^\}/m) ||
                      code.match(/async function.*?\([\s\S]*?\)\s*{([\s\S]+?)^\}/m);

    if (!cmdMatch || !bodyMatch) return reply('❌ Tidak bisa mendeteksi struktur command atau isi fungsi.');

    const commands = cmdMatch[1].split(',').map(v => v.replace(/['"\[\]\s]/g, '')).filter(Boolean);
    const body = bodyMatch[1].trim();

    const result = commands.map(cmd => {
      return `case '${cmd}': {\n  ${body.replace(/\n/g, '\n  ')}\n}\nbreak;`;
    }).join('\n\n');

    if (result.length > 4000) {
      const filename = `converted_case_${Date.now()}.js`;
      const filepath = path.join(__dirname, filename);
      fs.writeFileSync(filepath, result);

await Alice.sendMessage(m.chat, {
document: fs.readFileSync(filepath),
mimetype: 'application/javascript',
fileName: filename,
caption: result
}, { quoted: m })

      fs.unlinkSync(filepath);
    } else {
      reply('✅ Berikut hasil konversi:\n\n' + '```js\n' + result + '\n```');
    }

  } catch (e) {
    console.error(e);
    reply('❌ Gagal mengonversi plugin: ' + e.message);
  }
}
break;
case 'npm':
case 'npms':
case 'npmjs':
case 'npmshare':
case 'npmsearch': {
await XReaction();
                if (!text) return reply(`Masukkan nama package!\nContoh: ${prefix + command} axios'`);
                let res = await fetch(`https://api.ditss.cloud/search/npm?apikey=DitssGanteng&q=${encodeURIComponent(text)}`);
                let json = await res.json();

                if (!json.result || !json.result.length) return reply('❌ Paket tidak ditemukan.');

                async function createImage(url) {
                    const {
                        imageMessage
                    } = await generateWAMessageContent({
                        image: {
                            url
                        }
                    }, {
                        upload: Alice.waUploadToServer
                    });
                    return imageMessage;
                }

                let cards = [];
                let data = json.result.slice(0, 10); // maksimal 10 paket

                for (let pkg of data) {
                    let npmLink = pkg.links?.npm || '';
                    let github = pkg.links?.repository?.replace(/^git\+/, '').replace(/\.git$/, '');
                    let img = 'https://raw.githubusercontent.com/ditss-dev/database/main/mbnojzwp.jpg'; // ikon NPM

                    cards.push({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `📦 ${pkg.title}\n📅 Update: ${pkg.update}\n👤 ${pkg.author}`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: 'NPM Search'
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: pkg.title,
                            hasMediaAttachment: true,
                            imageMessage: await createImage(img)
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [{
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📄 NPM",
                                        url: npmLink,
                                        merchant_url: npmLink
                                    })
                                },
                                github ? {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🔗 GitHub",
                                        url: github,
                                        merchant_url: github
                                    })
                                } : null
                            ].filter(Boolean)
                        })
                    });
                }

                const msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `🔍 *Hasil Pencarian:* _${text}_`
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: `powered by ${global.namaowner}`
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    hasMediaAttachment: false
                                }),
                                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                    cards
                                })
                            })
                        }
                    }
                }, {});

                await Alice.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break
case 'getpastebin': 
case 'getpb': {
 if (!text) return reply(`🔗 Masukkan link pastebin`);

 try {
 const res = await fetch(`https://api.nekorinn.my.id/tools/getpastebin?url=${encodeURIComponent(q)}`);
 const json = await res.json();
 if (!json.status) return reply(`⚠️ Gagal ambil data dari Pastebin.`);

 let content = json.result.content
 .split('\n')
 .filter(line => !line.trim().startsWith('//'))
 .join('\n');

 const isiPreview = content.length > 4000 ? content.slice(0, 4000) + '\n\n📌 Terpotong otomatis.' : content;

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 header: proto.Message.InteractiveMessage.Header.create({
 title: '📄 Pastebin Content',
 subtitle: 'Hasil dari link kamu',
 hasMediaAttachment: false
 }),
 body: { text: isiPreview },
 footer: { text: `Powered by ${botname}` },
 nativeFlowMessage: {
 buttons: [
 {
 name: 'cta_copy',
 buttonParamsJson: JSON.stringify({
 display_text: '📋 Salin Semua Isi',
 copy_code: content.slice(0, 10000)
 })
 }
 ]
 }
 })
 }
 }
 }, { userJid: m.chat, quoted: m });

 await Alice.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

 } catch (err) {
 console.error(err);
 reply(`❌ Error: ${err.message}`);
 }
}
break
case 'ggist':
case 'getgist': {
await XReaction();
 if (!text) return reply(`📌 Kirim ID atau URL Gist!\nContoh: ${prefix + command} 4c2db6dca3ee1e5f3eac53bd31c2f4d7`);

 const gistId = text.includes('gist.github.com')
 ? text.split('/').pop().split('?')[0]
 : text.trim();

 try {
 const res = await fetch(`https://api.github.com/gists/${gistId}`);
 if (!res.ok) throw `Gist tidak ditemukan atau private.`;

 const json = await res.json();
 const files = json.files;
 const firstFile = Object.values(files)[0];

 if (!firstFile || !firstFile.content) throw `Isi Gist kosong atau file tidak bisa dibaca.`;

 const namaFile = firstFile.filename;
 const isiFile = firstFile.content;
 const gistUrl = json.html_url;

 const output = `📂 *Gist ID:* ${gistId}\n` +
 `📄 *Nama File:* ${namaFile}\n\n` +
 `📜 *Isi:* \n${isiFile.slice(0, 10000)}\n`;

 await Alice.sendMessage(m.chat, {
 text: output.trim(),
 footer: packname,
 interactiveButtons: [{
 name: 'cta_copy',
 buttonParamsJson: JSON.stringify({
 display_text: '📂 Copy Gist',
 copy_code: gistUrl
 })
 }]
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 reply(`❌ Gagal ambil Gist!\n📄 *Error:* ${err.message || err}`);
 }
}
break
case 'faketiktok': case 'tiktokfake': {
await XReaction();
  if (!text) {
    return Alice.sendMessage(m.chat, {
      text: `*Fake TikTok Profile Generator*\n\n` +
            `Kirim perintah dengan format:\n` +
            `*${prefix + command}* Nama|Username|Followers|Following|Likes|Bio|Verified(true/false)|isFollow(true/false)|dark/light\n\n` +
            `Contoh:\n` +
            `*${prefix + command}* Apa Kek|Yubi|4020030|12|789000|Beginner in coding, but I love it! Follow me for more coding tips and tricks.|true|true|dark`
    }, { quoted: m });
  }
  let [name, username, followers, following, likes, bio, verified = 'true', isFollow = 'true', dark = 'true'] = text.split('|')
  if (!name || !username || !followers || !following || !likes || !bio) {
    return reply('Format salah.\nCoba ikuti contoh:\nNama|Username|Followers|Following|Likes|Bio|Verified|isFollow|Theme')
  }
  let ppUrl = await Alice.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/2f61d40b7cfb440f3cfa7.jpg')
  let apiUrl = `https://flowfalcon.dpdns.org/imagecreator/faketiktok?name=${encodeURIComponent(name)}&username=${encodeURIComponent(username)}&pp=${encodeURIComponent(ppUrl)}&verified=${verified}&followers=${followers}&following=${following}&likes=${likes}&bio=${encodeURIComponent(bio)}&dark=${dark}&isFollow=${isFollow}`

  try {
const axios = require('axios');
    let { data } = await axios.get(apiUrl, { responseType: 'arraybuffer' })
    const buffer = Buffer.from(data)
    const FormData = (await import('form-data')).default
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('userhash', '')
    form.append('fileToUpload', buffer, 'tiktokfake.jpg')
    const upres = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    })
    if (!upres.data || !upres.data.includes('catbox')) return reply('Gagal upload gambar.')
    Alice.sendMessage(m.chat, {
      image: { url: upres.data }
    }, { quoted: m })
  } catch (e) {
    console.error(e)
    reply('Terjadi kesalahan saat membuat gambar.')
  }
}
  break
case 'phlogo': {
await XReaction();
  if (!text || !text.includes('|')) {
    return reply(`Masukkan dua teks dipisah dengan "|"\nContoh: *${prefix + command} Xyroo|Rynzz*`)
  }

  let [text1, text2] = text.split('|').map(t => t.trim())
  if (!text1 || !text2) return reply('Kedua teks harus diisi!')

  try {
    const apiUrl = `https://apikey.sazxofficial.web.id/api/imagecreator/pornhub?text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`
    const res = await fetch(apiUrl)
    const json = await res.json()

    if (!json.status) return reply('Gagal mengambil gambar dari API.')

    await Alice.sendMessage(m.chat, {
      image: { url: json.result },
      caption: `✅ *Berhasil membuat logo Pornhub*\n\n• *Text1:* ${text1}\n• *Text2:* ${text2}`,
      contextInfo: {
        externalAdreply: {
          title: "Pornhub Logo Generator",
          body: packname,
          thumbnailUrl: thumb,
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: json.result
        }
      }
    }, { quoted: m })

  } catch (e) {
    reply('Terjadi kesalahan saat memproses permintaan.')
    console.error(e)
  }
}
break
case 'scweb':
case 'gethtml': {
await XReaction();
    if (!text) return reply(`Contoh: ${prefix + command} https://example.com`);

    try {
        let res = await fetch(text);
        if (!res.ok) return reply('❌ Gagal mengambil data dari URL tersebut');
        let html = await res.text();

        const filePath = path.join(__dirname, './tmp/html_dump.html');
        fs.writeFileSync(filePath, html);

        await Alice.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: 'text/html',
            fileName: 'source.html'
        }, { quoted: m });

        fs.unlinkSync(filePath); // hapus setelah terkirim
    } catch (e) {
        console.error(e);
        reply('❌ Terjadi kesalahan saat mengambil HTML\n'+e.message);
    }
}
break
case 'texttonote': {
  await XReaction();
  if (!text) return reply(`Example : ${prefix + command} Nama|Kelas|Mata Pelajaran|Tanggal|Isi Catatan`)
  let [name, classroom, subject, date, ...content] = text.split('|')
  if (!name || !classroom || !subject || !date || content.length == 0) {
    return reply(`Format salah!\nContoh:\n${prefix + command} Xyroo|XII - Bio A|Sexual Organs|2026-01-25|Isi catatan...`)
  }

  let contentEncoded = encodeURIComponent(content.join('|').trim())
  let url = `https://fastrestapis.fasturl.cloud/tool/texttonote?name=${encodeURIComponent(name)}&classroom=${encodeURIComponent(classroom)}&subject=${encodeURIComponent(subject)}&date=${encodeURIComponent(date)}&content=${contentEncoded}`

  try {
    await Alice.sendMessage(m.chat, {
      image: { url },
      caption: `Catatan untuk ${subject} berhasil dibuat!`
    }, { quoted: m })
  } catch (err) {
    console.error(err)
    reply('Gagal membuat catatan, pastikan format dan isi valid.')
  }
}
  break

case'ceklinkgc':{
await XReaction();
    const iidgc = budy.match('@g.us')
    if(!iidgc)return reply(`Sertakan IdGroup Dengan Benar\nExample : ${prefix + command} 120.......@g.us`)
    try{
    const gc = "https://chat.whatsapp.com/" + await Alice.groupInviteCode(text)
await reply(`${gc}`)
        }catch(e){
            reply('IdGroup Tidak Valid!!')
        }
}
break
case "nulis": case "tulis": {
await XReaction();
if (!text) return reply('textnya mana anjim???')
  let apiUrl = `https://brat.siputzx.my.id/nulis?text=${encodeURIComponent(text)}`;

  try {
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    Alice.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: `📝 *Hasil Tulisan* 📝\n\n📌 *Teks:* ${text}`
    }, { quoted: m });
  } catch (error) {
    console.log(error);
    reply(`❌ Error\nLogs error : ${error.message}`);
  }
}
break
case 'codegen': {
await XReaction();
  if (!text) return reply(`*Contoh penggunaan:*\n${prefix + command} Fungsi untuk menghitung luas segitiga|Python`)

  let [prompt, language] = text.split("|").map(v => v.trim());

  if (!prompt || !language) {
    return reply(
      `*Format salah!*\nGunakan format seperti ini:\n` +
      `.${prefix + command} <prompt>|<bahasa>\n\n` +
      `Contoh:\n.${prefix + command} Cek bilangan prima|JavaScript`
    );
  }

  try {
    const payload = {
      customInstructions: prompt,
      outputLang: language
    };

    const { data } = await axios.post("https://www.codeconvert.ai/api/generate-code", payload);

    if (!data || typeof data !== "string") {
      return reply("Gagal mengambil hasil dari API.");
    }

    reply(
      `*Kode Hasil (${language}):*\n` +
      "```" + language.toLowerCase() + "\n" +
      data.trim() +
      "\n```"
    );

  } catch (error) {
    console.error(error);
    reply("Terjadi kesalahan saat memproses permintaan.");
  }
};
break
case 'spamtag': {
await XReaction();
  if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!')
  if (!text.includes('|')) return reply('Format salah!\nGunakan: .spamtag 628xxx/@tag|jumlah|pesan')

  let [targetRaw, jumlahRaw, ...pesanArray] = text.split('|')
  let jumlah = parseInt(jumlahRaw.trim())
  let pesan = pesanArray.join('|').trim()

  if (!targetRaw || isNaN(jumlah) || jumlah < 1 || !pesan)
    return reply('Format salah!\nGunakan: .spamtag 628xxx/@tag|jumlah|pesan')

  let target = targetRaw.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const chatId = m.chat

  // Inisialisasi kalau belum ada
  if (!Alice.spamStatus) Alice.spamStatus = {}
  Alice.spamStatus[chatId] = true

  for (let i = 1; i <= jumlah; i++) {
    if (!Alice.spamStatus[chatId]) break
    await Alice.sendMessage(chatId, {
      text: `[#${i}] ${pesan}\n@${target.split('@')[0]}`,
      mentions: [target]
    }, { quoted: m })
    await new Promise(res => setTimeout(res, 1000))
  }

  delete Alice.spamStatus[chatId]
}
break

case 'stopspam': {
await XReaction();
  if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!')
  if (!Alice.spamStatus) Alice.spamStatus = {}

  const chatId = m.chat
  if (Alice.spamStatus[chatId]) {
    delete Alice.spamStatus[chatId]
    reply('Spam tag berhasil dihentikan!')
  } else {
    reply('Tidak ada spam tag yang sedang berjalan.')
  }
}
break

            case "tocode": {
                if (!text && !m.quoted) return reply(`\nreply something, then enter the file name, example: ${prefix + command} yaya\n`);
                let fullFileName = `c-${text}.js`;
                let quotedType = m.quoted?.mtype || '';
                let penis = JSON.stringify({ [quotedType]: m.quoted }, null, 2);

                const HeaderType = {
                    UNKNOWN: 0,
                    EMPTY: 1,
                    TEXT: 2,
                    DOCUMENT: 3,
                    IMAGE: 4,
                    VIDEO: 5,
                    LOCATION: 6
                };

                const ButtonType = {
                    UNKNOWN: 0,
                    RESPONSE: 1,
                    NATIVE_FLOW: 2
                };
                
                let result;
                if (quotedType === 'liveLocationMessage') {
                    result = ` 
let handler = async (m, { Alice, prefix, reply }) => {
  Alice.relayMessage(m.chat, {
    viewOnceMessage: {
      message: ${penis}
    }
  }, {})
}

handler.help = ["c${text}"]
handler.tags = ['copy']
handler.command = ["${text}"]
handler.owner = true

module.exports = handler
`;
                } else if (quotedType === 'buttonsMessage') {
                    let buttonsMessage = {};
                    let headerType = HeaderType.UNKNOWN;
                    let buttonType = ButtonType.RESPONSE;
                    result = `
let handler = async (m, { Alice, prefix, reply }) => {
  Alice.relayMessage(m.chat, {
    viewOnceMessage: {
      message: ${penis}
    }
  }, {})
}

handler.help = ["c${text}"]
handler.tags = ['copy']
handler.command = ["${text}"]
handler.owner = true

module.exports = handler
`;
                } else {
                    result = `

let handler = async (m, { Alice, prefix, reply }) => {
  Alice.relayMessage(m.chat, ${penis}, {})
}

handler.help = ['c${text}']
handler.tags = ['copy']
handler.command = ["${text}"]
handler.owner = true

module.exports = handler
`
}
                function convertToNumbers(message) {
                    if (message?.buttonsMessage) {
                        message.buttonsMessage.headerType = HeaderType[message.buttonsMessage.headerType] || HeaderType.UNKNOWN;
                        if (message.buttonsMessage.buttons) {
                            message.buttonsMessage.buttons = message.buttonsMessage.buttons.map(button => {
                                button.type = ButtonType[button.type] || ButtonType.RESPONSE;
                                return button;
                            });
                        }
                    }
                    return message;
                }
      
                const message = JSON.parse(penis);
                const convertedMessage = convertToNumbers(message);
                let updatedPenis = JSON.stringify({ [quotedType]: convertedMessage[quotedType] }, null, 2);
                
                if (!fs.existsSync('./AlicePlugins')) {
                    fs.mkdirSync('./AlicePlugins');
                }
                
                fs.writeFileSync(`./AlicePlugins/${fullFileName}`, result.trim().replace(penis, updatedPenis));
                reply(`file ${fullFileName} successfully created in plugins folder`);
            }
            break;

            case "reactch": { 
await XReaction();
                if (!text) return reply(`${prefix + command} < ch url > 😂😂😂😂\n`);
                const match = text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
                if (!match) return reply("URL tidak valid. Silakan periksa kembali.");
                const channelId = match[1];
                const chatId = match[2];
                if (!chatId) return reply("ID chat tidak ditemukan dalam link yang diberikan.");
                Alice.newsletterMetadata("invite", channelId).then(data => {
                    if (!data) return reply("Newsletter tidak ditemukan atau terjadi kesalahan.");
                    Alice.newsletterReactMessage(data.id, chatId, text.split(" ").slice(1).join(" ") || "😀");
                });
                reply(`sukses mengirimkan custom reaction ke channel tersebut`)
            }
            break;

			case 'getinfogc':
            case 'cekidgc':
			case 'getinfogrup': {
  
    await XReaction()

    // Jika user memberikan link GC
    if (text && text.includes("chat.whatsapp.com")) {
        let url = text.trim()
        let code = url.split("chat.whatsapp.com/")[1].split(/[? ]/)[0].trim()

        try {
            let info = await Alice.groupGetInviteInfo(code)

            let teks = `*ID Group:* ${info.id}\n*Nama:* ${info.subject}`

            let button = [
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Copy ID Group",
                        id: info.id,
                        copy_code: info.id
                    })
                }
            ]

            await Alice.sendInteractive(m.chat, button, null, packname, teks, m)
        } catch (e) {
            return reply("❌ Link undangan tidak valid atau expired.")
        }

        return
    }

    // Jika tidak memakai link → ambil ID group dari chat sekarang
    if (!m.isGroup) return reply("❌ Hanya bisa dipakai dalam grup atau pakai link GC.")

    let idgc = m.chat

    let teks = `*ID Group:* ${idgc}`

    let button = [
        {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "Copy ID Group",
                id: idgc,
                copy_code: idgc
            })
        }
    ]

    await Alice.sendInteractive(m.chat, button, null, packname, teks, m)
}
break
			case 'inspect':
            case 'cekidch':
			case 'getch':
			case 'getinfoch':
			case 'getchid': {
await XReaction();
				if (!text) return reply(`${prefix + command} Url Channel WhatsApp`)
				if (!isUrl(args[0]) && !args[0].includes('whatsapp.com/channel')) return reply('tidak valid')

				function formatDate(timestamp) {
					const date = new Date(timestamp * 1000);
					const months = [
						'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
						'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
					];
					const day = date.getDate();
					const month = months[date.getMonth()];
					const year = date.getFullYear();
					return `${day} ${month} ${year}`;
				}
				try {
					let result = args[0].split('https://whatsapp.com/channel/')[1]
					let data = await Alice.newsletterMetadata("invite", result)
					let teks = `
* name: ${data.name}
* ID: ${data.id}
* status: ${data.state}
* dibuat Pada: ${formatDate(data.creation_time)}
* subscribers: ${data.subscribers}
* meta Verify: ${data.verification}
* react emoji: ${data.reaction_codes}
* description: ${data.description}`
					let button = [
                        {
                            name: "cta_copy",
					        buttonParamsJson: JSON.stringify({
                                display_text: "ID Channelnya",
                                id: `${data.id}`,
                                copy_code: `${data.id}`
                            })
					    }
                    ]
					Alice.sendInteractive(m.chat, button, null, packname, teks, xy)
				} catch (error) {
					XRR()
				}
			}
			break

case 'ccgen': {
  let [type, jumlah] = args;
  if (!type || !jumlah) return reply(
    `Contoh:\n${prefix}ccgen Visa 5\n\nTipe:\n- Visa\n- MasterCard\n- American Express\n- JCB\n\nJumlah: 5 - 20`
  );

  let allowed = ['Visa', 'MasterCard', 'American Express', 'JCB'];
  if (!allowed.includes(type)) return reply(`Tipe tidak valid:\n${allowed.join('\n')}`);

  let num = parseInt(jumlah);
  if (isNaN(num)) return reply('Jumlah harus angka');
  if (num < 5 || num > 20) return reply('Jumlah kartu harus 5-20');

  try {
    let { data } = await axios.get(`https://backend.lambdatest.com/api/dev-tools/credit-card-generator?type=${encodeURIComponent(type)}&no-of-cards=${num}`);
    if (!Array.isArray(data) || !data.length) return reply('Gagal dapat data');

    let teks = `*Generated ${type} Credit Cards (${num}) :*\n\n` + data.map((v, i) =>
      `*${i + 1}.* ${v.name}\n• Number : ${v.number}\n• CVV : ${v.cvv}\n• Expired : ${v.expiry}\n`
    ).join('\n');

    reply(teks.trim());
  } catch (e) {
    console.error(e);
    reply('Error, coba lagi nanti');
  }
}
break
case 'py':
case 'python': {
  if (!q) return reply(`Masukkan input`);
  if (q.length > 600) return reply(`Maksimal 600 Karakter`);

  try {
    const result = await Python(q);
    if (!result) {
      return reply("invalid server");
    }
    await reply(`${packname}\n\n${result}`);
  } catch (error) {
    console.error("Error :", error.message);
    reply("invalid server");
  }
}
break

case 'js':
case 'javascript': {
  if (!q) return reply(`Masukkan input`);
  if (q.length > 600) return reply(`Maksimal 600 Karakter`);

  try {
    const result = await JavaScript(q);
    if (!result) {
      return reply("invalid server");
    }
    await reply(`${packname}\n\n${result}`);
  } catch (error) {
    console.error("Error :", error.message);
    reply("invalid server");
  }
}
break

case 'html': {
  if (!q) return reply(`Masukkan input`);

  try {
    const result = await Html(q);
    if (!result) {
      return reply("invalid server");
    }
    await reply(`${result}`);
  } catch (error) {
    console.error("Error :", error.message);
    reply("invalid server");
  }
}
break

case 'topcmd': {
await XReaction();  
  let data = Object.entries(global.topcmd)
      .sort((a, b) => b[1] - a[1]) // Urutkan Dari Yang Paling Banyak Dipakai
      .slice(0, 10) // Ambil 10 Teratas
      .map(([cmd, count], index) => `${index + 1}. *${cmd} - ${count}x*`)
      .join('\n');

  if (!data) data = "Tidak Ada Data";

  let teks = `Fitur Paling Sering Digunakan\n\n${data}`;
  Alice.sendMessage(m.chat, { text: teks }, { quoted: m });
}
break

case 'resize': {
await XReaction();
  if (!args[0]) return reply(`Contoh ${prefix + command} 300x300\nPanjangxlebar`)
  
  let panjang = q.split('x')[0]
  let lebar = q.split('x')[1]
  
  let media = await Alice.downloadAndSaveMediaMessage(quoted);
  let ran = getRandom('.jpeg')

  const command = `ffmpeg -i ${media} -vf scale=${panjang}:${lebar} ${ran}`
  
  exec(command, async (err) => {
    fs.unlinkSync(media)

    try {
      let buffer453 = fs.readFileSync(ran)
      await Alice.sendMessage(
        m.chat, 
        {
          mimetype: 'image/jpeg',
          image: buffer453
        }, 
        { quoted: m }
      );
    } catch (readError) {
      return reply('Terjadi kesalahan: '+readError)
    } finally {
      fs.unlinkSync(ran)
    }
  })
}
break

case 'diffusion':{
await XReaction();
if (!text) return reply('Apa yang ingin kamu buat?')
await Alice.sendMessage(m.chat, { react: { text: "🔎",key: m.key,}}) 
    try {
 Alice.sendMessage(m.chat, { image: { url: `https://imgen.duck.mom/prompt/${encodeURIComponent(text)}`}, caption: `_Sukses Membuat ${prefix + command} Dengan Promt:\n${text}_`}, { quoted: m})
    } catch (error) {
reply('eror')
    }
}
break

case 'delete': case 'del': case 'd':{
await XReaction();
if (!isAdmins) return XRA()
            	 let key = {}
             try {
               	key.remoteJid = m.quoted ? m.quoted.fakeObj.key.remoteJid : m.key.remoteJid
            	key.fromMe = m.quoted ? m.quoted.fakeObj.key.fromMe : m.key.fromMe
            	key.id = m.quoted ? m.quoted.fakeObj.key.id : m.key.id
             	key.participant = m.quoted ? m.quoted.fakeObj.participant : m.key.participant
         } catch (e) {
 	console.error(e)
 }
 Alice.sendMessage(m.chat, { delete: key })
}
break

case 'get': {
await XReaction();
  if (!/^https?:\/\//.test(text))
  return reply("Awali *URL* dengan http:// atau https://");
  const ajg = await fetch(text);
  if (ajg.headers.get("content-length") > 100 * 1024 * 1024 * 1024) {
    throw `Content-Length: ${ajg.headers.get("content-length")}`;
  }
  const contentType = ajg.headers.get("content-type");
  if (contentType.startsWith("image/")) {
    return Alice.sendMessage(m.chat, { image: { url: text } });
  }
  if (contentType.startsWith("video/")) {
    return Alice.sendMessage(m.chat, { video: { url: text } });
  }
  if (contentType.startsWith("audio/")) {
    return Alice.sendMessage(m.chat, { audio: { url: text }, mimetype: "audio/mpeg"  });
  }
  let alak = await ajg.buffer();
  try {
    alak = util.format(JSON.parse(alak + ""));
  } catch (e) {
    alak = alak + "";
  } finally {
    reply(alak.slice(0, 65536));
  }
}
break
case "kalkulator":{
await XReaction();
if (text.split("+")[0] && text.split("+")[1]) {
const nilai_one = Number(text.split("+")[0])
const nilai_two = Number(text.split("+")[1])
reply(`${nilai_one + nilai_two}`)
} else if (text.split("-")[0] && text.split("-")[1]) {
const nilai_one = Number(text.split("-")[0])
const nilai_two = Number(text.split("-")[1])
reply(`${nilai_one - nilai_two}`)
} else if (text.split("×")[0] && text.split("×")[1]) {
const nilai_one = Number(text.split("×")[0])
const nilai_two = Number(text.split("×")[1])
reply(`${nilai_one * nilai_two}`)
} else if (text.split("÷")[0] && text.split("÷")[1]) {
const nilai_one = Number(text.split("÷")[0])
const nilai_two = Number(text.split("÷")[1])
reply(`${nilai_one / nilai_two}`)
} else reply(`*Example* : ${prefix + command} 1 + 1`)
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Tools Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Downloader Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'playvid':
case 'playvideo': {
  await XReaction()

  try {
    if (!text) return reply(`Gunakan contoh: ${prefix + command} serana`)

    let api = 'https://api-faa.my.id/faa/ytplayvid?q=' + encodeURIComponent(text)

    let res = await fetch(api)
    let json = await res.json()

    if (!json || !json.status || !json.result) throw Error('gagal ambil data')

    let d = json.result
    if (!d.download_url) throw Error('link download tidak ada')

    let title = (d.searched_title || 'YTMP4').split('|||')[0]
    let url = d.searched_url

    await Alice.sendMessage(m.chat, {
      text: `🎬 *${title}*\n\n📥 Sedang mengirim video...`
    }, { quoted: m })

    await Alice.sendMessage(m.chat, {
      video: { url: d.download_url },
      mimetype: "video/mp4",
      fileName: `${title}.mp4`,
      caption: `🎬 *${title}*\n🔗 ${url}`,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: "YouTube Video",
          mediaUrl: url,
          mediaType: 2,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

  } catch (error) {
    console.error('PLAYVID ERROR:', error)
    reply(`Error: ${error.message || error}`)
  }
}
break
case 'douyindl': {
await XReaction();

    const url = args[0];
    if (!url || !/^https:\/\/v\.douyin\.com\/|^https:\/\/www\.douyin\.com\//.test(url)) {
        return reply(`Format: ${prefix + command} [link douyin]\nContoh: ${prefix + command} https://v.douyin.com/example`);
    }

    try {
        const result = await douyindl(url);

        if (!result.length) {
            return reply('Tidak ada video ditemukan dari link tersebut.');
        }

        for (const vid of result) {
            const video = vid.downloadLinks.find(dl => dl.url && dl.url.endsWith('.mp4'));
            if (!video) continue;

            let teks = `*📥 Douyin Downloader*\n\n`;
            teks += `*📌 Judul:* ${vid.title || '-'}\n`;
            teks += `*⏱️ Durasi:* ${vid.duration || '-'}\n`;

            await Alice.sendMessage(m.chat, {
                video: { url: video.url },
                caption: teks.trim()
            }, { quoted: m });
        }

    } catch (err) {
        reply('Terjadi kesalahan saat mengambil data: ' + (err.message || err));
    }
}
break;
case 'soundcloud-download': {
await XReaction();
  if (!text) return reply(`Ex? ${prefix + command} https://soundcloud.com/xxxxxxx/xxxx/xxx`);
 
  try {
 
    const res = await fetch(`https://zenz.biz.id/downloader/SoundCloud?url=${encodeURIComponent(text)}`);
    const json = await res.json();
 
    if (!json.status || !json.audio_url) {
      return reply('pastiin url SoundCloud lu bener ya dek');
    }
 
    const caption = `
🎵 *Judul:* ${json.title}
👤 *Author:* ${json.author}
🕒 *Durasi:* ${json.duration}
🔗 *Source:* ${json.source_url}
`.trim();
 
    await Alice.sendMessage(m.chat, {
      audio: { url: json.audio_url },
      mimetype: 'audio/mpeg',
      ptt: false,
      fileName: `${json.title}.mp3`,
      contextInfo: {
        externalAdreply: {
          title: json.title,
          body: `Author: ${json.author}`,
          thumbnailUrl: json.thumbnail,
          mediaType: 2,
          mediaUrl: json.source_url,
          sourceUrl: json.source_url,
          renderLargerThumbnail: true,
        },
      },
    }, { quoted: m });
 
    await reply(caption);
 
  } catch (err) {
    console.error(err);
    reply('eror nih bre.');
  }
};
break
case "spotify-download": 
case "spdown":
case "spotifydown": 
case "spotifydl": {
await XReaction();

    if (!text) {
        return reply(`Example: ${prefix + command} https://open.spotify.com/track/xxxxx`);
    }

    try {

        const res = await SpotifyDl(text)

        if (!res.status) {
            return reply(`❌ ${res.message}`)
        }

        const data = res.result

        const caption = `*🎶 SPOTIFY DOWNLOADER*\n\n` +
        `◦ *Judul* : ${data.title}\n` +
        `◦ *Artis* : ${data.artist.map(v => v.name).join(' & ')}\n` +
        `◦ *Status* : ✅ Berhasil`

        const thumb = data.album?.images?.[0]?.url

        if (thumb) {
            await Alice.sendMessage(m.chat, {
                image: { url: thumb },
                caption
            }, { quoted: m })
        } else {
            await Alice.sendMessage(m.chat, {
                text: caption
            }, { quoted: m })
        }

        const safeName = data.title.replace(/[\\/:*?"<>|]/g, "")

        await Alice.sendMessage(m.chat, {
            audio: { url: data.download },
            mimetype: 'audio/mpeg',
            fileName: `${safeName}.mp3`
        }, { quoted: m })

    } catch (err) {
        console.error(err)
        reply(`❌ Error: ${err.message || err}`)
    }
}
break;
case 'twitter':
case 'twitterdl':
case 'x':
case 'xdl': {
await XReaction()

if (!text) {
  return reply(`• *Example :* ${prefix + command} https://x.com/xxxx`)
}

if (!text.includes('x.com') && !text.includes('twitter.com')) {
  return reply('• Link Twitter/X tidak valid.')
}

try {
  const res = await twitterDl(text)

  if (res.error) {
    return reply(res.message || 'Gagal mengambil media.')
  }

  if (!res.videos || res.videos.length < 1) {
    return reply('Media video tidak ditemukan.')
  }

  const videoUrl = res.videos[0].url

  await Alice.sendMessage(
    m.chat,
    {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      caption:
`*Twitter/X Downloader*

• Durasi: ${res.metadata.duration}
• Resolusi: ${res.videos[0].resolution || 'Unknown'}`
    },
    { quoted: m }
  )

} catch (err) {
  console.log(err)
  reply('Terjadi kesalahan saat mengambil media.')
}
}
break
case 'resepdownload': {
await XReaction();
  try {
    if (!text) return reply(`Please provide a Cookpad recipe URL!\n\nExample: ${prefix + command} https://cookpad.com/id/resep/1234567`);

async function getRecipeDetails(url) {
  let { data } = await axios.get(url);
  let $ = cheerio.load(data);

  let cookingTime = $(".recipe-show__meta-container .icon_with_text .recipe-show__time").text().trim();
  let ingredients = [];
  let steps = [];

  $(".ingredient").each((i, el) => {
    ingredients.push($(el).text().trim());
  });

  $(".step").each((i, el) => {
    steps.push($(el).text().trim());
  });

  return { cookingTime, ingredients, steps };
}

    const detail = await getRecipeDetails(text);

    if (!detail) {
      return reply('No details found for the given URL.');
    }

    let message = `
🍽️ *Recipe Details!* 🍽️
- ⏲️ Cooking Time: ${detail.cookingTime}
- 📝 Ingredients: ${detail.ingredients.join(', ')}
- 📖 Steps: ${detail.steps.join('\n')}
- 🔗 [View Recipe](${text})
    `;

    await Alice.sendMessage(m.chat, { text: message, footer: packname }, { quoted: m });
  } catch (error) {
    console.error(error);
    return reply("An error occurred: " + error.message);
  }
};
break

    case "nontonanime-detail": {
await XReaction();
        if (!args[0]) return reply("Masukkan URL anime!");
        const detail = await nontonAnime.details(args[0]);
        if (!detail) return reply("Gagal mengambil detail anime.");
        await Alice.sendMessage(m.chat, {
          image: { url: detail.thumbnail },
          caption: `*${detail.title}*\n\n${detail.synopsis}\n\nStatus: ${detail.status}\nStudio: ${detail.studio}\nSeason: ${detail.season}\nTipe: ${detail.type}`
        }, { quoted: m });
      }
      break;
      
    case "nontonanime-download": {
await XReaction();
        if (!args[0]) return reply("Masukkan link episode!");
        const links = await nontonAnime.download(args[0]);
        if (!links.length) return reply("Link download tidak ditemukan.");
        await Alice.sendMessage(m.chat, {
          text: `*Link Download:*\n\n${links.join("\n\n")}`,
        }, { quoted: m });
      }
      break;
            
      case "shortlink-dl": {
await XReaction();    
          if (!text) return reply(`Example: ${prefix + command} https://xyroorinzi.net`);
          if (!isUrl(text)) return reply(`Example: ${prefix + command} https://xyroorinzi.net`);
          var a = await fetch(
            `https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`
          );
          await Alice.sendMessage(m.chat, { text: a.url }, { quoted: m });
        }
        break;

case 'fb':
case 'fbdl':
case 'facebook': {
  await XReaction()

  if (m.isGroup && global.autodonlod) {
    return reply(`Autodownload sedang dinyalakan, mohon kirim link saja tanpa command ${prefix + command}`)
  }

  if (!text) return reply('url facebook?')

  if (!/^https?:\/\/(www\.)?(facebook|fb)\.com\/.+/i.test(text)) {
    return reply('Format URL Facebook tidak valid.')
  }

  try {

    let res = await fetchJson(
      `https://api.skyzopedia.web.id/download/facebook?apikey=skyy&url=${encodeURIComponent(text)}`
    )

    if (!res.status || !res.result) {
      return reply('Gagal mengambil video Facebook.')
    }

    let data = res.result

    let videoUrl = data.video?.[0]?.url || data.media

    if (!videoUrl) {
      return reply('Link video tidak ditemukan.')
    }

    await Alice.sendMessage(
      m.chat,
      {
        video: { url: videoUrl },
        caption: `*FACEBOOK DOWNLOADER*\n\n*Title:* ${data.title}\n*Duration:* ${data.duration}\n*Quality:* ${data.video?.[0]?.quality || 'HD'}`,
        mimetype: 'video/mp4'
      },
      { quoted: m }
    )

  } catch (e) {
    console.log(e)
    reply('Terjadi kesalahan saat mengambil video Facebook.')
  }
}
break;

case 'samehadakudl': {
await XReaction();
    if (!text) return reply('Link?..');
    
    let cari = await (await fetch(`https://api.siputzx.my.id/api/anime/samehadaku/download?url=${text}`)).json();
    
    if (cari.status) {
        let title = cari.data.title;
        let cap = `*_PILIH LINK ALTERNATIF untuk ${title}*_` + '\n\n';
        
        for (let ciroo of cari.data.downloads) {
            cap += `*🏷️ ALTERNATIF ${ciroo.nume} :* ${ciroo.name}\n*🔗 LINK UNDUH :* ${ciroo.link || 'Tidak tersedia'}\n\n`;
        }
        
        await reply(cap);
    } else {
        await reply('Data tidak ditemukan.');
    }
}
break;

case 'apkdl': 
case 'apkdownload': {
await XReaction();
    if (!text) return reply('link dari apksearch');
    
    try {
        let response = await fetch(`https://api-alice.vercel.app/api/apk?action=download&url=` + text);
        let apk = await response.json();

        if (apk.status === 200 && apk.data.status === 200) {
            let app = apk.data.data;
            Alice.sendMessage(m.chat, {
                document: {
                    url: app.url
                },
                fileName: app.package + '.apk',
                mimetype: 'application/xapk',
                contextInfo: {
                    externalAdreply: {
                        title: app.title,
                        body: `${botname}`,
                        thumbnailUrl: app.img || '',
                        mediaType: 1,
                        showAdAttribution: true,
                        renderLargerThumbnail: false,
                    },
                },
            }, { quoted: m });
        } else {
            reply('ada masalah');
        }
    } catch (e) {
        reply('ada masalah');
    }
}
break;
case 'git':
case 'gitclone': {
  try {
    if (!args[0]) return reply(`Contoh: ${prefix + command} linknya`)
    if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Harus berupa link github!`)
    let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    var [, userr, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    var url = `https://api.github.com/repos/${userr}/${repo}/zipball`
    let filename = (await fetch(url, {
      method: 'HEAD'
    })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    Alice.sendMessage(m.chat, {
      document: {
        url: url
      },
      fileName: filename + '.zip',
      mimetype: 'application/zip'
    }, {
      quoted: m
    })
  } catch (err) {
    reply('Terjadi kesalahan')
  }
}
break

case 'pindl': {
await XReaction()

if (!text)
  return reply(`Example:\n${prefix + command} https://pin.it/example`)

if (!/pinterest\.com|pin\.it/i.test(text))
  return reply('URL bukan link Pinterest.')

try {
  const res = await PinDL(text)

  if (!res.success || !res.data.length)
    return reply('Gagal mengambil media.')

  const mediaUrl = res.data[0].url

  const media = await axios.get(mediaUrl, {
    responseType: 'arraybuffer'
  })

  const buffer = Buffer.from(media.data)
  const type = media.headers['content-type']

  if (type.includes('image')) {

    await Alice.sendMessage(
      m.chat,
      {
        image: buffer,
        mimetype: type,
        caption:
`✅ Pinterest Image Downloaded

• Author: ${res.metadata.author}`
      },
      { quoted: m }
    )

  } else if (type.includes('video')) {

    await Alice.sendMessage(
      m.chat,
      {
        video: buffer,
        mimetype: type,
        caption:
`✅ Pinterest Video Downloaded

• Author: ${res.metadata.author}`
      },
      { quoted: m }
    )

  } else {

    await Alice.sendMessage(
      m.chat,
      {
        document: buffer,
        mimetype: type,
        fileName: 'pinterest_media.mp4'
      },
      { quoted: m }
    )

  }

} catch (e) {
  console.log(e)
  reply('Error saat scrape Pinterest.')
}
}
break

case 'cocofun':{
await XReaction();
if (!text) return reply(`Example: ${prefix + command} https://www.icocofun.com/share/post/565326210234?lang=id&pkg=id&share_to=copy_link&m=06fa9a57a737be2bee99bea6bcdb20ee&d=7a1c5048f54ef09b7c0fa0f3c463692949f35fa30d93fc1130f6e8153f537b51&nt=1`)
await XReaction()
let old = new Date()
let asy = await chApi.cocofun(text)
let caption = `乂  *C O C O F U N*\n\n`
caption += `	◦  *Topic* : ${asy.topic}\n`
caption += `	◦  *Caption* : ${asy.caption}\n`
caption += `	◦  *Play* : ${asy.play}\n`
caption += `	◦  *Like* : ${asy.like}\n`
caption += `	◦  *Share* : ${asy.share}\n`
caption += `	◦  *Duration* : ${asy.duration}\n\n`
caption += `	◦  *Fetching* : ${((new Date - old) * 1)} ms\n\n` 
Alice.sendMessage(m.chat, { video: { url: asy.no_watermark }, caption: caption }, { quoted: m })
}
break

case 'sf': case 'sfile': case 'sfiledl': case 'sfdl': {
await XReaction();
if (!text.includes('https://sfile.mobi')) return reply(`• *Example :* ${prefix + command} https://sfile.mobi/xxxxxxx/`)

await XReaction()
const sfile = {
    latest_uploads: async function(page = 1) {
        try {
            const res = await axios.get('https://sfile.mobi');
            const cookies = res.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
            const headers = {
                'cookie': cookies,
                'referer': 'https://sfile.mobi/uploads.php',
                'user-agent': 'Postify/1.0.0'
            };
            const uploads = await axios.get(`https://sfile.mobi/uploads.php?page=${page}`, { headers });
            const $ = cheerio.load(uploads.data);

            const data = $('.list').map((_, el) => ({
                title: $(el).find('a').text().trim(),
                link: $(el).find('a').attr('href'),
                size: $(el).find('small').text().match(/(\d+(?:\.\d+)?\s[KMGT]B)/)?.[1],
                uploadDate: $(el).find('small').text().match(/Uploaded:\s([\d\-a-zA-Z]+)/)?.[1]
            })).get().filter(item => item.title && item.link && item.size && item.uploadDate);

            return { creator: `${ownername}`, status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: 'An error occurred while fetching the latest updates.' };
        }
    },

    top_trending: async function(page = 1) {
        try {
            const response = await axios.get('https://sfile.mobi');
            const cookies = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
            const headers = {
                'authority': 'sfile.mobi',
                'accept': 'application/json, text/html, application/xhtml+xml, application/xml;q=0.9, image/avif, image/webp, image/apng, */*;q=0.8, application/signed-exchange;v=b3;q=0.7',
                'cookie': cookies,
                'referer': `https://sfile.mobi/top.php?page=${page}`,
                'user-agent': 'Postify/1.0.0'
            };
            const top = await axios.get(`https://sfile.mobi/top.php?page=${page}`, { headers });
            const $ = cheerio.load(top.data);

            const data = $('.list').map((_, el) => {
                const title = $(el).find('a').text().trim();
                const link = $(el).find('a').attr('href');
                const [size, downloadInfo] = $(el).find('small').text().split(', Download: ').map(e => e.trim());
                const [downloadCount, uploadedDate] = downloadInfo ? downloadInfo.split(' Uploaded: ').map(e => e.trim()) : [undefined, undefined];

                return title && link && size && downloadCount && uploadedDate ? 
                    { title, link, size, downloadCount, uploadDate: uploadedDate } : null;
            }).get().filter(item => item);

            return { creator: `${ownername}`, status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: 'An error occurred while fetching the top trending files.' };
        }
    },
    
    search: async function(query, page = 1) {
        try {
            const url = `https://sfile.mobi/search.php?q=${query}&page=${page}`;
            const response = await axios.get(url, {
                headers: {
                    'authority': 'sfile.mobi',
                    'accept': 'application/json, text/html, application/xhtml+xml, application/xml;q=0.9,*/*;q=0.8',
                    'referer': url,
                    'user-agent': 'Postify/1.0.0'
                }
            });

            const $ = cheerio.load(response.data);
            
            const data = $('.list').map((_, el) => {
                const title = $(el).find('a').text().trim();
                const link = $(el).find('a').attr('href');
                const sizeMatch = $(el).text().match(/\(([^)]+)\)$/);
                const size = sizeMatch ? sizeMatch[1] : undefined;
                return title ? { title, link, size } : null;
            }).get();

            return { creator: `${ownername}`, status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: 'An error occurred while fetching search results.' };
        }
    },
    
    download: async function(url) {
        const headers = {
            'referer': url,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-Agent': 'Postify/1.0.0',
        };

        try {
            const response = await axios.get(url, { headers });
            headers.Cookie = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');

            const [filename, mimetype, downloadLink] = [
                response.data.match(/<h1 class="intro">(.*?)<\/h1>/s)?.[1] || '',
                response.data.match(/<div class="list">.*? - (.*?)<\/div>/)?.[1] || '',
                response.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1]
            ];
            
            if (!downloadLink) return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: 'Download link tidak ditemukan!' };

            headers.Referer = downloadLink;
            const final = await axios.get(downloadLink, { headers });

            const [directLink, key, filesize] = [
                final.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1],
                final.data.match(/&k='\+(.*?)';/)?.[1].replace(`'`, ''),
                final.data.match(/Download File \((.*?)\)/)?.[1]
            ];

            const result = directLink + (key ? `&k=${key}` : '');
            if (!result) return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: 'Direct Link Download tidak ditemukan!' };

            const data = await this.convert(result, url);

            return { creator: `${ownername}`, status: 'success', code: 200, data: { filename, filesize, mimetype, result: data } };
        } catch (error) {
            return { creator: `${ownername}`, status: 'error', code: 500, data: [], message: error.message };
        }
    },

    convert: async function(url, directLink) {
        try {
            const init = await axios.get(url, {
                maxRedirects: 0,
                validateStatus: status => status >= 200 && status < 303,
                headers: {
                    'Referer': directLink,
                    'User-Agent': 'Postify/1.0.0'
                },
            });

            const cookies = init.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
            const redirect = init.headers.location;

            const final_result = await axios.get(redirect, {
                responseType: 'arraybuffer',
                headers: {
                    'referer': directLink,
                    'user-agent': 'Postify/1.0.0',
                    'cookie': cookies,
                },
            });

            const filename = final_result.headers['content-disposition']?.match(/filename=["']?([^"';]+)["']?/)?.[1] || 'Tidak diketahui';
            return {
                filename,
                mimeType: final_result.headers['content-type'],
                buffer: Buffer.from(final_result.data)
            };
        } catch (error) {
            throw error;
        }
    }
};

try {
let hasil = await sfile.download(text)
let { filename, filesize, mimetype } = hasil.data
let sfdl = hasil.data.result
let sfcap = `┏⪻── *[ ᴅ ᴏ ᴡ ɴ ʟ ᴏ ᴀ ᴅ - s ғ ]* ──⪼┓`
sfcap += `〆 ɴᴀᴍᴀ : ${filename}\n`
sfcap += `〆 ᴛʏᴘᴇ : ${mimetype}\n`
sfcap += `〆 ᴅᴇᴛᴀɪʟ : ${filesize}\n`
sfcap += `〆 ᴜʀʟ : ${text}\n`
sfcap += `┗⪻─────────────────────────⪼┛`

await Alice.sendMessage(m.chat, {document: sfdl.buffer, mimetype: sfdl.mimeType, fileName: sfdl.filename, caption: sfcap }, {quoted: m});
} catch (err) {
}}
break

case 'mediafire':
case 'mf':
case 'mfdl': {
await XReaction();
  try {

    const link = args[0]
    const res = await mediafiredl(link)

    const { data } = await axios.get(res.url, { responseType: 'arraybuffer' })
    const { mime } = await Alice.getFile(data)

    const caption = `📁 *MediaFire Downloader*

📄 *Nama File*  
${res.name}

📦 *Ukuran*  
${res.size}

🌍 *Lokasi Server*  
${res.location} (${res.continent})

📌 *Tipe File*  
${mime}

🔗 *Link Asli*  
${res.url}

— ${packname}`

    await Alice.sendMessage(
      m.chat,
      {
        document: data,
        mimetype: mime,
        fileName: res.name,
        caption
      },
      { quoted: m }
    )

  } catch (e) {
    reply(`❌ ${e.message}`)
  }
}
break

case 'capcut':
case 'ccdl': {
await XReaction();
  try {
    if (!text) return reply(`Contoh: ${prefix + command} linknya`)
    if (!text.includes('capcut.com') && !text.includes('capcut.net')) return reply('Harus berupa link capcut!')

    const videoData = await capcutDownloader(text)

    if (videoData.status && videoData.video) {
      // kirim thumbnail dulu (kalau ada)
      if (videoData.thumbnail) {
        await Alice.sendMessage(
          m.chat,
          { image: { url: videoData.thumbnail }, caption: `🎬 ${videoData.title}\n👤 ${videoData.author}` },
          { quoted: m }
        )
      }

      // lalu kirim video
      return await Alice.sendMessage(
        m.chat,
        {
          video: { url: videoData.video },
          caption: `© ${botname}`
        },
        { quoted: m }
      )
    } else {
      return reply(videoData.msg || 'Video tidak ditemukan.')
    }
  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan')
  }
}
break

case 'videy':
case 'videydl': {
await XReaction();
  try {
    if (!text) return reply(`Contoh: ${prefix + command} linknya`)
    let twitter = await fetchJson(`https://vapis.my.id/api/videy?url=${Enc(text)}`)
    Alice.sendMessage(m.chat, {
      video: {
        url: twitter.data
      },
      caption: `${packname}`
    }, {
      quoted: m
    })
  } catch (err) {
    reply(`Terjadi kesalahan`);
  }
}
break

case 'ig':
case 'instagram': {

if (m.isGroup && global.autodonlod) return reply(`Autodownload sedang dinyalakan, mohon untuk mengirim linlnya saja tanpa command ${prefix + command}`)

await XReaction()
if (!text) return reply("Masukkan Linknya ?")

try {
    const result = await igdl(text)
    if (result.error) return reply(result.message || "Gagal mengambil data")

    if (result.photos?.length) {
        for (let photo of result.photos) {
            await Alice.sendMessage(m.chat,{
                image:{url:photo.url},
                caption:`donee\nSize: ${photo.fSize}`
            },{quoted:m})
        }
        return
    }

    if (result.videos?.length) {
        for (let video of result.videos) {
            await Alice.sendMessage(m.chat,{
                video:{url:video.url},
                caption:`donee\nSize: ${video.fSize}`
            },{quoted:m})
        }
        return
    }

    reply("Tidak ada media yang bisa diunduh.")

} catch (e) {
    console.error(e)
    XRR()
}
}
break

case 'tt':
case 'tiktok': {
  if (m.isGroup && global.autodonlod) return reply(`Autodownload sedang dinyalakan, mohon untuk mengirim linknya saja tanpa command ${prefix + command}`)

  await XReaction()
  if (!text) return reply(`Contoh : ${prefix + command} linknya`)

  try {
    let data = await fg.tiktok(text)
    let json = data.result

    let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
    caption += `◦ *Id* : ${json.id}\n`
    caption += `◦ *Username* : ${json.author?.nickname}\n`
    caption += `◦ *Title* : ${json.title}\n`

    if (json.images) {
      for (let img of json.images) {
        await Alice.sendMessage(m.chat, { image: { url: img } }, { quoted: m })
      }
    } else {
      await Alice.sendMessage(m.chat, {
        video: { url: json.play },
        mimetype: 'video/mp4',
        caption,
        footer: 'TikTok Downloader',
        buttons: [
          {
            buttonId: `${prefix}tiktokmp3 ${text}`,
            buttonText: { displayText: '🎵 Audio' },
            type: 1
          }
        ],
        headerType: 4
      }, { quoted: m })
    }

  } catch (e) {
    console.log(e)
    reply(`Error:\n${e}`)
  }
}
break

case 'tiktokmp3':
case 'ttmp3': {
  await XReaction()

  if (!text) return reply(`Contoh:\n${prefix + command} https://tiktok.com/...`)

  try {
    const audioUrl = await tiktokmp3(text)

    await Alice.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m })
  } catch (e) {
    try {
      await Alice.sendMessage(m.chat, {
        audio: { url: text },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m })
    } catch {
      reply('❌ Gagal mengambil audio TikTok')
    }
  }
}
break

case 'aio':
  if (!q) return reply('link Sosmed?')
   try {
    async function fetchInitialPage(initialUrl) {
      try {
        const axios = require('axios')
        const cheerio = require('cheerio')
        const headers = {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36',
          'Referer': initialUrl,
        }
        const response = await axios.get(initialUrl, { headers })
        const $ = cheerio.load(response.data)
        const csrfToken = $('meta[name="csrf-token"]').attr('content')
        if (!csrfToken) throw new Error('Gagal nemu token keamanan, coba lagi!')
        let cookies = ''
        if (response.headers['set-cookie']) {
          cookies = response.headers['set-cookie'].join('; ')
        }
        return { csrfToken, cookies }
      } catch (error) {
        throw new Error(`Gagal ambil halaman awal: ${error.message}`)
      }
    }
    async function postDownloadRequest(downloadUrl, userUrl, csrfToken, cookies) {
      try {
        const axios = require('axios')
        const headers = {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36',
          'Referer': 'https://on4t.com/online-video-downloader',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Accept': '*/*',
          'X-Requested-With': 'XMLHttpRequest',
          'Cookie': cookies
        }
        const postData = new URLSearchParams()
        postData.append('_token', csrfToken)
        postData.append('link[]', userUrl)
        const response = await axios.post(downloadUrl, postData.toString(), { headers })
        if (response.data?.result?.length) {
          return response.data.result.map(item => ({
            title: item.title,
            thumb: item.image,
            url: item.video_file_url || item.videoimg_file_url
          }))
        } else {
          throw new Error('Respons dari server gak sesuai harapan, coba link lain!')
        }
      } catch (error) {
        throw new Error(`Gagal proses permintaan download: ${error.message}`)
      }
    }
    async function sendMediaAutoType(url, title) {
      try {
        const axios = require('axios')
        const { fromBuffer } = require('file-type')   
        const res = await axios.get(url, { responseType: 'arraybuffer' })
        const buff = Buffer.from(res.data)
        const fileInfo = await fromBuffer(buff)
        if (!fileInfo) return reply(`Gagal deteksi tipe file: ${title}`)
        let mime = fileInfo.mime
        let ext = fileInfo.ext
        if (mime.startsWith('video/')) {
          await Alice.sendMessage(m.chat, { video: buff, caption: title }, { quoted: m })
        } else if (mime.startsWith('audio/')) {
          await Alice.sendMessage(m.chat, { audio: buff, mimetype: mime }, { quoted: m })
        } else if (mime.startsWith('image/')) {
          await Alice.sendMessage(m.chat, { image: buff, caption: title }, { quoted: m })
        } else {
          await Alice.sendMessage(m.chat, {
            document: buff,
            fileName: `${title}.${ext}`,
            mimetype: mime
          }, { quoted: m })
        }
      } catch (err) {
        reply(`Gagal kirim media: ${err.message}`)
      }
    }
    const initialUrl = 'https://on4t.com/online-video-downloader'
    const downloadUrl = 'https://on4t.com/all-video-download'
    const { csrfToken, cookies } = await fetchInitialPage(initialUrl)
    const results = await postDownloadRequest(downloadUrl, q, csrfToken, cookies)
    for (let i = 0; i < results.length; i++) {
      await sendMediaAutoType(results[i].url, results[i].title)
    }
    await Alice.sendMessage(m.chat, { react: { text: '💕', key: m.key } })
  } catch (err) {
    await Alice.sendMessage(m.chat, { react: { text: '😳', key: m.key } }) 
    reply(err.message)
  }
  break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Downloader Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\




//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Menfess Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\

case 'anonymous':
case 'anonymouschat': {
await XReaction();
if (!isPc) return XRPC()
  reply(`Hai ${pushname} selamat datang di Anonymous chat!\n\nKetik ${prefix}start untuk memulai sesi chat`)
}
break

case 'start':
case 'mulai': {
await XReaction();
if (!isPc) return XRPC()
  this.anonymous = this.anonymous ? this.anonymous : {}
  if (Object.values(this.anonymous).find(room => room.check(m.sender))) {
    reply(`Kamu masih berada di dalam sesi Anonymous!\n\n${prefix}leave untuk keluar dari sesi chat`)
    return false
  }
  let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
  if (room) {
    Alice.sendMessage(room.a, {
      text: `Berhasil menemukan partner. Sekarang kamu dapat mengirim pesan!\n\n${prefix}skip untuk mencari partner lain\n${prefix}leave untuk menghentikan sesi chat`
    })
    room.b = m.sender
    room.state = 'CHATTING'
    reply(`Berhasil menemukan partner. Sekarang kamu dapat mengirim pesan!\n\n${prefix}skip untuk mencari partner lain\n${prefix}leave untuk menghentikan sesi chat`)
  } else {
    let id = +new Date
    this.anonymous[id] = {
      id,
      a: m.sender,
      b: '',
      state: 'WAITING',
      check: function (who = '') {
        return [this.a, this.b].includes(who)
      },
      other: function (who = '') {
        return who === this.a ? this.b : who === this.b ? this.a : ''
      },
    }
    reply(`Menunggu partner...`)
  }
}
break

case 'leave':
case 'keluar': {
await XReaction();
if (!isPc) return XRPC()
  this.anonymous = this.anonymous ? this.anonymous : {}
  let room = Object.values(this.anonymous).find(room => room.check(m.sender))
  if (!room) {
    reply(`Kamu sedang tidak berada di sesi Anonymous!\n\n${prefix}start untuk memulai sesi chat`)
    return false
  }
  reply('Berhasil keluar dari Anonymous chat!')
  let other = room.other(m.sender)
  if (other) await Alice.sendText(other, `Partner telah meninggalkan sesi Anonymous!`, m)
  delete this.anonymous[room.id]
  if (command === 'leave')
    break
}
break

case 'skip':
case 'next':
case 'lanjut': {
await XReaction();
if (!isPc) return XRPC()
  this.anonymous = this.anonymous ? this.anonymous : {}
  let romeo = Object.values(this.anonymous).find(room => room.check(m.sender))
  if (!romeo) {
    reply(`Kamu sedang tidak berada di sesi Anonymous!\n\n${prefix}start untuk mencari partner`)
    return false
  }
  let other = romeo.other(m.sender)
  if (other) await Alice.sendText(other, `Partner telah meninggalkan sesi Anonymous!`, m)
  delete this.anonymous[romeo.id]
  let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
  if (room) {
    Alice.sendMessage(room.a, {
      text: `Berhasil menemukan partner. Sekarang kamu dapat mengirim pesan!\n\n${prefix}skip untuk mencari partner lain\n${prefix}leave untuk menghentikan sesi chat`
    })
    room.b = m.sender
    room.state = 'CHATTING'
    reply(`Berhasil menemukan partner. Sekarang kamu dapat mengirim pesan!\n\n${prefix}skip untuk mencari partner lain\n${prefix}leave untuk menghentikan sesi chat`)
  } else {
    let id = +new Date
    this.anonymous[id] = {
      id,
      a: m.sender,
      b: '',
      state: 'WAITING',
      check: function (who = '') {
        return [this.a, this.b].includes(who)
      },
      other: function (who = '') {
        return who === this.a ? this.b : who === this.b ? this.a : ''
      },
    }
    reply(`Menunggu partner...`)
  }
}
break

case 'confes':
case 'menfes':
case 'confess':
case 'menfess': {
await XReaction();
    this.menfes = this.menfes ? this.menfes : {}
    const roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
if (m.isGroup) return XRPC()
    if (roof) return reply("Kamu masih berada dalam sesi menfess")
    if (!text) return reply(`Contoh: ${prefix + command} Nama, 628xx, Menfes nih\n`)
    if (!text.includes(',')) return reply(`Contoh: ${prefix + command} Nama, 628xxx, Menfes nih\n`)

    const parts = text.split(',').map(item => item.trim());
    if (parts.length < 3) return reply(`Format salah! Contoh: ${prefix + command} Nama, 628xx, Menfes nih\n`);
    
    const [namaNya, nomorNyaRaw, pesanNya] = parts;
    let nomorNya = nomorNyaRaw.startsWith('0') ? '62' + nomorNyaRaw.slice(1) : nomorNyaRaw;
    
    if (isNaN(nomorNya)) return reply(`Nomor tidak valid! Contoh: ${prefix + command} Nama, 628xx, Menfes nih\n`);
    
    const yoi = `Dari: ${namaNya}\nPesan: ${pesanNya}\n\nKlik *Terima* untuk menerima menfess\nKlik *Tolak* untuk menolak menfess`;
    const id = m.sender;
    
    this.menfes[id] = {
        id,
        a: m.sender,
        b: `${nomorNya}@s.whatsapp.net`,
        state: 'WAITING'
    };
    
    try {
        await Alice.sendMessage(`${nomorNya}@s.whatsapp.net`, {
            text: yoi,
            footer: ownername,
            buttons: [
                {
                    buttonId: '.balasmenfes',
                    buttonText: { displayText: 'Terima' },
                    type: 1
                },
                {
                    buttonId: '.tolakmenfes',
                    buttonText: { displayText: 'Tolak' },
                    type: 1
                }
            ],
            headerType: 1,
            viewOnce: true
        })
        reply('Pesan berhasil dikirim ke nomor tujuan. Semoga dibales ya')
    } catch (error) {
        console.error(error)
        reply('Pesan gagal dikirim. Periksa kembali nomor tujuan.')
    }
}
break

case 'balasconfes':
case 'balasmenfes':
case 'balasconfess':
case 'balasmenfess': {
await XReaction();
    roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
    if (!roof) return reply("Belum ada sesi menfess")
    find = Object.values(this.menfes).find(menpes => menpes.state == 'WAITING')
    let room = Object.values(this.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING')
    let other = [room, room.b].find(user => user !== m.sender)
    find.b = m.sender
    find.state = 'CHATTING'
    this.menfes[find.id] = {
        ...find
    }
    await Alice.sendMessage(other, {
        text: `_@${m.sender.split("@")[0]} telah menerima menfess kamu, sekarang kamu bisa chat lewat bot ini_\n\n*NOTE:*\nJika ingin berhenti dari menfess, silahkan ketik .stopmenfess`,
        mentions: [m.sender]
    })
    Alice.sendMessage(m.chat, {
        text: `_Menfess telah diterima, sekarang kamu bisa chatan lewat bot ini_\n\n*NOTE:*\nJika ingin berhenti dari menfess, silahkan ketik .stopmenfess`
    })
}
break

case 'tolakconfes':
case 'tolakmenfes':
case 'tolakconfess':
case 'tolakmenfess': {
await XReaction();
    roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
    if (!roof) return reply("Belum ada sesi menfess")
    let room = Object.values(this.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING')
    let other = [room.a, room.b].find(user => user !== m.sender)
    find = Object.values(this.menfes).find(menpes => menpes.state == 'WAITING')
    Alice.sendMessage(other, {
        text: `_Uppsss... @${m.sender.split("@")[0]} Menolak menfess kamu_`,
        mentions: [m.sender]
    })
    reply("Menfess berhasil di tolak")
    delete this.menfes[roof.id]
}
break

case 'stopconfes':
case 'stopmenfes':
case 'stopconfess':
case 'stopmenfess': {
await XReaction();
    find = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
    if (!find) return reply("Belum ada sesi menfess")
    const to = find.a == m.sender ? find.b : find.a
    Alice.sendMessage(to, {
        text: `Teman chat telah menghentikan menfess ini`,
        mentions: [m.sender]
    })
    reply("Menfess berhasil di stop")
    delete this.menfes[find.id]
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Menfess Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Panel Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case "cadp": case "createadp": {
  try {
    if (!isOwner) return reply('❌ Fitur khusus Owner.')
    if (!args[0]) return reply(`Masukkan Username!\nContoh: ${prefix + command} xyroo [email-opsional]`)

    let username = args[0].toLowerCase()
    let email = (args[1] && args[1].includes('@')) ? args[1] : `${username}@gmail.com`
    let firstName = capital(username)
    let lastName = "Admin"
    let password = username + crypto.randomBytes(2).toString('hex')

    // Create ADMIN user (root_admin: true)
    let f = await fetch(domain + "/api/application/users", {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikeyplta
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: firstName,
        last_name: lastName,
        language: "en",
        password: password.toString(),
        root_admin: true
      })
    })

    let data = await f.json()
    if (data.errors) return reply("❌ Gagal membuat admin:\n" + JSON.stringify(data.errors[0], null, 2))

    let user = data.attributes
    let teks = `✅ Admin Panel Berhasil Dibuat

Role: Root Admin
User: ${user.username}
Email: ${user.email}
Password: ${password.toString()}
Login: ${global.domain || '—'}

Tips Keamanan:
• Segera login dan ganti password.
• Aktifkan 2FA di menu Security.
• Jangan bagikan kredensial ke siapapun.

© ${packname || 'Admin Panel'}`

    // Pesan interaktif
    let msgii = generateWAMessageFromContent(m.sender, { // ⬅ kirim langsung ke user (private chat)
      viewOnceMessage: { message: { 
        "messageContextInfo": { 
          "deviceListMetadata": {}, 
          "deviceListMetadataVersion": 2
        }, 
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: { 
            mentionedJid: [m.sender], 
            externalAdreply: { showAdAttribution: true }
          },
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          footer: proto.Message.InteractiveMessage.Footer.create({ text: packname }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
            buttons: [
              {
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"Login Admin Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
              },
              {
                "name": "cta_copy",
                "buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"copy_user\",\"copy_code\":\"${user.username}\"}`
              },
              {
                "name": "cta_copy",
                "buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"copy_pass\",\"copy_code\":\"${password.toString()}\"}`
              }
            ]
          })
        })
      }}
    }, { userJid: m.sender, quoted: null })

    // Kirim ke chat pribadi
    await Alice.relayMessage(msgii.key.remoteJid, msgii.message, { messageId: msgii.key.id })

    // Beri info singkat di grup biar jelas
    if (m.isGroup) {
      reply(`✅ Data Admin berhasil dibuat.\n👉 Detail dikirim ke private chat @${m.sender.split('@')[0]}`, { mentions: [m.sender] })
    }

  } catch (e) {
    console.error(e)
    reply('❌ Terjadi kesalahan saat membuat admin.\n' + (e?.message || e))
  }
}
break

case "buatpanel": case "cpanel": {
    if (!isPrem) return XRP()
    if (!args[0]) return reply(`Masukkan Username\n\nContoh: .buatpanel username 6281234567890`)

    // username
    global.panel = [args[0].toLowerCase()]

    // nomor tujuan opsional
    global.nomorPanel = args[1] ? args[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : m.sender

    let teksnya = "Silahkan Pilih Ram Server Panel"
    let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
        "messageContextInfo": { 
            "deviceListMetadata": {}, 
            "deviceListMetadataVersion": 2
        }, 
        interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: { 
                mentionedJid: [m.sender], 
                externalAdreply: { showAdAttribution: true }
            }, 
            body: proto.Message.InteractiveMessage.Body.create({ 
                text: teksnya
            }), 
            footer: proto.Message.InteractiveMessage.Footer.create({ 
                text: packname
            }), 
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                buttons: [{
                    "name": "single_select",
                    "buttonParamsJson": `{ "title": "Pilih Ram Panel", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"⭐\", "rows": [
                        { "header": "Ram 1GB", "title": "Ram 1GB | CPU 40%", "id": ".1gb ${args[0]}" }, 
                        { "header": "Ram 2GB", "title": "Ram 2GB | CPU 60%", "id": ".2gb ${args[0]}" }, 
                        { "header": "Ram 3GB", "title": "Ram 3GB | CPU 80%", "id": ".3gb ${args[0]}" }, 
                        { "header": "Ram 4GB", "title": "Ram 4GB | CPU 100%", "id": ".4gb ${args[0]}" }, 
                        { "header": "Ram 5GB", "title": "Ram 5GB | CPU 120%", "id": ".5gb ${args[0]}" }, 
                        { "header": "Ram 6GB", "title": "Ram 6GB | CPU 140%", "id": ".6gb ${args[0]}" }, 
                        { "header": "Ram 7GB", "title": "Ram 7GB | CPU 160%", "id": ".7gb ${args[0]}" }, 
                        { "header": "Ram 8GB", "title": "Ram 8GB | CPU 180%", "id": ".8gb ${args[0]}" }, 
                        { "header": "Ram 9GB", "title": "Ram 9GB | CPU 200%", "id": ".9gb ${args[0]}" },
                        { "header": "Ram 10GB", "title": "Ram 10GB | CPU 250%", "id": ".10gb ${args[0]}" }, 
                        { "header": "Ram Unlimited", "title": "Ram Unlimited | CPU 0%", "id": ".unli ${args[0]}" }
                    ]}]}`
                }]
            })
        })
    } }}, {userJid: m.sender, quoted: null}) 
    await Alice.relayMessage(msgii.key.remoteJid, msgii.message, { 
        messageId: msgii.key.id 
    })
}
break


case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unli": {
    if (!isPrem) return XRP()
    if (global.panel == null) return reply('Nama/Username Tidak Ditemukan')
    
    var ram, disknya, cpu
    if (command == "1gb") { ram = "1000"; disknya = "1000"; cpu = "40" }
    else if (command == "2gb") { ram = "2000"; disknya = "1000"; cpu = "60" }
    else if (command == "3gb") { ram = "3000"; disknya = "2000"; cpu = "80" }
    else if (command == "4gb") { ram = "4000"; disknya = "2000"; cpu = "100" }
    else if (command == "5gb") { ram = "5000"; disknya = "3000"; cpu = "120" }
    else if (command == "6gb") { ram = "6000"; disknya = "3000"; cpu = "140" }
    else if (command == "7gb") { ram = "7000"; disknya = "4000"; cpu = "160" }
    else if (command == "8gb") { ram = "8000"; disknya = "4000"; cpu = "180" }
    else if (command == "9gb") { ram = "9000"; disknya = "5000"; cpu = "200" }
    else if (command == "10gb") { ram = "10000"; disknya = "5000"; cpu = "220" }
    else { ram = "0"; disknya = "0"; cpu = "0" }

    let username = global.panel[0].toLowerCase()
    let email = username + "@gmail.com"
    let name = capital(username) + " Server"
    let password = username + crypto.randomBytes(2).toString('hex')

    let f = await fetch(domain + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyplta
        },
        "body": JSON.stringify({
            "email": email,
            "username": username.toLowerCase(),
            "first_name": name,
            "last_name": "Server",
            "language": "en",
            "password": password.toString()
        })
    })
    let data = await f.json();
    if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
    let user = data.attributes

    let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyplta
        }
    })
    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup

    let f2 = await fetch(domain + "/api/application/servers", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyplta,
        },
        "body": JSON.stringify({
            "name": name,
            "description": packname,
            "user": user.id,
            "egg": parseInt(egg),
            "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
            "startup": startup_cmd,
            "environment": {
                "INST": "npm",
                "USER_UPLOAD": "0",
                "AUTO_UPDATE": "0",
                "CMD_RUN": "npm start"
            },
            "limits": {
                "memory": ram,
                "swap": 0,
                "disk": disknya,
                "io": 500,
                "cpu": cpu
            },
            "feature_limits": {
                "databases": 5,
                "backups": 5,
                "allocations": 5
            },
            deploy: {
                locations: [parseInt(loc)],
                dedicated_ip: false,
                port_range: [],
            },
        })
    })
    let result = await f2.json()
    if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
    
    let teks = `✅ Succes Create Panel

📌 *Data Akun Panel Kamu:*
👤 User     : ${user.username}
🔑 Password : ${password.toString()}
🌐 Login    : ${global.domain}
🐣 Egg     :  bot whatsapp/nodejs

━━━━━━━━━━━━━━━━━━━━━━
📖 *Keterangan & Pengajaran:*
1. Simpan baik-baik data akun di atas (User & Password). 
   ➝ Admin hanya mengirim 1 kali saja, jika hilang server tidak bisa dikembalikan.
2. Gunakan panel untuk belajar & mengelola project kamu. 
   ➝ Jangan biarkan server idle atau tidak dipakai.
3. Panel ini bergaransi 30 hari full dari pembelian. 
   ➝ Jika ada kendala, sertakan bukti transaksi/transfer saat klaim garansi.
4. Panel yang sudah *lama OFF / tidak digunakan* akan *otomatis dihapus*.
   ➝ Jadi *gunakan servermu secara aktif* agar tidak dianggap tidak terpakai.
5. Dilarang menggunakan panel untuk aktivitas ilegal/terlarang. 
   ➝ Jika terdeteksi, server akan langsung dihapus tanpa peringatan.
6. Jangan menjalankan script ddos tools
   ➝ Bikin panel delay, dan servermu akan dihapus
7. Jangan menyebarluaskan domain
   ➝ Rawan di ddos/serang

━━━━━━━━━━━━━━━━━━━━━━
📝 *Catatan Penting:*
- Gunakan panel sebaik mungkin untuk belajar, project, atau testing.
- Jangan share akun panel ke orang lain sembarangan.
- Jangan menyebar domain, memicu ddos.
- Claim garansi, sertakan bukti transfer dan chat!
- Jangan bales chat ini, untuk menghindari banned !!
- Info panel https://t.me/+SKJB7wDzEiBlNzQ9

━━━━━━━━━━━━━━━━━━━━━━
✅ Terima kasih sudah order di ${ownername} Panel Services.
© ${botname}
`

    let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 }, 
        interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: { mentionedJid: [m.sender], externalAdreply: { showAdAttribution: true }}, 
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }), 
            footer: proto.Message.InteractiveMessage.Footer.create({ text: packname }), 
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                buttons: [
                    { "name": "cta_url", "buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`}, 
                    { "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`},
                    { "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`}
                ]
            })
        })
    } }}, {userJid: m.sender, quoted: null})

    // kirim ke nomor tujuan (opsional)
    await Alice.relayMessage(global.nomorPanel, msgii.message, { messageId: msgii.key.id })

    // info ke chat asal
    await reply(`*Berhasil membuat panel ✅*\nData akun sudah dikirim ke nomor: wa.me/${global.nomorPanel.split('@')[0]}`)

    global.panel = null
    global.nomorPanel = null
}
break


case "delpanel": {
    if (!isPrem) return XRP()
    if (!text) return reply("id server")

    let f = await fetch(domain + "/api/application/servers?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyplta
        }
    })
    let result = await f.json()
    let servers = result.data
    let sections, nameSrv

    for (let server of servers) {
        let s = server.attributes
        if (Number(text) == s.id) {
            sections = s.name.toLowerCase()
            nameSrv = s.name
            let f = await fetch(domain + `/api/application/servers/${s.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyplta,
                }
            })
        }
    }

    let cek = await fetch(domain + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyplta
        }
    })
    let res2 = await cek.json();
    let users = res2.data;

    for (let user of users) {
        let u = user.attributes
        if (u.first_name.toLowerCase() == sections) {
            await fetch(domain + `/api/application/users/${u.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyplta
                }
            })
        }
    }

    if (sections == undefined) return reply("Server panel tidak ditemukan!")
    reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

                case "listsrv": {
    if (!isOwner) return reply('❌ Fitur khusus Owner.')
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyplta
    }
  });
  let res = await f.json();
  let servers = res.data;
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";
  
  for (let server of servers) {
    let s = server.attributes;
    
    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey
      }
    });
    
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    
    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Status: ${status}\n\n`;
  }
  
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;
  
  await Alice.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }        
}
break;
              case "listusr": {
    if (!isOwner) return reply('❌ Fitur khusus Owner.')
  
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyplta
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list user:\n\n";
  
  for (let user of users) {
    let u = user.attributes;
    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
    messageText += `${u.username}\n`;
    messageText += `${u.first_name} ${u.last_name}\n\n`;
  }
  
  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Users: ${res.meta.pagination.count}`;
  
  await Alice.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Panel Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\



//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Premium Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'tobugil':
case 'removeclothes':
case 'telanjangin': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        const { removeclothes } = require('./AliceSystem/AliceScraper/alice-removeclothes.js')
        let resultBuffer = await removeclothes.generate(media)
        
        if (!resultBuffer) return reply('gagal kak')

        await Alice.sendMessage(m.chat, { 
            image: resultBuffer, 
            caption: 'done kak 😎' 
        }, { quoted: m })

    } catch (e) {
        reply(e.message)
    }
}
break
case 'img':
case 'text2img':
case 'text2image': {
if (!isPrem) return XRP()
    await XReaction()
    if (!text) return reply('promptnya mana kak')

    let w = await reply('tunggu bentar kak, lagi digambar…')

    try {
        let url = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(text)}`
        let res = await fetch(url)
        let buff = await res.arrayBuffer()
        let ct = res.headers.get("content-type") || ""

        if (ct.includes("image")) {
            return await Alice.sendMessage(m.chat, {
                image: Buffer.from(buff),
                caption: 'jadi kak 😎\nprompt: ' + text
            }, { quoted: m })
        }

        let json
        try {
            json = JSON.parse(Buffer.from(buff).toString())
        } catch {
            return reply('respon aneh kak')
        }

        let img =
            json.url ||
            json.result ||
            json.image ||
            (json.data && json.data.url) ||
            json.data

        if (!img) return reply('gagal dapet gambar kak')

        await Alice.sendMessage(m.chat, {
            image: { url: img },
            caption: 'jadi kak 😎\nprompt: ' + text
        }, { quoted: m })

    } catch (e) {
        console.log("ERR IMG:", e)
        reply("error kak: " + e.message)
    }
}
break

case 'imganime':
case 'txt2anime':
case 'text2anime': {
if (!isPrem) return XRP()
    await XReaction()
    if (!text) return reply('prompt anime apa kak')

    let w = await reply('tunggu bentar kak, lagi digambar…')

    let prompt = "anime style, vibrant color, clean lineart, big eyes, soft shading, masterpiece, " + text

    try {
        let url = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(prompt)}`
        let res = await fetch(url)
        let buff = await res.arrayBuffer()
        let ct = res.headers.get("content-type") || ""

        if (ct.includes("image")) {
            return await Alice.sendMessage(m.chat, {
                image: Buffer.from(buff),
                caption: 'jadi kak 😎\nprompt anime: ' + prompt
            }, { quoted: m })
        }

        let json
        try {
            json = JSON.parse(Buffer.from(buff).toString())
        } catch {
            return reply('respon aneh kak')
        }

        let img =
            json.url ||
            json.result ||
            json.image ||
            (json.data && json.data.url) ||
            json.data

        if (!img) return reply('gagal dapet gambar kak')

        await Alice.sendMessage(m.chat, {
            image: { url: img },
            caption: 'jadi kak 😎\nprompt anime: ' + prompt
        }, { quoted: m })

    } catch (e) {
        console.log("ERR IMG ANIME:", e)
        reply("error kak: " + e.message)
    }
}
break

case 'imgghibli':
case 'txt2ghibli':
case 'text2ghibli': {
if (!isPrem) return XRP()
    await XReaction()
    if (!text) return reply('prompt ghibli apa kak')

    let w = await reply('tunggu bentar kak, lagi digambar…')

    let prompt = "studio ghibli style, pastel soft color, warm light, dreamy background, handpaint style, " + text

    try {
        let url = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(prompt)}`
        let res = await fetch(url)
        let buff = await res.arrayBuffer()
        let ct = res.headers.get("content-type") || ""

        if (ct.includes("image")) {
            return await Alice.sendMessage(m.chat, {
                image: Buffer.from(buff),
                caption: 'jadi kak 😎\nprompt ghibli: ' + prompt
            }, { quoted: m })
        }

        let json
        try {
            json = JSON.parse(Buffer.from(buff).toString())
        } catch {
            return reply('respon aneh kak')
        }

        let img =
            json.url ||
            json.result ||
            json.image ||
            (json.data && json.data.url) ||
            json.data

        if (!img) return reply('gagal dapet gambar kak')

        await Alice.sendMessage(m.chat, {
            image: { url: img },
            caption: 'jadi kak 😎\nprompt ghibli: ' + prompt
        }, { quoted: m })

    } catch (e) {
        console.log("ERR IMG GHIBLI:", e)
        reply("error kak: " + e.message)
    }
}
break

case 'imgpixel':
case 'txt2pixel':
case 'text2pixel': {
if (!isPrem) return XRP()
    await XReaction()
    if (!text) return reply('prompt pixel apa kak')

    let w = await reply('tunggu bentar kak, lagi digambar…')

    let prompt = "pixel art, retro 16-bit, blocky texture, sprite style, vibrant pixel color, " + text

    try {
        let url = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(prompt)}`
        let res = await fetch(url)
        let buff = await res.arrayBuffer()
        let ct = res.headers.get("content-type") || ""

        if (ct.includes("image")) {
            return await Alice.sendMessage(m.chat, {
                image: Buffer.from(buff),
                caption: 'jadi kak 😎\nprompt pixel: ' + prompt
            }, { quoted: m })
        }

        let json
        try {
            json = JSON.parse(Buffer.from(buff).toString())
        } catch {
            return reply('respon aneh kak')
        }

        let img =
            json.url ||
            json.result ||
            json.image ||
            (json.data && json.data.url) ||
            json.data

        if (!img) return reply('gagal dapet gambar kak')

        await Alice.sendMessage(m.chat, {
            image: { url: img },
            caption: 'jadi kak 😎\nprompt pixel: ' + prompt
        }, { quoted: m })

    } catch (e) {
        console.log("ERR IMG PIXEL:", e)
        reply("error kak: " + e.message)
    }
}
break
case 'xnxxsearch': {
if (!isPrem) return XRP()
    if (!args[0]) return reply(`Tobat Woi\n\nExample : ${prefix + command} Japanese`);

await XReaction()
    let data = await xnxxSearch(text);
    let results = data.result;

    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result) => {
            message += `Title : ${result.title}\nInfo : ${result.info}\nLink : ${result.link}\n\n`;
        });
        reply(message);
    } else {
        reply('Tidak Ada Hasil.');
    }
}
break;

case 'xnxxdl': {
if (!isPrem) return XRP()
    if (!args[0]) return reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`);

await XReaction()
    let data = await xnxxDownloader(text);
    
    let capp = `XNXX DL\nTitle : ${data.title}\nDurasi : ${data.duration}\nUrl : ${data.URL}\n`;
    
    await Alice.sendMessage(m.chat, {
        video: {
            url: data.files.high
        },
        caption: capp,
    }, {
        quoted: m
    });
}
break;
case 'toblur': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('blurwajah', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🙈 Wajah diblur' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tozombie': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tozombie', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🧟 jadi zombie' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tovintage': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tovintage', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '📼 vintage' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'totato': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('totato', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🧿 tato ditambah' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'totua': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('totua', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '👴 jadi tua' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tomirror': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tomirror', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '📱 mirror' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tohitam':
case 'toblack': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tohitam', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '⚫ Tohitam' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'topacar': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('topacar', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '💑 pacar baru' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'toreal': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('toreal', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🎨 realistic' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tojepang': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tojepang', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🗾 ke jepang' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tohijab': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tohijab', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🧕 hijab' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'toghibli': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('toghibli', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🌿 ghibli' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tochibi': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tochibi', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🍼 chibi' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'toanime': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('toanime', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '🎨 anime' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break

case 'tofigure': {
    if (!isPrem) return XRP()
    await XReaction()

    let mime = m.quoted?.mimetype || ''
    if (!mime.includes('image')) return reply('❌ Reply gambar')

    try {
        let media = await m.quoted.download()
        let link = await uploadToAliceCdn(media, 'img.jpg')
        let hasil = await convertTo('tofigura', link)

        await Alice.sendMessage(m.chat, { image: hasil, caption: '😎 figure' }, { quoted: m })
    } catch (e) {
        reply(e?.response?.status == 500 ? '⚠️ API gangguan' : e.message)
    }
}
break
case "buatlagu": {
if (!isPrem) return XRP();
 if (!text) return reply(`❌ Contoh:\n${prefix + command} lagu sedih berbahasa Indonesia, tentang kisah cinta`);

 const axios = require("axios");
 const { v4: uuidv4 } = require("uuid");

 function randomHex(length) {
 const chars = "abcdef0123456789";
 return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
 }

 function gieneticTrace() {
 return `${randomHex(32)}-${randomHex(16)}`;
 }

 // login otomatis
 async function login(deviceId) {
 const res = await axios.post("https://api.sunora.mavtao.com/api/auth/login", {
 device_id: deviceId
 }, {
 headers: {
 "user-agent": "Dart/3.4 (gienetic_build)",
 "version": "2.2.2",
 "accept-encoding": "gzip",
 "content-type": "application/json",
 "buildnumber": "105",
 "platform": "android",
 "sentry-trace": gieneticTrace()
 }
 });
 return res.data?.data?.token || null;
 }

 // cek status generate
 async function polling(xAuth, maxAttempts = 20, delayMs = 15000) {
 for (let attempt = 1; attempt <= maxAttempts; attempt++) {
 try {
 const res = await axios.get("https://api.sunora.mavtao.com/api/music/music_page?page=1&pagesize=50", {
 headers: {
 "user-agent": "Dart/3.4 (gienetic_build)",
 "version": "2.2.2",
 "accept-encoding": "gzip",
 "x-auth": xAuth,
 "buildnumber": "105",
 "platform": "android",
 "sentry-trace": gieneticTrace()
 }
 });

 const records = res.data?.data?.records || [];
 const doneSongs = records.filter(r => r.status === "complete");

 if (doneSongs.length > 0) {
 return doneSongs[0]; // ambil 1 lagu aja
 }
 } catch (err) {
 console.error("⚠️ Polling error:", err.response?.data || err.message);
 }
 await new Promise(r => setTimeout(r, delayMs));
 }
 return null;
 }

 // mulai generate
 async function generateSong(prompt) {
 const deviceId = uuidv4();
 const token = await login(deviceId);
 if (!token) throw new Error("⚠️ Error: gagal login ke API.");

 await axios.post("https://api.sunora.mavtao.com/api/music/advanced_custom_generate", {
 description: prompt,
 instrumental_only: false
 }, {
 headers: {
 "user-agent": "Dart/3.4 (gienetic_build)",
 "version": "2.2.2",
 "accept-encoding": "gzip",
 "x-auth": token,
 "content-type": "application/json",
 "buildnumber": "105",
 "platform": "android",
 "sentry-trace": gieneticTrace()
 }
 });

 return await polling(token);
 }

 try {
 reply(`🎶 Lagi bikin lagu untuk prompt:\n\n"${text}"\n⏳ Mohon tunggu sekitar 2-3 menit...`);
 const result = await generateSong(text);

 if (!result) return reply("❌ Gagal generate lagu, coba lagi nanti.");

 await Alice.sendMessage(m.chat, {
 audio: { url: result.audio_url },
 mimetype: 'audio/mpeg',
 ptt: false
 }, { quoted: m });

 reply(`✅ Lagu berhasil dibuat!\n\n🎵 Judul: ${result.title}\n📌 Prompt: ${result.meta_prompt || text}\n🔗 Audio: ${result.audio_url}`);
 } catch (e) {
 console.error(e);
 reply("❌ Error saat generate lagu, coba ulang lagi.");
 }
}
break
case 'gimg18+': {
    if (!isPrem) return XRP();
    await XReaction();
    try {
        if (!text) return reply(`⚠️ Masukkan prompt.\nContoh: .${prefix + command} neko girl`);

        const API_URL = 'https://velyn.mom/api/ai/arting';
        const API_KEY = 'velynapis';

        reply('🎨 Sedang membuat gambar...');

        let res = await axios.get(
            `${API_URL}?apikey=${API_KEY}&prompt=${encodeURIComponent(text)}`
        );

        if (!res.data || !res.data.success) {
            return reply("❌ API tidak mengembalikan hasil valid");
        }

        // Ambil hanya gambar pertama
        let images = res.data.results;
        if (!Array.isArray(images) || images.length === 0) {
            return reply("❌ API tidak mengembalikan gambar.");
        }

        let url = images[0]; // ambil gambar pertama
        let imgRes = await axios.get(url, { responseType: 'arraybuffer' });
        let buffer = Buffer.from(imgRes.data);

        await Alice.sendMessage(m.chat, {
            image: buffer,
            caption: `✅ Gambar selesai!\n\n📌 Prompt: *${text}*`
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply(`🚨 Eror kak : ${e.message}`);
    }
}
break;
case 'veo3': {
    if (!isPrem) return XRP();
    await XReaction();
    try {
        if (!text) return reply('Masukkan prompt. Contoh:\n.veo3 kota futuristik dengan AI');

        // panggil API veo3
        const API_URL = 'https://faa-veo.vercel.app/faa/veo3';
        const res = await axios.get(`${API_URL}?prompt=${encodeURIComponent(text)}`);

        if (!res.data) return reply('API tidak mengembalikan hasil');

        // coba ambil link video dari beberapa kemungkinan field
        let videoUrl = res.data.video || res.data.url;

        // kalau belum ketemu, coba scan semua field untuk cari link mp4
        if (!videoUrl) {
            const stringified = JSON.stringify(res.data);
            const match = stringified.match(/https?:\/\/[^\s"]+\.mp4/);
            if (match) videoUrl = match[0];
        }

        if (videoUrl) {
            await Alice.sendMessage(m.chat, {
                video: { url: videoUrl },
                caption: '✅ Video berhasil dibuat dengan VEO3 🎥'
            }, { quoted: m });
        } else {
            reply('❌ Gagal menemukan link video dari API.\nBalikan API:\n' + JSON.stringify(res.data, null, 2));
        }

    } catch (e) {
        reply(`🚨 Eror kak: ${e.message}`);
    }
}
break;

case 'removebg': {
  if (!isPrem) return XRP();
  await XReaction();

  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/image\/(jpe?g|png)/.test(mime)) {
      return reply('⚠️ Reply gambar lalu ketik: .removebg');
    }

    const imgBuffer = await q.download();
    if (!imgBuffer) return reply('❌ Gagal download gambar');

    reply('🪄 Sedang memproses background, tunggu...');

    const axios = require("axios");
    const FormData = require("form-data");

    // upload gambar ke CDN Alice dulu
    const form = new FormData();
    form.append("cdnFile", imgBuffer, "image.png");

    const upload = await axios.post(
      "https://aliceecdn.vercel.app/upload",
      form,
      { headers: form.getHeaders() }
    );

    if (!upload.data?.url) return reply("❌ Upload CDN gagal");

    const fileUrl = upload.data.url;
    const apiKey = global.apikey.xtermai;

    // request removebg ke Termai API
    const removeRes = await axios.get(
      `https://api.termai.cc/api/tools/image-removebg?url=${encodeURIComponent(fileUrl)}&key=${apiKey}`
    );

    if (!removeRes.data?.data?.url) {
      return reply("❌ Gagal mengambil hasil removebg");
    }

    const outputUrl = removeRes.data.data.url;

    // download gambar hasil
    const finalImg = await axios.get(outputUrl, { responseType: "arraybuffer" });

    // kirim gambar hasil
    await Alice.sendMessage(m.chat, {
      image: Buffer.from(finalImg.data),
      caption: "✅ Background berhasil dihapus!"
    }, { quoted: m });

  } catch (e) {
    console.error("REMOVE-BG ERROR:", e.response?.data || e.message);
    reply(`🚨 Error: ${e.message}`);
  }

}
break;

case 'img2video':
case 'luma': {
  if (!isPrem) return XRP();
  await XReaction();

  const axios = require('axios');
  ;

  try {
    if (!qmsg) return reply(`reply/kirim gambar dengan caption ${prefix + command}`);
    if (!/image/.test(mime)) return reply(`reply/kirim gambar dengan caption ${prefix + command}`);

    await XReaction();

    let media = await Alice.downloadAndSaveMediaMessage(qmsg);
    if (!media) return reply('Gagal mengambil media');

    const fileStream = fs.createReadStream(media);

    const apiKey = global.apikey.xtermai;
    const url = `https://api.termai.cc/api/img2video/luma?key=${apiKey}` + (text ? `&prompt=${encodeURIComponent(text)}` : '');

    const response = await axios.post(url, fileStream, {
      headers: {
        'Content-Type': 'application/octet-stream'
      },
      responseType: 'stream'
    });

    let sentProcessing = false;

    response.data.on('data', async (chunk) => {
      try {
        const eventString = chunk.toString();
        const eventData = eventString.match(/data: (.+)/);

        if (eventData && eventData[1]) {
          let data;
          try {
            data = JSON.parse(eventData[1]);
          } catch (e) {
            console.log('parse err:', eventData[1]);
            data = {};
          }

          switch (data.status) {
            case 'generating':
            case 'queueing':
            case 'processing':
              if (!sentProcessing) {
                sentProcessing = true;
                reply('⏱ Sedang diproses, bisa makan waktu 1-5 menit...');
              }
              break;

            case 'failed':
              reply('❌ Gagal membuat video');
              response.data.destroy();
              if (fs.existsSync(media)) fs.unlinkSync(media);
              break;

            case 'completed':
              if (data.video && data.video.url) {
                await Alice.sendMessage(
                  m.chat,
                  {
                    video: { url: data.video.url },
                    mimetype: 'video/mp4',
                    caption: '✅ Selesai, ini videonya!'
                  },
                  { quoted: m }
                );
              } else {
                reply('❌ Response tidak berisi URL video');
              }
              response.data.destroy();
              if (fs.existsSync(media)) fs.unlinkSync(media);
              break;

            default:
              console.log('Unknown status:', data);
          }
        }
      } catch (e) {
        console.error('Error processing chunk:', e.message);
        response.data.destroy();
        if (fs.existsSync(media)) fs.unlinkSync(media);
        reply('Err!!');
      }
    });

    response.data.on('error', (err) => {
      console.error('Stream error:', err.message);
      if (fs.existsSync(media)) fs.unlinkSync(media);
      reply('❌ Terjadi kesalahan pada stream');
    });

  } catch (err) {
    console.error(err);
    reply(`Error: ${err.message}`);
  }
}
break;
case "animediff": {
  if (!isPrem) return XRP()
  if (!text) return reply("Harap sertakan promptnya!")
  await XReaction()
  await Alice.sendMessage(m.chat, { 
    image: { 
      url: `https://aihub.xtermai.xyz/api/text2img/animediff?prompt=${text}&key=${global.apikey.xtermai_key}` 
    } 
  }, { quoted: m })
}
break

case "dalle3": {
  if (!isPrem) return XRP()
  if (!text) return reply("Harap sertakan promptnya!")
  await XReaction()
  await Alice.sendMessage(m.chat, { 
    image: { 
      url: `https://aihub.xtermai.xyz/api/text2img/dalle3?prompt=${text}&key=${global.apikey.xtermai_key}` 
    } 
  }, { quoted: m })
}
break
case 'hdvideo':
case 'hdvid': {
  if (!isPrem) return XRP()
    try {

    const q = m.quoted || m
    const mime = q.mimetype || q.msg?.mimetype || q.mediaType || ''

    if (!mime.startsWith('video/'))
      return Alice.sendMessage(
        m.chat,
        { text: '❌ Mana videonya?' },
        { quoted: m }
      )

    Alice.sendMessage(
      m.chat,
      { text: '⏫ Meng-HD-kan video, tunggu ±1–5 menit...' },
      { quoted: m }
    )

    const buffer = await q.download()
    if (!buffer)
      return Alice.sendMessage(
        m.chat,
        { text: '❌ Gagal download video' },
        { quoted: m }
      )

    const res = await hdvideo(buffer)

    await Alice.sendMessage(
      m.chat,
      {
        video: { url: res.output_url },
        caption: `✅ Berhasil HD\n${packname}`
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('HDVIDEO ERROR:', e)
    Alice.sendMessage(
      m.chat,
      { text: `❌ Gagal HD video\n${e.message}` },
      { quoted: m }
    )
  }
}
break

		case 'ssweb': {
if (!isPrem) return XRP()
				if (!text) return reply(`Example: ${prefix + command} https://`)
				if (!text.startsWith('http')) {
					let buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/https://' + q;
					await Alice.sendMessage(m.chat, { image: { url: buf }, caption: 'Done' }, { quoted: m })
				} else {
					let buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/' + q;
					await Alice.sendMessage(m.chat, { image: { url: buf }, caption: 'Done' }, { quoted: m })
				}
			}
			break

            case 'reminder': {
if (!isPrem) return XRP()
                if (!args[0] || !args[1] || !args[2]) return reply('*contoh : Reminder Waktu Detik/Menit/Jam Pesan*\n\n*Contoh : Reminder 30 Menit Jangan Lupa Sholat*')
                const time = parseInt(args[0]) * (args[1].match(/(m|minute)/i) ? 60 : args[1].match(/(h|hour)/i) ? 3600 : 1) * 1000
                const message = args.slice(2).join(' ')
                setTimeout(() => {
                    Alice.sendMessage(m.chat, { text: `*Reminder Untuk @${sender.split("@")[0]}*\n\n📑 *Dengan Pesan :* ${message}`, contextInfo: { mentionedJid: [sender] } }, { quoted: m })
                }, time)
                reply(`*Berhasil Mengatur Reminder Untuk ${args[0]} ${args[1]} Ke Depan*`)
            }
                break


case 'nglspam':{
if (!isPrem) return XRP()
    if (!text.split("|")[0] || !text.split("|")[1] || !text.split("|")[2]) {
        return reply("Masukan username, pesan, dan jumlah spam!\nContoh: .nglspam username|haloo|5");
    }
    const [username, message, count] = text.split("|");
    const spamCount = parseInt(count, 10);
    if (isNaN(spamCount) || spamCount <= 0) {
        return reply("Jumlah spam harus berupa angka positif!");
    }
    try {
        await nglspam(username, message, spamCount);
        reply(`Sukses mengirim ${spamCount} pesan NGL ke ${username}`);
    } catch (e) {
        console.error(e);
        return reply("Fitur error, coba lagi nanti.");
    }
}
break

case 'threads': {
if (!isPrem) return XRP()
if (!args || !args[0]) return reply(`Example: ${prefix + command} https://www.threads.net/@httpnald_/post/CwWvCFvJr_N/?igshid=NTc4MTIwNjQ2YQ==`)
await XReaction()
let timestamp = speed()
let latensi = speed() - timestamp
const json = await fetchJson(`https://aemt.uk.to/download/threads?url=${text}`)
Alice.sendMessage(m.chat, { video: { url: json.result.videourls[0].download_url }, caption: `🍟 *Fetching* : ${latensi.toFixed(4)} ms` }, { quoted: m })
}
break

case 'threadsimg': {
if (!isPrem) return XRP()
if (!args || !args[0]) return reply(`Example: ${prefix + command} https://www.threads.net/t/Cujx6ryoYx6/?igshid=NTc4MTIwNjQ2YQ==`)
let timestamp = speed()
let latensi = speed() - timestamp
const json = await fetchJson(`https://aemt.uk.to/download/threads?url=${text}`)
Alice.sendMessage(m.chat, { image: { url: json.result.image_urls }, caption: 'succes' }, { quoted: m })
}
break	

case 'gempa':
            case 'infogempa': {
            if (!isPrem) return XRP()
                try {
                    const res = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json')
                    const data = await res.json()
                    const gempa = data.Infogempa.gempa
                    let txt = `*${gempa.Wilayah}*\n\n`
                    txt += `Tanggal : ${gempa.Tanggal}\n`
                    txt += `Waktu : ${gempa.Jam}\n`
                    txt += `Potensi : *${gempa.Potensi}*\n\n`
                    txt += `Magnitude : ${gempa.Magnitude}\n`
                    txt += `Kedalaman : ${gempa.Kedalaman}\n`
                    txt += `Koordinat : ${gempa.Coordinates}`
                    if (gempa.Dirasakan.length > 3) {
                        txt += `\nDirasakan : ${gempa.Dirasakan}`
                    }

                    Alice.sendMessage(m.chat, {
                        text: txt, contextInfo: {
                            "externalAdreply": {
                                "title": botname,
                                "body": command,
                                "showAdAttribution": true,
                                "mediaType": 1,
                                "sourceUrl": global.sosialmedia.telegram,
                                "thumbnailUrl": thumbnailReply, "renderLargerThumbnail": true
                            }
                        }
                    }, { quoted: m })
                } catch (e) {
                    console.log(e)
                    reply('[!] Ada Yang Error.')
                }
            }
                break
               

case 'readmore': {
if (!isPrem) return XRP()
	let [l, r] = text.split`|`
    if (!l) l = ''
    if (!r) r = ''
    Alice.sendMessage(m.chat, {text: l + readmore + r}, {quoted: m})
}
break;                				

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Premium Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Asupan Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'tiktokgirl':
await XReaction();
var asupan = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/tiktokgirl.json'))
var ii = pickRandom(asupan)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: ii.url }}, { quoted: m })
break
case 'tiktokghea':
await XReaction();
var gheayubi = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/gheayubi.json'))
var iii = pickRandom(gheayubi)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iii.url }}, { quoted: m })
break
case 'tiktokbocil':
await XReaction();
var bocil = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/bocil.json'))
var iiii = pickRandom(bocil)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiii.url }}, { quoted: m })
break
case 'tiktoknukhty':
await XReaction();
var ukhty = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/ukhty.json'))
var iiiii = pickRandom(ukhty)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiiii.url }}, { quoted: m })
break
case 'tiktoksantuy':
await XReaction();
var santuy = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/santuy.json'))
var iiiiii = pickRandom(santuy)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiiiii.url }}, { quoted: m })
break
case 'tiktokkayes':
await XReaction();
var kayes = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/kayes.json'))
var iiiiiii = pickRandom(kayes)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiiiiii.url }}, { quoted: m })
break
case 'tiktokpanrika':
await XReaction();
var rikagusriani = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/panrika.json'))
var iiiiiiii = pickRandom(rikagusriani)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiiiiiii.url }}, { quoted: m })
break
case 'tiktoknotnot':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokvids/notnot.json'))
var iiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', video: { url: iiiiiiiii.url }}, { quoted: m })
break
case 'chinese':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/china.json'))
var iiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiii.url } }, { quoted: m })
break
case 'hijab':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/hijab.json'))
var iiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiii.url } }, { quoted: m })
break
case 'indo':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/indonesia.json'))
var iiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiii.url } }, { quoted: m })
break
case 'japanese':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/japan.json'))
var iiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiii.url } }, { quoted: m })
break
case 'korean':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/korea.json'))
var iiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'malay':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/malaysia.json'))
var iiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomgirl':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/random.json'))
var iiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomboy':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/random2.json'))
var iiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'thai':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/thailand.json'))
var iiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'vietnamese':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/tiktokpics/vietnam.json'))
var iiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Asupan Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Ephoto Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'cecankorea': {
  try {
    const res = await fetch('https://api.siputzx.my.id/api/r/cecan/korea');
    if (!res.ok) throw new Error('Gagal mengambil gambar');

    const buffer = await res.buffer();

    await Alice.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: '📸 Sukses :v'
      },
      { quoted: m }
    );
  } catch (e) {
    console.error('[CECAN_KOREA ERROR]', e);
    reply('❌ Terjadi kesalahan saat mengambil gambar.');
  }
};
break
      case "glitchtext":
      case "writetext":
      case "advancedglow":
      case "typographytext":
      case "pixelglitch":
      case "neonglitch":
      case "flagtext":
      case "flag3dtext":
      case "deletingtext":
      case "blackpinkstyle":
      case "glowingtext":
      case "underwatertext":
      case "logomaker":
      case "cartoonstyle":
      case "papercutstyle":
      case "watercolortext":
      case "effectclouds":
      case "blackpinklogo":
      case "gradienttext":
      case "summerbeach":
      case "luxurygold":
      case "multicoloyellowneon":
      case "sandsummer":
      case "galaxywallpaper":
      case "1917style":
      case "makingneon":
      case "royaltext":
      case "freecreate":
      case "galaxystyle":
      case "lighteffects":
await XReaction();      
        {
          if (!q) {
            return reply(`Contoh : ${prefix + command} ${botname}`);
          }
          let link;
          if (/glitchtext/.test(command)) {
            link = "https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html";
          }
          if (/writetext/.test(command)) {
            link = "https://en.ephoto360.com/write-text-on-wet-glass-online-589.html";
          }
          if (/advancedglow/.test(command)) {
            link = "https://en.ephoto360.com/advanced-glow-effects-74.html";
          }
          if (/typographytext/.test(command)) {
            link = "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html";
          }
          if (/pixelglitch/.test(command)) {
            link = "https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html";
          }
          if (/neonglitch/.test(command)) {
            link = "https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html";
          }
          if (/flagtext/.test(command)) {
            link = "https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html";
          }
          if (/flag3dtext/.test(command)) {
            link = "https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html";
          }
          if (/deletingtext/.test(command)) {
            link = "https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html";
          }
          if (/blackpinkstyle/.test(command)) {
            link = "https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html";
          }
          if (/glowingtext/.test(command)) {
            link = "https://en.ephoto360.com/create-glowing-text-effects-online-706.html";
          }
          if (/underwatertext/.test(command)) {
            link = "https://en.ephoto360.com/3d-underwater-text-effect-online-682.html";
          }
          if (/logomaker/.test(command)) {
            link = "https://en.ephoto360.com/free-bear-logo-maker-online-673.html";
          }
          if (/cartoonstyle/.test(command)) {
            link = "https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html";
          }
          if (/papercutstyle/.test(command)) {
            link = "https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html";
          }
          if (/watercolortext/.test(command)) {
            link = "https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html";
          }
          if (/effectclouds/.test(command)) {
            link = "https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html";
          }
          if (/blackpinklogo/.test(command)) {
            link = "https://en.ephoto360.com/create-blackpink-logo-online-free-607.html";
          }
          if (/gradienttext/.test(command)) {
            link = "https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html";
          }
          if (/summerbeach/.test(command)) {
            link = "https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html";
          }
          if (/luxurygold/.test(command)) {
            link = "https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html";
          }
          if (/multicoloyellowneon/.test(command)) {
            link = "https://en.ephoto360.com/create-multicoloyellow-neon-light-signatures-591.html";
          }
          if (/sandsummer/.test(command)) {
            link = "https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html";
          }
          if (/galaxywallpaper/.test(command)) {
            link = "https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html";
          }
          if (/1917style/.test(command)) {
            link = "https://en.ephoto360.com/1917-style-text-effect-523.html";
          }
          if (/makingneon/.test(command)) {
            link = "https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html";
          }
          if (/royaltext/.test(command)) {
            link = "https://en.ephoto360.com/royal-text-effect-online-free-471.html";
          }
          if (/freecreate/.test(command)) {
            link = "https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html";
          }
          if (/galaxystyle/.test(command)) {
            link = "https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html";
          }
          if (/lighteffects/.test(command)) {
            link = "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html";
          }
          let haldwhd = await ephoto(link, q);
          Alice.sendMessage(m.chat, {
            image: {
              url: haldwhd
            },
            caption: `${packname}`
          }, {
            quoted: m
          });
        }
        break;


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Ephoto Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Random Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
      case "handsomecheck":
        if (!text) {
          return reply(`Tag Someone, Contoh : ${prefix + command} tes`);
        }
        const gan = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"];
        const teng = gan[Math.floor(Math.random() * gan.length)];
        Alice.sendMessage(m.chat, {
          text: `*${prefix + command}*\n\nName : ${q}\nAnswer : *${teng}%*`
        }, {
          quoted: m
        });
        break;
      case "beautifulcheck":
        if (!text) {
          return reply(`Tag Someone, Contoh : ${prefix + command} tes`);
        }
        const can = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"];
        const tik = can[Math.floor(Math.random() * can.length)];
        Alice.sendMessage(m.chat, {
          text: `*${prefix + command}*\n\nNama : ${q}\nAnswer : *${tik}%*`
        }, {
          quoted: m
        });
        break;
      case "charactercheck":
        if (!text) {
          return reply(`Tag Someone, Contoh : ${prefix + command} tes`);
        }
        const xeony = ["Compassionate", "Generous", "Grumpy", "Forgiving", "Obedient", "Good", "Simp", "Kind-Hearted", "patient", "UwU", "top, anyway", "Helpful"];
        const taky = xeony[Math.floor(Math.random() * xeony.length)];
        Alice.sendMessage(m.chat, {
          text: `Character Check : ${q}\nAnswer : *${taky}*`
        }, {
          quoted: m
        });
        break;
      case "awesomecheck":
      case "greatcheck":
      case "gaycheck":
      case "cutecheck":
      case "lesbicheck":
      case "lesbiancheck":
      case "hornycheck":
      case "prettycheck":
      case "lovelycheck":
      case "uglycheck":
        const cex = body.slice(0);
        const cek1 = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"];
        const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
        if (mentionByreply) {
          Alice.sendMessage(m.chat, {
            text: `${"Question : *" + cex + "*\nChecker : "}@${mentionByreply.split("@")[0]}
Answer : ${cek2}%`,
            mentions: [mentionByreply]
          }, {
            quoted: m
          });
        } else if (mentionByTag[0]) {
          Alice.sendMessage(m.chat, {
            text: `${"Question : *" + cex + "*\nChecker : "}@${mentionByTag[0].split("@")[0]}
Answer : ${cek2}%`,
            mentions: [mentionByTag[0]]
          }, {
            quoted: m
          });
        } else if (!mentionByreply && !mentionByTag[0]) {
          Alice.sendMessage(m.chat, {
            text: `${"Question : *" + cex + "*\nChecker : "}@${sender.split("@")[0]}
Answer : ${cek2}%`,
            mentions: [sender]
          }, {
            quoted: m
          });
        }
        break;
       
case 'aesthetic':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/aesthetic.json'))
var iiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'antiwork':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/antiwork.json'))
var iiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'blackpink2':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/blackpink.json'))
var iiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'bike':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/bike.json'))
var iiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'boneka':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/boneka.json'))
var iiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cosplay':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/cosplay.json'))
var iiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cat':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/cat.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'doggo':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/doggo.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiil = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiil.url } }, { quoted: m })
break
case 'justina':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/justina.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiill = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiill.url } }, { quoted: m })
break

case 'kayes':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/kayes.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiilll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiilll.url } }, { quoted: m })
break
case 'kpop':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/kpop.json'))
var ll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: ll.url } }, { quoted: m })
break
case 'notnot':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/notnot.json'))
var lll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lll.url } }, { quoted: m })
break
case 'car':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/car.json'))
var llll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: llll.url } }, { quoted: m })
break
case 'couplepic':case 'couplepicture':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/ppcouple.json'))
var lllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lllll.url } }, { quoted: m })
break
case 'profilepic':  case 'profilepicture':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/profile.json'))
var llllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: llllll.url } }, { quoted: m })
break
case 'pubg':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/pubg.json'))
var lllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lllllll.url } }, { quoted: m })
break
case 'rose':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/rose.json'))
var llllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: llllllll.url } }, { quoted: m })
break
case 'ryujin':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/ryujin.json'))
var lllllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lllllllll.url } }, { quoted: m })
break
case 'ulzzangboy':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/ulzzangboy.json'))
var llllllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: llllllllll.url } }, { quoted: m })
break
case 'ulzzanggirl':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/ulzzanggirl.json'))
var lllllllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lllllllllll.url } }, { quoted: m })
break
case 'wallml': case 'wallpaperml':case 'mobilelegend':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/wallml.json'))
var llllllllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: llllllllllll.url } }, { quoted: m })
break
case 'wallpaperphone': case 'wallphone':
await XReaction();
var notnot = JSON.parse(fs.readFileSync('./AliceSystem/AliceResource/randompics/wallhp.json'))
var lllllllllllll = pickRandom(notnot)
Alice.sendMessage(m.chat, { caption: 'donee', image: { url: lllllllllllll.url } }, { quoted: m })
break

case 'faktaunik': {
await XReaction(); 
let Xyroo = await fetchJson(`https://api.autoresbot.com/api/random/faktaunik`)
let qutenya = Xyroo.data;
await reply(qutenya)
}
break
case 'quotesbucin': {
await XReaction(); 
let Xyroo = await fetchJson(`https://api.autoresbot.com/api/random/bucinquote`)
let qutenya = Xyroo.data;
await reply(qutenya)
}
break
case 'animequote': {
  await XReaction();

  try {
    let apiUrl = `https://aliceeapis.vercel.app/random/animequote?apikey=${global.apikey.alice}`;
    let { data } = await axios.get(apiUrl);

    if (!data.status) return reply('Gagal mengambil anime quote!');

    let q = data.result;
    let caption = `[ ANIME QUOTE ]\n\n`;
    caption += `◦ *Character* : ${q.char}\n`;
    caption += `◦ *Anime* : ${q.from_anime}\n`;
    caption += `◦ *Episode* : ${q.episode}\n\n`;
    caption += `_"${q.quote}"_`;

    return Alice.sendMessage(
      m.chat,
      { text: caption },
      { quoted: m }
    );
  } catch (err) {
    console.error('AnimeQuote Error:', err.message);
    reply('Terjadi kesalahan saat mengambil quote anime.');
  }
}
break;
case "quotesanime":
case "quotesanim":
{
let res = await await fetch("https://katanime.vercel.app/api/getrandom?limit=1");
if (!res.ok) {
return await res.text();
}
let json = await res.json();
if (!json.result[0]) {
return json;
}
let {
indo,
character,
anime
} = json.result[0];
reply(`${indo}\n\n📮By:  _${character}_ \nAnime:\n${anime}`);
}
break;
case 'quotesjawa': {
await XReaction();

await XReaction() 
let Xyroo = await fetchJson(`https://api.autoresbot.com/api/random/jawaquote`)
let qutenya = Xyroo.data;
await reply(qutenya)
}
break
case 'quotes': {
await XReaction();

await XReaction() 
let Xyroo = await Quotes();
let cap = `
_✨° ${Xyroo.quotes} °_

_🍂${Xyroo.author} ~_`
await reply(cap)
}
break
case 'randommeme':
case 'meme':
case 'rmeme': {
await XReaction();

  const API = 'https://api.zenzxz.my.id/random/meme'
  const MAX_IMG = 15 * 1024 * 1024 // batas 15 MB

  // helper kecil
  const humanSize = (n=0) => { const u=['B','KB','MB','GB']; let i=0,v=+n; while(v>=1024&&i<u.length-1){v/=1024;i++} return `${v.toFixed(v>=100?0:v>=10?1:2)} ${u[i]}` }
  const extFromCtype = (t='') => (t.split('/')[1] || 'jpg').split(';')[0]

  const when = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
  const caption = `😂 *Random Meme*\n🕒 ${when}\n🔗 Sumber: api.zenzxz.my.id\n\nKetik *.meme* lagi untuk next.`

  try {
    // 1) coba request biasa (mungkin JSON dengan url)
    let r = await axios.get(API, { timeout: 15000, validateStatus: s => s>=200 && s<400 })
    let ctype = (r.headers['content-type'] || '').toLowerCase()

    if (ctype.includes('application/json')) {
      const j = r.data || {}
      const mediaUrl = j.url || j.result || j.image || j.data?.url || j.data?.image
      if (!mediaUrl) return reply('⚠️ API tidak mengembalikan URL gambar.')

      // cek ukuran lewat HEAD
      let clen = 0, mim = ''
      try {
        const h = await axios.head(mediaUrl, { timeout: 10000 })
        clen = parseInt(h.headers['content-length'] || '0', 10)
        mim  = (h.headers['content-type'] || '').toLowerCase()
      } catch {}

      if (clen && clen > MAX_IMG) {
        await Alice.sendMessage(
          m.chat,
          { document: { url: mediaUrl }, mimetype: mim || 'image/jpeg', fileName: `random_meme.${extFromCtype(mim||'image/jpeg')}`, caption: `${caption}\n(📦 dokumen – ${humanSize(clen)})` },
          { quoted: m }
        )
      } else {
        await Alice.sendMessage(m.chat, { image: { url: mediaUrl }, caption }, { quoted: m })
      }
      return
    }

    // 2) kalau bukan JSON → API langsung stream gambar
    r = await axios.get(API, {
      timeout: 20000,
      responseType: 'arraybuffer',
      validateStatus: s => s>=200 && s<400
    })
    ctype = (r.headers['content-type'] || 'image/jpeg').toLowerCase()
    const length = parseInt(r.headers['content-length'] || '0', 10)
    const buff = Buffer.from(r.data)

    if (length && length > MAX_IMG) {
      await Alice.sendMessage(
        m.chat,
        { document: buff, mimetype: ctype, fileName: `random_meme.${extFromCtype(ctype)}`, caption: `${caption}\n(📦 dokumen – ${humanSize(length)})` },
        { quoted: m }
      )
    } else {
      await Alice.sendMessage(
        m.chat,
        { image: buff, caption },
        { quoted: m }
      )
    }

  } catch (e) {
    console.error('randommeme error:', e?.message || e)
    const msg =
      (e?.response?.status === 429) ? '⌛ Terlalu banyak permintaan. Coba sebentar lagi.' :
      (e?.code === 'ECONNABORTED') ? '⌛ Timeout koneksi ke API.' :
      '❌ Gagal mengambil meme. Coba lagi.'
    return reply(msg)
  }
}
break
case 'darkjokes':
case 'jokesgelap':
case 'jokesdark':
case 'darkjoke': {
await XReaction();
try {
let Xyroo = await Darkjokes()
await Alice.sendMessage(m.chat, { image: { url: Xyroo }, caption: 'donee' }, { quoted: m })
} catch (error) {
  return XRR()
}
}
break
case 'kataanime':{
await XReaction();

await XReaction()
    	try {
//wm senn
		let res = await await fetch("https://katanime.vercel.app/api/getrandom");
		if (!res.ok) throw await res.text();
		let json = await res.json();
//wm senn
		if (!json.result) throw json;
		let data = "";
		for (let i = 0; i < json.result.length; i++) {
			let { id, english, indo, character, anime } = json.result[i];
			data += `_*•.* "${indo}"_\n${character} (${anime})\n\n`;
		}
//wm senn
		reply(data);
	} catch (e) {
		console.log(e);
		reply(msg.error)
	}
//wm senn
};
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Random Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Search Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'ptv': {
  await XReaction()
  if (!text) return reply(`contoh: ${prefix + command} jj epep`)

  try {
    const res = await ds.search.tiktoks(text)
    if (!res || !res.no_watermark) return reply('video ga ketemu')

    await Alice.sendMessage(
      m.chat,
      {
        video: { url: res.no_watermark },
        ptv: true,
        mimetype: 'video/mp4',
        caption: res.title || ''
      },
      { quoted: m }
    )

  } catch (e) {
    console.log('PTV ERROR:', e)
    reply('gagal bikin ptv')
  }
}
break
case 'whatmusic': {
await XReaction();
  try {

    const target = m.quoted || m
    const mime = (target.msg || target)?.mimetype || ''

    if (!/audio/.test(mime))
      return reply('🎵 Balas audio yang ingin dicari lagunya.')

    const buffer = await target.download()
    if (!buffer) return reply('❌ Gagal mengambil audio.')

    const res = await whatmusic(buffer)

    let caption = `🎶 *What Music Finder*\n\n`

    for (const r of res) {
      caption += `🎧 *Judul*  
${r.title}

👤 *Artis*  
${r.artist}

⏱️ *Durasi*  
${r.duration}

🔗 *Sumber*  
${r.url.join('\n') || '-'}

`
    }

    caption += `— ${packname}`
    reply(caption)

  } catch (e) {
    reply(`❌ ${e.message}`)
  }
}
break
case 'douyinsearch':
case 'douyin':
case 'dysearch': {
await XReaction();
  let text = m.text ? m.text.trim().split(' ').slice(1).join(' ') : '';
  
  if (!text)
    return reply(`⚠️ Kamu lupa kasih kata kunci!\nContoh: *${prefix + command} fifty fifty*`);

  try {

    const douyin = new DouyinSearchPage();
    const result = await douyin.search({ query: text });

    if (!result || !Array.isArray(result) || result.length === 0)
      return reply('😕 Tidak ada video Douyin ditemukan.');

    const vid = result[0]; // Ambil hasil pertama
    const videoUrl = vid.video?.play_addr?.url_list?.[0];

    let captionText = `🎵 *${text}*\n\n`;
    captionText += vid.desc ? `📝 *Deskripsi*: ${vid.desc}\n` : '';
    captionText += vid.author?.nickname ? `👤 *Author*: ${vid.author.nickname}\n` : '';
    captionText += `⏳ *Durasi*: ${vid.duration || 'Tidak diketahui'} detik\n`;
    captionText += `❤️ *Likes*: ${vid.statistics?.digg_count || 0}\n`;
    captionText += `💬 *Komentar*: ${vid.statistics?.comment_count || 0}\n`;
    captionText += `🔄 *Shares*: ${vid.statistics?.share_count || 0}`;

    await Alice.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: captionText.trim()
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    reply('❌ Gagal mencari video Douyin. Coba lagi nanti ya!');
  }
}
break;
case 'komiku':
case 'komiku-search':{
await XReaction();
 if (!text) return reply(`Ex : ${prefix + command} manhwa regression`);

 try {
 const res = await fetch(`https://fastrestapis.fasturl.cloud/comic/komikindo/search?name=${encodeURIComponent(text)}`);
 const json = await res.json();
 const result = json.result;

 if (!result || result.length === 0) return reply('❌ Tidak ada hasil ditemukan.');

 const selected = result.slice(0, 10);

 const cards = await Promise.all(selected.map(async (komik, i) => ({
 header: {
 title: `📖 ${komik.title}`,
 hasMediaAttachment: true,
 imageMessage: (await generateWAMessageContent({
 image: { url: komik.image }
 }, { upload: Alice.waUploadToServer })).imageMessage
 },
 body: {
 text: `⭐ *Rating:* ${komik.rating}\n🖇️ *Link:* ${komik.url}`
 },
 footer: {
 text: `🔗 Klik tombol di bawah untuk membaca langsung`
 },
 nativeFlowMessage: {
 buttons: [
 {
 name: 'cta_url',
 buttonParamsJson: JSON.stringify({
 display_text: '📘 Baca Sekarang',
 url: komik.url
 })
 }
 ]
 }
 })));

 const carousel = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: {
 text: `🔍 ʜᴀsɪʟ ᴍᴀɴʜᴡᴀ ᴅᴀʀɪ: *"${text}"*`
 },
 footer: {
 text: "Geser buat lihat semua pilihan yang tersedia~"
 },
 carouselMessage: {
 cards
 }
 })
 }
 }
 }, { quoted: m });

 await Alice.relayMessage(m.chat, carousel.message, {
 messageId: carousel.key.id
 });

 } catch (err) {
 console.error('❌ Error fetch manhwa:', err);
 reply('Gagal ngambil data manhwa, coba beberapa saat lagi.');
 }
}
 break
case 'vivadetail': {
await XReaction();
  if (!text) return reply(`contoh penggunaan:\n${prefix + command} https://vivagoal.com/pecat-branko-ivankovic-nama-shin-tae-yong-masuk-daftar-pelatih-timnas-china-selanjutnya/`)
 
  try {
    let api = `https://zenz.biz.id/berita/vivagoal/detail?url=${encodeURIComponent(text)}`
    let res = await fetch(api)
    if (!res.ok) reply('gbisa akses api nya, coba cek api nya')
 
    let json = await res.json()
    if (!json.status || !json.result) reply('tidak ditemukan data yang valid')
 
    let { title, thumbnail, published, content, url } = json.result
    let tanggal = new Date(published).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
 
    let pesan = ` *${title}*\n *Terbit:* ${tanggal}\n\n *Sumber:* ${url}\n\n${content}`
 
    await Alice.sendFile(m.chat, thumbnail, 'berita.jpg', pesan, m)
  } catch (e) {
    reply(m.chat, e.toString(), m)
  }
 
  break
}
case 'soundcloud-search': {
await XReaction();
  const cache = { version: '', id: '' }

  async function getClientID() {
    const { data: html } = await axios.get('https://soundcloud.com/', {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Exonity/1.0' }
    })

    const version = html.match(/<script>window\.__sc_version="(\d{10})"<\/script>/)?.[1]
    if (!version) return

    if (cache.version === version) return cache.id

    const scriptMatches = [...html.matchAll(/<script.*?src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+)"/g)]
    for (const [, scriptUrl] of scriptMatches) {
      const { data: js } = await axios.get(scriptUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Exonity/1.0' }
      })
      const idMatch = js.match(/client_id:"([a-zA-Z0-9]{32})"/)
      if (idMatch) {
        cache.version = version
        cache.id = idMatch[1]
        return idMatch[1]
      }
    }
  }

  function formatDuration(ms) {
    const sec = Math.floor(ms / 1000)
    const min = Math.floor(sec / 60)
    const sisa = sec % 60
    return `${min}:${sisa.toString().padStart(2, '0')}`
  }

  function formatNumber(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M'
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K'
    return n.toString()
  }

  function formatDate(dateStr) {
    if (!dateStr) return null
    const d = new Date(dateStr)
    return d.toISOString().split('T')[0]
  }

  try {
    if (!text) return reply(`Ex? : ${prefix + command} dj stecu x nana buang muka`)
    
    const client_id = await getClientID()

    const { data } = await axios.get('https://api-v2.soundcloud.com/search/tracks', {
      params: { q: text, client_id, limit: 10 },
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Exonity/1.0' }
    })

    const results = data.collection.map(track => `
*°${track.title}*
Author : ${track.user.username}
Durasi : ${formatDuration(track.full_duration)}
Like : ${formatNumber(track.likes_count || 0)}
Play : ${formatNumber(track.playback_count || 0)}
Rilis : ${formatDate(track.release_date || track.created_at)}
Link : ${track.permalink_url}
`).join('\n')

    await Alice.sendMessage(m.chat, { 
      image: { url: data.collection[0]?.artwork_url }, 
      caption: results 
    }, { quoted: m })

  } catch (e) {
    reply(e.message)
  }
}
break;

case 'soundcloud-play':
case 'playsc': {
await XReaction();
 if (!text) return reply(`Silakan berikan judul lagu.\n\n*Contoh:* ${prefix + command} Avenged Sevenfold Dear God`);
 
 try {
 const searchUrl = `https://xyro.site/search/soundcloud?q=${encodeURIComponent(text)}`;
 const searchResponse = await fetchJson(searchUrl);

 if (!searchResponse.status || searchResponse.result.length === 0) {
 await react('❌');
 return reply(`❌ Maaf, lagu dengan judul "${text}" tidak dapat ditemukan.`);
 }

 const songDetails = searchResponse.result[0]; 
 const downloadApiUrl = `https://xyro.site/download/soundcloud?url=${encodeURIComponent(songDetails.url)}`;
 const downloadResponse = await fetchJson(downloadApiUrl);

 if (!downloadResponse.status || !downloadResponse.result.download_url) {
 await react('❌');
 return reply('❌ Gagal mendapatkan link unduhan untuk lagu ini. Coba lagi nanti.');
 }

 const audioUrl = downloadResponse.result.download_url;

 const caption = `
🥳 *LAGU SEDANG DIPUTAR!* 🎉

📀 *Judul:* ${songDetails.title}
🎤 *Artis:* ${songDetails.author.name}
⏰ *Durasi:* ${songDetails.duration}
👀 *Diputar:* ${songDetails.plays}
💖 *Suka:* ${songDetails.likes}
🗓️ *Tanggal Rilis:* ${songDetails.release_date}

⏬ *File audio akan segera dikirim... Sabar ya!* 🙏
`;

 // Mengirim pesan informasi dengan gambar thumbnail
 await Alice.sendMessage(m.chat, {
 image: { url: songDetails.thumbnail },
 caption: caption
 }, { quoted: m });
 
 // Mengirim file audio secara terpisah
 await Alice.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mpeg',
 // Menambahkan ptt: true jika ingin dikirim sebagai Voice Note
 // ptt: true 
 }, { quoted: m });

 } catch (error) {
 console.error('Error pada perintah play:', error);
 await react('❌'); // Memberi reaksi gagal
 reply('Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.');
 }
}
break;
case 'jkt48': {
await XReaction();
  try {
const axios = require("axios");
    const liveRes = await axios.get('https://48intensapi.my.id/api/idnlive/jkt48');
    const liveList = liveRes.data?.data || [];
    if (!Array.isArray(liveList) || liveList.length === 0) {
      return reply('Tidak ada member JKT48 yang sedang live saat ini.');
    }
    for (let i = 0; i < liveList.length; i++) {
      const mbr = liveList[i];
      const nama = mbr.user.name;
      const username = mbr.user.username;
      const judul = mbr.title;
      const viewers = mbr.view_count;
      const waktu = new Date(mbr.live_at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      const link = `https://www.idn.app/${username}/live/${mbr.slug}`;
      const img = mbr.image;
      await Alice.sendMessage(m.chat, {
        text: `*${nama} (@${username}) sedang LIVE!*\n\n` +
              `• *Judul:* ${judul}\n` +
              `• *Penonton:* ${viewers}\n` +
              `• *Sejak:* ${waktu}\n\n` +
              `Tonton sekarang:\n${link}`,
        contextInfo: {
          externalAdreply: {
            showAdAttribution: true,
            title: `${nama} sedang LIVE!`,
            body: `Judul: ${judul}`,
            mediaUrl: link,
            mediaType: 1,
            renderLargerThumbnail: true,
            thumbnailUrl: img,
            sourceUrl: link
          }
        }
      }, { quoted: m });
    }
  } catch (e) {
    console.error('ERROR JKT48:', e);
    reply(`Gagal mengambil data JKT48: ${e.message}`);
  }
}
break
case 'waktudunia': {
await XReaction();
async function getWorldTime() {
    const url = 'https://onlinealarmkur.com/world/id/';
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        let hasil = [];

        $('.flex.items-center.space-x-3').each((index, element) => {
            const bendera = $(element).find('.avatar .text-2xl').text().trim();
            const kota = $(element).find('.city-name').text().trim();
            const zona = $(element).find('.city-time').attr('data-tz');

            if (zona) {
                const realTime = moment().tz(zona).format('ddd - HH:mm');
                hasil.push({ bendera, kota, waktu: realTime });
            }
        });

        return hasil;
    } catch (error) {
        return [];
    }
}
    let hasilWaktu = await getWorldTime();
    if (hasilWaktu.length === 0) {
        return reply('❌ Gagal mengambil data waktu dunia!');
    }

    let pesanWaktu = '*🕰️ Waktu Dunia Saat Ini 🕰️*\n\n';
    hasilWaktu.forEach(item => {
        pesanWaktu += `${item.bendera} *${item.kota}* - ${item.waktu}\n`;
    });

    await Alice.sendMessage(m.chat, { text: pesanWaktu }, { quoted: m });
};
break
case 'cerpen': {
await XReaction();
async function getCerpen() {
try {
const anu = await axios.get("http://cerpenmu.com/100-cerpen-kiriman-terbaru")
const $ = cheerio.load(anu.data)
const dbres = []

$("a[title]").each((a, b) => {
const judul = $(b).attr("title")
const link = $(b).attr("href")
dbres.push({ judul, link })
})

return dbres
} catch (err) {
console.log(err)
}
}

const rs = await getCerpen()
if (rs.length === 0) return Alice.sendMessage(m.chat, { text: "Gagal Mengambil Berita" }, { quoted:m })
await Alice.sendMessage(m.chat, { text: `RESULT\n\n`+rs.map(a => `JUDUL CERPEN: ${a.judul}\nLINK: ${a.link}`).join("\n\n") }, { quoted: m})
}
break
case "searchspotify":
case "spotifysearch":
case "spotifys":
case "ssp": {
    await XReaction()

    if (!text) {
        return reply(`Example: ${prefix + command} judul lagu`)
    }

    try {
        const res = await SpotifySearch(text)

        if (!res.status) {
            return reply(`❌ ${res.message}`)
        }

        const lagu = res.result

        let hasil = `*HASIL PENCARIAN SPOTIFY*\n\n`

        hasil += `*Judul* : ${lagu.name}\n`
        hasil += `*Artis* : ${lagu.artists}\n`
        hasil += `*Album* : ${lagu.album}\n`
        hasil += `*URL* : ${lagu.url}\n\n`

        hasil += `Ketik ${prefix}spotify-download ${lagu.url}\n`
        hasil += `untuk download music Spotify!`

        if (lagu.image) {
            await Alice.sendMessage(m.chat, {
                image: { url: lagu.image },
                caption: hasil
            }, { quoted: m })
        } else {
            await Alice.sendMessage(m.chat, {
                text: hasil
            }, { quoted: m })
        }

    } catch (e) {
        console.log(e)
        reply("Error occurred while searching!")
    }
}
break
case 'waifu': {
  await XReaction();
  try {
    let res = await axios({
      method: 'GET',
      url: 'https://api.zenzxz.my.id/anime/Waifu',
      responseType: 'arraybuffer'
    });

    await Alice.sendMessage(m.chat, {
      image: Buffer.from(res.data),
      caption: 'Nih waifumu~ 🤗'
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    reply('Lagi error bang, coba lagi nanti.');
  }
}
break
case 'hentais':
case 'hentai': {
await XReaction();
  if (!args.length) return reply(`Masukkan judul yang ingin dicari!\nContoh: ${prefix + command} hinata`)

async function searchHentai(query) {
  try {
    const { data } = await axios.get("https://hentai.tv/?s=" + encodeURIComponent(query))
    const $ = cheerio.load(data)
    const result = []
    
    $('div.flex > div.crsl-slde').each((i, el) => {
      const thumbnail = $(el).find('img').attr('src')
      const title = $(el).find('a').text().trim()
      const views = $(el).find('p').text().trim()
      const url = $(el).find('a').attr('href')
      result.push({ thumbnail, title, views, url })
    })

    return {
      coder: 'SaaOfc',
      warning: 'failed',
      result
    }
  } catch (err) {
    return { error: 'error', message: err.message }
  }
}

  const res = await searchHentai(args.join(" "))
  if (!res || res.result.length === 0) return reply('Tidak ditemukan!')

  let teks = `*Hasil Pencarian dari Hentai.tv*\n\n`
  for (let i = 0; i < Math.min(5, res.result.length); i++) {
    const x = res.result[i]
    teks += `*${x.title}*\nViews: ${x.views}\nURL: ${x.url}\n\n`
  }

  await Alice.sendMessage(m.chat, {
    text: teks.trim(),
    contextInfo: {
      externalAdreply: {
        title: "Hentai Search",
        body: packname,
        thumbnailUrl: res.result[0]?.thumbnail,
        sourceUrl: res.result[0]?.url,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}
break

case 'jadwaltv': {

  if (!text) return reply('⚠️ Contoh: *.jadwaltv rcti*')

  try {
    const channel = text.toLowerCase().trim()
    const res = await axios.get(`https://api.zenzxz.my.id/info/jadwaltv?channel=${encodeURIComponent(channel)}`)
    const data = res.data

    if (!data.status || !data.jadwal || !data.jadwal.length) 
      return reply(`🙅 Tidak ada jadwal ditemukan untuk channel: ${channel.toUpperCase()}`)

    let teks = `📺 *Jadwal TV ${data.channel.toUpperCase()}*\n\n`
    data.jadwal.slice(0, 10).forEach((item, i) => {
      teks += `${i+1}. ⏰ ${item.time}\n   🎬 ${item.program}\n\n`
    })
    if (data.jadwal.length > 10) teks += `…dan ${data.jadwal.length - 10} acara lainnya.`

    await Alice.sendMessage(m.chat, { text: teks }, { quoted: m })
  } catch (e) {
    console.error('jadwaltv error:', e.message)
    reply('❌ Gagal mengambil jadwal TV.')
  }
}
break

case 'jadwalbola':
case 'jdbola':
case 'bola': {
await XReaction();

  try {
    const res = await axios.get('https://api.zenzxz.my.id/info/jadwalbola')
    const data = res.data
    if (!data.status || !data.data || !data.data.length) 
      return reply('🙅 Tidak ada jadwal bola ditemukan.')

    let teks = `⚽ *Jadwal Pertandingan Sepakbola*\n📅 Tanggal: ${data.date}\n📊 Total: ${data.total} pertandingan\n\n`

    data.data.slice(0, 10).forEach((m, i) => {
      teks += `${i+1}. *${m.team1}* vs *${m.team2}*\n`
      teks += `   🏆 Liga: ${m.liga}\n`
      teks += `   ⏰ Waktu: ${m.time}\n`
      teks += `   📍 Lokasi: ${m.location}\n`
      teks += `   🔗 Detail: ${m.detail}\n\n`
    })

    if (data.data.length > 10) teks += `…dan ${data.data.length - 10} pertandingan lainnya.`

    await Alice.sendMessage(m.chat, { text: teks }, { quoted: m })
  } catch (e) {
    console.error('jadwalbola error:', e.message)
    reply('❌ Gagal mengambil jadwal bola.')
  }
}
break

case 'alkitab': {
await XReaction();
    if (!text) return reply(`teksnya mana?\n\ncontoh: ${prefix + command} kejadian`)
    let res = await axios.get(`https://alkitab.me/search?q=${encodeURIComponent(text)}`, { headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36" } })

    let $ = cheerio.load(res.data)
    let result = []
    $('div.vw').each(function (a, b) {
        let teks = $(b).find('p').text().trim()
        let link = $(b).find('a').attr('href')
        let title = $(b).find('a').text().trim()
        result.push({ teks, link, title })
    })

    let caption = result.map(v => `${v.title}\n${v.teks}`).join('\n────────\n')
    reply(caption)
}
break

case 'jkt48news': {
await XReaction();

async function jktNews(lang = "id") {
   let { data } = await axios.get(`https://jkt48.com/news/list?lang=${lang}`);
   let $ = cheerio.load(data);

   const news = [];
   
   $(".entry-news__list").each((index, element) => {
      const title = $(element).find("h3 a").text();
      const link = $(element).find("h3 a").attr("href");
      const date = $(element).find("time").text();

      news.push({ title, link: "https://jkt48.com" + link, date });
   });

   return news;
}

   try {
      let data = await jktNews();
      if (data.length === 0) return reply("Tidak Ada Berita Terbaru Hari Ini, Silahkan Kembali.")
      let result = data.map((res, id) => {
        return `${id + 1}, ${res.title}\nLink: ${res.link}\nTanggal Mulai: ${res.date}`
        }).join("\n\n");
        await reply(result)
   } catch (error) {
      throw "Gagal Mencari Berita."
      console.error(error.message)
   }
}
break
case 'resepsearch': {
await XReaction();
  try {
    if (!text) return reply(`Please provide a dish name to search!\n\nExample: ${prefix + command} Nasi Goreng`);

async function resep(makanan) {
  let BASE = `https://cookpad.com/id/cari/${encodeURIComponent(makanan)}`;
  let { data } = await axios.get(BASE);

  let $ = cheerio.load(data);
  let hasil = [];

  $("li[data-search-tracking-target='result']").each((i, el) => {
    let namaResep = $(el).find("h2 a").text().trim();
    let linkResep = "https://cookpad.com" + $(el).find("h2 a").attr("href");
    let waktuMasak = $(el).find(".mise-icon-time + .mise-icon-text").text().trim();
    let pembuat = $(el).find(".flex.items-center span.text-cookpad-gray-600").text().trim();

    hasil.push({ namaResep, linkResep, waktuMasak, pembuat });
  });

  return hasil;
}

    const results = await resep(text);

    if (results.length === 0) {
      return reply('No recipes found for the given dish name.');
    }

    let message = `
🍽️ *Recipes Found!* 🍽️

`;
    results.forEach((res, index) => {
      message += `
🔹 *Recipe ${index + 1}*
- 🍲 Name: ${res.namaResep}
- ⏲️ Cooking Time: ${res.waktuMasak}
- 👨‍🍳 Created by: ${res.pembuat}
- 🔗 [View Recipe](${res.linkResep})
`;
    });

    await Alice.sendMessage(m.chat, { text: message, footer: packname }, { quoted: m });
  } catch (error) {
    console.error(error);
    reply("An error occurred: " + error.message);
  }
};
break

case 'animexin' : {
await XReaction();
  try {
    if (!text) { return reply(`Please provide a keyword or an action (update/detail/search)!\n\nExample:\n${prefix + command} update`);
    }

    const args = text.split(' ');
    const action = args[0].toLowerCase();
    const query = args.slice(1).join(' ');

    if (action === 'update') {
      reply('Fetching latest anime updates... Please wait...');
      const result = await animexin.animexinUpdate();
      if (result && result.length > 0) {
        let message = '🔍 *Latest Anime Updates* 🔍\n\n';
        result.forEach(anime => {
          message += `📺 *Title*: ${anime.title}\n🔗 *URL*: ${anime.url}\n🖼️ *Image*: ${anime.image}\n🎬 *Episode*: ${anime.episode}\n📦 *Type*: ${anime.type}\n\n`;
        });
        reply(message);
      } else {
        reply('No updates found.');
      }
    } else if (action === 'detail' && query) {
      reply('Fetching anime details... Please wait...');
      const result = await animexin.animexinDetail(query);
      if (result) {
        reply(`🔍 *Anime Details* 🔍\n\n${result}`);
      } else {
        reply('No details found for the provided URL.');
      }
    } else if (action === 'search' && query) {
      reply('Searching for anime... Please wait...');
      const result = await animexin.animexinSearch(query);
      if (result) {
        reply(`🔍 *Search Results* 🔍\n\n${result}`);
      } else {
        reply('No results found for the provided keyword.');
      }
    } else {
      reply(`Invalid command or missing query. Please use the following format:\n\n${prefix + command} update\n${prefix + command} detail <URL>\n${prefix + command} search <keyword>`);
    }
  } catch (error) {
    console.error(error);
    reply('Error: ' + error.message);
  }
};
break

    case "nontonanime-latest": {
await XReaction();
        const list = await nontonAnime.latest();
        if (!list.length) return reply("Gagal mengambil data anime terbaru.");
        for (let i = 0; i < Math.min(3, list.length); i++) {
          const Xyroo = list[i];
          await Alice.sendMessage(m.chat, {
            image: { url: Xyroo.thumbnail },
            caption: `*${Xyroo.title}*\nEpisode: ${Xyroo.episode}\nTipe: ${Xyroo.type}\nURL: ${Xyroo.url}`
          }, { quoted: m });
        }
      }
      break;

    case "nontonanime-upcoming": {
await XReaction();
        const list = await nontonAnime.upcoming();
        if (!list.length) return reply("Tidak ada anime upcoming ditemukan.");
        for (let i = 0; i < Math.min(3, list.length); i++) {
          const Xyroo= list[i];
          await Alice.sendMessage(m.chat, {
            image: { url: Xyroo.thumbnail },
            caption: `*${Xyroo.title}*\nEpisode: ${Xyroo.episode}\nTipe: ${Xyroo.type}\nURL: ${Xyroo.url}`
          }, { quoted: m });
        }
      }
      break;

    case "nontonanime-search": {
await XReaction();
        if (!args[0]) return reply("Masukkan judul anime yang ingin dicari!");
        const list = await nontonAnime.search(args.join(" "));
        if (!list.length) return reply("Anime tidak ditemukan.");
        for (let i = 0; i < Math.min(3, list.length); i++) {
          const Xyroo= list[i];
          await Alice.sendMessage(m.chat, {
            image: { url: Xyroo.thumbnail },
            caption: `*${Xyroo.title}*\nEpisode: ${Xyroo.episode}\nTipe: ${Xyroo.type}\nURL: ${Xyroo.url}`
          }, { quoted: m });
        }
      }
      break;
      
case 'myanimelist': {
  if (!q) return reply(`Example: ${prefix + command} one piece`)
  let anime = await fetch(`https://api.jikan.moe/v4/anime?q=${q}`)
  let res = await anime.json()
  if (!res.data || res.data.length === 0) return reply('Anime tidak ditemukan!')
  let result = res.data[0]
  let teks = `*${result.title}*\n\n`
  teks += `*Judul Jepang:* ${result.title_japanese || '-'}\n`
  teks += `*Tipe:* ${result.type || '-'}\n`
  teks += `*Episode:* ${result.episodes || '-'}\n`
  teks += `*Status:* ${result.status || '-'}\n`
  teks += `*Tanggal Tayang:* ${result.aired?.string || '-'}\n`
  teks += `*Skor:* ${result.score || '-'}\n`
  teks += `*Produser:* ${(result.producers?.map(p => p.name).join(', ')) || '-'}\n`
  teks += `*Studio:* ${(result.studios?.map(s => s.name).join(', ')) || '-'}\n`
  teks += `*Genre:* ${(result.genres?.map(g => g.name).join(', ')) || '-'}\n`
  teks += `*Durasi:* ${result.duration || '-'}\n`
  teks += `*Rating:* ${result.rating || '-'}\n`
  teks += `\n*Sinopsis:* ${result.synopsis || '-'}\n`
  teks += `\n*Link:* ${result.url}`
  Alice.sendMessage(m.chat, {
    image: { url: result.images.jpg.image_url },
    caption: teks
  }, { quoted: m })
}
break
        
case 'yahooimg':
case 'yahooimage' : {
await XReaction();
if (!text) return reply("Ingin Mencari Apa?");
    try {
        const images = await Yimg(text);
        if (images.length === 0) {
            reply("Tidak ada gambar yang ditemukan");
        } else {
            const image = images[0];
            let imageText = `*Judul :* _${image.title}_\n`;
            imageText += `*Ukuran :* _${image.size}_\n`;
            imageText += `*Dimensi :* _${image.width}x${image.height}_\n\n`;
            imageText += `*Sumber :* _${image.url}_\n`;

            await Alice.sendMessage(m.chat, {
                image: { url: image.url },
                caption: imageText,
            }, { quoted: m });
        }
    } catch (error) {
        reply("❌ Terjadi kesalahan saat mengambil gambar.");
        console.error(error);
    }
  }
break

case 'cuaca' :
case 'cuacakota' : {
    if (!text) return reply(`Masukkan nama kota!\nContoh: ${prefix + command} pandeglang`)

    try {
        let res = await fetch(`https://fastrestapis.fasturl.cloud/search/weather?location=${encodeURIComponent(text)}`)
        let json = await res.json()

        if (json.status !== 200) {
            return reply('Gagal mengambil data cuaca, pastikan kota valid.')
        }

function getWeatherEmoji(condition) {
    condition = condition.toLowerCase()
    if (condition.includes('cloud')) return '☁️'
    if (condition.includes('rain')) return '🌧️'
    if (condition.includes('sun')) return '☀️'
    if (condition.includes('clear')) return '🌞'
    if (condition.includes('storm')) return '⛈️'
    if (condition.includes('snow')) return '❄️'
    if (condition.includes('fog')) return '🌫️'
    return '⛅'
}

        let r = json.result
        let emojiCuaca = getWeatherEmoji(r.condition)

        // 1
        await Alice.sendMessage(m.chat, {
            location: {
                degreesLatitude: parseFloat(r.latitude),
                degreesLongitude: parseFloat(r.longitude)
            }
        }, { quoted: m })

        // 2
        let caption = `
*「 INFO CUACA 」*
📍 *Kota:* ${r.city}
${emojiCuaca} *Kondisi:* ${r.condition}
🌡️ *Suhu:* ${r.temperature}
💧 *Kelembaban:* ${r.humidity}
🌬️ *Angin:* ${r.wind}
🌧️ *Curah Hujan:* ${r.precipitation}
☁️ *Tutup Awan:* ${r.cloudCover}
🔭 *Jarak Pandang:* ${r.visibility}
🌅 *Matahari Terbit:* ${r.sunrise}
🌇 *Matahari Terbenam:* ${r.sunset}
`

        await reply(caption)
    } catch (e) {
        console.log('Error saat mengambil data cuaca:', e)
        reply('Terjadi kesalahan saat memproses permintaan cuaca.')
    }
}
break

case 'sanime':
case 'searchanime':
case 'kuronime': {
  if (!q) return reply('🔎 *Silakan masukkan judul anime yang ingin kamu cari.*')

  try {
    const axios = require("axios")
    const cheerio = require("cheerio")
    const url = `https://kuronime.biz/page/1/?s=${encodeURIComponent(q)}`
    const { data } = await axios.get(url)
    const $ = cheerio.load(data)
    const results = []
    $(".listupd article").each((_, el) => {
      const anchor = $(el).find("a")
      const title = anchor.find("h4").text().trim()
      const link = anchor.attr("href")
      const image = anchor.find("img.lazyload").last().attr("data-src")
      const rating = anchor.find("i").text().trim()
      const type = anchor.find(".type").text().trim()
      results.push({ title, link, image, rating, type })
    })
    if (!results.length) return reply('Anime tidak ditemukan, coba kata kunci lain.')
    let message = `Hasil pencarian untuk *${q}*:\n\n`
    results.forEach((anime, index) => {
      message += `*${index + 1}. ${anime.title}*\n`
      message += `   🔗 *Link*: ${anime.link}\n`
      message += `   📊 *Rating*: ${anime.rating}\n`
      message += `   📌 *Type*: ${anime.type}\n\n`
    })
    Alice.sendMessage(m.chat, {
      text: message.trim(),
      contextInfo: {
        externalAdreply: {
          title: "Kuronime Search",
          body: packname,
          thumbnailUrl: results[0]?.image || '',
          sourceUrl: results[0]?.link || '',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })
  } catch (err) {
    console.log(err)
    XRR()
  }
}
break

case 'ffw': {
await XReaction();
  try {
      const hasil = await FFW();

      if (typeof hasil === 'string' && hasil.startsWith('Error')) {
          reply(hasil);
      } else if (hasil.length === 0) {
          reply('*Tidak ada informasi senjata yang ditemukan!*');
      } else {
          let result = `*Daftar Senjata Free Fire*\n\n`;
          hasil.forEach((item, index) => {
              result += `*Nama Senjata :* _${item.name}_\n`;
              result += `*Damage :* _${item.damage}_\n`; 
              result += `*Kategori :* _${item.tags.join(', ')}_\n\n`;
              result += `*Deskripsi :* _${item.description}_\n\n========================\n\n`;
          });
          reply(result);
      }
  } catch (error) {
      console.error(error);
      XRR()
  }
}
break
case 'wikimedia': {
await XReaction();
  if (!text) return reply(`*Mau Cari Gambar Apa di Wikimedia?*`);
  try {
    const images = await WikiMedia(text);
    if (!images || images.length === 0) {
      return reply("⚠️ *Tidak ditemukan gambar dengan pencarian tersebut di Wikimedia.*");
    }
    function shuffleArray(array) {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
    shuffleArray(images);
    const selectedImages = images.slice(0, 5);
    let push = [];
    let i = 1;
    async function createImage(url) {
      const { imageMessage } = await generateWAMessageContent({
        image: { url }
      }, { upload: Alice.waUploadToServer });
      return imageMessage;
    }
    for (let img of selectedImages) {
      push.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `*Pencarian : ${text}*`
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `*Gambar ${i++}*`,
          hasMediaAttachment: true,
          imageMessage: await createImage(img.image)
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              "name": "cta_url",
              "buttonParamsJson": `{"display_text":"Wikimedia","url":"${img.source}","merchant_url":"${img.source}"}`
            }
          ]
        })
      });
    }
    const bot = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `*Berhasil Memuat 5 Gambar*`
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: [...push]
            })
          })
        }
      }
    }, {});

    await Alice.relayMessage(m.chat, bot.message, {
      messageId: bot.key.id
    }).catch((err) => reply(mess.error));

  } catch (error) {
    console.error("Error:", error.message);
    XRR()
  }
}
break
case 'playstore':
case 'playstoresearch':
case 'ps': {
    await XReaction()

    if (!text) {
        return reply(`Example: ${prefix + command} whatsapp`)
    }

    try {

        const res = await PlaystoreSearch(text)

        if (!res.apps || !res.apps.length) {
            return reply('❌ Aplikasi tidak ditemukan')
        }

        let hasil = `*📱 PLAYSTORE SEARCH*\n\n`

        for (let i = 0; i < Math.min(10, res.apps.length); i++) {

            const app = res.apps[i]

            hasil += `*${i + 1}. ${app.name || '-'}*\n`
            hasil += `◦ Developer : ${app.developer || '-'}\n`
            hasil += `◦ Rating : ${app.rating || '-'}\n`
            hasil += `◦ Package : ${app.package_id || '-'}\n`
            hasil += `◦ URL : ${app.play_store_url || '-'}\n\n`

        }

        const thumb = res.apps[0]?.icon_url

        if (thumb) {

            await Alice.sendMessage(m.chat, {
                image: { url: thumb },
                caption: hasil
            }, { quoted: m })

        } else {

            await Alice.sendMessage(m.chat, {
                text: hasil
            }, { quoted: m })

        }

    } catch (e) {

        console.log(e)
        reply(`❌ Error: ${e.message || e}`)

    }
}
break
case 'caribuku': {
await XReaction();
  const query = args.join(" ");
  if (!query) return reply("Cari buku apa?");

  try {
    const hasil = await BookSearch(query);

    if (hasil.length === 0) {
      reply("🔍 *Tidak Ada Hasil, Pastikan Nama Buku Valid*");
    } else {
      let result = `*Hasil Pencarian Dari : ${query}*\n\n`;
      hasil.forEach((buku, index) => {
        result += `*${index + 1}. ${buku.title}*\n`;
        result += `*Rating :* _${buku.rating}_\n\n`;
        result += `*Link Buku :* \n_${buku.link}_\n\n==============================\n`;
      });
      reply(result);
    }
  } catch (error) {
    console.error(error);
    XRR()
  }
}
break

case 'lirik2': {
  if (!text) return reply(`Masukkan judul lagu atau keyword lirik.\n\nContoh:\n.lirik new jeans romanized`)
await XReaction();
  try {
    let res = await fetch(`https://api.betabotz.eu.org/api/search/lirik?apikey=beta-gilang&lirik=${encodeURIComponent(text)}`)
    let json = await res.json()

    if (!json.result) return Alice.sendMessage(m.chat, {
      text: `⚠️ Lirik tidak ditemukan untuk: *${text}*`
    }, { quoted: m })

    let r = json.result
    let cap = `🎼 *Lirik Lagu Ditemukan!*\n\n`
    cap += `📌 *Title:* ${r.title}\n`
    cap += `🎤 *Artist:* ${r.artist}\n`
    cap += `🔗 *Link:* ${r.url}\n\n`
    cap += `📝 *Lyrics:*\n${r.lyrics.substring(0, 4000)}` // antisipasi teks panjang

    await Alice.sendMessage(m.chat, {
      image: { url: r.image },
      caption: cap
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    Alice.sendMessage(m.chat, {
      text: `❌ Terjadi error saat mengambil lirik.`
    }, { quoted: m })
  }
}
break

case 'lirik':
case 'liriklagu': {
;
  await XReaction();

  if (!text) return reply(`Judul lagu?\nExample: duka`);

  // --- Semua fungsi bantu & fetch disatukan di sini ---
  const axios = require('axios');

  const norm = (s = '') => String(s)
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')     // hapus diakritik
    .replace(/[^a-z0-9\s]/g, ' ')        // sisakan alnum & spasi
    .replace(/\s+/g, ' ')
    .trim();

  const scoreItem = (query, item) => {
    const q = norm(query);
    const t = norm(item.title || item.trackName || item.name || '');
    const a = norm(item.artistName || item.artist || '');
    let score = 0;
    if (t && (t.includes(q) || q.includes(t))) score += 60;
    if (a && q.includes(a)) score += 15;
    if (item.syncedLyrics) score += 10; // bonus jika ada LRC
    if (item.plainLyrics) score += 5;
    return score;
  };

  const pickBest = (query, results = []) => {
    if (!Array.isArray(results) || !results.length) return null;
    return [...results].sort((a, b) => scoreItem(query, b) - scoreItem(query, a))[0];
  };

  const safeFileName = (s = 'lyrics') =>
    (s.replace(/[^\w\-]+/g, '_').slice(0, 80) || 'lyrics');

  const parseQuery = (qText) => {
    if (!qText) return { combined: '' };
    const parts = qText.split(' - ');
    const title = parts[0]?.trim() || '';
    const artist = parts[1]?.trim();
    return { combined: artist ? `${title} ${artist}` : title || qText };
  };

  const lyrics = async (title) => {
    if (!title) throw new Error('Title is required');
    const { data } = await axios.get(
      `https://lrclib.net/api/search?q=${encodeURIComponent(title)}`,
      {
        headers: {
          referer: `https://lrclib.net/search/${encodeURIComponent(title)}`,
          'user-agent':
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
        },
        timeout: 20000
      }
    );
    return data;
  };
  // --- end helper ---

  try {
    const { combined } = parseQuery(text);

    // 1) Cari ke LrcLib
    const results = await lyrics(combined);
    if (!results || results.length === 0) {
      return reply('Tidak Ditemukan');
    }

    // 2) Pilih hasil paling relevan
    const best = pickBest(combined, results);
    if (!best) return reply('Tidak Ditemukan');

    // 3) Normalisasi field
    const title = best.title || best.trackName || best.name || 'Unknown Title';
    const artistName = best.artistName || best.artist || 'Unknown Artist';
    const albumName = best.albumName || best.album || null;
    const duration = best.duration || null;
    const plainLyrics = best.plainLyrics || best.lyrics || null;
    const syncedLyrics = best.syncedLyrics || null;

    const header =
      `🎵 *${title}* — *${artistName}*` +
      (albumName ? `\n💿 ${albumName}` : '') +
      (duration ? `\n⏱️ ${Math.round(duration)}s` : '');

    // 4) Kirim LRC jika ada
    if (syncedLyrics) {
      const fileName = `${safeFileName(`${title}-${artistName}`)}.lrc`;
      await Alice.sendMessage(
        m.chat,
        {
          document: Buffer.from(syncedLyrics, 'utf-8'),
          mimetype: 'text/plain',
          fileName,
          caption: `${header}\n\nSumber: LrcLib (lrclib.net)`
        },
        { quoted: m }
      );
      break;
    }

    // 5) Fallback: kirim lirik teks
    if (plainLyrics) {
      await Alice.sendMessage(
        m.chat,
        { text: `${header}\n\n${plainLyrics}\n\nSumber: LrcLib (lrclib.net)` },
        { quoted: m }
      );
      break;
    }

    // 6) Jika dua-duanya kosong
    reply('Lirik tidak tersedia. Coba judul lain atau tambahkan artis.');

  } catch (error) {
    console.error('Lyrics error:', error?.message || error);
    reply('Tidak Ditemukan');
  }
}
break;

case 'samehadakudetail': {
await XReaction();
    if (!text) return reply('Link?');
    
    let cari = await (await fetch(`https://api.siputzx.my.id/api/animesamehadaku/detail?link=${text}`)).json();
    if (cari.status) {
        let cap = '*_LIST ALL EPISODE_*' + '\n\n';
        for (let episode of cari.data.episodes) {
            cap += `*🏷️ TITLE :* ${episode.title}\n*🀄 DATE :* ${episode.date}\n*🔗 LINK :* ${episode.link}\n\n`;
        }
        await Alice.sendMessage(m.chat, { image: { url: cari.data.thumbnail }, caption: cap }, { quoted: m });
    } else {
        await reply('Data tidak ditemukan.');
    }
}
break;
case 'samehadakusearch': {
await XReaction();
    if (!text) return reply('name?');

    let cari = await (await fetch(`https://api.siputzx.my.id/api/anime/samehadaku/search?query=${text}`)).json();
    if (cari.status) {
        let cap = '_Samehadaku Search From: *' + text + '*_\n\n';
        for (let ciro of cari.data) {
            cap += `*🏷️ TITLE :* ${ciro.title}\n*🃏 RATING :* ${ciro.star}\n*🏯 GENRE :* ${ciro.genre.join(', ')}\n*☃️ STATUS :* ${ciro.type.join(', ')}\n*🔗 LINK :* ${ciro.link}\n*🄄 DESKRIPSI :*\n${ciro.description}\n\n`;
        }
        await Alice.sendMessage(m.chat, { image: { url: cari.data[0].thumbnail }, caption: cap }, { quoted: m });
    } else {
        await reply('Data tidak ditemukan.');
    }
}
break;

case 'apksearch': {
await XReaction();
    if (!text) return reply('apk name?');
    
    try {
        let response = await fetch(`https://api-Alice.vercel.app/api/apk?action=search&query=` + text);
        let apkData = await response.json();

        if (apkData.status === 200) {
            let results = apkData.data;
            let message = 'Here are the results:\n\n';

            results.forEach(app => {
                message += `*Title:* ${app.title}\n`;
                message += `*Developer:* ${app.developer || 'N/A'}\n`;
                message += `*Version:* ${app.version || 'N/A'}\n`;
                message += `*Rating:* ${app.rating || 'N/A'}\n`;
                message += `*Link:* ${app.link}\n`;
                message += `![Image](${app.image})\n\n`;
            });

            reply(message);
        } else {
            reply('errrorr');
        }
    } catch (e) {
        reply('errrorrr');
    }
}
break;
case 'apkdetail': {
await XReaction();
    if (!text) return reply('apk id or name');

    try {
        let response = await fetch(`https://api-Alice.vercel.app/api/apk?action=detail&url=` + text);
        let apkDetail = await response.json();

        if (apkDetail.status === 200) {
            let app = apkDetail.data;
            let message = `*Title:* ${app.title}\n`;
            message += `*Version:* ${app.version}\n`;
            message += `*Genre:* ${app.genre}\n`;
            message += `*Rating:* ${app.rating} (${app.votes} votes)\n`;
            message += `*Developer:* ${app.developer}\n`;
            message += `*Requirements:* ${app.requirements}\n`;
            message += `*Downloads:* ${app.downloads}\n`;
            message += `*Download Link:* ${app.download}\n`;
            message += `*Play Store:* ${app.playstore}\n`;
            message += `*Description:* ${app.description}\n\n`;
            message += `*What's New:* ${app.whatsnew}\n`;
            message += `*Video:* ${app.video}\n\n`;
            message += `*Related Apps:*\n`;

            app.related.forEach(relatedApp => {
                message += `- [${relatedApp.title}](${relatedApp.link}) by ${relatedApp.developer} (Version: ${relatedApp.version}, Rating: ${relatedApp.rating})\n`;
            });

            reply(message);
        } else {
            reply('ada masalah');
        }
    } catch (e) {
        reply('ada masalah');
    }
}
break;

case "spotifyplay":
case "spplay":
case "splay": {
    await XReaction()

    if (!text) {
        return reply(`Example: ${prefix + command} monolog pamungkas`)
    }

    try {

        let trackUrl = text
        let lagu = null

        const isUrl = text.includes("open.spotify.com/track")

        if (!isUrl) {

            await reply(`🔍 Mencari lagu *${text}*...`)

            const searchRes = await SpotifySearch(text)

            if (!searchRes.status) {
                return reply(`❌ ${searchRes.message}`)
            }

            lagu = searchRes.result
            trackUrl = lagu.url

            const searching =
            `*🎵 Lagu Ditemukan*\n\n` +
            `◦ *Judul* : ${lagu.name}\n` +
            `◦ *Artis* : ${lagu.artists}\n` +
            `◦ *Album* : ${lagu.album}\n\n` +
            `⏳ Sedang mengunduh audio...`

            await Alice.sendMessage(m.chat,
                lagu.image
                ? {
                    image: { url: lagu.image },
                    caption: searching
                }
                : {
                    text: searching
                },
            { quoted: m })

        } else {
            await reply(`⏳ Sedang mengunduh musik Spotify...`)
        }

        const dlRes = await SpotifyDl(trackUrl)

        if (!dlRes.status) {
            return reply(`❌ ${dlRes.message}`)
        }

        const data = dlRes.result

        const thumb = data.album?.images?.[0]?.url || lagu?.image

        const caption =
        `*🎶 SPOTIFY PLAY*\n\n` +
        `◦ *Judul* : ${data.title}\n` +
        `◦ *Artis* : ${data.artist.map(v => v.name).join(" & ")}\n` +
        `◦ *Status* : ✅ Berhasil`

        if (thumb) {
            await Alice.sendMessage(m.chat, {
                image: { url: thumb },
                caption
            }, { quoted: m })
        } else {
            await Alice.sendMessage(m.chat, {
                text: caption
            }, { quoted: m })
        }

        const safeName = data.title.replace(/[\\/:*?"<>|]/g, "")

        await Alice.sendMessage(m.chat, {
            audio: { url: data.download },
            mimetype: "audio/mpeg",
            fileName: `${safeName}.mp3`
        }, { quoted: m })

    } catch (err) {
        console.error(err)
        reply(`❌ Error: ${err.message || err}`)
    }
}
break;

case 'sticker-search': {
await XReaction();
stickersearch = (query) => {
	return new Promise((resolve, reject) => {
		axios.get(`https://getstickerpack.com/stickers?query=${query}`)
			.then(({
				data
			}) => {
				const $ = cheerio.load(data)
				const source = [];
				const link = [];
				$('#stickerPacks > div > div:nth-child(3) > div > a').each(function(a, b) {
					source.push($(b).attr('href'))
				})
				axios.get(source[Math.floor(Math.random() * source.length)])
					.then(({
						data
					}) => {
						const $$ = cheerio.load(data)
						$$('#stickerPack > div > div.row > div > img').each(function(c, d) {
							link.push($$(d).attr('src').replace(/&d=200x200/g, ''))
						})
					let result = {
							status: 200,
							author: global.creator,
							title: $$('#intro > div > div > h1').text(),
							sticker_url: link
						}
						resolve(result)
					})
			}).catch(reject)
	})
}
if (!text) return reply(`example ${prefix + command} Doraemon`)
await XReaction()
anu = await stickersearch(text)
for (let rehs of anu.sticker_url) {
await sleep(1500)
await Alice.sendImageAsSticker(m.chat, rehs, m, { packname: packname, author: author })
}
}
break

case 'alosehat': {
await XReaction();
  if (!q) return reply("Apa yang ingin dicari?");

  const fetch = require('node-fetch');
  const cheerio = require('cheerio');
  
  async function alosehat(query) {
    try {
      const url = `https://wp.hellosehat.com/?s=${encodeURIComponent(query)}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`${response.status}`);
      }
      
      const body = await response.text();
      const $ = cheerio.load(body);
      
      const articles = $(".card.article--card").map((index, element) => {
        const article = $(element);
        return {
          title: article.find("h2.entry-title a").text().trim(),
          link: article.find("h2.entry-title a").attr("href"),
          desc: article.find(".entry-summary p").text().trim(),
          author: article.find(".author.vcard a").text().trim(),
          time: article.find("time.entry-date.published").attr("datetime")
        };
      }).get().filter(article => article.title && article.desc);
      
      if (!articles.length) {
        throw new Error("No matching results found.");
      }
      
      const totalResults = parseInt($(".search--result-count").text(), 10) || 0;
      return { total: totalResults, results: articles };
      
    } catch (error) {
      throw new Error(`Error: ${error.message}`);
    }
  }

  try {
    const results = await alosehat(q);
    const { total, results: articles } = results;
    
    if (total === 0) {
      return reply("gd hsil.");
    }
    
    const response = articles.map((item, index) => (
      `${index + 1}. ${item.title}\nPenulis: ${item.author}\nTanggal: ${item.time}\nDeskripsi: ${item.desc}\nLink: ${item.link}\n\n`
    )).join('');

    reply(`Hasil pencarian Hello Sehat (${total} hasil):\n\n${response}`);
    
  } catch (error) {
    reply(`Terjadi kesalahan: ${error.message}`);
  }
}
break

case 'infoanime':
case 'Informationanime':
case 'informasianime': {
await XReaction();
if (!text) return reply(`masukan judul anime? contoh ${prefix + command}atri: my dear moments`)
await XReaction()

try {
const infoanime = await fetchJson(`https://api.ryzendesu.vip/api/weebs/anime-info?query=${text}`)
let capt = `╭──── *[ ɪɴғᴏ - ᴀɴɪᴍᴇ ]* ──々\n`
capt += `│ =〆 ᴊᴜᴅᴜʟ : ${infoanime.title}\n`
capt += `│ =〆 sᴄᴏʀᴇ : ${infoanime.score}\n`
capt += `│ =〆 ᴍᴇᴍʙᴇʀs : ${infoanime.members}\n`
capt += `│ =〆 sᴛᴀᴛᴜs : ${infoanime.status}\n`
capt += `│ =〆 ᴅᴇsᴄʀɪᴘᴛɪᴏɴ : ${infoanime.synopsis}\n`
capt += `│ =〆 ғᴀᴠᴏʀɪᴛᴇ : ${infoanime.favorites}\n`
capt += `│ =〆 ᴜʀʟ : ${infoanime.url}\n`
capt += `╰─々`
await Alice.sendMessage(m.chat, {
image: { url: infoanime.images.jpg.large_image_url },
caption: capt,
contextInfo: {
mentionedJid: [m.sender], 
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: channel,
newsletterName: `InfoAnime By: ${ownername}`,
serverMessageId: 143
}
}
}, { quoted: m })
} catch (err) {
}}
break

case 'gimage': {
await XReaction();
    if (!text) return reply(`gimage Kucing`)
    await XReaction()
    const axios = require('axios')
    const cheerio = require('cheerio')
// wm avs
    const nyariGambar = async (query) => {
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`
        const { data } = await axios.get(url)
        const $ = cheerio.load(data)
        let images = []
        $('img').each((i, elem) => {
            images.push($(elem).attr('src'))
        })
        return images
    }
// wm avs
    nyariGambar(text).then(images => {
        if (images.length === 0) {
            return reply('Tidak ada gambar.')
        }
        let SaannzImage = images[Math.floor(Math.random() * images.length)]
        Alice.sendMessage(m.chat, { image: { url: SaannzImage }, caption: `*Query* : ${text}\n*Media Url* : ${SaannzImage}` }, { quoted: m })
    }).catch(error => {
        reply('Terjadi kesalahan.')
    })
}
break

case 'bingimg': {
await XReaction();
  if (!text) return reply('Masukkan kata kunci yang akan dicari!')

  //created by hann

  const AXIOS_OPTIONS = {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36",
    },
  };

  function parseimg(url) {
    const urlObj = new URL(url);
    const searchParams = new URLSearchParams(urlObj.search);
    return decodeURIComponent(searchParams.get('mediaurl'));
  }

  function search(query) {
    return axios.get(
      `https://www.bing.com/images/search?q=${query}`,
      AXIOS_OPTIONS
    ).then(function ({ data }) {
      let $ = cheerio.load(data)

      const url = []

      $(".imgpt > a").each((i, el) => {
        url[i] = $(el).attr("href");
      });

      const result = [];
      for (let i = 0; i < url.length; i++) {
       result[i] = {
          photo: parseimg('https://bing.com'+url[i])
        };
      }
      return result;
    });
  }

  let img = await search(text)
  let hasil = img[Math.floor(Math.random() * img.length)]

  Alice.sendMessage(m.chat, { image: {url: `${hasil.photo}`}}, { quoted: m })
}
break


case 'movie-search': {
await XReaction();
  if (!text) {
    throw 'Contoh: .movie-search horror';
  }
// wm avs
  reply('_sabar tuan sedang mencari film nya_');
// wm avs
  async function avzz(query) {
    const url = `https://www.themoviedb.org/search?query=${query}`;
    try {
      const response = await axios.get(url);
      const html = response.data;
      const $ = cheerio.load(html);
      const movies = [];
// wm avs
      $('.card').each((index, element) => {
        const title = $(element).find('.title a').text().trim();
        const link = `https://www.themoviedb.org${$(element).find('.title a').attr('href')}`;
        const synopsis = $(element).find('.overview').text().trim();
        movies.push({ title, link, synopsis });
      });
// wm avs
      return movies;
    } catch (error) {
      console.error('error di sini:', error);
      return [];
    }
  }
// wm avs
  try {
    const query = encodeURIComponent(text);
    const movies = await avzz(query);

    if (movies.length === 0) {
      throw new Error('Film tidak ditemukan.');
    }
// wm avs
    let result = '';
    movies.forEach((movie, index) => {
      result += `*${index + 1}. ${movie.title}*\nLink: ${movie.link}\nSinopsis: ${movie.synopsis}\n\n`;
    });
// wm avs
    reply(result);
  } catch (error) {
    reply(`terjadi kesalahan: ${error.message}`);
  }
}
break


case 'sbook': {
await XReaction();
    if (!q.trim()) return reply(`Mau cari buku apa?`);
    const axios = require('axios');
    const cheerio = require('cheerio');
    // wm avz
    async function avzzzz(query) {
        const url = `https://www.goodreads.com/search?q=${encodeURIComponent(query)}`;
        // wm avz
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const books = [];
            $('.tableList tr').each((index, element) => {
                const title = $(element).find('a.bookTitle span').text().trim();
                const link = $(element).find('a.bookTitle').attr('href');
                const rating = $(element).find('span.minirating').text().trim();
                // wm avz
                books.push({ title, link: `https://www.goodreads.com${link}`, rating });
            });
            // wm avz
            return books;
        } catch (error) {
            console.error('Error fetching data:', error.message);
            return [];
        }
    }
    // wm avz
    avzzzz(q)
        .then(results => {
            if (results.length === 0) {
                reply('ora eneng.');
            } else {
                let response = `Hasil pencarian Goodreads untuk: ${q}\n\n`;
                results.forEach((item, index) => {
                    response += `${index + 1}. ${item.title}\nRating: ${item.rating}\nLink: ${item.link}\n\n`;
                });
                reply(response);
            }
        })
        .catch(error => {
            reply('emror.');
        });
        }
    break                 

case "yts": {
await XReaction();
if (!text) return reply('we dont talk')
await Alice.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await reply(teks)
await Alice.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
}
break

case 'play': {
await XReaction()

if (!text) return reply('Lagu apa yg ingin dicari?')

try {

let search = await yts(text)

if (!search.videos.length)
return reply('Video tidak ditemukan.')

let vid = search.videos[0]

let result = await ytdl(vid.url, 'mp3')

await Alice.sendMessage(m.chat, {
audio: { url: result.download },
mimetype: 'audio/mpeg',
fileName: result.title + '.mp3',
ptt: false,
contextInfo: {
externalAdReply: {
title: vid.title,
body: `Durasi: ${vid.timestamp}`,
thumbnailUrl: vid.thumbnail,
sourceUrl: vid.url,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: m })

} catch (err) {

console.log('play err:', err)

reply('❌ Gagal mengambil lagu.')

}
}
break

case 'ytmp3': {

await XReaction()

if (!text) return reply('Lagu apa yg ingin dicari?')

try {

let search = await yts(text)

if (!search.videos.length)
return reply('Video tidak ditemukan.')

let vid = search.videos[0]

let result = await ytdl(vid.url, 'mp3')

await Alice.sendMessage(m.chat, {
audio: { url: result.download },
mimetype: 'audio/mpeg',
fileName: result.title + '.mp3',
ptt: false,
contextInfo: {
externalAdReply: {
title: vid.title,
body: `Durasi: ${vid.timestamp}`,
thumbnailUrl: vid.thumbnail,
sourceUrl: vid.url,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: m })

} catch (err) {

console.log('ytmp3 err:', err)

await Alice.sendMessage(m.chat, {
react: { text: '🚫', key: m.key }
})

reply('❌ Gagal mengambil mp3.')

}

}
break

case 'ytmp4': {
  await XReaction();

  try {
    if (!text) return reply('Masukin url youtube mp4')

    let link = 'https://api-faa.my.id/faa/ytmp4?url=' + encodeURIComponent(text)

    let r = await fetch(link)
    let res = await r.json()

    if (!res || !res.status || !res.result) throw Error('gagal ambil data')

    let d = res.result

    if (!d.download_url) throw Error('link download tidak ada')

    await Alice.sendMessage(
      m.chat,
      {
        video: { url: d.download_url },
        mimetype: 'video/mp4',
        caption: 'YTMP4'
      },
      { quoted: m }
    )

  } catch (e) {
    reply('Eror kak : ' + (e.message || e))
  }
}
break

case "pinterest":
case "pin": {
  await XReaction()

  if (!text) return reply(`✨ Contoh: ${prefix + command} michiejkt48`)

  try {
    let results = []

    try {
      let r = await axios.get(`https://api-faa.my.id/faa/pinterest?q=${encodeURIComponent(text)}`)
      if (r.data?.result?.length) results = r.data.result
    } catch {}

    if (!results.length) {
      let r = await axios.get(`https://api.zenzzx.my.id/api/search/pinterest?query=${encodeURIComponent(text)}`)
      if (r.data?.data?.length) results = r.data.data.map(v => v.directLink)
    }

    if (!results.length) return reply("❌ Tidak ditemukan hasil.")

    let img = results[Math.floor(Math.random() * results.length)]

    await Alice.sendMessage(m.chat, {
      image: { url: img },
      caption: `📌 *Pinterest Result*\n\n✨ Keyword: *${text}*`,
      footer: 'Pinterest Search Engine',
      buttons: [
        { buttonId: `${prefix}pin ${text}`, buttonText: { displayText: '🔄 Next' }, type: 1 }
      ],
      headerType: 4
    }, { quoted: m })
  } catch {
    reply("⚠️ Terjadi kesalahan, coba lagi.")
  }
}
break

case 'tiktoksearch':
case 'ttsearch': {
  await XReaction()

  if (!text) return reply(`Contoh: ${prefix + command} jj epep`)

  try {
    let anu = await ds.search.tiktoks(text)

    let data = Array.isArray(anu) ? anu[0] : anu
    if (!data) return reply("❌ Tidak ditemukan hasil.")

    let videoUrl = data.no_watermark || data.video || data.play || data.url || data.link || ''
    if (!videoUrl) return reply("❌ Link video tidak ditemukan.")

    let audioUrl = data.music || data.audio || videoUrl

    await Alice.sendMessage(m.chat, {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      caption: `*T I K T O K - S E A R C H*\n\n*Title* : ${data.title || '-'}\n*Author* : ${data.author || '-'}`,
      footer: 'Tiktok Search',
      buttons: [
        { buttonId: `${prefix}ttsearch ${text}`, buttonText: { displayText: '🔄 Next' }, type: 1 },
        { buttonId: `${prefix}tiktokmp3 ${audioUrl}`, buttonText: { displayText: '🎵 Audio' }, type: 1 }
      ],
      headerType: 4
    }, { quoted: m })
  } catch (e) {
    reply(`❌ Gagal: ${e.message}`)
  }
}
break

case 'weather':{
await XReaction();
if (!text) return reply('What location?')
            let wdata = await axios.get(
                `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`
            );
            let textw = ""
            textw += `*🗺️Weather of  ${text}*\n\n`
            textw += `*Weather:-* ${wdata.data.weather[0].main}\n`
            textw += `*Description:-* ${wdata.data.weather[0].description}\n`
            textw += `*Avg Temp:-* ${wdata.data.main.temp}\n`
            textw += `*Feels Like:-* ${wdata.data.main.feels_like}\n`
            textw += `*Pressure:-* ${wdata.data.main.pressure}\n`
            textw += `*Humidity:-* ${wdata.data.main.humidity}\n`
            textw += `*Humidity:-* ${wdata.data.wind.speed}\n`
            textw += `*Latitude:-* ${wdata.data.coord.lat}\n`
            textw += `*Longitude:-* ${wdata.data.coord.lon}\n`
            textw += `*Country:-* ${wdata.data.sys.country}\n`

           Alice.sendMessage(
                m.chat, {
                    text: textw,
                }, {
                    quoted: m,
                }
           )
           }
           break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Search Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\
           
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Islami Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'hadistid': {
await XReaction();
    const query = args.join(' ');
    if (!query) {
        await Alice.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply(`Format: ${prefix + command} [kata kunci/kitab]\nContoh: ${prefix + command} bukhari`);
    }

    try {
        const hasil = await hadist(query);

        if (!hasil.length) {
            await Alice.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply('Tidak ditemukan hadits dengan kata kunci tersebut.');
        }

        let teks = `*📜 Hasil Pencarian Hadits.id*\n\n`;
        hasil.slice(0, 5).forEach((item, i) => {
            teks += `*${i+1}. ${item.judul}*\nPerawi: ${item.perawi}\nKitab: ${item.kitab}\n${item.teks}\nLink: ${item.link}\n\n`;
        });

        reply(teks.trim());
    } catch (err) {
        reply('Error: ' + (err.message || err));
    }
}
break;

case 'hadistdetail': {
await XReaction();

    const url = args[0];
    if (!url || !/^https:\/\/www\.hadits\.id\//.test(url)) {
        return reply(`Format: ${prefix + command} [link_haditsid]\nContoh: ${prefix + command} https://www.hadits.id/hadits/bukhari/6886`);
    }

    try {
        const hasil = await detail(url);

        if (!hasil) {
            await Alice.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply('Detail hadits tidak ditemukan.');
        }

        let teks = `*📖 Detail Hadits.id*\n\n`;
        teks += `*Judul:* ${hasil.title}\n`;
        teks += `*No Hadits:* ${hasil.hadithNumber}\n`;
        teks += `*Breadcrumb:* ${hasil.breadcrumb.join(' > ')}\n\n`;
        teks += `*Teks Arab:*\n${hasil.haditsArab}`;

        reply(teks.trim());
    } catch (err) {
        reply('Error: ' + (err.message || err));
    }
}
break;
case 'murotal': {
await XReaction();
  if (!args[0]) {
    try {
      let { data } = await axios.get('https://gist.githubusercontent.com/Bell575/382f3dd393f45eaac298d5b845112258/raw/dbcdc554a51e06a13795a2ff1fe15b85f55e8d9d/List%2520Surah')
      return reply(
        `Cara Pakai : murotal [Nomor Surah]\n*Example : .murotal 144*\n\n*List Surah :*\n\n${data}\n\n`
      )
    } catch (e) {
      return reply('Gagal Ambil List Surah')
    }
  }

  try {
    let { data } = await axios.get(`https://cloudku.us.kg/api/murotal/surah?id=${args[0]}`)
    let res = data.result
    if (!res) return reply('Surah Gak Ada')

    let teks =
      `Surah : ${res.name_id}\n\n` +
      `Nomor : ${res.number}\n` +
      `Nama Latin : ${res.name_en}\n` +
      `Nama Arab : ${res.name_long}\n` +
      `Jumlah Ayat : ${res.number_of_verses}\n` +
      `Tempat Turun : ${res.revelation_id} (${res.revelation_en})\n` +
      `Urutan Wahyu : ${res.sequence}\n` +
      `Arti : ${res.translation_id} (${res.translation_en})\n\n` +
      `Tafsir :\n${res.tafsir}`

    await reply(teks)
    await Alice.sendMessage(m.chat, {
      audio: { url: res.audio_url },
      mimetype: 'audio/mpeg',
      ptt: true
    }, { quoted: m })

  } catch (e) {
    reply('Failed to fetch surah data. Make sure the surah number is correct')
  }
}
break;
case 'ayat': {
  await XReaction();
 if (!text) {
 return reply(`Masukkan format\nExample: ${prefix + command} <surah> <ayat>`);
 }

 let [surah, ayat] = text.split(" ");
 if (!surah || !ayat || isNaN(surah) || isNaN(ayat)) {
 return reply("Format tidak valid. Pastikan Anda memasukkan angka untuk surah dan ayat.");
 }

async function alquran(surah, ayat) {
    try {
        const url = `https://www.velyn.biz.id/api/search/alquran?surah=${surah}&ayat=${ayat}`;
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();

        if (!data || !data.text) {
            throw new Error("Data tidak ditemukan atau format tidak valid.");
        }

        return {
            text: data.text,
            translation: data.translation,
            tafsir: data.tafsir,
            surah_nama: data.surah_nama,
            surah: data.surah,
            ayat: data.ayat,
            revelation_place: data.revelation_place,
            surah_total_ayat: data.surah_total_ayat,
            tafsir_lengkap: data.tafsir_lengkap
        };
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
        return null;
    }
}

 try {
        let result = await alquran(surah, ayat);
        if (result) {
            let output = `📖 **Surah ${result.surah_nama} (${surah}), Ayat ${ayat}**\n\n${result.text}\n\n📜 **Terjemahan:** ${result.translation}\n\n📝 **Tafsir Singkat:** ${result.tafsir}\n\n📌 **Informasi Tambahan:**\n- **Nama Surah**: ${result.surah_nama}\n- **Nomor Surah**: ${result.surah}\n- **Nomor Ayat**: ${result.ayat}\n- **Revelasi**: ${result.revelation_place}\n- **Jumlah Ayat dalam Surah**: ${result.surah_total_ayat}\n- **Tafsir Lengkap**: ${result.tafsir_lengkap}`;
            reply(m.chat, output, m);
        } else {
           reply("Ayat tidak ditemukan.")
        }
    } catch (error) {
        reply(m.chat, `Terjadi kesalahan: ${error.message}`, m);
    }
};
break;
case 'caridoa':
case 'doa': {
await XReaction();
if (!text) return reply('Contoh : .doa Bangun Tidur');
await XReaction()
let Xyroo = await fetchJson(`https://api.autoresbot.com/api/doa?q=${text}`)
let cap = Xyroo.data[0];
let doanya = `*_${cap.doa}_\n${cap.ayat}\n${cap.latin}\nArtinya : ${cap.artinya}"`
await reply(doanya)
}
break

case 'tafsir': 
case 'tafsirsurah': {
await XReaction();
    if (!text) return reply(`Example : .tafsir adam\n\n💡 *Tips* : Ketik nama surah yang ingin Anda ketahui tafsirnya, misalnya '.tafsir Yusuf'.`)
  await XReaction();
    try {
        let response = await fetchJson(`https://widipe.com/tafsirsurah?text=${text}`);
const results = response.result;
function getRandomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}
const anubis = getRandomElement(results);
if (anubis && anubis.surah && anubis.tafsir && anubis.type && anubis.source) {
    let surah = anubis.surah;
    let tafsir = anubis.tafsir;
    let artikel = anubis.type;
    let source = anubis.source;

    let tafsirResult = `🌿 *Tafsir Surah ${surah}*\n\n` +
        `• *Surah* : ${surah}\n` +
        `• *Tafsir* :\n${tafsir}\n\n` +
        `• *Kategori Tafsir* : ${artikel}\n` +
        `• *Sumber* : ${source}\n\n` +
        `Terima kasih telah menggunakan layanan kami! 🌸`;

    return reply(tafsirResult);
} else {
    return reply("*Maaf, data tafsir tidak lengkap atau tidak ditemukan.*");
}
    } catch (error) {
        return reply("*Terjadi Kesalahan!* 🙁\n\nMohon maaf, ada masalah saat mencari tafsir surah. Silakan coba lagi nanti.");
    }
}
                break

case 'jadwalshalat':
case 'jadwalsholat': {
await XReaction();
  try {

    if (!text)
      return reply('📍 Masukkan nama kota\nContoh: *jadwal jakarta*')

    reply('⏳ Mencari jadwal sholat...')

    const res = await jadwalsholat(text)

    const now = new Date()
    const hari = now.toLocaleString('id-ID', { weekday: 'long' })
    const tanggal = now.getDate()
    const bulan = now.toLocaleString('id-ID', { month: 'long' })
    const tahun = now.getFullYear()

    const caption = `🕌 *Jadwal Sholat*

📍 *${res.kota}*
📅 ${hari}, ${tanggal} ${bulan} ${tahun}

⏰ *Waktu Sholat*
• Imsyak ${res.jadwal.imsyak}
• Subuh ${res.jadwal.subuh}
• Terbit ${res.jadwal.terbit}
• Dhuha ${res.jadwal.dhuha}
• Dzuhur ${res.jadwal.dzuhur}
• Ashar ${res.jadwal.ashar}
• Maghrib ${res.jadwal.maghrib}
• Isya ${res.jadwal.isya}

— ${packname}`

    reply(caption)

  } catch (e) {
    reply(`❌ ${e.message}`)
  }
}
break

case 'artisurah': {
await XReaction();
  if (!q) return reply(`Example ${prefix + command} 113`)
async function surah(no){
	return new Promise(async(resolve, reject) => {
		axios.get('https://kalam.sindonews.com/surah/' + no)
		.then(({ data }) => {
			const $ = cheerio.load(data)
			const result = [];
			const ar = [];
			const id = [];
			const lt = [];
			const au = [];
			$('div.breadcrumb-new > ul > li:nth-child(5)').each(function(c,d) {
			result.audio = $(d).find('a').attr('href').replace('surah','audioframe')
			})
			$('div.ayat-arab').each(function(a, b) {
				ar.push($(b).text()) 
			})
			$('li > div.ayat-text').each(function(e, f) {
				id.push($(f).text().replace(',','').trim()) })
			$('div.ayat-latin').each(function(g, h) {
				lt.push($(h).text().trim())	})
			for(let i = 0; i < ar.length ; i++){
			result.push({
				arab: ar[i],
				indo: id[i],
				latin: lt[i],
			})
		}
			resolve(result)
		})
		.catch(reject)
	})
}
surah(q).then(result => {
 if (result.length === 0) {
 reply('Tidak ada hasil yang ditemukan.');
 return;
 }
 
 let replyTexttt = `Hasil dari Surah untuk "${q}":\n\n`;
 result.forEach((result, index) => {
 replyTexttt += `${result.indo}\n${result.arab}\n${result.latin}\n\n`;
 });
 
 reply(replyTexttt);
 }).catch(error => {
 reply('Terjadi kesalahan saat memasuki angka di surah.');
 console.error(error);
 });
}
break
case 'niatsholat': {
await XReaction();
    if (!q) return reply(`Contoh Penggunaan :\nniatsholat Subuh`)
const niatsholat = [
    {
        index: 1,
        solat: "subuh",
        latin: "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 2,
        solat: "maghrib",
        latin: "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلاَثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 3,
        solat: "dzuhur",
        latin: "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الظُّهْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 4,
        solat: "isha",
        latin: "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "صَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 5,
        solat: "ashar",
        latin: "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "صَلِّى فَرْضَ الْعَصْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala",
    }
]
    let text = q.toLowerCase() || ''
    let data = Object.values(niatsholat).find(v => v.solat == text)
    if (!data) return reply(`${text} Tidak Ditemukan\n\nList Solat 5 Waktu :\n• Subuh\n• Maghrib\n• Dzuhur\n• Isha\n• Ashar`)
    reply(`
_*Niat Sholat ${text}*_

*Arab :* ${data.arabic}

*Latin :* ${data.latin} 

*Translate :* ${data.translation_id}`.trim())
}

break
 case 'kisahnabi': {
await XReaction();

     if (!text) return reply(`Masukan nama nabi\nExample: kisahnabi adam`)

     let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`)

     let kisah = await url.json().catch(_ => "Error")

     if (kisah == "Error") return reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital")

     

    let hasil = `_*👳 Nabi :*_ ${kisah.name}

_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}

_*📍 Tempat Lahir :*_ ${kisah.tmp}

_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`

     reply(`${hasil}`)

}

break
        
case 'ayatkursi': {
await XReaction();

  let caption = `

*「 Ayat Kursi 」*

اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”

Artinya:

Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.

Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 

(QS. Al Baqarah: 255)

`.trim()

  reply(caption)

}

break            
case 'dalamislam': {
await XReaction();
    if (!q.trim()) return reply("_contoh .dalamislam dosa");
// wm avs
    const axios = require('axios');
    const cheerio = require('cheerio');
// wm avs
    async function scrapeHadis(searchTerm) {
        const url = `https://dalamislam.com/?s=${encodeURIComponent(searchTerm)}`;
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const hadisList = [];
// wm avs
            $('.entry-title a').each((index, element) => {
                const title = $(element).text().trim();
                const link = $(element).attr('href');
                hadisList.push({ title, link });
            });
// wm avs
            return hadisList;
        } catch (error) {
            console.error('Error fetching data:', error);
            throw new Error('elul.');
        }
    }
// wm avs
    scrapeHadis(q)
        .then(results => {
            if (results.length === 0) {
                reply('tak ada hasil.');
            } else {
                let response = `Hasil pencarian hadis dari Dalam Islam untuk: ${q}\n\n`;
                results.forEach((item, index) => {
                    response += `${index + 1}. ${item.title}\nLink: ${item.link}\n\n`;
                });
                reply(response);
            }
        })
        .catch(error => {
            console.error(`${error.message}`);
            reply('Terjadi kesalahan.');
        });
}
    break        
case 'kisahnabi': {
await XReaction();
if (!text) return reply(`Masukan nama nabi\nExample: kisahnabi adam`)
let url = await fetch(`https://raw.githubusercontent.com/Sanz-MDChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`)
let kisah = await url.json().catch(_ => "Error")
if (kisah == "Error") return reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital")

let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`

reply(`${hasil}`)

}
break

case 'asmaulhusna': {
await XReaction();
const contoh = `*Asmaul Husna*`
const anjuran = `
Dari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: "إِنَّ لِلَّهِ تَعَالَى تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةٌ إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دخل الجنة، وهو وتر يُحِبُّ الْوِتْرَ"
Artinya: "Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir".`
const asmaulhusna = [
{
index: 1,
latin: "Ar Rahman",
arabic: "الرَّحْمَنُ",
translation_id: "Yang Memiliki Mutlak sifat Pemurah",
translation_en: "The All Beneficent"
},
{
index: 2,
latin: "Ar Rahiim",
arabic: "الرَّحِيمُ",
translation_id: "Yang Memiliki Mutlak sifat Penyayang",
translation_en: "The Most Merciful"
},
{
index: 3,
latin: "Al Malik",
arabic: "الْمَلِكُ",
translation_id: "Yang Memiliki Mutlak sifat Merajai/Memerintah",
translation_en: "The King, The Sovereign"
},
{
index: 4,
latin: "Al Quddus",
arabic: "الْقُدُّوسُ",
translation_id: "Yang Memiliki Mutlak sifat Suci",
translation_en: "The Most Holy"
},
{
index: 5,
latin: "As Salaam",
arabic: "السَّلاَمُ",
translation_id: "Yang Memiliki Mutlak sifat Memberi Kesejahteraan",
translation_en: "Peace and Blessing"
},
{
index: 6,
latin: "Al Mu’min",
arabic: "الْمُؤْمِنُ",
translation_id: "Yang Memiliki Mutlak sifat Memberi Keamanan",
translation_en: "The Guarantor"
},
{
index: 7,
latin: "Al Muhaimin",
arabic: "الْمُهَيْمِنُ",
translation_id: "Yang Memiliki Mutlak sifat Pemelihara",
translation_en: "The Guardian, the Preserver"
},
{
index: 8,
latin: "Al ‘Aziiz",
arabic: "الْعَزِيزُ",
translation_id: "Yang Memiliki Mutlak Kegagahan",
translation_en: "The Almighty, the Self Sufficient"
},
{
index: 9,
latin: "Al Jabbar",
arabic: "الْجَبَّارُ",
translation_id: "Yang Memiliki Mutlak sifat Perkasa",
translation_en: "The Powerful, the Irresistible"
},
{
index: 10,
latin: "Al Mutakabbir",
arabic: "الْمُتَكَبِّرُ",
translation_id: "Yang Memiliki Mutlak sifat Megah,Yang Memiliki Kebesaran",
translation_en: "The Tremendous"
},
{
index: 11,
latin: "Al Khaliq",
arabic: "الْخَالِقُ",
translation_id: "Yang Memiliki Mutlak sifat Pencipta",
translation_en: "The Creator"
},
{
index: 12,
latin: "Al Baari’",
arabic: "الْبَارِئُ",
translation_id: "Yang Memiliki Mutlak sifat Yang Melepaskan(Membuat, Membentuk, Menyeimbangkan)",
translation_en: "The Maker"
},
{
index: 13,
latin: "Al Mushawwir",
arabic: "الْمُصَوِّرُ",
translation_id: "Yang Memiliki Mutlak sifat YangMembentuk Rupa (makhluknya)",
translation_en: "The Fashioner of Forms"
},
{
index: 14,
latin: "Al Ghaffaar",
arabic: "الْغَفَّارُ",
translation_id: "Yang Memiliki Mutlak sifat Pengampun",
translation_en: "The Ever Forgiving"
},
{
index: 15,
latin: "Al Qahhaar",
arabic: "الْقَهَّارُ",
translation_id: "Yang Memiliki Mutlak sifat Memaksa",
translation_en: "The All Compelling Subduer"
},
{
index: 16,
latin: "Al Wahhaab",
arabic: "الْوَهَّابُ",
translation_id: "Yang Memiliki Mutlak sifat Pemberi Karunia",
translation_en: "The Bestower"
},
{
index: 17,
latin: "Ar Razzaaq",
arabic: "الرَّزَّاقُ",
translation_id: "Yang Memiliki Mutlak sifat Pemberi Rejeki",
translation_en: "The Ever Providing"
},
{
        index: 18,
        latin: "Al Fattaah",
        arabic: "الْفَتَّاحُ",
        translation_id: "Yang Memiliki Mutlak sifat Pembuka Rahmat",
        translation_en: "The Opener, the Victory Giver"
    },
    {
        index: 19,
        latin: "Al ‘Aliim",
        arabic: "اَلْعَلِيْمُ",
        translation_id: "Yang Memiliki Mutlak sifatMengetahui (Memiliki Ilmu)",
        translation_en: "The All Knowing, the Omniscient"
    },
    {
        index: 20,
        latin: "Al Qaabidh",
        arabic: "الْقَابِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMenyempitkan (makhluknya)",
        translation_en: "The Restrainer, the Straightener"
    },
    {
        index: 21,
        latin: "Al Baasith",
        arabic: "الْبَاسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMelapangkan (makhluknya)",
        translation_en: "The Expander, the Munificent"
    },
    {
        index: 22,
        latin: "Al Khaafidh",
        arabic: "الْخَافِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMerendahkan (makhluknya)",
        translation_en: "The Abaser"
    },
    {
        index: 23,
        latin: "Ar Raafi’",
        arabic: "الرَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMeninggikan (makhluknya)",
        translation_en: "The Exalter"
    },
    {
        index: 24,
        latin: "Al Mu’izz",
        arabic: "الْمُعِزُّ",
        translation_id: "Yang Memiliki Mutlak sifat YangMemuliakan (makhluknya)",
        translation_en: "The Giver of Honor"
    },
    {
        index: 25,
        latin: "Al Mudzil",
        arabic: "المُذِلُّ",
        translation_id: "Yang Memiliki Mutlak sifatYang Menghinakan (makhluknya)",
        translation_en: "The Giver of Dishonor"
    },
    {
        index: 26,
        latin: "Al Samii’",
        arabic: "السَّمِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendengar",
        translation_en: "The All Hearing"
    },
    {
        index: 27,
        latin: "Al Bashiir",
        arabic: "الْبَصِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melihat",
        translation_en: "The All Seeing"
    },
    {
        index: 28,
        latin: "Al Hakam",
        arabic: "الْحَكَمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menetapkan",
        translation_en: "The Judge, the Arbitrator"
    },
    {
        index: 29,
        latin: "Al ‘Adl",
        arabic: "الْعَدْلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Utterly Just"
    },
    {
        index: 30,
        latin: "Al Lathiif",
        arabic: "اللَّطِيفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Lembut",
        translation_en: "The Subtly Kind"
    },
    {
        index: 31,
        latin: "Al Khabiir",
        arabic: "الْخَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifatMaha Mengetahui Rahasia",
        translation_en: "The All Aware"
    },
    {
        index: 32,
        latin: "Al Haliim",
        arabic: "الْحَلِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penyantun",
        translation_en: "The Forbearing, the Indulgent"
    },
    {
        index: 33,
        latin: "Al ‘Azhiim",
        arabic: "الْعَظِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Agung",
        translation_en: "The Magnificent, the Infinite"
    },
    {
        index: 34,
        latin: "Al Ghafuur",
        arabic: "الْغَفُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengampun",
        translation_en: "The All Forgiving"
    },
    {
        index: 35,
        latin: "As Syakuur",
        arabic: "الشَّكُورُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaPembalas Budi (Menghargai)",
        translation_en: "The Grateful"
    },
    {
        index: 36,
        latin: "Al ‘Aliy",
        arabic: "الْعَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Sublimely Exalted"
    },
    {
        index: 37,
        latin: "Al Kabiir",
        arabic: "الْكَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Besar",
        translation_en: "The Great"
    },
    {
        index: 38,
        latin: "Al Hafizh",
        arabic: "الْحَفِيظُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menjaga",
        translation_en: "The Preserver"
    },
    {
        index: 39,
        latin: "Al Muqiit",
        arabic: "المُقيِت",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Kecukupan",
        translation_en: "The Nourisher"
    },
    {
        index: 40,
        latin: "Al Hasiib",
        arabic: "الْحسِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMembuat Perhitungan",
        translation_en: "The Reckoner"
    },
    {
        index: 41,
        latin: "Al Jaliil",
        arabic: "الْجَلِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Majestic"
        },
    {
        index: 42,
        latin: "Al Kariim",
        arabic: "الْكَرِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemurah",
        translation_en: "The Bountiful, the Generous"
    },
    {
        index: 43,
        latin: "Ar Raqiib",
        arabic: "الرَّقِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengawasi",
        translation_en: "The Watchful"
    },
    {
        index: 44,
        latin: "Al Mujiib",
        arabic: "الْمُجِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengabulkan",
        translation_en: "The Responsive, the Answerer"
    },
    {
        index: 45,
        latin: "Al Waasi’",
        arabic: "الْوَاسِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Luas",
        translation_en: "The Vast, the All Encompassing"
    },
    {
        index: 46,
        latin: "Al Hakiim",
        arabic: "الْحَكِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maka Bijaksana",
        translation_en: "The Wise"
    },
    {
        index: 47,
        latin: "Al Waduud",
        arabic: "الْوَدُودُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencinta",
        translation_en: "The Loving, the Kind One"
    },
    {
        index: 48,
        latin: "Al Majiid",
        arabic: "الْمَجِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The All Glorious"
    },
    {
        index: 49,
        latin: "Al Baa’its",
        arabic: "الْبَاعِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Membangkitkan",
        translation_en: "The Raiser of the Dead"
    },
    {
        index: 50,
        latin: "As Syahiid",
        arabic: "الشَّهِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menyaksikan",
        translation_en: "The Witness"
    },
    {
        index: 51,
        latin: "Al Haqq",
        arabic: "الْحَقُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Benar",
        translation_en: "The Truth, the Real"
    },
    {
        index: 52,
        latin: "Al Wakiil",
        arabic: "الْوَكِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memelihara",
        translation_en: "The Trustee, the Dependable"
    },
    {
        index: 53,
        latin: "Al Qawiyyu",
        arabic: "الْقَوِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kuat",
        translation_en: "The Strong"
    },
    {
        index: 54,
        latin: "Al Matiin",
        arabic: "الْمَتِينُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kokoh",
        translation_en: "The Firm, the Steadfast"
    },
    {
        index: 55,
        latin: "Al Waliyy",
        arabic: "الْوَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melindungi",
        translation_en: "The Protecting Friend, Patron, and Helper"
    },
    {
        index: 56,
        latin: "Al Hamiid",
        arabic: "الْحَمِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Terpuji",
        translation_en: "The All Praiseworthy"
    },
    {
        index: 57,
        latin: "Al Mushii",
        arabic: "الْمُحْصِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengkalkulasi",
        translation_en: "The Accounter, the Numberer of All"
    },
    {
        index: 58,
        latin: "Al Mubdi’",
        arabic: "الْمُبْدِئُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memulai",
        translation_en: "The Producer, Originator, and Initiator of all"
    },
    {
        index: 59,
        latin: "Al Mu’iid",
        arabic: "الْمُعِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMengembalikan Kehidupan",
        translation_en: "The Reinstater Who Brings Back All"
    },
    {
        index: 60,
        latin: "Al Muhyii",
        arabic: "الْمُحْيِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menghidupkan",
        translation_en: "The Giver of Life"
    },
    {
        index: 61,
        latin: "Al Mumiitu",
        arabic: "اَلْمُمِيتُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mematikan",
        translation_en: "The Bringer of Death, the Destroyer"
    },
    {
        index: 62,
        latin: "Al Hayyu",
        arabic: "الْحَيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Hidup",
        translation_en: "The Ever Living"
    },
    {
        index: 63,
        latin: "Al Qayyuum",
        arabic: "الْقَيُّومُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mandiri",
        translation_en: "The Self Subsisting Sustainer of All"
    },
    {
        index: 64,
        latin: "Al Waajid",
        arabic: "الْوَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penemu",
        translation_en: "The Perceiver, the Finder, the Unfailing"
    },
    {
        index: 65,
        latin: "Al Maajid",
        arabic: "الْمَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Illustrious, the Magnificent"
    },
    {
        index: 66,
        latin: "Al Wahiid",
        arabic: "الْواحِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tunggal",
        translation_en: "The One, The Unique, Manifestation of Unity"
    },
    {
        index: 67,
        latin: "Al ‘Ahad",
        arabic: "اَلاَحَدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Esa",
        translation_en: "The One, the All Inclusive, the Indivisible"
    },
    {
        index: 68,
        latin: "As Shamad",
        arabic: "الصَّمَدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaDibutuhkan, Tempat Meminta",
        translation_en: "The Self Sufficient, the Impregnable,the Eternally Besought of All, the Everlasting"
    },
    {
        index: 69,
        latin: "Al Qaadir",
        arabic: "الْقَادِرُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMenentukan, Maha Menyeimbangkan",
        translation_en: "The All Able"
    },
    {
        index: 70,
        latin: "Al Muqtadir",
        arabic: "الْمُقْتَدِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkuasa",
        translation_en: "The All Determiner, the Dominant"
    },
    {
        index: 71,
        latin: "Al Muqaddim",
        arabic: "الْمُقَدِّمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendahulukan",
        translation_en: "The Expediter, He who brings forward"
    },
    {
        index: 72,
        latin: "Al Mu’akkhir",
        arabic: "الْمُؤَخِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengakhirkan",
        translation_en: "The Delayer, He who puts far away"
    },
    {
        index: 73,
        latin: "Al Awwal",
        arabic: "الأوَّلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Awal",
        translation_en: "The First"
    },
    {
        index: 74,
        latin: "Al Aakhir",
        arabic: "الآخِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Akhir",
        translation_en: "The Last"
    },
    {
        index: 75,
        latin: "Az Zhaahir",
        arabic: "الظَّاهِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Nyata",
        translation_en: "The Manifest; the All Victorious"
    },
    {
        index: 76,
        latin: "Al Baathin",
        arabic: "الْبَاطِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Ghaib",
        translation_en: "The Hidden; the All Encompassing"
    },
    {
        index: 77,
        latin: "Al Waali",
        arabic: "الْوَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memerintah",
        translation_en: "The Patron"
    },
    {
        index: 78,
        latin: "Al Muta’aalii",
        arabic: "الْمُتَعَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Self Exalted"
    },
    {
        index: 79,
        latin: "Al Barri",
        arabic: "الْبَرُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penderma",
        translation_en: "The Most Kind and Righteous"
    },
    {
        index: 80,
        latin: "At Tawwaab",
        arabic: "التَّوَابُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penerima Tobat",
        translation_en: "The Ever Returning, Ever Relenting"
    },
    {
        index: 81,
        latin: "Al Muntaqim",
        arabic: "الْمُنْتَقِمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penuntut Balas",
        translation_en: "The Avenger"
    },
    {
        index: 82,
        latin: "Al Afuww",
        arabic: "العَفُوُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemaaf",
        translation_en: "The Pardoner, the Effacer of Sins"
    },
    {
        index: 83,
        latin: "Ar Ra`uuf",
        arabic: "الرَّؤُوفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengasih",
        translation_en: "The Compassionate, the All Pitying"
    },
    {
        index: 84,
        latin: "Malikul Mulk",
        arabic: "مَالِكُ الْمُلْكِ",
        translation_id: "Yang Memiliki Mutlak sifatPenguasa Kerajaan (Semesta)",
        translation_en: "The Owner of All Sovereignty"
    },
    {
        index: 85,
        latin: "Dzul JalaaliWal Ikraam",
        arabic: "ذُوالْجَلاَلِوَالإكْرَامِ",
        translation_id: "Yang Memiliki Mutlak sifat PemilikKebesaran dan Kemuliaan",
        translation_en: "The Lord of Majesty and Generosity"
    },
    {
        index: 86,
        latin: "Al Muqsith",
        arabic: "الْمُقْسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Equitable, the Requiter"
    },
    {
        index: 87,
        latin: "Al Jamii’",
        arabic: "الْجَامِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengumpulkan",
        translation_en: "The Gatherer, the Unifier"
    },
    {
        index: 88,
        latin: "Al Ghaniyy",
        arabic: "الْغَنِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkecukupan",
        translation_en: "The All Rich, the Independent"
    },
    {
        index: 89,
        latin: "Al Mughnii",
        arabic: "الْمُغْنِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Kekayaan",
        translation_en: "The Enricher, the Emancipator"
    },
    {
        index: 90,
        latin: "Al Maani",
        arabic: "اَلْمَانِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mencegah",
        translation_en: "The Withholder, the Shielder, the Defender"
    },
    {
        index: 91,
        latin: "Ad Dhaar",
        arabic: "الضَّارَّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Derita",
        translation_en: "The Distressor, the Harmer"
    },
    {
        index: 92,
        latin: "An Nafii’",
        arabic: "النَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Manfaat",
        translation_en: "The Propitious, the Benefactor"
    },
    {
        index: 93,
        latin: "An Nuur",
        arabic: "النُّورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Bercahaya(Menerangi, Memberi Cahaya)",
        translation_en: "The Light"
    },
    {
        index: 94,
        latin: "Al Haadii",
        arabic: "الْهَادِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Petunjuk",
        translation_en: "The Guide"
    },
    {
        index: 95,
        latin: "Al Baadii",
        arabic: "الْبَدِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencipta",
        translation_en: "Incomparable, the Originator"
    },
    {
        index: 96,
        latin: "Al Baaqii",
        arabic: "اَلْبَاقِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kekal",
        translation_en: "The Ever Enduring and Immutable"
    },
    {
        index: 97,
        latin: "Al Waarits",
        arabic: "الْوَارِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pewaris",
        translation_en: "The Heir, the Inheritor of All"
    },
    {
        index: 98,
        latin: "Ar Rasyiid",
        arabic: "الرَّشِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pandai",
        translation_en: "The Guide, Infallible Teacher, and Knower"
    },
    {
        index: 99,
        latin: "As Shabuur",
        arabic: "الصَّبُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Sabar",
        translation_en: "The Patient"
    }
]
    let json = JSON.parse(JSON.stringify(asmaulhusna))
    let data = json.map((v, i) => `${i + 1}. ${v.latin}\n${v.arabic}\n${v.translation_id}`).join('\n\n')
    if (isNaN(args[0])) return reply (`contoh:\nasmaulhusna 1`)
    if (args[0]) {
        if (args[0] < 1 || args[0] > 99) throw `minimal 1 & maksimal 99!`
        let { index, latin, arabic, translation_id, translation_en } = json.find(v => v.index == args[0].replace(/[^0-9]/g, ''))
        return reply(`No. ${index}
${arabic}
${latin}
${translation_id}
${translation_en}
`.trim())
    }
    reply(`${contoh} + ${data} + ${anjuran}`)
}
break   
case 'bacaansholat': {
await XReaction();
const bacaanshalat = {
"result": [
{
 "id": 1,
 "name": "Bacaan Iftitah",
 "arabic": "اللَّهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللَّهِ بُكْرَةً وَأَصِيلاً , إِنِّى وَجَّهْتُ وَجْهِىَ لِلَّذِى فَطَرَ السَّمَوَاتِ وَالأَرْضَ حَنِيفًا وَمَا أَنَا مِنَ الْمُشْرِكِينَ إِنَّ صَلاَتِى وَنُسُكِى وَمَحْيَاىَ وَمَمَاتِى لِلَّهِ رَبِّ الْعَالَمِينَ لاَ شَرِيكَ لَهُ وَبِذَلِكَ أُمِرْتُ وَأَنَا أَوَّلُ الْمُسْلِمِينَ",
 "latin": "Alloohu akbar kabiirow wal hamdu lillaahi katsiiroo wasubhaanalloohi bukrotaw wa-ashiilaa, Innii wajjahtu wajhiya lilladzii fathoros samaawaati wal ardlo haniifaa wamaa ana minal musyrikiin. Inna sholaatii wa nusukii wamahyaa wa mamaatii lillaahi robbil &lsquo;aalamiin. Laa syariikalahu wa bidzaalika umirtu wa ana awwalul muslimiin",
 "terjemahan": "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak. Mahasuci Allah pada waktu pagi dan petang, Sesungguhnya aku hadapkan wajahku kepada Allah yang telah menciptakan langit dan bumi dalam keadaan tunduk dan aku bukanlah dari golongan orang-orang musyrik. Sesungguhnya shalatku, sembelihanku, hidupku dan matiku hanya untuk Allah Tuhan semesta alam. Tidak ada sekutu bagiNya. Dan dengan yang demikian itu lah aku diperintahkan. Dan aku adalah orang yang pertama berserah diri"
},
{
 "id": 2,
 "name": "Al Fatihah",
 "arabic": "بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ ﴿١﴾الْحَمْدُ لِلَّـهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَـٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَاالصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧",
 "latin": "1. Bismillahirrahmanirrahim, 2. Alhamdulillahi rabbil alamin, 3. Arrahmaanirrahiim, 4. Maaliki yaumiddiin, 5. Iyyaka nabudu waiyyaaka nastaiin, 6. Ihdinashirratal mustaqim, 7. shiratalladzina an&rsquo;amta alaihim ghairil maghduubi alaihim waladhaalin",
 "terjemahan": "1. Dengan menyebut nama Allah Yang Maha Pemurah lagi Maha Penyayang, 2. Segala puji bagi Allah, Tuhan semesta alam, 3. Maha Pemurah lagi Maha Penyayang, 4. Yang menguasai di Hari Pembalasan, 5. Hanya Engkaulah yang kami sembah, dan hanya kepada Engkaulah kami meminta pertolongan, 6. Tunjukilah kami jalan yang lurus, 7. (yaitu) Jalan orang-orang yang telah Engkau beri nikmat kepada mereka; bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) mereka yang sesat"
},
{
 "id": 3,
 "name": "Bacaan Ruku",
 "arabic": "(3x) سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
 "latin": "Subhana Rabbiyal Adzimi Wabihamdih (3x)",
 "terjemahan": "Maha Suci Tuhanku Yang Maha Agung Dan Dengan Memuji-Nya"
},
{
 "id": 4,
 "name": "Bacaan Sujud",
 "arabic": "(3x) سُبْحَانَ رَبِّىَ الْأَعْلَى وَبِحَمْدِهِ",
 "latin": "Subhaana robbiyal a'la wabihamdih (3x)",
 "terjemahan": "Mahasuci Tuhanku yang Mahatinggi dan segala puji bagiNya"
},
{
 "id": 5,
 "name": "Bacaan Duduk Diantara Dua Sujud",
 "arabic": "رَبِّ اغْفِرْلِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَاعْفُ عَنِّيْ",
 "latin": "Rabbighfirli Warhamni Wajburnii Warfaknii Wazuqnii Wahdinii Wa'aafinii Wa'fuannii",
 "terjemahan": "Ya Allah,ampunilah dosaku,belas kasihinilah aku dan cukuplah segala kekuranganku da angkatlah derajatku dan berilah rezeki kepadaku,dan berilah aku petunjuk dan berilah kesehatan padaku dan berilah ampunan kepadaku"
},
{
 "id": 6,
 "name": "Duduk Tasyahud Awal",
 "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ",
 "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahummasholli ala Sayyidina Muhammad",
 "terjemahan": "Segala penghormatan, keberkahan, shalawat dan kebaikan hanya bagi Allah. Semoga salam sejahtera selalu tercurahkan kepadamu wahai Nabi, demikian pula rahmat Allah dan berkahNya dan semoga salam sejahtera selalu tercurah kepada kami dan hamba-hamba Allah yang shalih. Aku bersaksi bahwa tiada ilah kecuali Allah dan aku bersaksi bahwa Muhammad adalah utusan Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad"
},
{
 "id": 7,
 "name": "Duduk Tasyahud Akhir",
 "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ كَمَا بَرَكْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ فِى الْعَالَمِيْنَ إِنَّكَ حَمِيْدٌ مَجِيْدٌ",
 "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahumma Shalli Ala Sayyidina Muhammad Wa Ala Ali Sayyidina Muhammad. Kama Shollaita Ala Sayyidina Ibrahim wa alaa aali sayyidina Ibrahim, wabaarik ala Sayyidina Muhammad Wa Alaa Ali Sayyidina Muhammad, Kama barokta alaa Sayyidina Ibrahim wa alaa ali Sayyidina Ibrahim, Fil aalamiina innaka hamiidummajid",
 "terjemahan": "Segala penghormatan yang berkat solat yang baik adalah untuk Allah. Sejahtera atas engkau wahai Nabi dan rahmat Allah serta keberkatannya. Sejahtera ke atas kami dan atas hamba-hamba Allah yang soleh. Aku bersaksi bahwa tiada Tuhan melainkan Allah dan aku bersaksi bahwasanya Muhammad itu adalah pesuruh Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad dan ke atas keluarganya. Sebagaimana Engkau selawatkan ke atas Ibrahim dan atas keluarga Ibrahim. Berkatilah ke atas Muhammad dan atas keluarganya sebagaimana Engkau berkati ke atas Ibrahim dan atas keluarga Ibrahim di dalam alam ini. Sesungguhnya Engkau Maha Terpuji lagi Maha Agung"
},
{
 "id": 8,
 "name": "Salam",
 "arabic": "اَلسَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
 "latin": "Assalamualaikum Warohmatullahi Wabarokatuh",
 "terjemahan": "Semoga keselamatan, rohmat dan berkah ALLAH selalu tercurah untuk kamu sekalian."
}
]
}
let bacaan = JSON.stringify(bacaanshalat)
let json = JSON.parse(bacaan)
let data = json.result.map((v, i) => `${i + 1}. ${v.name}\n${v.arabic}\n${v.latin}\n*Artinya:*\n_"${v.terjemahan}"_`).join('\n\n')
let contoh = `*「 Bacaan Shalat 」*\n\n`
reply(`${contoh} + ${data}`)
}
break

case 'doaharian': {
await XReaction();
let src = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/islami/doaharian.json', 'utf-8'))
let caption = src.map((v, i) => {
return `
*${i + 1}.* ${v.title}

❃ Latin :
${v.latin}

❃ Arabic :
${v.arabic}

❃ Translate :
${v.translation}
`.trim()
}).join('\n\n')
reply(`${caption}`)

}
break

case 'niatsholat': {
await XReaction();
if (!q) return reply(`Contoh Penggunaan :\nniatsholat Subuh`)
const niatsholat = [
{
index: 1,
solat: "subuh",
latin: "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
arabic: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
translation_id: "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala",
},
{
index: 2,
solat: "maghrib",
latin: "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
arabic: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلاَثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
translation_id: "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala",
},
{
index: 3,
solat: "dzuhur",
latin: "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
arabic: "اُصَلِّى فَرْضَ الظُّهْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
translation_id: "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala",
},
{
index: 4,
solat: "isha",
latin: "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
arabic: "صَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
translation_id: "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala",
},
{
index: 5,
solat: "ashar",
latin: "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
arabic: "صَلِّى فَرْضَ الْعَصْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
translation_id: "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala",
}
]
let text = q.toLowerCase() || ''
let data = Object.values(niatsholat).find(v => v.solat == text)
if (!data) return reply(`${txt} Tidak Ditemukan\n\nList Solat 5 Waktu :\n• Subuh\n• Maghrib\n• Dzuhur\n• Isha\n• Ashar`)
reply(`
_*Niat Sholat ${text}*_

*Arab :* ${data.arabic}

*Latin :* ${data.latin} 

*Translate :* ${data.translation_id}`.trim())
}

break

case 'quotesislami': {
await XReaction();
const islami = [
{
 "id": "1",
 "arabic": "مَنْ سَارَ عَلىَ الدَّرْبِ وَصَلَ",
 "arti": "Barang siapa berjalan pada jalannya, maka dia akan sampai (pada tujuannya)."
},
{
 "id": "2",
 "arabic": "مَنْ صَبَرَ ظَفِرَ",
 "arti": "Barang siapa bersabar, maka dia akan beruntung."
},
{
 "id": "3",
 "arabic": "مَنْ جَدَّ وَجَـدَ",
 "arti": "Barang siapa bersungguh-sungguh, maka dia akan meraih (kesuksesan)."
},
{
 "id": "4",
 "arabic": "جَالِسْ أَهْلَ الصِّدْقِ وَالوَفَاءِ",
 "arti": "Bergaulah bersama orang-orang yang jujur dan menepati janji."
},
{
 "id": "5",
 "arabic": "مَنْ قَلَّ صِدْقُهُ قَلَّ صَدِيْقُهُ",
 "arti": "Barang siapa sedikit kejujurannya, maka sedikit pulalah temannya."
},
{
 "id": 6,
 "arabic": "مَوَدَّةُ الصَّدِيْقِ تَظْهَرُ وَقْتَ الضِّيْقِ",
 "arti": "Kecintaan seorang teman itu akan terlihat pada waktu kesempitan."
},
{
 "id": "7",
 "arabic": "الصَّبْرُ يُعِيْنُ عَلَى كُلِّ عَمَلٍ",
 "arti": "Kesabaran akan menolong segala pekerjaan."
},
{
 "id": "8",
 "arabic": "وَمَا اللَّذَّةُ إِلاَّ بَعْدَ التَّعَبِ",
 "arti": "Tidak ada kenikmatan kecuali setelah kepayahan."
},
{
 "id": "9",
 "arabic": "جَرِّبْ وَلاَحِظْ تَكُنْ عَارِفًا",
 "arti": "Coba dan perhatikanlah, maka engkau akan menjadi orang yang tahu."
},
{
 "id": "10",
 "arabic": "بَيْضَةُ اليَوْمِ خَيْرٌ مِنْ دَجَاجَةِ الغَدِ",
 "arti": "Telur hari ini lebih baik daripada ayam esok hari."
},
{
 "id": "11",
 "arabic": "أُطْلُبِ الْعِلْمَ مِنَ الْمَهْدِ إِلَى الَّلحْدِ",
 "arti": "Carilah ilmu sejak dari buaian hingga liang lahat."
},
{
 "id": "12",
 "arabic": "الوَقْتُ أَثْمَنُ مِنَ الذَّهَبِ",
 "arti": "Waktu itu lebih berharga daripada emas."
},
{
 "id": "13",
 "arabic": "لاَ خَيْرَ فيِ لَذَّةٍ تَعْقِبُ نَدَماً",
 "arti": "Tak ada kebaikan bagi kenikmatan yang diiringi dengan penyesalan."
},
{
 "id": "14",
 "arabic": "أَخِي لَنْ تَنَالَ العِلْمَ إِلاَّ بِسِتَّةٍ سَأُنْبِيْكَ عَنْ تَفْصِيْلِهَا بِبَيَانٍ: ذَكَاءٌ وَحِرْصٌ وَاجْتِهَادٌ وَدِرْهَمٌ وَصُحْبَةُ أُسْتَاذٍ وَطُوْلُ زَمَانٍ",
 "arti": "Wahai saudaraku, Kamu tidak akan memperoleh ilmu kecuali dengan enam perkara, akan aku sampaikan rinciannya dengan jelas; 1) Kecerdasan, 2) Ketamaan (terhadap ilmu), 3) Kesungguhan, 4) Harta benda (sebagai bekal), 5) Bergaul dengan guru, 6) Waktu yang lama."
},
{
 "id": "15",
 "arabic": "لاَ تَكُنْ رَطْباً فَتُعْصَرَ وَلاَ يَابِسًا فَتُكَسَّرَ",
 "arti": "Janganlah kamu bersikap lemah, sehingga kamu mudah diperas. Dan janganlah kamu bersikap keras, sehingga kamu mudah dipatahkan."
},
{
 "id": "16",
 "arabic": "لِكُلِّ مَقَامٍ مَقَالٌ وَلِكُلِّ مَقَالٍ مَقَامٌ",
 "arti": "Setiap tempat memiliki perkataannya masing-masing, dan setiap perkataan memiliki tempatnya masing-masing."
},{
 "id": "17",
 "arabic": "خَيْرُ النَّاسِ أَحْسَنُهُمْ خُلُقاً وَأَنْفَعُهُمْ لِلنَّاسِ",
 "arti": "Sebaik-baik manusia adalah yang paling baik budi pekertinya dan yang paling bermanfaat bagi manusia lainnya."
},
{
 "id": "18",
 "arabic": "خَيْرُ جَلِيْسٍ في الزّمانِ كِتابُ",
 "arti": "Sebaik-baik teman duduk di setiap waktu adalah buku."
},
{
 "id": "19",
 "arabic": "مَنْ يَزْرَعْ يَحْصُدْ",
 "arti": "Barang siapa menanam, pasti ia akan memetik (mengetam)."
},
{
 "id": "20",
 "arabic": "لَوْلاَ العِلْمُ لَكَانَ النَّاسُ كَالبَهَائِمِ",
 "arti": "Kalaulah tidak karena ilmu, niscaya manusia itu seperti binatang."
},
{
 "id": "21",
 "arabic": "سَلاَمَةُ الإِنْسَانِ فيِ حِفْظِ اللِّسَانِ",
 "arti": "Keselamatan manusia itu terletak pada penjagaan lidahnya (perkataannya)."
},
{
"id": "22",
 "arabic": "الرِّفْقُ بِالضَّعِيْفِ مِنْ خُلُقِ الشَّرِيْفِ",
 "arti": "Berlaku lemah lembut kepada orang yang lemah itu termasuk akhlak orang yang mulia (terhormat)."
},
{
 "id": "23",
 "arabic": "وَعَامِلِ النَّاسَ بِمَا تُحِبُّ مِنْهُ دَائِماً",
 "arti": "Dan bergaullah dengan manusia dengan sikap yang kamu juga suka diperlakukan seperti itu."
},
{
 "id": "24",
 "arabic": "لَيْسَ الجَمَالُ بِأَثْوَابٍ تُزَيِّنُنُا إِنَّ الجَمَالَ جمَاَلُ العِلْمِ وَالأَدَبِ",
 "arti": "Kecantikan bukanlah dengan pakaian yang melekat menghiasi diri kita, sesungguhnya kecantikan ialah kecantikan dengan ilmu dan budi pekerti."
},
{
 "id": "25",
 "arabic": "مَنْ أَعاَنَكَ عَلىَ الشَّرِّ ظَلَمَكَ",
 "arti": "Barang siapa membantumu dalam kejahatan, maka sesungguhnya ia telah berbuat aniaya terhadapmu."
}
]
const randomIndex = Math.floor(Math.random() * islami.length);
const randomQuote = islami[randomIndex];
const { arabic, arti } = randomQuote;
reply(`${arabic}\n${arti}`)
}
break

case 'doatahlil': {
await XReaction();
let { result } = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/islami/tahlil.json', 'utf-8'))
let caption = result.map((v, i) => {
return `
*${i + 1}.* ${v.title}

❃ Arabic :
${v.arabic}

❃ Translate :
${v.translation}
`.trim()
}).join('\n\n')
reply(`${caption}`)
}
break

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Islami Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Group Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'listadmin': {
  if (!m.isGroup) return reply('❌ fitur ini khusus grup')

  if (!groupAdmins || groupAdmins.length === 0)
    return reply('❌ tidak ada admin di grup ini')

  let teks = `👮 *DAFTAR ADMIN GRUP*\n`
  teks += `📛 *${groupName}*\n\n`

  let no = 1
  for (let admin of groupAdmins) {
    teks += `${no++}. @${admin.split('@')[0]}\n`
  }

  reply(teks)
}
break
case 'statusgroup':
case 'groupstate':
case 'groupstatus': {
  if (!m.isGroup) return reply('❌ Fitur ini hanya bisa dipakai di grup.')

  const meta = await Alice.groupMetadata(m.chat)
  const participants = meta.participants || []

  const admins = participants.filter(v => v.admin)
  const adminCount = admins.length
  const memberCount = participants.length
  const owner =
    meta.owner ||
    admins.find(v => v.admin === 'superadmin')?.id ||
    '-'

  const groupStatus = meta.announce
    ? 'Tertutup (admin only)'
    : 'Terbuka'

  const chats = global.db.data.chats[m.chat] || {}

  const status = (v) => v ? 'ON' : 'OFF'

let teks = `📊 *STATUS GRUP*

🏷️ *Info Grup*
• Nama    : ${meta.subject}
• Owner   : @${owner.split('@')[0]}
• Admin   : ${adminCount}
• Member  : ${memberCount}
• Mode    : ${groupStatus}

🛡️ *Keamanan Grup*
• Anti Bot        : ${status(chats.antibot)}
• Anti Virtex     : ${status(chats.antivirtex)}
• Anti Toxic      : ${status(chats.antitoxic)}
• Anti Call       : ${status(chats.anticall)}
• Anti Tag SW     : ${status(chats.antitagsw)}
• Anti WAME       : ${status(chats.antiwame)}
• Anti Spam       : ${status(chats.antispam)}

📂 *Anti Media*
• Anti Media      : ${status(chats.antimedia)}
• Anti Image      : ${status(chats.antiimage)}
• Anti Video      : ${status(chats.antivideo)}
• Anti Audio      : ${status(chats.antiaudio)}
• Anti Sticker    : ${status(chats.antisticker)}
• Anti Document   : ${status(chats.antidocument)}
• Anti Contact    : ${status(chats.anticontact)}
• Anti Location   : ${status(chats.antilocation)}
• Anti Poll       : ${status(chats.antipoll)}
• Anti ViewOnce   : ${status(chats.antiviewonce)}

🔗 *Anti Link*
• Link Grup       : ${status(chats.antilinkgc)}
• Link Kick       : ${status(chats.antilinkkick)}
• Promotion       : ${status(chats.antipromotion)}
• Mediafire       : ${status(chats.antilinkmediafire)}
• Facebook        : ${status(chats.antilinkfacebook)}
• Instagram       : ${status(chats.antilinkinstagram)}
• TikTok          : ${status(chats.antilinktiktok)}
• Telegram        : ${status(chats.antilinktelegram)}
• Terabox         : ${status(chats.antilinkterabox)}
• YouTube Video   : ${status(chats.antilinkyoutubevideo)}
• YouTube Channel : ${status(chats.antilinkyoutubechannel)}
• Twitter         : ${status(chats.antilinktwitter)}

⚙️ *Pengaturan Lain*
• Welcome         : ${status(chats.welcome)}
• Goodbye         : ${status(chats.goodbye)}
• Detect          : ${status(chats.detect)}
• Auto Sticker    : ${status(chats.autosticker)}
• Auto AI         : ${status(chats.autoai)}

_🔎 Status diambil langsung dari pengaturan grup_`

reply(teks)
}
break
case 'swgroup': {
  if (!m.isGroup) return reply('❌ Fitur ini hanya bisa dipakai di grup.')
  if (!isAdmins && !isOwner) return reply('❌ Fitur khusus admin grup atau owner bot.')

  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ""
  
  // Ambil caption user atau caption dari media
  const captionQuoted = quoted.msg?.caption || quoted.caption || ""
  const caption = text || captionQuoted
  const jid = m.chat

  try {
      if (/image/.test(mime)) {
          const buffer = await quoted.download()
          await Alice.sendMessage(jid, {
              groupStatusMessage: {
                  image: buffer,
                  caption
              }
          })
          await Alice.sendMessage(jid, { text: "✔️ Status gambar terkirim!" })
      } 
      else if (/video/.test(mime)) {
          const buffer = await quoted.download()
          await Alice.sendMessage(jid, {
              groupStatusMessage: {
                  video: buffer,
                  caption
              }
          })
          await Alice.sendMessage(jid, { text: "✔️ Status video terkirim!" })
      } 
      else if (/audio/.test(mime)) {
          const buffer = await quoted.download()
          await Alice.sendMessage(jid, {
              groupStatusMessage: {
                  audio: buffer,
                  caption
              }
          })
          await Alice.sendMessage(jid, { text: "✔️ Status audio terkirim!" })
      } 
      else if (caption) {
          await Alice.sendMessage(jid, {
              groupStatusMessage: {
                  text: caption
              }
          })
          await Alice.sendMessage(jid, { text: "✔️ Status teks terkirim!" })
      } 
      else {
          reply(`- example: .swgroup (reply media)`)
      }
  } catch (e) {
      reply(String(e))
  }
}
break
case 'onlyadmin': {
  if (!m.isGroup) return reply('❌ Fitur ini hanya bisa dipakai di grup.')
  if (!isAdmins && !isOwner) return reply('❌ Fitur khusus admin grup atau owner bot.')

  let groupId = m.chat
  let groupName = (await Alice.groupMetadata(groupId)).subject
  let action = (args[0] || '').toLowerCase()

  if (!action) {
    // kalau tanpa argumen → kasih info status
    let status = onlyadmin.includes(groupId) 
      ? '🔒 *Only Admin aktif* (hanya admin yang bisa pakai bot).' 
      : '🔓 *Only Admin nonaktif* (semua member bisa pakai bot).'
    return reply(`📋 Status di grup *${groupName}*:\n\n${status}\n\n💡 Gunakan: ${prefix + command} on/off`)
  }

  if (action === 'on') {
    if (onlyadmin.includes(groupId)) return reply(`❌ Grup *${groupName}* sudah dalam mode *Only Admin*!`)
    onlyadmin.push(groupId)
    fs.writeFileSync('./AliceDatabase/group-db/onlyadmin.json', JSON.stringify(onlyadmin, null, 2))
    reply(`✅ Grup *${groupName}* berhasil mengaktifkan mode *Only Admin*!`)
    await Alice.sendMessage(groupId, { text: `⚠️ Mode *Only Admin* aktif.\nSekarang hanya admin grup yang bisa menggunakan bot.` })
  } else if (action === 'off') {
    if (!onlyadmin.includes(groupId)) return reply(`❌ Grup *${groupName}* tidak dalam mode *Only Admin*!`)
    onlyadmin = onlyadmin.filter(id => id !== groupId)
    fs.writeFileSync('./AliceDatabase/group-db/onlyadmin.json', JSON.stringify(onlyadmin, null, 2))
    reply(`🔓 Grup *${groupName}* berhasil menonaktifkan mode *Only Admin*!`)
    await Alice.sendMessage(groupId, { text: `✅ Mode *Only Admin* dimatikan.\nSekarang semua member bisa menggunakan bot.` })
  } else {
    reply(`❌ Argumen tidak valid!\nGunakan: ${prefix + command} on/off`)
  }
}
break
case 'acc': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.')
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin atau owner bot.')

  const pending = await Alice.groupRequestParticipantsList(m.chat);
  if (pending.length === 0) return reply('✅ Tidak ada member yang minta bergabung.');

  if (args[0] === 'all') {
    await Alice.groupRequestParticipantsUpdate(m.chat, pending.map(u => u.jid), 'approve');
    reply(`✅ Semua member yang meminta bergabung sudah di-ACC (${pending.length} orang).`);
  } else {
    let jumlah = parseInt(args[0]);
    if (isNaN(jumlah) || jumlah < 1) return reply('Masukkan jumlah yang valid!\nContoh: .acc 1 atau .acc all');

    let selected = pending.slice(0, jumlah);
    await Alice.groupRequestParticipantsUpdate(m.chat, selected.map(u => u.jid), 'approve');
    reply(`✅ Berhasil ACC ${selected.length} member yang meminta gabung.`);
  }
}
break;
case 'tolakacc': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.')
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin atau owner bot.')

  const pending = await Alice.groupRequestParticipantsList(m.chat);
  if (pending.length === 0) return reply('✅ Tidak ada member yang minta bergabung.')

  if (args[0] === 'all') {
    await Alice.groupRequestParticipantsUpdate(m.chat, pending.map(u => u.jid), 'reject')
    reply(`✅ Semua permintaan gabung sudah DITOLAK (${pending.length} orang).`)
  } else {
    let jumlah = parseInt(args[0])
    if (isNaN(jumlah) || jumlah < 1) return reply('Masukkan jumlah yang valid!\nContoh: .tolakacc 1 atau .tolakacc all')

    let selected = pending.slice(0, jumlah)
    await Alice.groupRequestParticipantsUpdate(m.chat, selected.map(u => u.jid), 'reject')
    reply(`✅ Berhasil menolak ${selected.length} permintaan gabung.`)
  }
}
break;
case 'kickall': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.')
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin atau owner bot.')

  
  const moment = require('moment-timezone')
  const path = './AliceSystem/AliceDatabase/Group/kicklog.json'
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

  if (!fs.existsSync('./AliceSystem/AliceDatabase/Group')) {
    fs.mkdirSync('./AliceSystem/AliceDatabase/Group', { recursive: true })
  }

  let kickLog = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path)) : {}
  let dataKick = []

  const botId = Alice.user.id.split(':')[0]

  for (let p of participants) {
    const userId = p.id
    if (userId.includes(botId) || userId === m.sender) continue

    try {
      await Alice.groupParticipantsUpdate(m.chat, [userId], 'remove')
      const name = (await Alice.getName(userId)) || userId.split('@')[0]
      dataKick.push({
        id: userId,
        nama: name,
        waktu: moment().tz('Asia/Jakarta').format('D MMMM YYYY, HH:mm [WIB]')
      })
      await delay(500)
    } catch (err) {
      console.log(`❌ Gagal kick ${userId}`, err)
    }
  }

  kickLog[m.chat] = dataKick
  fs.writeFileSync(path, JSON.stringify(kickLog, null, 2))
  reply(`✅ ${dataKick.length} member telah dikeluarkan dan disimpan di log.`)
}
break

case 'addallback': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.');
  if (!isAdmins) return reply('❌ Hanya admin yang bisa mengatur');


const path = './AliceSystem/AliceDatabase/Group/kicklog.json.json'
const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

  if (!fs.existsSync(path)) return reply('📭 Tidak ada data kick.')
  let kickLog = JSON.parse(fs.readFileSync(path))
  let data = kickLog[m.chat]
  if (!data || data.length === 0) return reply('📭 Tidak ada yang bisa dikembalikan.')

  let sukses = 0, gagal = 0
  for (let user of data) {
    try {
      await Alice.groupParticipantsUpdate(m.chat, [user.id], 'add')
      sukses++
      await delay(500)
    } catch (e) {
      gagal++
      await Alice.sendMessage(m.chat, {
        text: `⚠️ Tidak bisa mengundang @${user.id.split('@')[0]}

Mungkin mereka menonaktifkan:
*Privasi > Grup > Semua orang*

⏰ Dikeluarkan: *${user.waktu}*
👤 Nama: *${user.nama}*`,
        mentions: [user.id]
      })
    }
  }

  delete kickLog[m.chat]
  fs.writeFileSync(path, JSON.stringify(kickLog, null, 2))
  reply(`🔁 *Selesai mengembalikan*\n✅ Berhasil: ${sukses}\n❌ Gagal: ${gagal}`)
}
break

case 'kicklog': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.');
  if (!isAdmins) return reply('❌ Hanya admin yang bisa mengatur');

  
  const path = './AliceSystem/AliceDatabase/Group/kicklog.json'

  if (!fs.existsSync(path)) return reply('📭 Tidak ada data kick ditemukan.')

  const kickLog = JSON.parse(fs.readFileSync(path))
  const data = kickLog[m.chat]

  if (!data || data.length === 0) return reply('📭 Tidak ada yang dikick di grup ini.')

  // Format teks log
  let teks = `📄 *LOG ANGGOTA YANG DIKELUARKAN:*\n`
  teks += `Grup: ${groupName}\nTotal: ${data.length} member\n`
  teks += `──────────────────────\n`

  for (let i = 0; i < data.length; i++) {
    let u = data[i]
    teks += `🧍 *${i + 1}.* ${u.nama}\n📱 @${u.id.split('@')[0]}\n🕒 ${u.waktu}\n\n`
  }

  // Kalau terlalu panjang (lebih dari 4000 karakter), kirim sebagai file txt
  if (teks.length > 4000) {
    const filePath = './tmp/kicklog.txt'
    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true })
    fs.writeFileSync(filePath, teks)
    await Alice.sendMessage(m.chat, {
      document: fs.readFileSync(filePath),
      fileName: 'kicklog.txt',
      mimetype: 'text/plain',
      caption: `📎 Kicklog disimpan sebagai file (panjang melebihi batas).`
    }, { quoted: m })
  } else {
    Alice.sendMessage(m.chat, {
      text: teks.trim(),
      mentions: data.map(v => v.id)
    }, { quoted: m })
  }
}
break

case 'clearkicklog': {
  if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup.')
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin grup atau owner bot.')

  
  const path = './AliceSystem/AliceDatabase/Group/kicklog.json'

  if (!fs.existsSync(path)) return reply('📭 Tidak ada file log kick.')

  let kickLog = JSON.parse(fs.readFileSync(path))

  if (!kickLog[m.chat]) return reply('✅ Tidak ada log kick tersimpan untuk grup ini.')

  delete kickLog[m.chat]
  fs.writeFileSync(path, JSON.stringify(kickLog, null, 2))

  reply('🧹 Log kick untuk grup ini berhasil dihapus.')
}
break


case "setwelcome": {
  if (!m.isGroup) return reply("❌ Khusus di group");
  if (!isAdmins && !isOwner) return reply("❌ Hanya admin yang bisa pakai ini");

  const welcomeDB = readWelcomeDB();
  const groupCfg = welcomeDB[m.chat] || {};

  // === Auto Detect Media (gambar/video) ===
  if (
    (m.quoted && (m.quoted.mtype === "videoMessage" || m.quoted.mtype === "imageMessage")) ||
    m.message?.videoMessage ||
    m.message?.imageMessage
  ) {
    const mediaMsg = m.quoted ? m.quoted : m;
    const mediaUrl = await Alice.downloadAndSaveMediaMessage(mediaMsg, WELCOME_MEDIA_DIR);

    groupCfg.thumb = groupCfg.thumb || {};
    groupCfg.thumb.add = mediaUrl;         // simpan path file
    groupCfg.thumb.addType = mediaMsg.mtype.includes("video") ? "video" : "image"; // simpan jenis
    welcomeDB[m.chat] = groupCfg;
    writeWelcomeDB(welcomeDB);

    return reply(`✅ Background *welcome* berhasil diubah (${groupCfg.thumb.addType})!`);
  }

  // === Auto Detect Teks ===
  if (text) {
    groupCfg.welcome = text;
    welcomeDB[m.chat] = groupCfg;
    writeWelcomeDB(welcomeDB);

    return reply("✅ Pesan *welcome* berhasil diatur!");
  }

  reply(
    `⚙️ Cara pakai:\n\n` +
    `- Kirim/reply video/gambar + ketik *${prefix}setwelcome* → set background.\n` +
    `- Ketik *${prefix}setwelcome Teks* → set pesan teks.\n\n` +
    `Placeholder: @user, @group, @tanggal, @jam, @member`
  );
}
break;

case "setleft": {
  if (!m.isGroup) return reply("❌ Khusus di group");
  if (!isAdmins && !isOwner) return reply("❌ Hanya admin yang bisa pakai ini");

  const welcomeDB = readWelcomeDB();
  const groupCfg = welcomeDB[m.chat] || {};

  // === Auto Detect Media (gambar/video) ===
  if (
    (m.quoted && (m.quoted.mtype === "videoMessage" || m.quoted.mtype === "imageMessage")) ||
    m.message?.videoMessage ||
    m.message?.imageMessage
  ) {
    const mediaMsg = m.quoted ? m.quoted : m;
    const mediaUrl = await Alice.downloadAndSaveMediaMessage(mediaMsg, LEFT_MEDIA_DIR);

    groupCfg.thumb = groupCfg.thumb || {};
    groupCfg.thumb.remove = mediaUrl;
    groupCfg.thumb.removeType = mediaMsg.mtype.includes("video") ? "video" : "image";
    welcomeDB[m.chat] = groupCfg;
    writeWelcomeDB(welcomeDB);

    return reply(`✅ Background *left* berhasil diubah (${groupCfg.thumb.removeType})!`);
  }

  // === Auto Detect Teks ===
  if (text) {
    groupCfg.left = text;
    welcomeDB[m.chat] = groupCfg;
    writeWelcomeDB(welcomeDB);

    return reply("✅ Pesan *left* berhasil diatur!");
  }

  // === Panduan penggunaan ===
  reply(
    `⚙️ Cara pakai:\n\n` +
    `- Kirim/reply video/gambar + ketik *${prefix}setleft* → set background.\n` +
    `- Ketik *${prefix}setleft Teks* → set pesan teks.\n\n` +
    `Placeholder yang bisa dipakai:\n` +
    `@user → tag user\n` +
    `@group → nama grup\n` +
    `@tanggal → tanggal sekarang\n` +
    `@jam → jam sekarang\n` +
    `@member → jumlah member`
  );
}
break;

// welcome on/off
case 'welcome': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.');
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin yang bisa mengubah.');
  const arg = (text || '').trim().toLowerCase();

  if (!['on','off'].includes(arg)) {
    let db={}; try{db=JSON.parse(fs.readFileSync(WELCOME_DB_PATH))}catch{}
    const g = db[m.chat] || {};
    return reply(`⚙️ Penggunaan:
${prefix}welcome on
${prefix}welcome off

Status saat ini: ${g.welcome_enabled === false ? 'OFF' : 'ON'}`);
  }

  let db = {}; try { db = JSON.parse(fs.readFileSync(WELCOME_DB_PATH)); } catch {}
  if (!db[m.chat]) db[m.chat] = {};
  db[m.chat].welcome_enabled = (arg === 'on');
  fs.writeFileSync(WELCOME_DB_PATH, JSON.stringify(db, null, 2));
  reply(`✅ Welcome: *${arg.toUpperCase()}* untuk grup ini.`);
  break;
}

// left on/off (pakai nama berbeda agar tidak bentrok dg perintah 'left' lain)
case 'left': {
  if (!m.isGroup) return reply('❌ Hanya bisa di dalam grup.');
  if (!isAdmins && !isOwner) return reply('❌ Hanya admin yang bisa mengubah.');
  const arg = (text || '').trim().toLowerCase();

  if (!['on','off'].includes(arg)) {
    let db={}; try{db=JSON.parse(fs.readFileSync(WELCOME_DB_PATH))}catch{}
    const g = db[m.chat] || {};
    return reply(`⚙️ Penggunaan:
${prefix}lefttoggle on
${prefix}lefttoggle off

Status saat ini: ${g.left_enabled === false ? 'OFF' : 'ON'}`);
  }

  let db = {}; try { db = JSON.parse(fs.readFileSync(WELCOME_DB_PATH)); } catch {}
  if (!db[m.chat]) db[m.chat] = {};
  db[m.chat].left_enabled = (arg === 'on');
  fs.writeFileSync(WELCOME_DB_PATH, JSON.stringify(db, null, 2));
  reply(`✅ Left: *${arg.toUpperCase()}* untuk grup ini.`);
  break;
}
      case "totalchat":
      case "totalpesan":
      if (!m.isGroup) return XRG()
      await XReaction();
        {
          if (!global.db.data.chats[m.chat]?.totalChat) {
            return reply("Tidak ada data chat.");
          }
          if (text && text == "reset") {
            global.db.data.chats[m.chat].totalChat = {};
            return reply("Total chat telah di reset untuk grup ini.");
          }
          const entries = Object.entries(global.db.data.chats[m.chat].totalChat);
          const total = await Promise.all(entries.map(async ([index, value], i) => {
            return `${i + 1}. @${index.split("@")[0]} : ${value} pesan`;
          }));
          reply(`*\`ᴛᴏᴛᴀʟ ᴄʜᴀᴛs ɢʀᴏᴜᴘ ᴀʟʟ ᴜsᴇʀ \`*:\n\n${total.join("\n")}`);
        }
        break;

case 'cekasalmember' : {
if (!m.isGroup) return XRG()
await XReaction();
const participants = await Alice.groupMetadata(m.chat).then(metadata => metadata.participants);
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  let member = groupMetadata.participants.length;
  
  participants.forEach(participant => {
    const phoneNumber = participant.id.split('@')[0];
    if (phoneNumber.startsWith("62")) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else if (phoneNumber.startsWith("+1")) {
      countOther++;
    } else {
      countOther++;
    }
  });
  
  const replyMessage = 
  `
┌─⊷ *ASAL NEGARA*
Jumlah Anggota Grup Berdasarkan Negara:
🇮🇩 • Indonesia: ${countIndonesia}
🇲🇾 • Malaysia: ${countMalaysia}
🇺🇲 • USA + OTHER : ${countUSA}
🏳️ • Negara Lain: ${countOther}
👥 • jumlah semua mmeber: ${member}
└──────────────
`;

  reply(replyMessage);
}
break
case 'warn': {
    if (!m.isGroup) return Alice.sendMessage(m.chat, { text: 'Fitur ini hanya untuk grup.' });
    if (!isAdmins) return Alice.sendMessage(m.chat, { text: 'Kamu bukan admin grup.' });

    const target = mentionUser[0];
    if (!target) return Alice.sendMessage(m.chat, { text: 'Tag user yang ingin diberikan peringatan.' });

    const groupWarn = warnData[m.chat] || { maxWarn: 3, warns: {} };
    groupWarn.warns[target] = (groupWarn.warns[target] || 0) + 1;

    if (groupWarn.warns[target] >= groupWarn.maxWarn) {
      delete groupWarn.warns[target];
      await Alice.groupParticipantsUpdate(m.chat, [target], 'remove');
      Alice.sendMessage(m.chat, {
        text: `User @${target.split('@')[0]} telah mencapai batas peringatan dan telah dikeluarkan.`,
        mentions: [target],
      });
    } else {
      Alice.sendMessage(m.chat, {
        text: `User @${target.split('@')[0]} telah diberi peringatan (${groupWarn.warns[target]}/${groupWarn.maxWarn}).`,
        mentions: [target],
      });
    }

    warnData[m.chat] = groupWarn;
    saveWarnData();
    }
break;
case 'warninfo': {
    if (!m.isGroup) return Alice.sendMessage(m.chat, { text: 'Fitur ini hanya untuk grup.' });

    try {
        const metadata = await Alice.groupMetadata(m.chat);
        const groupName = metadata.subject;
        const groupWarn = warnData[m.chat] || { maxWarn: 3, warns: {} };
        const totalWarned = Object.keys(groupWarn.warns).length;
        const warnList = Object.entries(groupWarn.warns)
            .map(([user, count]) => `• @${user.split('@')[0]} (${count}/${groupWarn.maxWarn})`)
            .join('\n') || 'Tidak ada user yang mendapat peringatan.';

        const warnInfoText = `╭─── *「 ${groupName} 」*\n` +
            `│ *Max Warn:* ${groupWarn.maxWarn}\n` +
            `│ *Total User:* ${totalWarned}\n` +
            `╰──────────────\n\n` +
            `*List User:*\n${warnList}`;

        Alice.sendMessage(m.chat, { text: warnInfoText, mentions: Object.keys(groupWarn.warns) });
    } catch (err) {
        console.error(err);
        Alice.sendMessage(m.chat, { text: 'Terjadi kesalahan saat mengambil metadata grup.' });
    }
    }
break;
case 'setwarn': {
    if (!m.isGroup) return Alice.sendMessage(m.chat, { text: 'Fitur ini hanya untuk grup.' });
    if (!isAdmins) return Alice.sendMessage(m.chat, { text: 'Kamu bukan admin grup.' });

    const maxWarn = parseInt(args[0]);
    if (isNaN(maxWarn) || maxWarn <= 0) return Alice.sendMessage(m.chat, { text: 'Masukkan jumlah maksimal peringatan yang valid.' });

    const groupWarn = warnData[m.chat] || { maxWarn: 3, warns: {} };
    groupWarn.maxWarn = maxWarn;

    warnData[m.chat] = groupWarn;
    saveWarnData();

    Alice.sendMessage(m.chat, { text: `Jumlah maksimal peringatan di grup ini telah diatur menjadi ${maxWarn}.` });
    }
break;
case 'delwarn': {
    if (!m.isGroup) return Alice.sendMessage(m.chat, { text: 'Fitur ini hanya untuk grup.' });
    if (!isAdmins) return Alice.sendMessage(m.chat, { text: 'Kamu bukan admin grup.' });

    const target = mentionUser[0];
    if (!target) return Alice.sendMessage(m.chat, { text: 'Tag user yang ingin dihapus peringatannya.' });

    const warnCount = parseInt(args[1]);
    if (isNaN(warnCount) || warnCount <= 0) return Alice.sendMessage(m.chat, { text: 'Masukkan jumlah peringatan yang valid untuk dihapus.' });

    const groupWarn = warnData[m.chat] || { maxWarn: 3, warns: {} };
    if (!groupWarn.warns[target]) return Alice.sendMessage(m.chat, { text: 'User ini tidak memiliki peringatan.' });

    if (groupWarn.warns[target] < warnCount) {
      return Alice.sendMessage(m.chat, { text: `User ini hanya memiliki ${groupWarn.warns[target]} peringatan.` });
    }

    groupWarn.warns[target] -= warnCount;
    if (groupWarn.warns[target] <= 0) delete groupWarn.warns[target];

    warnData[m.chat] = groupWarn;
    saveWarnData();

    Alice.sendMessage(m.chat, {
      text: `Peringatan sebanyak ${warnCount} untuk user @${target.split('@')[0]} telah dihapus.`,
      mentions: [target],
    });
    }
break;
case 'reswarn': {
    if (!m.isGroup) return Alice.sendMessage(m.chat, { text: 'Fitur ini hanya untuk grup.' });
    if (!isAdmins) return Alice.sendMessage(m.chat, { text: 'Kamu bukan admin grup.' });

    if (!warnData[m.chat]) return Alice.sendMessage(m.chat, { text: 'Tidak ada data peringatan di grup ini.' });

    delete warnData[m.chat];
    saveWarnData();

    Alice.sendMessage(m.chat, { text: 'Semua peringatan di grup ini telah dihapus.' });
    }
break;

case 'autobio':
if (!isOwner) return XRO()
if (args[0] == 'on'){
if (global.autobio) return reply('sudah aktif!')
global.autobio = true
reply('autobio aktif')
} else if (args[0] == 'off'){
if (!global.autobio) return reply('sudah dimatikan!')
global.autobio = false
reply('autobio di matikan')
} else reply('on / off')
break

case 'autodownload':
if (!m.isGroup) return reply('Khusus Grup')
if (!isAdmins && !isOwner) return reply('Khusus Admin')

if (args[0] === 'on') {
  if (autoDlSettings[m.chat]) return reply('sudah aktif di grup ini!')
  autoDlSettings[m.chat] = true
  saveAutoDl()
  reply('✅ Auto download AKTIF untuk grup ini')
} else if (args[0] === 'off') {
  if (!autoDlSettings[m.chat]) return reply('sudah nonaktif di grup ini!')
  delete autoDlSettings[m.chat]
  saveAutoDl()
  reply('❌ Auto download NONAKTIF untuk grup ini')
} else {
  reply('on / off')
}
break

case 'resetsider': {
if (!isAdmins) return XRA()
    if (db_sider && db_sider[m.chat]) {
      delete db_sider[m.chat];
      fs.writeFileSync('./AliceSystem/AliceDatabase/Group/sider.json', JSON.stringify(db_sider));
      reply("_Sider Berhasil Direset Pada Grub ini_")
    } else {
      reply("_Sider Sudah Direset Pada Grub ini_")
    }
}
break
case 'gcsider' : {
await Alice.sendPresenceUpdate('composing', m.chat)
    var lama = 86400000 * 7
    const now = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    });
    const milliseconds = new Date(now).getTime();

    let member = groupMetadata.participants.map(v => v.id)
    if (!text) {
        var pesan = "Harap aktif di grup karena akan ada pembersihan member setiap saat"
    } else {
        var pesan = text
    }
    var sum
    sum = member.length
    var total = 0
    var sider = []
    for (let i = 0; i < sum; i++) {
        let users = m.isGroup ? groupMetadata.participants.find(u => u.id == member[i]) : {}
        if ((typeof global.db.data.users[member[i]] == 'undefined' || milliseconds * 1 - global.db.data.users[member[i]].lastseen > lama) && !users.isAdmin) {
            if (typeof global.db.data.users[member[i]] !== 'undefined') {
                if (global.db.data.users[member[i]].banned == true) {
                    total++
                    sider.push(member[i])
                }
            } else {
                total++
                sider.push(member[i])
            }
        }
    }
    if (total == 0) return reply(m.chat, `*Digrup ini tidak terdapat sider.*`, xy)
    reply(m.chat, `*${total}/${sum}* anggota grup *${await Alice.getName(m.chat)}* adalah sider dengan alasan :\n1. Tidak aktif selama lebih dari 7 hari\n2. Baru join tetapi tidak pernah nimbrung\n\n_“${pesan}”_\n\n*LIST SIDER :*\n${sider.map(v => '  ○ @' + v.replace(/@.+/, '' + typeof global.db.data.users[v] == "undefined" ? ' Sider ' : ' Off ' + msToDate(milliseconds * 1 - global.db.data.users[v].lastseen))).join('\n')}`, m, {
        contextInfo: {
            mentionedJid: sider
        }
    })
}
break

case 'listabsen': {
    if (!isAdmins) return XRA()
    if (!m.isGroup) return XRG()
    if (db_absen[m.chat+hariini]) {
    let stringAbsen = `*LIST ABSEN [ ${hariini} ]*\n\n`
    stringAbsen += db_absen[m.chat+hariini].map(absen => `⭔ @${absen.user_id.split('@')[0]} \n`).join('');    

    let arr_listabsen   = db_absen[m.chat+hariini].map(absen => ({ id: absen.user_id }));
    let jumlahOrangAbsen= arr_listabsen.length;
    let total_orgdgrub  = participants.length;

    let lomAbsen        = total_orgdgrub - jumlahOrangAbsen

    if (lomAbsen == 0) {
         stringAbsen += `\n*${jumlahOrangAbsen}* Orang Telah Absen Semua`
    }else{
         stringAbsen += `\n*${jumlahOrangAbsen}* Orang Telah Absen, Tersisa ${lomAbsen} Orang`
    }

    Alice.sendMessage(m.chat, { text: stringAbsen, mentions: arr_listabsen.map(a => a.id) }, { quoted: m })

    } else{
        return reply('Belum ada absen hari ini')
    }
}
break
case 'absen': {
    if (!m.isGroup) return XRG()
    if (!db_absen[m.chat+hariini]) {

        // pertama absen
        db_absen[m.chat+hariini] = [{ user_id: sender, tanggal: hariini }];
        reply('Absen Berhasil')
    }else {

        // absen kedua
      const sudah_absen = db_absen[m.chat+hariini].findIndex(item => item.user_id === sender);

      if (sudah_absen !== -1) {
            reply('Kamu sudah absen hari ini')
        }else {
            reply('Absen Berhasil')
            db_absen[m.chat+hariini].push({ user_id: sender, tanggal: hariini });
        }
          
    }

 fs.writeFileSync('./AliceSystem/AliceDatabase/Group//absen.json', JSON.stringify(db_absen))

}
break

	case 'closetime': {
  if (!m.isGroup) return reply("⛔ Hanya grup.")
  if (!isAdmins && !isOwner) return reply("⛔ Admin only.")
  if (!isBotAdmins) return reply("⛔ Bot harus admin.")

  if (!args[0] || !args[1]) return reply("Contoh: .closetime 10 minute")

  let timeVal = parseInt(args[0])
  if (isNaN(timeVal)) return reply("Masukkan angka yang valid.")

  let timer
  if (args[1] === 'second') timer = timeVal * 1000
  else if (args[1] === 'minute') timer = timeVal * 60000
  else if (args[1] === 'hour') timer = timeVal * 3600000
  else return reply("Pilih waktu: second/minute/hour")

  reply(`⏳ Grup akan ditutup dalam ${timeVal} ${args[1]}...`)
  setTimeout(() => {
    Alice.groupSettingUpdate(m.chat, 'announcement')
    reply('🔒 Grup telah ditutup.')
  }, timer)
}
break;
            case 'opentime':
                if (!m.isGroup) return reply("*[ sʏsᴛᴇᴍ ]* ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴅᴏᴀɴɢ")
                if (!isAdmins && !isOwner) return XRA()
                if (!isBotAdmins) return reply("*[ sʏsᴛᴇᴍ ] ʙᴏᴛ ʜᴀʀᴜs ᴊᴀᴅɪ ᴀᴅᴍɪɴ ᴅᴜʟᴜ*")
                if (args[1] == 'second') {
                    var timer = args[0] * `1000`
                } else if (args[1] == 'minute') {
                    var timer = args[0] * `60000`
                } else if (args[1] == 'hour') {
                    var timer = args[0] * `3600000`
                } else if (args[1] == 'day') {
                    var timer = args[0] * `86400000`
                } else {
                    return reply('*select:*\nsecond\nminute\nhour\n\n*example*\n10 second')
                }
                reply(`Open time ${q} starting from now`)
                setTimeout(() => {
                    var nomor = m.participant
                    const open = `*Open time* the group was opened by admin\n now members can send messages`
                    Alice.groupSettingUpdate(m.chat, 'not_announcement')
                    reply(open)
                }, timer)
                break


case 'antilink':
case 'setgroup':
case 'groupset':
case 'setgc': {
if (!m.isGroup) return reply("*[ sʏsᴛᴇᴍ ]* ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴅᴏᴀɴɢ")
if (!isAdmins && !isOwner) return XRA()
if (!isBotAdmins) return reply("*[ sʏsᴛᴇᴍ ]* ʙᴏᴛ ʜᴀʀᴜs ᴊᴀᴅɪ ᴀᴅᴍɪɴ ᴅᴜʟᴜ")

const caption = 'Silahkan pilih setting group'

let sections = [
{
title: 'ANTI LINK ALL',
highlight_label: 'Antilinkall',
rows: [
{
title: 'Antilinkall On (Delete)',
id: `${prefix}antilinkall on delete`
},
{
title: 'Antilinkall On (Kick)',
id: `${prefix}antilinkall on kick`
},
{
title: 'Antilinkall Off',
id: `${prefix}antilinkall off`
}
]
},
{
title: 'ANTI LINK',
highlight_label: 'Antilink',
rows: [
{
title: 'Antilinkgc On',
id: `${prefix}antilinkgc on`
},
{
title: 'Antilinkgc Off',
id: `${prefix}antilinkgc off`
},
{
title: 'Antilinkkick On',
id: `${prefix}antilinkkick on`
},
{
title: 'Antilinkkick Off',
id: `${prefix}antilinkkick off`
},
{
title: 'Anti Wame On',
id: `${prefix}antiwame on`
},
{
title: 'Anti Wame Off',
id: `${prefix}antiwame off`
}
]
},
{
title: 'SOSIAL MEDIA',
highlight_label: 'Social',
rows: [
{
title: 'Antilink Instagram On',
id: `${prefix}antilinkinstagram on`
},
{
title: 'Antilink Instagram Off',
id: `${prefix}antilinkinstagram off`
},
{
title: 'Antilink Facebook On',
id: `${prefix}antilinkfacebook on`
},
{
title: 'Antilink Facebook Off',
id: `${prefix}antilinkfacebook off`
},
{
title: 'Antilink Telegram On',
id: `${prefix}antilinktelegram on`
},
{
title: 'Antilink Telegram Off',
id: `${prefix}antilinktelegram off`
},
{
title: 'Antilink Tiktok On',
id: `${prefix}antilinktiktok on`
},
{
title: 'Antilink Tiktok Off',
id: `${prefix}antilinktiktok off`
},
{
title: 'Antilink Twitter On',
id: `${prefix}antilinktwitter on`
},
{
title: 'Antilink Twitter Off',
id: `${prefix}antilinktwitter off`
}
]
},
{
title: 'YOUTUBE',
highlight_label: 'Youtube',
rows: [
{
title: 'Antilink Youtube Video On',
id: `${prefix}antilinkyoutubevideo on`
},
{
title: 'Antilink Youtube Video Off',
id: `${prefix}antilinkyoutubevideo off`
},
{
title: 'Antilink Youtube Channel On',
id: `${prefix}antilinkyoutubechannel on`
},
{
title: 'Antilink Youtube Channel Off',
id: `${prefix}antilinkyoutubechannel off`
}
]
},
{
title: 'MEDIA',
highlight_label: 'Media',
rows: [
{
title: 'Antiimage On',
id: `${prefix}antiimage on`
},
{
title: 'Antiimage Off',
id: `${prefix}antiimage off`
},
{
title: 'Antivideo On',
id: `${prefix}antivideo on`
},
{
title: 'Antivideo Off',
id: `${prefix}antivideo off`
},
{
title: 'Antisticker On',
id: `${prefix}antisticker on`
},
{
title: 'Antisticker Off',
id: `${prefix}antisticker off`
},
{
title: 'Antiaudio On',
id: `${prefix}antiaudio on`
},
{
title: 'Antiaudio Off',
id: `${prefix}antiaudio off`
},
{
title: 'Antimedia On',
id: `${prefix}antimedia on`
},
{
title: 'Antimedia Off',
id: `${prefix}antimedia off`
}
]
},
{
title: 'GROUP PROTECTION',
highlight_label: 'Protection',
rows: [
{
title: 'Antibot On',
id: `${prefix}antibot on`
},
{
title: 'Antibot Off',
id: `${prefix}antibot off`
},
{
title: 'Antivirtex On',
id: `${prefix}antivirtex on`
},
{
title: 'Antivirtex Off',
id: `${prefix}antivirtex off`
},
{
title: 'Antitoxic On',
id: `${prefix}antitoxic on`
},
{
title: 'Antitoxic Off',
id: `${prefix}antitoxic off`
},
{
title: 'Antiasing On',
id: `${prefix}antiasing on`
},
{
title: 'Antiasing Off',
id: `${prefix}antiasing off`
},
{
title: 'Antipromotion On',
id: `${prefix}antipromotion on`
},
{
title: 'Antipromotion Off',
id: `${prefix}antipromotion off`
},
{
title: 'Antiviewonce On',
id: `${prefix}antiviewonce on`
},
{
title: 'Antiviewonce Off',
id: `${prefix}antiviewonce off`
}
]
},
{
title: 'MESSAGE TYPE',
highlight_label: 'Message',
rows: [
{
title: 'Antipoll On',
id: `${prefix}antipoll on`
},
{
title: 'Antipoll Off',
id: `${prefix}antipoll off`
},
{
title: 'Antidocument On',
id: `${prefix}antidocument on`
},
{
title: 'Antidocument Off',
id: `${prefix}antidocument off`
},
{
title: 'Anticontact On',
id: `${prefix}anticontact on`
},
{
title: 'Anticontact Off',
id: `${prefix}anticontact off`
},
{
title: 'Antilocation On',
id: `${prefix}antilocation on`
},
{
title: 'Antilocation Off',
id: `${prefix}antilocation off`
}
]
},
{
title: 'DOWNLOAD LINK',
highlight_label: 'Download',
rows: [
{
title: 'Antilink Bokep On',
id: `${prefix}antilinkbokep on`
},
{
title: 'Antilink Bokep Off',
id: `${prefix}antilinkbokep off`
},
{
title: 'Antilink Terabox On',
id: `${prefix}antilinkterabox on`
},
{
title: 'Antilink Terabox Off',
id: `${prefix}antilinkterabox off`
},
{
title: 'Antilink Mediafire On',
id: `${prefix}antilinkmediafire on`
},
{
title: 'Antilink Mediafire Off',
id: `${prefix}antilinkmediafire off`
}
]
},
{
title: 'LAINNYA',
highlight_label: 'Others',
rows: [
{
title: 'Antitagsw On',
id: `${prefix}tagsw on`
},
{
title: 'Antitagsw Off',
id: `${prefix}tagsw off`
},
{
title: 'Autodownload On',
id: `${prefix}autodownload on`
},
{
title: 'Autodownload Off',
id: `${prefix}autodownload off`
},
{
title: 'Group Open',
id: `${prefix}gc open`
},
{
title: 'Group Close',
id: `${prefix}gc close`
}
]
}
]

let listMessage = {
title: 'Setting Group',
sections
}

let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: author,
newsletterJid: idch,
serverMessageId: 143
},
businessMessageForwardInfo: {
businessOwnerJid: Alice.decodeJid(Alice.user.id)
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: caption
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: packname
}),
header: proto.Message.InteractiveMessage.Header.create({
title: 'Hai Atmin',
subtitle: '',
hasMediaAttachment: true,
...(await prepareWAMessageMedia(
{ image: { url: thumb } },
{ upload: Alice.waUploadToServer }
))
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
name: 'single_select',
buttonParamsJson: JSON.stringify(listMessage)
}
]
})
})
}
}
}, {})

if (!text) {
await Alice.relayMessage(
msg.key.remoteJid,
msg.message,
{ messageId: msg.key.id }
)
}
}
break
                
case 'linkgc': {
  if (!m.isGroup) return reply('⛔ Hanya di grup.')
  try {
    let response = await Alice.groupInviteCode(m.chat)
    return reply(`📎 Link grup:\nhttps://chat.whatsapp.com/${response}`)
  } catch (e) {
    return reply("❌ Gagal ambil link.")
  }
}
break;

case 'addlist': {
  if (!m.isGroup) return reply('🌸 Hanya bisa digunakan di grup.')
  if (!isAdmins) return reply('Khusus admin kak ❤️')

  const [keyRaw, ...textRaw] = q.split('|')
  const key = keyRaw?.trim().toLowerCase()
  const text = textRaw.join('|').trim()
  if (!key || !text) return reply(`Gunakan format:\n${prefix}addlist nama produk|isinya`)

  let type = 'text'
  let url = '-'
  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ''

  if (/image|video|document/.test(mime)) {
    type = /image/.test(mime)
      ? 'image'
      : /video/.test(mime)
      ? 'video'
      : 'document'

    const buffer = await quoted.download()
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, 'file')
    const upload = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    })
    url = upload.data
  }

  const success = await addList(m.chat, key, text, type, url)
  if (!success) return reply(`❌ List dengan key *${key}* sudah ada.`)
  reply(`✅ List berhasil ditambahkan!\nKey: *${key}*\nTipe: *${type.toUpperCase()}* 🌸`)
  break
}

case 'dellist': {
  if (!m.isGroup) return reply('🌸 Hanya bisa digunakan di grup.')
  if (!isAdmins) return reply('Khusus admin kak ❤️')

  const key = q.trim().toLowerCase()
  if (!key) return reply(`Gunakan format:\n${prefix}dellist ( nama produk )`)

  const success = delList(m.chat, key)
  if (!success) return reply(`Tidak ada list dengan key *${key}* 🌸`)
  reply(`🗑️ List *${key}* berhasil dihapus ❤️`)
  break
}

case 'list': {
  const lists = getList(m.chat)
  if (!lists.length) return reply('Belum ada list di grup ini 🌸')

  let teks = `🛒 *List Produk:*\n\n`
  teks += lists.map((v, i) => `${i + 1}. *${v.key}* [${v.type}]`).join('\n')
  reply(teks)
  break
}

case 'updatelist': {
  if (!m.isGroup) return reply('🌸 Hanya bisa digunakan di grup.')
  if (!isAdmins) return reply('Khusus admin kak ❤️')

  const [keyRaw, ...textRaw] = q.split('|')
  const key = keyRaw?.trim().toLowerCase()
  const text = textRaw.join('|').trim()
  if (!key || !text) return reply(`Gunakan format:\n${prefix}updatelist nama produk|isi baru`)

  let type = 'text'
  let url = '-'
  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ''

  if (/image|video|document/.test(mime)) {
    type = /image/.test(mime)
      ? 'image'
      : /video/.test(mime)
      ? 'video'
      : 'document'

    const buffer = await quoted.download()
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, 'file')
    const upload = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    })
    url = upload.data
  }

  const success = await updateList(m.chat, key, text, type, url)
  if (!success) return reply(`❌ Tidak ditemukan list dengan key *${key}* di grup ini.`)
  reply(`✅ List *${key}* berhasil diperbarui!\nTipe: *${type.toUpperCase()}* 🌸`)
  break
}

case 'afk': {
  if (!m.isGroup) return XRG()
  if (m.key.fromMe) return reply('Bot tidak dapat AFK')

  if (afk.checkAfkUser(m.chat, m.sender, _afk))
    return reply('AFK sudah diaktifkan sebelumnya')

  let reason = text ? text : 'Tidak ada.'
  afk.addAfkUser(m.chat, m.sender, Date.now(), reason, _afk)

  Alice.sendTextWithMentions(
    m.chat,
    `📴 @${m.sender.split('@')[0]} lagi *AFK*.\n` +
    `Alasan : _${reason}_\n` +
    `⏱️ Mulai : ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })}\n\n` +
    `Jangan ganggu ya, nanti dibales kalau sudah balik 🙏`,
    xy
  )
}
break

case 'addbadwords': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()
if (!text) return reply(`Contoh: ${prefix + command} anjing`)

addbadwords(text)
reply(`✅ Berhasil menambahkan badword: ${text}`)
}
break

case 'deletebadwords':
case 'delbadwords': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()
if (!text) return reply(`Contoh: ${prefix + command} anjing`)

deletebadwords(text)
reply(`✅ Berhasil menghapus badword: ${text}`)
}
break

case 'antivirus':
case 'antivirtex':
case 'antilinkyoutubevideo':
case 'antilinkyoutubevid':
case 'antilinkytvid':
case 'antilinkyoutubechannel':
case 'antilinkyoutubech':
case 'antilinkytch':
case 'antilinkinstagram':
case 'antilinkig':
case 'antilinkinsta':
case 'antilinkfacebook':
case 'antilinkfb':
case 'antilinktelegram':
case 'antilinktg':
case 'antilinktiktok':
case 'antilinktt':
case 'antilinktwitter':
case 'antilinktwt':
case 'antilinktwit':
case 'antilinkbokep':
case 'antilinkterabox':
case 'antilinkmediafire':
case 'antitoxic':
case 'antiwame':
case 'antiasing':
case 'antibot':
case 'anticall':
case 'antitagsw':
case 'antispam':
case 'antimedia':
case 'antiimage':
case 'antivideo':
case 'antiaudio':
case 'antisticker':
case 'antidocument':
case 'anticontact':
case 'antilocation':
case 'antipoll':
case 'antiviewonce':
case 'antilinkgc':
case 'antilinkkick':
case 'antipromotion': {

    if (!m.isGroup) return XRG()
    if (!isAdmins && !isOwner) return XRA()

    let type = command
        .replace('antivirtex', 'antivirus')
        .replace('antilinkyoutubevid', 'antilinkyoutubevideo')
        .replace('antilinkytvid', 'antilinkyoutubevideo')
        .replace('antilinkyoutubech', 'antilinkyoutubechannel')
        .replace('antilinkytch', 'antilinkyoutubechannel')
        .replace('antilinkig', 'antilinkinstagram')
        .replace('antilinkinsta', 'antilinkinstagram')
        .replace('antilinkfb', 'antilinkfacebook')
        .replace('antilinktg', 'antilinktelegram')
        .replace('antilinktt', 'antilinktiktok')
        .replace('antilinktwt', 'antilinktwitter')
        .replace('antilinktwit', 'antilinktwitter')

    let data = antiMap[type]
    if (!data) return

    if (args[0] === 'on') {
        if (data.status) return reply('_Sudah Diaktifkan_')

        data.list.push(m.chat)
        fs.writeFileSync(data.db, JSON.stringify(data.list))

        reply(`✅ Sukses mengaktifkan *${type}* di grup ini`)

        if (data.msg) {
            let group = await Alice.groupMetadata(m.chat)
            let mems = group.participants.map(v => v.id)
            Alice.sendMessage(m.chat, {
                text: `\`\`\`「 ⚠️ WARNING ⚠️ 」\`\`\`\n\n${data.msg}`,
                contextInfo: { mentionedJid: mems }
            }, { quoted: m })
        }

    } else if (args[0] === 'off') {

        if (!data.status) return reply('_Sudah Dimatikan_')

        let off = data.list.indexOf(m.chat)
        data.list.splice(off, 1)
        fs.writeFileSync(data.db, JSON.stringify(data.list))

        reply(`✅ Sukses mematikan *${type}* di grup ini`)

    } else {
        reply('on untuk mengaktifkan, off untuk menonaktifkan')
    }
}
break

case 'add':
case 'tambahmem':
case 'addmem': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()

let user = m.quoted?.sender

if (!user && text) {
let num = text.replace(/\D/g, '')
if (num.length < 8) return reply('❌ Nomor tidak valid!')
user = num + '@s.whatsapp.net'
}

if (!user) return reply('❌ Masukkan nomor atau reply target.')

try {
let metadata = await Alice.groupMetadata(m.chat)

if (metadata.participants.some(v => v.id === user)) {
return reply('❌ Pengguna sudah ada di grup.')
}

await Alice.groupParticipantsUpdate(m.chat, [user], 'add')

reply(`✅ Berhasil menambahkan @${user.split('@')[0]}`, {
mentions: [user]
})

} catch (e) {
try {
let code = await Alice.groupInviteCode(m.chat)
let link = `https://chat.whatsapp.com/${code}`
let name = (await Alice.groupMetadata(m.chat)).subject

await Alice.sendMessage(user, {
text: `👋 Admin mengundang kamu ke grup *${name}*\n\n${link}`
})

reply(`❌ Gagal add langsung, link undangan dikirim ke @${user.split('@')[0]}`, {
mentions: [user]
})

} catch {
reply('❌ Gagal menambahkan dan mengirim link.')
}
}
}
break

case 'kick': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()

let user =
m.mentionedJid?.[0] ||
m.quoted?.sender ||
(text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : null)

if (!user) return reply('⚠️ Tag / reply / masukkan nomor target.')

try {
await Alice.groupParticipantsUpdate(m.chat, [user], 'remove')

reply(`✅ Berhasil mengeluarkan @${user.split('@')[0]}`, {
mentions: [user]
})

} catch {
reply('❌ Gagal mengeluarkan member.')
}
}
break

case 'promote':
case 'demote': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()

let user =
m.mentionedJid?.[0] ||
m.quoted?.sender ||
(text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : null)

if (!user) return reply('⚠️ Tag / reply / masukkan nomor target.')

let action = command === 'promote' ? 'promote' : 'demote'
let status = action === 'promote' ? 'jadi admin' : 'dari admin'

try {
await Alice.groupParticipantsUpdate(m.chat, [user], action)

let name = await Alice.getName(user).catch(() => user.split('@')[0])

reply(`✅ Berhasil ${action} *${name}* ${status}`, {
mentions: [user]
})

} catch {
reply(`❌ Gagal ${action} user`)
}
}
break

case 'gc': { 
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()
if (args[0] === 'close'){
await Alice.groupSettingUpdate(m.chat, 'announcement').then((res) => reply(`Sukses Menutup Group`)).catch((err) => reply(jsonformat(err)))
} else if (args[0] === 'open'){
await Alice.groupSettingUpdate(m.chat, 'not_announcement').then((res) => reply(`Sukses Membuka Group`)).catch((err) => reply(jsonformat(err)))
} else {
 reply(`Silahkan Ketik ${prefix + command} open/ ${prefix + command} close`)
 }
}
break

case 'editinfo': {
if (!m.isGroup) return XRG()
if (!isAdmins && !isOwner) return XRA()
if (!isBotAdmins) return XRBADM
 if (args[0] === 'open'){
await Alice.groupSettingUpdate(m.chat, 'unlocked').then((res) => reply(`Sukses Membuka Edit Info Group`)).catch((err) => reply(jsonformat(err)))
 } else if (args[0] === 'close'){
await Alice.groupSettingUpdate(m.chat, 'locked').then((res) => reply(`Sukses Menutup Edit Info Group`)).catch((err) => reply(jsonformat(err)))
 } else {
 reply(`Silahkan Ketik ${prefix + command} open/ ${prefix + command} close`)
}
}
break

case 'join':
if (!isOwner) return reply('Khusus Owner Bot');
if (!text) return reply('Masukkan Link Group!');
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return reply('Link Invalid!');
let resultJoin = args[0].split('https://chat.whatsapp.com/')[1];
await Alice.groupAcceptInvite(resultJoin).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)));
break;

case 'leave':
if (!isOwner) return XRO();
reply("Aku Pergi :v");
await Alice.groupLeave(m.chat).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)));
break;

case "h":
case "hidetag":
if (!m.isGroup) return XRG();
if (!isOwner && !isAdmins) return XRA();
const qHidetag = m.text.split(" ").slice(1).join(" ");
const metadataHidetag = await Alice.groupMetadata(m.chat);
const participantsHidetag = metadataHidetag.participants || [];
if (m.quoted) {
await Alice.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participantsHidetag.map(a => a.id) }, { quoted: m });
} else {
const teksHidetag = qHidetag && qHidetag.trim() ? qHidetag : " ";
await Alice.sendMessage(m.chat, { text: teksHidetag, mentions: participantsHidetag.map(a => a.id) }, { quoted: m });
}
break;

case 'totag':
if (!m.isGroup) return XRG();
if (!isOwner && !isAdmins) return XRA();
if (!isBotAdmins) return XRBADM;
if (!m.quoted) return reply(`❌ Kutip pesan yang mau ditag.`);
const metadataTotag = await Alice.groupMetadata(m.chat);
const participantsTotag = metadataTotag.participants.map(a => a.id);
let forwardMsg;
if (m.quoted.fakeObj) {
forwardMsg = { forward: m.quoted.fakeObj };
} else {
const content = m.quoted.text || m.quoted.caption || " ";
forwardMsg = { text: content };
}
await Alice.sendMessage(m.chat, { ...forwardMsg, mentions: participantsTotag }, { quoted: m });
break;

case 'editsubjek':
if (!m.isGroup) return XRG();
if (!isAdmins && !isOwner) return XRA();
if (!isBotAdmins) return XRBADM();
if (!text) return reply('Text nya ?');
await Alice.groupUpdateSubject(m.chat, text).then((res) => {}).catch((err) => reply(jsonformat(err)));
break;

case 'editdesk':
if (!m.isGroup) return XRG();
if (!isAdmins && !isOwner) return XRA();
if (!isBotAdmins) return XRBADM();
if (!text) return reply('Text Nya ?');
await Alice.groupUpdateDescription(m.chat, text).then((res) => {}).catch((err) => reply(jsonformat(err)));
break;

case 'tagall':
if (!m.isGroup) return XRG();
if (!isAdmins) return XRA();
const metaTagall = await Alice.groupMetadata(m.chat).catch(() => null);
const partsTagall = metaTagall?.participants || [];
const jidsTagall = partsTagall.map(p => {
if (typeof p?.id === 'string') return p.id;
if (p?.id?.user && p?.id?.server) return `${p.id.user}@${p.id.server}`;
return null;
}).filter(Boolean);
if (!jidsTagall.length) return reply('Gagal ambil daftar member.');
const totalTagall = jidsTagall.length;
let teksTagall = `══✪〘 👥 Tag All 〙✪══\n ➲ Pesan: ${q || 'kosong'}\n ➲ Total Member: ${totalTagall}\n\n`;
for (let jid of jidsTagall) {
teksTagall += `⭔ @${jid.split('@')[0]}\n`;
}
await Alice.sendMessage(m.chat, { text: teksTagall, mentions: jidsTagall }, { quoted: m });
break;

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Group Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\


//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Game Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'crypto':
try {
const handleCrypto = require('./AliceSystem/AliceDatabase/Game/crypto.js');
if (typeof handleCrypto !== 'function') return reply('⚠️ Modul crypto tidak valid.');
handleCrypto(m, command, args, reply);
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'koboy':
try {
const koboyHandler = require('./AliceSystem/AliceDatabase/Game/koboy.js');
const teksKoboy = m.text || '';
const argsKoboy = teksKoboy.trim().split(/\s+/).slice(1);
console.log('[Alice.js] koboy command dipanggil!');
console.log('[Alice.js] args:', argsKoboy);
if (typeof koboyHandler !== 'function') return reply('⚠️ Modul koboy tidak valid.');
koboyHandler(m, command, argsKoboy, reply, db);
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'catur':
if (!m.mentionedJid || m.mentionedJid.length === 0) return reply('❌ Tag pengguna untuk ditantang!\nContoh: .catur @user');
const lawanCatur = m.mentionedJid[0];
if (lawanCatur === sender) return reply('Kamu tidak bisa menantang dirimu sendiri.');
if (caturData[m.chat]) return reply('❌ Masih ada game di chat ini.');
caturData[m.chat] = { player1: sender, player2: lawanCatur, turn: 'white', board: papanAwal(), status: 'pending', winner: null };
saveCatur();
reply(`♟️ Tantangan dikirim ke @${lawanCatur.split('@')[0]}!\n\nBalas dengan .caturterima untuk main.\nGunakan .caturhelp untuk panduan lengkap.`, m.chat, { mentions: [lawanCatur] });
break;

case 'caturterima':
const gameTerima = caturData[m.chat];
if (!gameTerima || gameTerima.status !== 'pending') return reply('❌ Tidak ada tantangan aktif.');
if (gameTerima.player2 !== sender) return reply('Kamu bukan yang ditantang.');
gameTerima.status = 'ongoing';
saveCatur();
reply(`♟️ Game dimulai!\nGiliran: Putih (${gameTerima.player1 == sender ? 'Kamu' : '@' + gameTerima.player1.split('@')[0]})\n\n${tampilkanPapan(gameTerima.board)}`, m.chat, { mentions: [gameTerima.player1, gameTerima.player2] });
break;

case 'caturtolak':
const gameTolak = caturData[m.chat];
if (!gameTolak || gameTolak.status !== 'pending') return reply('❌ Tidak ada tantangan aktif.');
if (gameTolak.player2 !== sender) return reply('Kamu bukan yang ditantang.');
delete caturData[m.chat];
saveCatur();
reply('❌ Tantangan ditolak.');
break;

case 'caturpapan':
const gamePapan = caturData[m.chat];
if (!gamePapan || gamePapan.status !== 'ongoing') return reply('❌ Tidak ada game berjalan.');
reply(`♟️ Papan saat ini:\n\n${tampilkanPapan(gamePapan.board)}\nGiliran: ${gamePapan.turn === 'white' ? 'Putih' : 'Hitam'}`);
break;

case 'caturlangkah':
const gameLangkah = caturData[m.chat];
if (!gameLangkah || gameLangkah.status !== 'ongoing') return reply('❌ Tidak ada game berjalan.');
const [fromRaw, toRaw] = text.trim().split(" ");
const from = fromRaw?.toLowerCase();
const to = toRaw?.toLowerCase();
if (!from || !to) return reply('Gunakan: .caturlangkah e2 e4');
const col = { a:0,b:1,c:2,d:3,e:4,f:5,g:6,h:7 };
const fx = 8 - parseInt(from[1]), fy = col[from[0]];
const tx = 8 - parseInt(to[1]), ty = col[to[0]];
const isWhiteTurn = gameLangkah.turn === 'white';
const currentPlayerTurn = isWhiteTurn ? gameLangkah.player1 : gameLangkah.player2;
if (sender !== currentPlayerTurn) return reply('⏳ Bukan giliranmu.');
if (isNaN(fx) || isNaN(fy) || isNaN(tx) || isNaN(ty)) return reply('❌ Posisi tidak valid.');
const piece = gameLangkah.board[fx][fy];
if (!piece) return reply('❌ Tidak ada bidak di posisi itu.');
if (isWhiteTurn && !'♙♖♘♗♕♔'.includes(piece)) return reply('Itu bukan bidakmu.');
if (!isWhiteTurn && !'♟♜♞♝♛♚'.includes(piece)) return reply('Itu bukan bidakmu.');
gameLangkah.board[tx][ty] = piece;
gameLangkah.board[fx][fy] = '';
gameLangkah.turn = isWhiteTurn ? 'black' : 'white';
saveCatur();
if (global.caturTimer && global.caturTimer[m.chat]) {
const waktuTimer = global.caturTimer[m.chat];
clearTimeout(gameLangkah.timeoutId);
gameLangkah.timeoutId = setTimeout(() => {
let kalahTimer = gameLangkah.turn === 'white' ? gameLangkah.player1 : gameLangkah.player2;
let menangTimer = gameLangkah.turn === 'white' ? gameLangkah.player2 : gameLangkah.player1;
delete caturData[m.chat];
saveCatur();
const skorTimer = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json'));
skorTimer[menangTimer] = skorTimer[menangTimer] || { menang: 0, kalah: 0 };
skorTimer[kalahTimer] = skorTimer[kalahTimer] || { menang: 0, kalah: 0 };
skorTimer[menangTimer].menang++;
skorTimer[kalahTimer].kalah++;
fs.writeFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json', JSON.stringify(skorTimer, null, 2));
Alice.sendMessage(m.chat, { text: `⏰ Waktu habis! @${kalahTimer.split('@')[0]} dianggap kalah.\n🏆 Pemenang: @${menangTimer.split('@')[0]}`, mentions: [menangTimer, kalahTimer] });
}, waktuTimer * 1000);
}
reply(`✅ Langkah berhasil!\n\n${tampilkanPapan(gameLangkah.board)}\nGiliran: ${gameLangkah.turn === 'white' ? 'Putih' : 'Hitam'}`);
break;

case 'caturmenyerah':
const gameMenyerah = caturData[m.chat];
if (!gameMenyerah || gameMenyerah.status !== 'ongoing') return reply('❌ Tidak ada game berjalan.');
if (sender !== gameMenyerah.player1 && sender !== gameMenyerah.player2) return reply('Kamu bukan pemain di game ini.');
const pemenangMenyerah = sender === gameMenyerah.player1 ? gameMenyerah.player2 : gameMenyerah.player1;
const skorMenyerah = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json'));
skorMenyerah[pemenangMenyerah] = skorMenyerah[pemenangMenyerah] || { menang: 0, kalah: 0 };
skorMenyerah[sender] = skorMenyerah[sender] || { menang: 0, kalah: 0 };
skorMenyerah[pemenangMenyerah].menang++;
skorMenyerah[sender].kalah++;
fs.writeFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json', JSON.stringify(skorMenyerah, null, 2));
gameMenyerah.status = 'selesai';
gameMenyerah.winner = pemenangMenyerah;
saveCatur();
reply(`🏳️ Pemain menyerah. Pemenang: @${pemenangMenyerah.split('@')[0]}`, m.chat, { mentions: [pemenangMenyerah] });
break;

case 'caturselesai':
if (!isOwner) return reply('❌ Hanya owner yang bisa paksa menyelesaikan.');
if (caturData[m.chat]) {
delete caturData[m.chat];
saveCatur();
reply('✅ Game dipaksa selesai.');
} else reply('Tidak ada game aktif.');
break;

case 'caturhelp':
const helpText = `┌───⌈ 📖 PANDUAN CATUR MULTIPLAYER ⌋
│
│ ♟️ Bermain catur langsung di grup bersama temanmu!
│
│ 🎮 Cara Memulai:
│ ➤ .catur @tag - Tantang pemain lain
│
│ ⚙️ Kontrol Permainan:
│ ➤ .caturstatus - Cek giliran dan papan
│ ➤ .caturskip - Lewati giliran
│ ➤ .caturdraw - Ajukan/terima hasil seri
│ ➤ .caturmenyerah - Menyerah
│ ➤ .caturhapus - (Admin) Hapus pertandingan
│
│ 📊 Skor & Ranking:
│ ➤ .caturnilai - Statistik kamu
│ ➤ .caturrank - Peringkat kamu
│ ➤ .caturtop10 - Top 10 pemain
│ ➤ .caturskorreset - (Owner) Reset skor
│
│ ♟️ Papan & Analisa:
│ ➤ .caturnext - Siapa giliran?
│ ➤ .caturboard - Lihat papan ASCII
│ ➤ .caturhistory - Riwayat langkah
│ ➤ .caturanalisa - Langkah terakhir
│
│ ⏱️ Timer & Notifikasi:
│ ➤ .caturtimer - Timer otomatis (3 menit)
│ ➤ .caturnotif - Notif jika diam >3 menit
│
│ 📌 Tambahan:
│ ➤ .caturhelp - Menu ini
│
└─────⌈ ♟️ Jadilah legenda catur grupmu! ⌋`;
reply(helpText);
break;

case 'caturrank':
const skor = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json'));
if (!Object.keys(skor).length) return reply('❌ Belum ada pemain yang memiliki skor.');
const urut = Object.entries(skor).sort((a, b) => b[1].menang - a[1].menang).slice(0, 10).map(([id, data], i) => `*${i + 1}.* @${id.split('@')[0]} — 🏆 ${data.menang} menang`);
reply(`🏁 RANKING CATUR TOP 10\n\n${urut.join('\n')}`, m.chat, { mentions: urut.map(v => v.match(/@(\d+)/)[0] + '@s.whatsapp.net') });
break;

case 'caturstatus':
const gameStatus = caturData[m.chat];
if (!gameStatus) return reply('❌ Tidak ada game catur di chat ini.');
const statusText = { pending: '🕐 Menunggu lawan menerima...', ongoing: '♟️ Sedang berlangsung', selesai: `🏁 Selesai — Pemenang: @${gameStatus.winner?.split('@')[0] || 'Tidak diketahui'}` }[gameStatus.status] || '❓ Tidak diketahui';
const p1 = '@' + gameStatus.player1.split('@')[0];
const p2 = '@' + gameStatus.player2.split('@')[0];
reply(`♟️ Status Game Catur:\n• Pemain 1: ${p1}\n• Pemain 2: ${p2}\n• Status: ${statusText}`, m.chat, { mentions: [gameStatus.player1, gameStatus.player2, gameStatus.winner] });
break;

case 'caturnilai':
const skorUser = JSON.parse(fs.readFileSync('./AliceSystem/AliceDatabase/Game/caturSkor.json'));
const dataUser = skorUser[sender] || { menang: 0, kalah: 0 };
reply(`📊 Skor Catur Kamu\n\n🏆 Menang: ${dataUser.menang}\n💀 Kalah: ${dataUser.kalah}`);
break;

case 'caturlawan':
const gameLawan = caturData[m.chat];
if (!gameLawan || gameLawan.status !== 'ongoing') return reply('❌ Tidak ada game berlangsung.');
const lawan = sender === gameLawan.player1 ? gameLawan.player2 : (sender === gameLawan.player2 ? gameLawan.player1 : null);
if (!lawan) return reply('Kamu bukan bagian dari game ini.');
reply(`🎯 Lawan kamu: @${lawan.split('@')[0]}`, m.chat, { mentions: [lawan] });
break;

case 'caturgiliran':
const gameGiliran = caturData[m.chat];
if (!gameGiliran || gameGiliran.status !== 'ongoing') return reply('❌ Tidak ada game yang sedang berjalan.');
const isWhite = gameGiliran.turn === 'white';
const giliran = isWhite ? gameGiliran.player1 : gameGiliran.player2;
reply(`⏳ Giliran: @${giliran.split('@')[0]} (${isWhite ? 'Putih' : 'Hitam'})`, m.chat, { mentions: [giliran] });
break;

case 'caturrematch':
const gameRematch = caturData[m.chat];
if (!gameRematch || gameRematch.status !== 'selesai') return reply('❌ Tidak ada game selesai untuk rematch.');
if (sender !== gameRematch.player1 && sender !== gameRematch.player2) return reply('Kamu bukan bagian dari game sebelumnya.');
const lawanRematch = sender === gameRematch.player1 ? gameRematch.player2 : gameRematch.player1;
caturData[m.chat] = { player1: sender, player2: lawanRematch, turn: 'white', board: papanAwal(), status: 'pending', winner: null };
saveCatur();
reply(`🔁 Rematch dikirim ke @${lawanRematch.split('@')[0]}!\nKetik caturterima untuk bermain ulang.`, m.chat, { mentions: [lawanRematch] });
break;

case 'caturafk':
const gameAfk = caturData[m.chat];
if (!gameAfk || gameAfk.status !== 'ongoing') return reply('❌ Tidak ada game yang sedang berjalan.');
if (!isOwner && sender !== gameAfk.player1 && sender !== gameAfk.player2) return reply('Hanya pemain atau owner yang bisa membatalkan.');
delete caturData[m.chat];
saveCatur();
reply('⚠️ Game dibatalkan karena lawan dianggap AFK.');
break;

case 'caturwaktu':
if (!isOwner) return reply('❌ Hanya owner yang bisa mengatur waktu giliran.');
let waktu = parseInt(text);
if (isNaN(waktu) || waktu < 10) return reply('Gunakan contoh: caturwaktu 60 (detik minimal 10)');
if (!global.caturTimer) global.caturTimer = {};
global.caturTimer[m.chat] = waktu;
reply(`⏱️ Batas waktu giliran disetel ke ${waktu} detik.`);
break;

case 'caturreset':
if (!isOwner) return reply('❌ Hanya owner yang bisa reset data.');
fs.writeFileSync('./database/catur.json', '{}');
fs.writeFileSync('./database/caturSkor.json', '{}');
if (global.caturTimer) global.caturTimer[m.chat] = undefined;
reply('✅ Semua data catur berhasil direset.');
break;

case 'caturskip':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan aktif.");
let gameSkip = dbCatur[m.chat];
if ((gameSkip.turn === 'white' && m.sender !== gameSkip.playerWhite) || (gameSkip.turn === 'black' && m.sender !== gameSkip.playerBlack)) return reply("❌ Bukan giliranmu.");
gameSkip.turn = gameSkip.turn === 'white' ? 'black' : 'white';
reply(`⏩ ${m.pushName} melewatkan giliran.\n🔁 Giliran selanjutnya: ${gameSkip.turn === 'white' ? gameSkip.nameWhite : gameSkip.nameBlack}`);
fs.writeFileSync(caturPath, JSON.stringify(dbCatur, null, 2));
break;

case 'caturdraw':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
let gameDraw = dbCatur[m.chat];
if (!gameDraw.drawRequest) {
gameDraw.drawRequest = m.sender;
reply(`🤝 ${m.pushName} mengajukan hasil seri.\nJika lawan setuju, ketik caturdraw juga untuk menyetujui.`);
} else if (gameDraw.drawRequest !== m.sender) {
let lawanDraw = gameDraw.drawRequest;
reply(`🤝 Pertandingan diakhiri dengan hasil Seri.`, m.chat, { mentions: [m.sender, lawanDraw] });
if (!dbSkor[m.sender]) dbSkor[m.sender] = { menang: 0, kalah: 0, seri: 0 };
if (!dbSkor[lawanDraw]) dbSkor[lawanDraw] = { menang: 0, kalah: 0, seri: 0 };
dbSkor[m.sender].seri++;
dbSkor[lawanDraw].seri++;
delete dbCatur[m.chat];
fs.writeFileSync(caturSkorPath, JSON.stringify(dbSkor, null, 2));
fs.writeFileSync(caturPath, JSON.stringify(dbCatur, null, 2));
} else {
reply("❌ Kamu sudah mengajukan permintaan seri, tunggu respon lawan.");
}
break;

case 'caturhapus':
if (!isOwner && !isAdmins) return reply("❌ Hanya admin atau owner yang bisa menghapus pertandingan.");
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan untuk dihapus.");
delete dbCatur[m.chat];
fs.writeFileSync(caturPath, JSON.stringify(dbCatur, null, 2));
reply("✅ Pertandingan catur dihapus.");
break;

case 'caturnext':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
let gameNext = dbCatur[m.chat];
let giliranNext = gameNext.turn === 'white' ? gameNext.nameWhite : gameNext.nameBlack;
reply(`🔁 Sekarang giliran: ${giliranNext}`);
break;

case 'caturboard':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
let gameBoard = dbCatur[m.chat];
let papan = gameBoard.board.ascii();
reply(`♟️ Papan Catur Saat Ini:\n\n${papan}`);
break;

case 'caturtimer':
if (!isOwner && !isAdmins) return reply("❌ Hanya owner/admin yang bisa menyalakan timer.");
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
global.caturTimer = global.caturTimer || {};
if (global.caturTimer[m.chat]) {
clearTimeout(global.caturTimer[m.chat]);
delete global.caturTimer[m.chat];
reply("⏱️ Timer giliran dimatikan.");
} else {
global.caturTimer[m.chat] = setTimeout(() => {
let gameTimer = dbCatur[m.chat];
if (!gameTimer) return;
let kalahTimer = gameTimer.turn === 'white' ? gameTimer.playerWhite : gameTimer.playerBlack;
let menangTimer = gameTimer.turn === 'white' ? gameTimer.playerBlack : gameTimer.playerWhite;
reply(`⏰ Waktu habis!\n@${kalahTimer.split('@')[0]} kalah karena tidak bergerak.\n🎉 Pemenang: @${menangTimer.split('@')[0]}`, m.chat, { mentions: [kalahTimer, menangTimer] });
if (!dbSkor[menangTimer]) dbSkor[menangTimer] = { menang: 0, kalah: 0, seri: 0 };
if (!dbSkor[kalahTimer]) dbSkor[kalahTimer] = { menang: 0, kalah: 0, seri: 0 };
dbSkor[menangTimer].menang++;
dbSkor[kalahTimer].kalah++;
delete dbCatur[m.chat];
fs.writeFileSync(caturPath, JSON.stringify(dbCatur, null, 2));
fs.writeFileSync(caturSkorPath, JSON.stringify(dbSkor, null, 2));
}, (global.caturTimer[m.chat] || 180) * 1000);
reply(`⏱️ Timer giliran dinyalakan (${global.caturTimer[m.chat] || 180} detik per giliran).`);
}
break;

case 'caturhistory':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
let gameHistory = dbCatur[m.chat];
let moves = gameHistory.board.history();
if (moves.length === 0) return reply("📜 Belum ada langkah yang dilakukan.");
reply(`📜 Riwayat Langkah:\n${moves.map((m, i) => `${i + 1}. ${m}`).join('\n')}`);
break;

case 'caturskorreset':
if (!isOwner) return reply("❌ Hanya owner yang bisa reset skor.");
let targetReset = m.mentionedJid?.[0] || m.sender;
if (!dbSkor[targetReset]) return reply("❌ Pengguna belum punya skor.");
delete dbSkor[targetReset];
fs.writeFileSync(caturSkorPath, JSON.stringify(dbSkor, null, 2));
reply(`✅ Skor catur @${targetReset.split('@')[0]} telah di-reset.`, m.chat, { mentions: [targetReset] });
break;

case 'caturanalisa':
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
let gameAnalisa = dbCatur[m.chat];
let langkah = gameAnalisa.board.history();
if (langkah.length === 0) return reply("📜 Belum ada langkah yang dilakukan.");
let last = langkah[langkah.length - 1];
reply(`📊 Langkah terakhir: ${last}`);
break;

case 'caturtop10':
if (Object.keys(dbSkor).length === 0) return reply('❌ Belum ada skor.');
let top = Object.entries(dbSkor).map(([jid, skorUser]) => ({ jid, poin: (skorUser.menang || 0) * 3 + (skorUser.seri || 0), menang: skorUser.menang, seri: skorUser.seri, kalah: skorUser.kalah })).sort((a, b) => b.poin - a.poin).slice(0, 10);
let teksTop = `🏆 Top 10 Pemain Catur\n\n`;
top.forEach((p, i) => { teksTop += `${i + 1}. @${p.jid.split('@')[0]} | ${p.poin} pts (W:${p.menang}, D:${p.seri}, L:${p.kalah})\n`; });
reply(teksTop, m.chat, { mentions: top.map(x => x.jid) });
break;

case 'caturnotif':
if (!isOwner && !isAdmins) return reply("❌ Hanya owner/admin yang bisa aktifkan notif.");
if (!dbCatur[m.chat]) return reply("❌ Tidak ada pertandingan.");
global.caturTimer = global.caturTimer || {};
if (global.caturTimer[m.chat]) {
clearTimeout(global.caturTimer[m.chat]);
delete global.caturTimer[m.chat];
return reply("🔕 Notifikasi dimatikan.");
}
let gameNotif = dbCatur[m.chat];
global.caturTimer[m.chat] = setTimeout(() => {
let sekarang = gameNotif.turn === 'white' ? gameNotif.playerWhite : gameNotif.playerBlack;
Alice.sendMessage(m.chat, { text: `⏳ @${sekarang.split('@')[0]}, giliranmu belum dimainkan selama 3 menit.`, mentions: [sekarang] });
}, 3 * 60 * 1000);
reply("🔔 Notifikasi dinyalakan (giliran >3 menit akan diingatkan).");
break;

case 'susunkata':
try {
const pathFile = './AliceSystem/AliceDatabase/Game/Alice-SusunKata.json';
if (!fs.existsSync(pathFile)) return reply('⚠️ File tidak ditemukan.');
const data = JSON.parse(fs.readFileSync(pathFile));
if (!Array.isArray(data) || data.length === 0) return reply('⚠️ Bank soal kosong.');
if (!global.susunKata) global.susunKata = {};
if (global.susunKata[m.sender]) return reply(`❗ Kamu masih punya soal yang belum dijawab.\nKetik jawabanmu atau *.nyerah* untuk menyerah.`);
const item = data[Math.floor(Math.random() * data.length)];
const kata = String(item.jawaban).toLowerCase().trim();
if (!kata || kata.length < 3) return reply('❌ Terjadi kesalahan pada soal.');
const shuffle = (str) => str.split('').sort(() => Math.random() - 0.5).join('');
let acak = shuffle(kata);
let limit = 0;
while (acak === kata && limit < 5) { acak = shuffle(kata); limit++; }
global.susunKata[m.sender] = { jawaban: kata, mulai: Date.now() };
reply(`🔤 GAME SUSUN KATA\n\nAcak huruf: ${acak}\n\n❓ Susun huruf di atas menjadi kata yang benar!\nKetik jawabanmu langsung di chat.\n\nKetik *.nyerah* untuk lihat jawaban.`);
} catch (e) {
console.log(e);
reply('❌ Terjadi kesalahan pada permainan Susun Kata.');
}
break;

case 'asahotak':
try {
const pathFile = './AliceSystem/AliceDatabase/Game/Alice-AsahOtak.json';
if (!fs.existsSync(pathFile)) return reply('⚠️ File Asah Otak tidak ditemukan.');
const data = JSON.parse(fs.readFileSync(pathFile));
const soal = data[Math.floor(Math.random() * data.length)];
if (!global.asahOtak) global.asahOtak = {};
global.asahOtak[m.sender] = { soal: soal.soal, jawaban: soal.jawaban.toLowerCase() };
reply(`🧠 ASAH OTAK!\n\nPertanyaan:\n❓ ${soal.soal}\n\nKetik jawabanmu.\nJika tidak tau ketik *.nyerah*`);
} catch (err) {
console.log(err);
reply('❌ Terjadi kesalahan saat memulai asah otak.');
}
break;

case 'dadu':
let ddsa = [
{ url: 'https://telegra.ph/file/9f60e4cdbeb79fc6aff7a.png', no: 1 },
{ url: 'https://telegra.ph/file/797f86e444755282374ef.png', no: 2 },
{ url: 'https://telegra.ph/file/970d2a7656ada7c579b69.png', no: 3 },
{ url: 'https://telegra.ph/file/0470d295e00ebe789fb4d.png', no: 4 },
{ url: 'https://telegra.ph/file/a9d7332e7ba1d1d26a2be.png', no: 5 },
{ url: 'https://telegra.ph/file/99dcd999991a79f9ba0c0.png', no: 6 }
];
let media = pickRandom(ddsa);
try {
await Alice.sendImageAsSticker(m.chat, media.url, m, { packname: packname, author: author, isAvatar: 1 });
} catch (e) {
let anu = await fetch(media.url);
let una = await anu.buffer();
await Alice.sendImageAsSticker(m.chat, una, m, { packname: packname, author: author, isAvatar: 1 });
}
break;

case 'patroli':
if (!m.isGroup) return XRG();
await XReaction();
const participants = (await Alice.groupMetadata(m.chat)).participants;
if (participants.length < 4) return reply('Minimal 4 member di grup untuk menjalankan game ini!');
const memberIDs = participants.map(p => p.id).filter(id => id !== Alice.user.jid);
const shuffled = memberIDs.sort(() => Math.random() - 0.5);
const polisi = shuffled[0];
const pencuri = shuffled[1];
const tahun = Math.floor(Math.random() * 3) + 1;
const hasilPatroli = `🚨 Patroli Berhasil, Maling Telah Ditemukan!!\n\n👮 Polisi: @${polisi.split('@')[0]}\n🕵 Pencuri: @${pencuri.split('@')[0]}\n\n!!Pencuri Ditangkap! Dan Dipenjara Selama ${tahun} tahun`;
Alice.sendMessage(m.chat, { text: hasilPatroli, mentions: [polisi, pencuri] }, { quoted: m });
break;

case 'suitbot':
if (!m.isGroup) return XRG();
await XReaction();
const userChoice = text.toLowerCase();
const choices = ['batu', 'gunting', 'kertas'];
const botChoice = choices[Math.floor(Math.random() * choices.length)];
if (!choices.includes(userChoice)) return reply(`Pilih antara batu, gunting, atau kertas ya!\nContoh: ${prefix + command} batu`);
let hasilSuit = '';
if (userChoice === botChoice) {
hasilSuit = `Kita Seri! Kamu pilih ${botChoice} dan aku juga pilih ${botChoice}`;
} else if (
(userChoice === 'batu' && botChoice === 'gunting') ||
(userChoice === 'gunting' && botChoice === 'kertas') ||
(userChoice === 'kertas' && botChoice === 'batu')
) {
hasilSuit = `😞 ${botname} Kalah, ${pushname} menang 👍\nAku pilih ${botChoice}`;
} else {
hasilSuit = `Yess, ${botname} menang! ${botname} pilih ${botChoice}`;
}
reply(hasilSuit);
break;

case "gaple":
try {
await XReaction();
if (!m.isGroup) return reply("❌ Perintah ini hanya bisa digunakan di grup.");

function readGapleGameData() {
global.db = global.db || {};
global.db.data = global.db.data || {};
global.db.data.gaple = global.db.data.gaple || {};
return global.db.data.gaple;
}

function writeGapleGameData(games) {
global.db = global.db || {};
global.db.data = global.db.data || {};
global.db.data.gaple = games;
}

function createDominoDeck() {
const deck = [];
for (let i = 0; i <= 6; i++) {
for (let j = i; j <= 6; j++) deck.push([i, j]);
}
return deck;
}

function shuffle(a) {
for (let i = a.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[a[i], a[j]] = [a[j], a[i]];
}
return a;
}

function getNextPlayer(game) {
return (game.currentPlayer + 1) % game.players.length;
}

function tryPlaceCard(table, card, side) {
if (!table.length) {
table.push([card[0], card[1]]);
return true;
}
const left = table[0][0];
const right = table[table.length - 1][1];
if (side === "left") {
if (card[1] === left) { table.unshift([card[1], card[0]]); return true; }
if (card[0] === left) { table.unshift([card[0], card[1]]); return true; }
return false;
} else if (side === "right") {
if (card[0] === right) { table.push([card[0], card[1]]); return true; }
if (card[1] === right) { table.push([card[1], card[0]]); return true; }
return false;
}
return false;
}

async function sendGapleStatus(chat) {
const mejaText = game.table.length ? game.table.map(c => `[${c[0]}|${c[1]}]`).join(" - ") : "(kosong)";
const handsText = game.players.map((p, i) => `${i}: @${p.id.split('@')[0]} (${p.hand.length} kartu)`).join("\n");
const giliranId = game.players[game.currentPlayer]?.id;
const giliranText = giliranId ? `@${giliranId.split('@')[0]}` : "-";
const statusText = `🀄 Permainan Gaple\n\nMeja: ${mejaText}\nGiliran: ${giliranText}\n\n📊 Jumlah kartu:\n${handsText}`;
await Alice.sendMessage(chat, { text: statusText, contextInfo: { mentionedJid: game.players.map(p => p.id) } });
}

const games = readGapleGameData();
const args = text.split(" ");
const command = args[0] || "";
const sub = args.slice(1);

if (!games[m.chat]) {
games[m.chat] = { players: [], deck: createDominoDeck(), table: [], currentPlayer: 0, stopVotes: [] };
writeGapleGameData(games);
return reply("🀄 Permainan Gaple dimulai! Ketik `gaple join` untuk bergabung.");
}

const game = games[m.chat];

switch (command) {
case "join":
if (game.players.find(p => p.id === m.sender)) return reply("Kamu sudah bergabung.");
game.players.push({ id: m.sender, hand: [] });
writeGapleGameData(games);
reply(`✅ @${m.sender.split('@')[0]} bergabung!`, null, { contextInfo: { mentionedJid: [m.sender] } });
break;

case "start":
if (game.players.length < 2) return reply("❌ Minimal 2 pemain.");
game.deck = shuffle(createDominoDeck());
for (const p of game.players) {
p.hand = [];
for (let i = 0; i < 7 && game.deck.length; i++) p.hand.push(game.deck.pop());
const handText = p.hand.map((c, i) => `${i}: [${c[0]}|${c[1]}]`).join("\n") || "(kosong)";
await Alice.sendMessage(String(p.id), { text: `🀱 Kartu Awalmu\n\n${handText}` });
}
game.table = game.deck.length ? [game.deck.pop()] : [];
game.currentPlayer = 0;
writeGapleGameData(games);
sendGapleStatus(m.chat);
break;

case "info":
reply(`
📘 Panduan Gaple (Domino)

1) Bergabung: gaple join
2) Mulai: gaple start (min 2 pemain)
3) Lihat kartu: gaple hand
4) Main kartu: gaple play <nomor> left/right
5) Ambil kartu: gaple draw
6) Lewati: gaple pass
7) Hentikan: gaple stop
`);
break;

case "hand":
const playerHand = game.players.find(p => p.id === m.sender);
if (!playerHand) return reply("❌ Kamu belum bergabung.");
const handText = playerHand.hand.map((c, i) => `${i}: [${c[0]}|${c[1]}]`).join("\n") || "(kosong)";
await Alice.sendMessage(String(m.sender), { text: `🀱 Kartu Milikmu\n\n${handText}` }, { quoted: m });
reply(`📩 @${m.sender.split('@')[0]} cek chat pribadi.`, null, { contextInfo: { mentionedJid: [m.sender] } });
break;

case "play":
const currentPlayer = game.players[game.currentPlayer];
if (!currentPlayer || currentPlayer.id !== m.sender) return reply("❌ Bukan giliranmu!");
const idx = parseInt(sub[0], 10);
const side = (sub[1] || "").toLowerCase();
if (isNaN(idx) || idx < 0 || idx >= currentPlayer.hand.length) return reply("❌ Nomor kartu tidak valid.");
if (!["left", "right"].includes(side)) return reply("❌ Pilih sisi: left/right.");
const card = currentPlayer.hand[idx];
const placed = tryPlaceCard(game.table, card, side);
if (!placed) return reply("❌ Kartu tidak cocok.");
currentPlayer.hand.splice(idx, 1);
if (currentPlayer.hand.length === 0) {
delete games[m.chat];
writeGapleGameData(games);
return reply(`🎉 @${m.sender.split('@')[0]} MENANG!`, null, { contextInfo: { mentionedJid: [m.sender] } });
}
game.currentPlayer = getNextPlayer(game);
writeGapleGameData(games);
sendGapleStatus(m.chat);
break;

case "draw":
const drawPlayer = game.players[game.currentPlayer];
if (!drawPlayer || drawPlayer.id !== m.sender) return reply("❌ Bukan giliranmu!");
if (!game.deck.length) return reply("📦 Deck kosong.");
const newCard = game.deck.pop();
drawPlayer.hand.push(newCard);
reply(`📥 @${m.sender.split('@')[0]} ambil kartu: [${newCard[0]}|${newCard[1]}]`, null, { contextInfo: { mentionedJid: [m.sender] } });
game.currentPlayer = getNextPlayer(game);
writeGapleGameData(games);
sendGapleStatus(m.chat);
break;

case "pass":
const passPlayer = game.players[game.currentPlayer];
if (!passPlayer || passPlayer.id !== m.sender) return reply("❌ Bukan giliranmu!");
game.currentPlayer = getNextPlayer(game);
writeGapleGameData(games);
sendGapleStatus(m.chat);
break;

case "stop":
const stopPlayer = game.players.find(p => p.id === m.sender);
if (!stopPlayer) return reply("❌ Kamu belum bergabung.");
if (isAdmins || isOwner) {
delete games[m.chat];
writeGapleGameData(games);
return reply("⏹ Permainan dihentikan admin.");
}
if (!game.stopVotes.includes(m.sender)) game.stopVotes.push(m.sender);
if (game.stopVotes.length === game.players.length) {
delete games[m.chat];
writeGapleGameData(games);
return reply("⏹ Permainan dihentikan semua pemain.");
}
writeGapleGameData(games);
reply(`📢 Menunggu ${game.players.length - game.stopVotes.length} pemain lagi.`);
break;

default:
reply("❓ Gunakan `gaple info` untuk panduan.");
}
} catch (err) {
console.error(err);
reply(`Error: ${err.message}`);
}
break;

case "uno":
try {
await XReaction();
if (!m.isGroup) return reply("Perintah ini hanya bisa digunakan di grup.");

const games = readUnoGameData();
const args = text.split(' ');
const command = args[0];
const subCommand = args.slice(1).join(' ');

if (!games[m.chat]) {
games[m.chat] = {
players: [],
deck: createDeck(),
discardPile: [],
currentPlayer: 0,
direction: 1,
currentCard: null,
drawStack: 0,
blockCardPlayed: false,
reverseCardPlayed: false,
stopVotes: new Set(),
awaitingColorChoice: false
};
writeUnoGameData(games);
return reply("Permainan UNO dimulai! Ketik `uno join` untuk bergabung.");
}

const game = games[m.chat];

switch (command) {
case "join":
if (game.players.find(player => player.id === m.sender)) return reply("Kamu sudah bergabung.");
game.players.push({ id: m.sender, hand: [] });
writeUnoGameData(games);
reply("Kamu berhasil bergabung ke permainan UNO!");
break;

case "start":
if (game.players.length < 2) return reply("Minimal 2 pemain dibutuhkan.");
game.deck = shuffle(game.deck);
game.players.forEach(player => {
for (let i = 0; i < 7; i++) player.hand.push(game.deck.pop());
});
game.currentCard = game.deck.pop();
game.discardPile.push(game.currentCard);
writeUnoGameData(games);
sendGameStatus(m.chat);
break;

case "info":
reply(`
📘 Aturan & Cara Bermain UNO:

1. Bergabung: \`uno join\`
2. Mulai: \`uno start\` (minimal 2 pemain)
3. Ambil kartu: \`uno draw\`
4. Mainkan kartu: \`uno play <nomor_kartu>\`
5. Lewati giliran: \`uno pass\`
6. Lihat kartu: \`uno hand\`
7. Lihat gambar: \`uno card <nomor>\`
8. Hentikan: \`uno stop\`

Kartu spesial:
- 12: +2 kartu & skip
- 14: +4 kartu & skip
- 10: skip
- 11: reverse
- wild13: ganti warna
- wild14: +4 & ganti warna
`);
break;

case "stop":
const playerStop = game.players.find(p => p.id === m.sender);
if (!playerStop) return reply("Kamu belum bergabung.");
if (isAdmins || isOwner) {
delete games[m.chat];
writeUnoGameData(games);
return reply("Permainan dihentikan oleh admin.");
}
game.stopVotes.add(m.sender);
if (game.stopVotes.size === game.players.length) {
delete games[m.chat];
writeUnoGameData(games);
return reply("Permainan dihentikan semua pemain.");
}
writeUnoGameData(games);
reply(`Menunggu ${game.players.length - game.stopVotes.size} pemain lagi untuk setuju.`);
break;

case "hand":
const playerHand = game.players.find(p => p.id === m.sender);
if (!playerHand) return reply("Kamu belum bergabung.");
const hand = playerHand.hand.map((card, idx) => `${idx}: ${card.color} ${card.value}`).join("\n");
await Alice.sendMessage(m.sender, { text: `Kartu milikmu:\n${hand}` }, { quoted: m });
reply("Kartu dikirim via chat pribadi!");
break;

case "card":
const cardIdx = parseInt(subCommand);
const handCards = game.players.find(p => p.id === m.sender).hand;
if (isNaN(cardIdx) || cardIdx < 0 || cardIdx >= handCards.length) return reply("Nomor kartu tidak valid.");
const card = handCards[cardIdx];
const cardUrl = `https://raw.githubusercontent.com/abhisheks008/UNO/main/images/${card.color === "black" ? card.value : card.color + card.value}.png`;
await Alice.sendMessage(m.sender, { image: { url: cardUrl }, caption: `${card.color} ${card.value}` }, { quoted: m });
reply("Gambar kartu dikirim via chat pribadi!");
break;

case "draw":
const drawPlayer = game.players[game.currentPlayer];
if (drawPlayer.id !== m.sender) return reply("Bukan giliranmu!");
if (game.drawStack > 0) {
for (let i = 0; i < game.drawStack; i++) {
if (game.deck.length === 0) {
game.deck = shuffle(game.discardPile);
game.discardPile = [];
}
drawPlayer.hand.push(game.deck.pop());
}
reply(`Ambil ${game.drawStack} kartu penalti.`);
game.drawStack = 0;
} else {
if (game.deck.length === 0) {
game.deck = shuffle(game.discardPile);
game.discardPile = [];
}
const newCard = game.deck.pop();
drawPlayer.hand.push(newCard);
reply(`Ambil 1 kartu: ${newCard.color} ${newCard.value}`);
}
game.currentPlayer = getNextPlayer(game);
game.reverseCardPlayed = false;
writeUnoGameData(games);
sendGameStatus(m.chat);
break;

case "play":
const currPlayer = game.players[game.currentPlayer];
if (currPlayer.id !== m.sender) return reply("Bukan giliranmu!");
const playIdx = parseInt(subCommand);
if (isNaN(playIdx) || playIdx < 0 || playIdx >= currPlayer.hand.length) return reply("Nomor kartu tidak valid.");
const playCard = currPlayer.hand[playIdx];
if (!isValidPlay(game.currentCard, playCard)) return reply("Kartu tidak bisa dimainkan.");
if (playCard.value === "12") game.drawStack += 2;
else if (playCard.value === "wild14") {
if (hasPlayableCard(currPlayer, game.currentCard)) return reply("Wild +4 hanya jika tidak ada kartu lain.");
game.drawStack += 4;
game.currentCard.color = "black";
game.awaitingColorChoice = true;
} else if (playCard.value === "10") game.currentPlayer = getNextPlayer(game);
else if (playCard.value === "11") game.direction *= -1;
game.currentCard = playCard;
game.discardPile.push(playCard);
currPlayer.hand.splice(playIdx, 1);
if (currPlayer.hand.length === 0) {
delete games[m.chat];
writeUnoGameData(games);
return reply(`🏆 ${m.sender} MENANG! 🏆`);
}
game.currentPlayer = getNextPlayer(game);
game.reverseCardPlayed = false;
writeUnoGameData(games);
sendGameStatus(m.chat);
break;

case "pass":
const passPlayer = game.players[game.currentPlayer];
if (passPlayer.id !== m.sender) return reply("Bukan giliranmu!");
game.currentPlayer = getNextPlayer(game);
game.reverseCardPlayed = false;
writeUnoGameData(games);
sendGameStatus(m.chat);
break;

case "color":
if (!game.awaitingColorChoice || game.players[game.currentPlayer].id !== m.sender) return reply("Tidak perlu pilih warna.");
const chosen = subCommand.trim().toLowerCase();
if (!["red", "yellow", "green", "blue"].includes(chosen)) return reply("Pilih: red, yellow, green, blue");
game.currentCard.color = chosen;
game.awaitingColorChoice = false;
game.currentPlayer = getNextPlayer(game);
writeUnoGameData(games);
sendGameStatus(m.chat);
break;

default:
reply("Gunakan `uno info` untuk melihat perintah.");
break;
}

function createDeck() {
const colors = ["red", "yellow", "green", "blue"];
const values = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
const deck = [];
colors.forEach(color => {
values.forEach(value => {
deck.push({ color, value });
if (value !== "1") deck.push({ color, value });
});
});
["wild13", "wild14"].forEach(value => {
deck.push({ color: "black", value });
deck.push({ color: "black", value });
});
return shuffle(deck);
}

function shuffle(arr) {
for (let i = arr.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[arr[i], arr[j]] = [arr[j], arr[i]];
}
return arr;
}

function isValidPlay(current, play) {
return play.color === "black" || current.color === play.color || current.value === play.value;
}

function getNextPlayer(game) {
return (game.currentPlayer + game.direction + game.players.length) % game.players.length;
}

function hasPlayableCard(player, current) {
return player.hand.some(card => isValidPlay(current, card));
}

async function sendGameStatus(chat) {
const curCard = game.currentCard;
const msg = `*PERMAINAN UNO*\n\nKartu saat ini: ${curCard.color} ${curCard.value}\nGiliran: ${game.players[game.currentPlayer].id.split("@")[0]}\n\nJumlah kartu:\n${game.players.map((p, i) => `${i}: ${p.id.split("@")[0]} (${p.hand.length} kartu)`).join("\n")}`;
const imgUrl = `https://raw.githubusercontent.com/abhisheks008/UNO/main/images/${curCard.color === "black" ? curCard.value : curCard.color + curCard.value}.png`;
await Alice.sendMessage(chat, { text: msg });
await Alice.sendMessage(chat, { image: { url: imgUrl }, caption: `Kartu saat ini: ${curCard.color} ${curCard.value}` });
}
} catch (err) {
console.error(err);
reply(`Error: ${err.message}`);
}
break;

case 'wwpc':
case 'ww':
case 'werewolf':
try {
await XReaction();

const jimp = require("jimp");
const resize = async (image, width, height) => {
const read = await jimp.read(image);
return await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
};

const {
emoji_role,
sesi,
playerOnGame,
playerOnRoom,
playerExit,
dataPlayer,
getPlayerById,
getPlayerById2,
killWerewolf,
dreamySeer,
sorcerer,
protectGuardian,
roleGenerator,
addTimer,
startGame,
vote,
clearAllVote,
run,
run_vote,
run_malam,
run_pagi
} = require('./AliceLibray/werewolf.js');

const thumb = "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";
const promoUrl = (typeof global.sosialmedia.telegram === 'string' && global.sosialmedia.telegram) || "https://example.com";

const sender = m.sender;
const chatId = (typeof m.chat === "string") ? m.chat : (m.key?.remoteJid || m.key?.participant || sender);

Alice.werewolf = Alice.werewolf || {};
const ww = Alice.werewolf;
const data = ww[chatId];
const value = (args[0] || '').toLowerCase();
const targetRaw = args[1];

const mustNumber = (v) => {
const n = parseInt(v, 10);
if (Number.isNaN(n) || n <= 0) return null;
return n;
};

if (value === "create") {
if (ww[chatId]) return reply("Group masih dalam sesi permainan");
if (playerOnGame(sender, ww)) return reply("Kamu masih dalam sesi game");
ww[chatId] = {
room: chatId,
owner: sender,
status: false,
iswin: null,
cooldown: 0,
day: 0,
time: "malem",
player: [],
dead: [],
voting: false,
seer: false,
guardian: []
};
return reply("Room berhasil dibuat, ketik .ww join untuk bergabung");
}
else if (value === "join") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (ww[chatId].status) return reply("Sesi permainan sudah dimulai");
if (ww[chatId].player.length >= 15) return reply("Player penuh (maksimal 15)");
if (playerOnRoom(sender, chatId, ww)) return reply("Kamu sudah join");
if (playerOnGame(sender, ww)) return reply("Kamu masih dalam sesi lain");
const pdata = {
id: sender,
number: ww[chatId].player.length + 1,
sesi: chatId,
status: false,
role: false,
effect: [],
vote: 0,
isdead: false,
isvote: false
};
ww[chatId].player.push(pdata);
let text = `\n*⌂ W E R E W O L F - P L A Y E R*\n\n`;
const mentions = [];
for (let i = 0; i < ww[chatId].player.length; i++) {
const p = ww[chatId].player[i];
text += `${p.number}) @${p.id.replace("@s.whatsapp.net", "")}\n`;
mentions.push(p.id);
}
text += "\nJumlah player minimal 5 dan maksimal 15";
return Alice.sendMessage(chatId, {
text: text.trim(),
contextInfo: {
externalAdreply: {
title: "W E R E W O L F",
mediaType: 1,
renderLargerThumbnail: true,
thumbnail: await resize(thumb, 300, 175),
sourceUrl: promoUrl,
mediaUrl: thumb
},
mentionedJid: mentions
}
}, { quoted: m });
}
else if (value === "start") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (ww[chatId].player.length < 5) return reply("Minimal 5 pemain untuk mulai");
if (!playerOnRoom(sender, chatId, ww)) return reply("Kamu belum join room");
if (ww[chatId].status) return reply("Game sudah dimulai");
if (ww[chatId].owner !== sender) return reply(`Hanya @${ww[chatId].owner.split("@")[0]} yang bisa start`);
if ((ww[chatId].cooldown || 0) > 0) {
clearAllVote(chatId, ww);
addTimer(chatId, ww);
if (ww[chatId].time === "voting") return await run_vote(Alice, chatId, ww);
if (ww[chatId].time === "malem") return await run_malam(Alice, chatId, ww);
if (ww[chatId].time === "pagi") return await run_pagi(Alice, chatId, ww);
}
roleGenerator(chatId, ww);
addTimer(chatId, ww);
startGame(chatId, ww);
for (let p of ww[chatId].player) {
let teksRole = `*⌂ W E R E W O L F - ROLE*\n\nHalo @${p.id.split("@")[0]}, role kamu adalah *${p.role.toUpperCase()}* ${emoji_role(p.role)}\n\nJangan kasih tau siapapun!`;
await Alice.sendMessage(p.id, { text: teksRole, mentions: [p.id] });
}
await Alice.sendMessage(chatId, {
text: "*⌂ W E R E W O L F - G A M E*\n\nGame dimulai, cek chat pribadi untuk role!",
contextInfo: {
externalAdreply: {
title: "W E R E W O L F",
mediaType: 1,
renderLargerThumbnail: true,
thumbnail: await resize(thumb, 300, 175),
sourceUrl: promoUrl,
mediaUrl: thumb
},
mentionedJid: ww[chatId].player.map(p => p.id)
}
});
return await run(Alice, chatId, ww);
}
else if (value === "kill") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (dataPlayer(sender, ww).role !== "werewolf") return reply("Hanya werewolf yang bisa kill");
const n = mustNumber(targetRaw);
if (!n) return reply("Format: .ww kill <nomor>");
const byId = getPlayerById2(sender, n, ww);
if (byId === false) return reply("Player tidak terdaftar");
if (byId.db.isdead) return reply("Player sudah mati");
if (byId.db.id === sender) return reply("Tidak bisa kill diri sendiri");
reply("Berhasil membunuh player " + n).then(() => {
dataPlayer(sender, ww).status = true;
killWerewolf(sender, n, ww);
});
}
else if (value === "dreamy") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (dataPlayer(sender, ww).role !== "seer") return reply("Bukan role kamu");
const n = mustNumber(targetRaw);
if (!n) return reply("Format: .ww dreamy <nomor>");
const byId = getPlayerById2(sender, n, ww);
if (byId === false) return reply("Player tidak terdaftar");
const result = dreamySeer(sender, n, ww);
reply(`Identitas player ${n}: ${result}`).then(() => {
dataPlayer(sender, ww).status = true;
});
}
else if (value === "deff") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (dataPlayer(sender, ww).role !== "guardian") return reply("Bukan role kamu");
const n = mustNumber(targetRaw);
if (!n) return reply("Format: .ww deff <nomor>");
protectGuardian(sender, n, ww);
reply(`Berhasil melindungi player ${n}`).then(() => {
dataPlayer(sender, ww).status = true;
});
}
else if (value === "sorcerer") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (dataPlayer(sender, ww).role !== "sorcerer") return reply("Bukan role kamu");
const n = mustNumber(targetRaw);
if (!n) return reply("Format: .ww sorcerer <nomor>");
const result = sorcerer(sender, n, ww);
reply(`Identitas player ${n}: ${result}`).then(() => {
dataPlayer(sender, ww).status = true;
});
}
else if (value === "vote") {
if (!ww[chatId]) return reply("Belum ada sesi permainan");
if (ww[chatId].status === false) return reply("Game belum dimulai");
const n = mustNumber(targetRaw);
if (!n) return reply("Format: .ww vote <nomor>");
vote(chatId, n, sender, ww);
return reply("✅ Vote berhasil");
}
else if (value === "exit") {
if (!ww[chatId]) return reply("Tidak ada sesi");
if (ww[chatId].status) return reply("Game sudah dimulai, tidak bisa keluar");
playerExit(chatId, sender, ww);
return reply(`${sender.split("@")[0]} keluar dari permainan`);
}
else if (value === "delete") {
if (!ww[chatId]) return reply("Tidak ada sesi");
if (ww[chatId].owner !== sender) return reply(`Hanya owner room yang bisa hapus sesi`);
delete ww[chatId];
return reply("Sesi permainan dihapus");
}
else if (value === "player") {
if (!ww[chatId]) return reply("Tidak ada sesi permainan");
let text = "\n*⌂ W E R E W O L F - LIST PLAYER*\n\n";
ww[chatId].player.forEach(p => {
text += `(${p.number}) @${p.id.replace("@s.whatsapp.net", "")} ${p.isdead ? `☠️ ${p.role}` : ""}\n`;
});
return Alice.sendMessage(chatId, {
text,
mentions: ww[chatId].player.map(p => p.id)
});
}
else {
let text = `\n*⌂ W E R E W O L F - G A M E*\n\nCommand:\n`;
text += ` • .ww create\n`;
text += ` • .ww join\n`;
text += ` • .ww start\n`;
text += ` • .ww exit\n`;
text += ` • .ww delete\n`;
text += ` • .ww player\n`;
text += ` • .ww kill <nomor>\n`;
text += ` • .ww dreamy <nomor>\n`;
text += ` • .ww deff <nomor>\n`;
text += ` • .ww sorcerer <nomor>\n`;
text += ` • .ww vote <nomor>\n`;
text += `\nGame dapat dimainkan oleh 5–15 orang.`;
return Alice.sendMessage(chatId, {
text: text.trim(),
contextInfo: {
externalAdreply: {
title: "W E R E W O L F",
mediaType: 1,
renderLargerThumbnail: true,
thumbnail: await resize(thumb, 300, 175),
sourceUrl: promoUrl,
mediaUrl: thumb
}
}
}, { quoted: m });
}
} catch (err) {
console.error(err);
return reply(`❌ Terjadi error: ${err?.message || err}`);
}
break;

case "clan":
case "clans":
if (!m.isGroup) return XRG();
await XReaction();

const {
playerOnClan,
readClans,
writeClans,
setMissions,
upgradeMissonProgress,
updateClanTaskProgress,
upgradeClanLevel,
simulateWinner,
getClanData,
saveClanData,
saveTournamentData,
} = require("./AliceSystem/AliceDatabase/Game/clan");

async function startNextMatch(tournament) {
let nextMatch = tournament.matches.find(match => match.status === "pending");
if (!nextMatch) {
tournament.status = "completed";
clans.currentTournament = null;
let winnerClan = tournament.participants[0];
let winningClanData = await getClanData(winnerClan);
winningClanData.power += 1000;
winningClanData.level += 5;
saveClanData(winnerClan, winningClanData);
await reply(`Tournament ${tournament.name} is over! Winner is ${winnerClan}. Gets 1000 power and +5 levels.`);
return;
}

let clan1Data = await getClanData(nextMatch.clan1);
let clan2Data = await getClanData(nextMatch.clan2);
nextMatch.status = "ongoing";
writeClans(clans);
let winner = simulateWinner(clan1Data, clan2Data);
nextMatch.winner = winner;
nextMatch.status = "completed";
tournament.participants = tournament.participants.filter(clan => clan !== (winner === clan1Data.clan ? clan2Data.clan : clan1Data.clan));
writeClans(clans);
await reply(`Match between ${clan1Data.clan} and ${clan2Data.clan} over! Winner: ${winner}`);
setTimeout(() => startNextMatch(tournament), 5000);
}

const clans = readClans();
const action = args[0];
const param1 = args[1];
const param2 = args[2];

switch (action) {
case "create":
let existingUserClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (existingUserClan) return reply("You already have a clan.");
clans[param1.toLowerCase()] = {
room: param1,
owner: sender.replace("@s.whatsapp.net", ""),
status: false,
clan: param1,
members: [],
joinRequests: [],
level: 1,
warLimit: 5,
currentWarCount: 0,
missions: {
daily: { description: "Recruit 5 new members", progress: 0, target: 5, reward: 100 },
weekly: { description: "Win 3 wars", progress: 0, target: 3, reward: 500 }
},
clanTasks: { description: "Reach level 3", progress: 1, target: 3, reward: 300 }
};
writeClans(clans);
await reply(`Clan ${param1} created successfully!\n\nTo join, type .clan join ${param1}`);
break;

case "join":
if (!param1) return reply("Enter clan name to join.");
let userClanCheck = Object.values(clans).find(c => c.members && c.members.some(m => m.id === sender));
if (userClanCheck) return reply("You are already in a clan.");
let targetJoinClan = Object.values(clans).find(c => c.clan.toLowerCase() === param1.toLowerCase());
if (!targetJoinClan) return reply("Clan not found.");
if (playerOnClan(sender, chat, clans)) return reply("Already in this clan.");
let joinData = {
id: sender,
number: targetJoinClan.members ? targetJoinClan.members.length + 1 : 1,
session: chat,
status: false,
clan: param1,
vote: 0,
isVote: false
};
if (!targetJoinClan.joinRequests) targetJoinClan.joinRequests = [];
targetJoinClan.joinRequests.push(joinData);
writeClans(clans);
reply(`Join request sent to ${targetJoinClan.clan}. Wait for approval.`);
break;

case "approve":
if (!param1) return reply("Enter clan name.");
let approveClan = Object.values(clans).find(c => c.clan.toLowerCase() === param1.toLowerCase());
if (!approveClan) return reply("Clan not found.");
if (approveClan.owner !== sender.replace("@s.whatsapp.net", "")) return reply("You are not the owner.");
if (!approveClan.joinRequests || approveClan.joinRequests.length === 0) return reply("No join requests.");
let approveText = "";
if (param2 === "all") {
approveClan.joinRequests.forEach(request => {
approveClan.members.push({ id: request.id, number: approveClan.members.length + 1, sesi: chat, status: false, clan: request.clan, vote: 0 });
approveText += `✅ @${request.id.replace("@s.whatsapp.net", "")} approved.\n`;
});
approveClan.joinRequests = [];
writeClans(clans);
} else if (param2) {
let index = parseInt(param2) - 1;
if (index < 0 || index >= approveClan.joinRequests.length) return reply("Invalid index.");
let requester = approveClan.joinRequests[index];
approveClan.joinRequests.splice(index, 1);
approveClan.members.push({ id: requester.id, number: approveClan.members.length + 1, session: chat, status: false, clan: requester.clan, vote: 0 });
approveText = `✅ @${requester.id.replace("@s.whatsapp.net", "")} approved.`;
writeClans(clans);
} else {
let pendingText = `Join requests:\n`;
approveClan.joinRequests.forEach((req, i) => { pendingText += `${i+1}. @${req.id.replace("@s.whatsapp.net", "")}\n`; });
pendingText += `\nUse .clan approve ${param1} [number/all]`;
return reply(pendingText);
}
await reply(approveText);
break;

case "war":
let warClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!warClan) return reply("You don't own a clan.");
if (warClan.currentWarCount >= warClan.warLimit) return reply(`Daily war limit reached (${warClan.currentWarCount}/${warClan.warLimit}).`);
let otherClans = Object.values(clans).filter(c => c.clan !== warClan.clan);
if (otherClans.length === 0) return reply("No other clans available.");
let targetWar = otherClans[Math.floor(Math.random() * otherClans.length)];
if (warClan.war || targetWar.war) return reply("One of the clans is already at war.");
let initiatorPower = warClan.level * warClan.members.length;
let targetPower = targetWar.level * targetWar.members.length;
let winner = initiatorPower >= targetPower ? warClan : targetWar;
let loser = initiatorPower < targetPower ? warClan : targetWar;
let reward = Math.floor(Math.random() * 3) + 1;
winner.level += 1;
winner.warLimit += reward;
winner.currentWarCount += 1;
loser.currentWarCount += 1;
writeClans(clans);
await reply(`*WAR RESULT*\n\nWinner: ${winner.clan} (Lv.${winner.level})\nLoser: ${loser.clan} (Lv.${loser.level})\n${winner.clan} gets +${reward} war limit.\n\n${warClan.clan}: ${warClan.currentWarCount}/${warClan.warLimit}`);
break;

case "list":
let listText = "*LIST OF CLANS*\n\n";
for (let key in clans) {
if (key === "tournaments" || key === "currentTournament") continue;
let clan = clans[key];
if (clan && clan.members) {
let limit = clan.warLimit !== undefined ? clan.warLimit : 3;
listText += `📛 ${clan.clan}\n   Level: ${clan.level}\n   Members: ${clan.members.length}\n   War: ${clan.currentWarCount}/${limit}\n\n`;
}
}
await reply(listText.trim());
break;

case "leave":
let leaveClan = Object.values(clans).find(c => c.members && c.members.some(m => m.id === sender));
if (!leaveClan) return reply("You are not in any clan.");
leaveClan.members = leaveClan.members.filter(m => m.id !== sender);
writeClans(clans);
await reply(`You left ${leaveClan.clan}.`);
break;

case "delete":
let deleteClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!deleteClan) return reply("You don't own a clan.");
delete clans[deleteClan.clan.toLowerCase()];
writeClans(clans);
await reply(`Clan ${deleteClan.clan} deleted.`);
break;

case "member":
if (!param1) return reply("Enter clan name.");
let memberClan = Object.values(clans).find(c => c.clan.toLowerCase() === param1.toLowerCase());
if (!memberClan) return reply("Clan not found.");
let memberText = `*MEMBERS OF ${memberClan.clan}*\n\n`;
memberClan.members.forEach((m, i) => {
memberText += `${i+1}. @${m.id.replace("@s.whatsapp.net", "")}\n`;
});
await reply(memberText.trim());
break;

case "missions":
let missionClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!missionClan) return reply("You don't own a clan.");
let missionText = `*${missionClan.clan} MISSIONS*\n\n`;
if (missionClan.missions?.daily) {
missionText += `📅 Daily: ${missionClan.missions.daily.description}\n   Progress: ${missionClan.missions.daily.progress}/${missionClan.missions.daily.target}\n   Reward: ${missionClan.missions.daily.reward}\n\n`;
}
if (missionClan.missions?.weekly) {
missionText += `📆 Weekly: ${missionClan.missions.weekly.description}\n   Progress: ${missionClan.missions.weekly.progress}/${missionClan.missions.weekly.target}\n   Reward: ${missionClan.missions.weekly.reward}\n`;
}
await reply(missionText.trim());
break;

case "task":
let taskClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!taskClan) return reply("You don't own a clan.");
let taskText = `*${taskClan.clan} TASKS*\n\n`;
if (taskClan.clanTasks) {
taskText += `📌 ${taskClan.clanTasks.description}\n   Progress: ${taskClan.clanTasks.progress}/${taskClan.clanTasks.target}\n   Reward: ${taskClan.clanTasks.reward}`;
} else {
taskText += "No active tasks.";
}
await reply(taskText.trim());
break;

case "upgrade":
let upgradeClan = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!upgradeClan) return reply("You don't own a clan.");
if (upgradeClan.level < upgradeClan.clanTasks.target) {
upgradeClan.level += 1;
upgradeClan.clanTasks.progress += 1;
writeClans(clans);
await reply(`Clan ${upgradeClan.clan} upgraded to level ${upgradeClan.level}.`);
} else {
await reply("Clan already at max level for current task.");
}
break;

case "tournament":
const subAction = param1;
switch (subAction) {
case "create":
if (!param2) return reply("Enter tournament name.");
if (!clans.tournaments) clans.tournaments = {};
if (clans.currentTournament) return reply("Tournament already ongoing.");
if (clans.tournaments[param2]) return reply("Tournament name exists.");
clans.currentTournament = param2;
clans.tournaments[param2] = { name: param2, participants: [], status: "pending", matches: [] };
writeClans(clans);
await reply(`Tournament ${param2} created.`);
break;

case "join":
if (!clans.currentTournament) return reply("No ongoing tournament.");
let joinTourney = clans.tournaments[clans.currentTournament];
let userClanTourney = Object.values(clans).find(c => c.owner === sender.replace("@s.whatsapp.net", ""));
if (!userClanTourney) return reply("You don't own a clan.");
if (joinTourney.participants.includes(userClanTourney.clan)) return reply("Already registered.");
joinTourney.participants.push(userClanTourney.clan);
writeClans(clans);
await reply(`${userClanTourney.clan} joined tournament.`);
break;

case "start":
if (!clans.currentTournament) return reply("No ongoing tournament.");
let startTourney = clans.tournaments[clans.currentTournament];
if (startTourney.status !== "pending") return reply("Tournament already started.");
if (startTourney.participants.length < 2 || startTourney.participants.length % 2 !== 0) {
return reply("Need at least 2 clans and even number of participants.");
}
startTourney.participants.sort(() => Math.random() - 0.5);
while (startTourney.participants.length > 1) {
for (let i = 0; i < startTourney.participants.length; i += 2) {
if (startTourney.participants[i + 1]) {
startTourney.matches.push({ clan1: startTourney.participants[i], clan2: startTourney.participants[i + 1], status: "pending" });
}
}
startTourney.participants = startTourney.participants.filter((_, idx) => idx % 2 === 0);
}
startTourney.status = "ongoing";
writeClans(clans);
await reply(`Tournament ${clans.currentTournament} started!`);
startNextMatch(startTourney);
break;

case "status":
if (!clans.currentTournament) return reply("No ongoing tournament.");
let statusTourney = clans.tournaments[clans.currentTournament];
let statusText = `*TOURNAMENT ${clans.currentTournament}*\n\nStatus: ${statusTourney.status}\nParticipants: ${statusTourney.participants.join(", ")}\n\nMatches:\n`;
statusTourney.matches.forEach((m, i) => {
statusText += `${i+1}. ${m.clan1} vs ${m.clan2} - ${m.status}\n`;
});
await reply(statusText.trim());
break;

default:
await reply("Tournament commands: create, join, start, status");
}
break;

default:
await reply("Commands: create, join, approve, war, list, leave, delete, member, missions, task, upgrade, tournament");
}
break;

case 'judibola':
try {
await XReaction();
Alice.jbRooms = Alice.jbRooms || {};
Alice.jbVotes = Alice.jbVotes || {};

const clubs = [
"Real Madrid", "Manchester United", "Inter Milan", "Barcelona",
"Liverpool", "Paris Saint-Germain", "Chelsea", "Juventus",
"Borussia Dortmund", "Atletico Madrid", "RB Leipzig", "Porto",
"Arsenal", "Shakhtar Donetsk", "Red Bull Salzburg", "AC Milan",
"Braga", "PSV Eindhoven", "Lazio", "Red Star Belgrade", "FC Copenhagen"
];

const shuffleArray = (array) => {
for (let i = array.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[array[i], array[j]] = [array[j], array[i]];
}
};

const countVotes = (votes) => {
const voteCount = { "1": 0, "2": 0 };
Object.values(votes).forEach(vote => {
if (voteCount[vote] !== undefined) voteCount[vote]++;
});
return voteCount;
};

if (!args[0] || args[0] === "help") {
const message = `*❏ JUDI BOLA⚽*

${emojipick}.judibola create (buat room)
${emojipick}.judibola join (player join, taruhan 10)
${emojipick}.judibola player (daftar pemain)
${emojipick}.judibola mulai (mulai game)
${emojipick}.judibola vote 1/2 (vote klub)
${emojipick}.judibola delete (hapus room)

Minimal player: 2 pemain
Taruhan: 10 Limit
Hadiah: 200 Limit`;
await Alice.sendMessage(m.chat, { text: message });
return;
}

switch (args[0].toLowerCase()) {
case 'create':
if (Alice.jbRooms[m.chat]) return reply('Room sudah ada.');
Alice.jbRooms[m.chat] = { players: [], gameStarted: false, clubs: [], limit: 0 };
reply('Room berhasil dibuat.');
break;

case 'join':
if (!Alice.jbRooms[m.chat]) return reply('Belum ada room. Gunakan .judibola create');
if (Alice.jbRooms[m.chat].gameStarted) return reply('Game sudah dimulai.');
if (Alice.jbRooms[m.chat].players.find(p => p.id === m.sender)) return reply('Sudah bergabung.');
const playerName = m.pushName || Alice.getName(m.sender);
Alice.jbRooms[m.chat].players.push({ id: m.sender, name: playerName });
Alice.jbRooms[m.chat].limit += 10;
reply(`Bergabung! Taruhan: 10. Total: ${Alice.jbRooms[m.chat].limit}`);
break;

case 'player':
if (!Alice.jbRooms[m.chat]) return reply('Belum ada room.');
const players = Alice.jbRooms[m.chat].players;
reply(`Pemain:\n${players.map(p => `${p.name}`).join('\n')}`);
break;

case 'mulai':
if (!Alice.jbRooms[m.chat]) return reply('Belum ada room.');
if (Alice.jbRooms[m.chat].players.length < 2) return reply('Minimal 2 pemain.');
shuffleArray(clubs);
Alice.jbRooms[m.chat].clubs = [clubs[0], clubs[1]];
Alice.jbRooms[m.chat].gameStarted = true;
reply(`Game dimulai! 1 ${clubs[0]} vs 2 ${clubs[1]}. Vote sekarang!`);
break;

case 'vote':
if (!Alice.jbRooms[m.chat]) return reply('Belum ada room.');
if (!Alice.jbRooms[m.chat].gameStarted) return reply('Game belum dimulai.');
if (!args[1] || !['1', '2'].includes(args[1])) return reply('Gunakan .judibola vote 1 atau 2');
const currentRoom = Alice.jbRooms[m.chat];
const player = currentRoom.players.find(p => p.id === m.sender);
if (!player) return reply('Anda belum bergabung.');
Alice.jbVotes[m.sender] = args[1];
reply(`Memilih klub ${args[1]}`);

const voteCount = countVotes(Alice.jbVotes);
if (Object.keys(Alice.jbVotes).length === currentRoom.players.length) {
reply('Semua sudah vote. Pertandingan dimulai...');
setTimeout(() => {
reply('Pertandingan selesai...');
setTimeout(() => {
const winnerVote = voteCount["1"] > voteCount["2"] ? "1" : "2";
const winningClub = currentRoom.clubs[winnerVote - 1];
const winners = currentRoom.players.filter(p => Alice.jbVotes[p.id] === winnerVote);
reply(`Pemenang: ${winningClub}\n${winners.map(w => w.name).join('\n')}\nMendapat 200 limit!`);
let users = global.db.data.users;
winners.forEach(w => {
if (!users[w.id]) users[w.id] = { limit: 0 };
users[w.id].limit += 200;
});
delete Alice.jbRooms[m.chat];
delete Alice.jbVotes;
}, 5000);
}, 5000);
}
break;

case 'delete':
if (!Alice.jbRooms[m.chat]) return reply('Tidak ada room.');
delete Alice.jbRooms[m.chat];
delete Alice.jbVotes;
reply('Room dihapus.');
break;

default:
reply('Perintah tidak dikenal.');
}
} catch (err) {
console.error(err);
reply('Error: ' + err.message);
}
break;

case 'gens-wildlife':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} snowboar`);
let result = await genshindb.wildlife(text);
if (result) {
let response = `*Binatang Liar: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}\n*Habitat:* ${result.habitat || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-weapons':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} claymore`);
let result = await genshindb.weapons(text);
if (result) {
let response = `*Senjata: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}\n*Type:* ${result.type || "-"}\n*Base ATK:* ${result.baseAttack || "-"}\n*Substat:* ${result.subStat || "-"}\n*Passive:* ${result.passiveName || "-"}\n${result.passiveDescription || "-"}`;
if (result.refinement) response += `\n*Refinement (${result.refinement.refine}):* ${result.refinement.description || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-voiceovers':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} venti`);
let result = await genshindb.voiceovers(text);
if (result) {
let response = `*Voiceover: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-viewpoint':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} starfell valley`);
let result = await genshindb.viewpoints(text);
if (result) {
let response = `*Pemandangan: ${result.name}*\n\n${result.description || "-"}\n\n*Region:* ${result.region || "-"}\n*Area:* ${result.area || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-talents':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} diluc`);
let result = await genshindb.talents(text);
if (result && result.length > 0) {
let response = `*Bakat ${text}:*\n\n`;
result.forEach((t, i) => {
response += `${i+1}. ${t.name}\n${t.description || "-"}\nType: ${t.type || "-"}\nElement: ${t.element || "-"}\n\n`;
});
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-potion':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} squirrel fish`);
let result = await genshindb.foods(text);
if (result) {
let response = `*Ramuan: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}\n*Efek:* ${result.effect || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-outfit':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} outrider`);
let result = await genshindb.outfits(text);
if (result) {
let response = `*Kostum: ${result.name}*\n\n${result.description || "-"}\n\n*Karakter:* ${result.character || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-nation':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} mondstadt`);
let result = await genshindb.geographies(text);
if (result) {
let response = `*Wilayah: ${result.name}*\n\n${result.description || "-"}\n\n*Area:* ${result.area || "-"}\n*Region:* ${result.region || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-namacard':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} anemo flare`);
let result = await genshindb.namecards(text);
if (result) {
let response = `*Kartu Nama: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}\n*Unlock:* ${result.unlock || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-materials':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} boreal wolf's milk`);
let result = await genshindb.materials(text);
if (result) {
let response = `*Material: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}\n*Type:* ${result.type || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-food':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} temptation`);
let result = await genshindb.foods(text);
if (result) {
let response = `*Makanan: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity}\n*Type:* ${result.foodtype}\n*Category:* ${result.foodfilter || "-"}\n\n*Effect:* ${result.effect || "-"}`;
if (result.suspicious) response += `\n*Suspicious:* ${result.suspicious.effect}`;
if (result.normal) response += `\n*Normal:* ${result.normal.effect}`;
if (result.delicious) response += `\n*Delicious:* ${result.delicious.effect}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-enemy':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} ruin guard`);
let result = await genshindb.enemies(text);
if (result) {
let response = `*Musuh: ${result.name}*\n\n${result.description || "-"}\n\n*Level:* ${result.level || "-"}\n*Rarity:* ${result.rarity || "-"}\n*Element:* ${result.element || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-emoji':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} anemo`);
let result = await genshindb.emojis(text);
if (result) {
let response = `*Emoji: ${result.name}*\n\n${result.description || "-"}\n\n*Rarity:* ${result.rarity || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-domain':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} valley of remembrance`);
let result = await genshindb.domains(text);
if (result) {
let response = `*Domain: ${result.name}*\n\n${result.description || "-"}\n\n*Area:* ${result.area || "-"}\n*Level:* ${result.level || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-craft':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} mystical enhancement ore`);
let result = await genshindb.crafts(text);
if (result) {
let response = `*Craft: ${result.name}*\n\n${result.description || "-"}\n\n*Type:* ${result.type || "-"}\n*Rarity:* ${result.rarity || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-giconstellation':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} diluc`);
let result = await genshindb.constellations(text);
if (result && result.length > 0) {
let response = `*Konstelasi ${text}:*\n\n`;
result.forEach((c, i) => {
response += `${i+1}. ${c.name}\n${c.effect}\nUnlock: C${c.unlock || "?"}\n\n`;
});
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-giartifact':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} berserker`);
let result = await genshindb.artifacts(text);
if (result) {
let response = `*Artefak: ${result.name}*\n\n${result.description || "-"}\n\n*Set:* ${result.set || "-"}\n*Rarity:* ${result.rarity || "-"}\n*Slot:* ${result.slot || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-area':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} liyue`);
let result = await genshindb.geographies(text);
if (result) {
let response = `*Geografi: ${result.name}*\n\n${result.description || "-"}\n\n*Area:* ${result.area || "-"}\n*Region:* ${result.region || "-"}\n*Sortorder:* ${result.sortorder || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-animals':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} shiba`);
let result = await genshindb.animals(text);
if (result) {
let response = `*Hewan: ${result.name}*\n\n${result.description || "-"}\n\n*Kategori:* ${result.category || "-"}\n*Counttype:* ${result.counttype || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-advrank':
try {
await XReaction();
if (!text || isNaN(parseInt(text))) return reply(`Masukkan nomor rank. Contoh: ${prefix + command} 5`);
let rankNumber = parseInt(text);
let result = await genshindb.adventureranks(rankNumber);
if (result) {
let response = `*Rank Petualang ${rankNumber}:*\n\nExperience: ${result.exp || "-"}\nReward: ${result.reward || "-"}\nDeskripsi: ${result.description || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-giachievement':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} mondstadt`);
let result = await genshindb.achievements(text);
if (result) {
let response = `*${result.name}*\n${result.description || "-"}\n\nKategori: ${result.category || "-"}\nRarity: ${result.rarity || "-"}\nDetail: ${result.detail || "-"}\nCara: ${result.howToObtain || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

case 'gens-characters':
try {
await XReaction();
if (!text) return reply(`Contoh: ${prefix + command} diluc`);
let result = await genshindb.characters(text);
if (result) {
let response = `*Karakter: ${result.name}*\n\n${result.description || "-"}\n\nRarity: ${result.rarity || "-"}\nVision: ${result.vision || "-"}\nSenjata: ${result.weapon || "-"}`;
reply(response);
} else reply("Tidak ditemukan.");
} catch (err) {
reply(`Error: ${err.message}`);
}
break;

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Game Features End
//📈————————————————————————— [ Batas Fitur Sayangg ] —————————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//————————————————————————//
// Main Features
//📈————————————————————————— [ Features ↓↓ ] —————————————————————————📉\\
case 'infobot':
case 'about':
try {
await XReaction();
let caption = `📌 INFO ${botname}\n\n`;
caption += `🤖 Nama: ${botname}\n`;
caption += `👤 Owner: ${ownername}\n`;
caption += `📌 Versi: ${version}\n`;
caption += `⏱️ Uptime: ${runtime(process.uptime())}\n`;
caption += `🔧 Fitur: ${totalfitur()}\n`;
caption += `👥 User: ${usersList.length}\n\n`;
caption += `💎 DONASI\n`;
caption += `🟢 GoPay: ${payment.gopay || '-'}\n`;
caption += `💰 Dana: ${payment.dana || '-'}\n`;
caption += `📷 QRIS: ${payment.qris || '-'}\n\n`;
caption += `📦 SEWA BOT\n`;
caption += `⏳ 1 Minggu: 15k\n`;
caption += `📆 1 Bulan: 25k\n`;
caption += `🗓️ 1 Tahun: 100k\n\n`;
caption += `🔗 LINK\n`;
caption += `📢 Channel: ${global.channel || '-'}\n`;
caption += `👥 Grup: ${global.groupbot || '-'}\n`;
caption += `📨 Telegram: ${global.sosialmedia?.telegram || '-'}`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'donasi':
case 'donate':
try {
await XReaction();
let caption = `💎 DONASI ${botname}\n\n`;
caption += `🟢 GoPay: ${payment.gopay || '-'}\n`;
caption += `💰 Dana: ${payment.dana || '-'}\n`;
caption += `📷 QRIS: ${payment.qris || '-'}\n\n`;
caption += `📌 Nama: ${payment.qris_an || '-'}\n\n`;
caption += `💡 Support biar bot makin kenceng 🚀`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'sewa':
case 'sewabot':
try {
await XReaction();
let caption = `📦 SEWA BOT ${botname}\n\n`;
caption += `⏳ 1 Minggu: Rp 15.000\n`;
caption += `📆 1 Bulan: Rp 25.000\n`;
caption += `🗓️ 1 Tahun: Rp 100.000\n\n`;
caption += `✨ Fasilitas:\n`;
caption += `✅ Bot masuk grup kamu\n`;
caption += `✅ Full akses semua fitur\n`;
caption += `✅ Update gratis\n`;
caption += `✅ Support 24 jam\n\n`;
caption += `💬 Minat? chat owner aja kak!\n`;
caption += `📱 wa.me/${global.owner[0]}`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'ownerinfo':
case 'contact':
try {
await XReaction();
let caption = `👤 INFO OWNER\n\n`;
caption += `📛 Nama: ${ownername}\n`;
caption += `📱 WhatsApp: wa.me/${global.owner[0]}\n`;
caption += `📨 Telegram: ${global.sosialmedia?.telegram || '-'}\n`;
caption += `📧 Email: ${global.gmail || '-'}\n`;
caption += `🐙 Github: ${global.github || '-'}\n\n`;
caption += `💬 Chat aja kalau ada perlu ya kak!`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'linkbot':
case 'links':
try {
await XReaction();
let caption = `🔗 LINK BOT ${botname}\n\n`;
caption += `📢 Channel Utama:\n${global.channel || '-'}\n\n`;
caption += `👥 Grup Update:\n${global.groupbot || '-'}\n\n`;
caption += `📝 Grup Testimoni:\n${global.chtesti || '-'}\n\n`;
caption += `📱 Owner:\nwa.me/${global.owner[0]}\n\n`;
caption += `📨 Telegram:\n${global.sosialmedia?.telegram || '-'}`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'profile':
case 'profil':
case 'myinfo':
try {
await XReaction();
let user = global.db.data.users[m.sender] || { registered: false, name: 'Tidak diketahui', age: 0, regTime: null };
let isPremUser = checkPremiumUser(m.sender, premium);
let now = Date.now();
let lastSeen = user.lastseen || now;
let diff = now - lastSeen;
let lastSeenText = diff < 60000 ? 'Baru saja' : diff < 3600000 ? `${Math.floor(diff/60000)} menit lalu` : diff < 86400000 ? `${Math.floor(diff/3600000)} jam lalu` : `${Math.floor(diff/86400000)} hari lalu`;
let limitData = getUserLimit(m.sender);
let currentLimit = limitData.limit || 0;
let limitReset = new Date(limitData.lastReset + 86400000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'long' });
let totalChatHere = 0;
if (m.isGroup && global.db.data.chats[m.chat]?.totalChat?.[m.sender]) totalChatHere = global.db.data.chats[m.chat].totalChat[m.sender];
let totalChatAll = 0;
for (let chatId in global.db.data.chats) {
if (global.db.data.chats[chatId]?.totalChat?.[m.sender]) totalChatAll += global.db.data.chats[chatId].totalChat[m.sender];
}
let isBanned = false;
let banReason = '';
if (bannedUsers[m.sender]) {
isBanned = true;
if (bannedUsers[m.sender].permanent) banReason = 'Permanent';
else {
let sisa = bannedUsers[m.sender].expired - Date.now();
let hari = Math.floor(sisa / 86400000);
let jam = Math.floor((sisa % 86400000) / 3600000);
banReason = `Sementara (${hari}d ${jam}h)`;
}
}
let isAfk = false;
let afkReason = '';
if (_afk[m.chat] && _afk[m.chat][m.sender]) {
isAfk = true;
afkReason = _afk[m.chat][m.sender].reason || 'Tidak ada alasan';
}
let pacar = global.db.data.users[m.sender]?.pacar || null;
let warnCount = 0;
if (warnData[m.chat] && warnData[m.chat].warns && warnData[m.chat].warns[m.sender]) warnCount = warnData[m.chat].warns[m.sender];
let totalCmd = 0;
for (let cmd in global.topcmd) totalCmd += global.topcmd[cmd];
let userCmdCount = Math.floor(totalCmd / Object.keys(global.db.data.users || {}).length) || 0;
let caption = `👤 PROFIL PENGGUNA\n\n`;
caption += `📛 Nama: ${user.name || pushname}\n`;
caption += `📱 Nomor: @${m.sender.split('@')[0]}\n`;
caption += `🎂 Umur: ${user.age || '-'} tahun\n`;
caption += `💎 Premium: ${isPremUser ? '✅ Ya' : '❌ Tidak'}\n`;
caption += `📝 Registrasi: ${user.registered ? '✅ Terdaftar' : '❌ Belum daftar'}\n`;
if (user.registered && user.regTime) caption += `📅 Tanggal Daftar: ${new Date(user.regTime).toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}\n`;
caption += `━━━━━━━━━━━━━━━━━━━━\n`;
caption += `💬 Statistik Chat\n`;
caption += `📊 Total Pesan: ${totalChatAll} pesan\n`;
if (m.isGroup) caption += `👥 Di Grup Ini: ${totalChatHere} pesan\n`;
caption += `🎮 Limit System\n`;
caption += `🎯 Sisa Limit: ${currentLimit}\n`;
caption += `⏰ Reset Limit: ${limitReset}\n`;
caption += `━━━━━━━━━━━━━━━━━━━━\n`;
caption += `📊 Statistik Command\n`;
caption += `🔢 Total Cmd Global: ${totalCmd}\n`;
caption += `👤 Rata2 per User: ${userCmdCount}\n`;
caption += `━━━━━━━━━━━━━━━━━━━━\n`;
if (pacar) caption += `💕 Status Jadian\n❤️ Pacar: @${pacar.split('@')[0]}\n━━━━━━━━━━━━━━━━━━━━\n`;
if (warnCount > 0) caption += `⚠️ Warning System\n🔔 Total Warn: ${warnCount}\n━━━━━━━━━━━━━━━━━━━━\n`;
if (isAfk) caption += `😴 Status AFK\n💬 Alasan: ${afkReason}\n━━━━━━━━━━━━━━━━━━━━\n`;
if (isBanned) caption += `🚫 Status Banned\n⛔ Status: ${banReason}\n━━━━━━━━━━━━━━━━━━━━\n`;
caption += `🕐 Aktivitas\n👀 Terakhir Dilihat: ${lastSeenText}\n`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'speed':
case 'botcepat':
try {
await XReaction();
let start = Date.now();
await Alice.sendPresenceUpdate('composing', m.chat);
let end = Date.now();
let wsLatency = Alice.ws?.socket?.readyState === 1 ? Math.round(Alice.ws.ping()) : '?';
reply(`⚡ SPEED TEST BOT\n\n📡 Ping API: ${end - start}ms\n🔌 WebSocket: ${wsLatency}ms\n💻 Server: ${os.hostname()}\n📊 Status: ${(end-start) < 500 ? '✅ Sangat Cepat' : (end-start) < 1500 ? '⚡ Cukup Cepat' : '🐌 Lambat'}`);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'infoban':
case 'cekok':
try {
await XReaction();
let target = m.mentionedJid?.[0] || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.sender);
if (!bannedUsers[target]) return reply(`✅ @${target.split('@')[0]} tidak dalam status banned.`, { mentions: [target] });
let data = bannedUsers[target];
if (data.permanent) return reply(`🚫 @${target.split('@')[0]} dibanned PERMANEN!`, { mentions: [target] });
let sisa = data.expired - Date.now();
let hari = Math.floor(sisa / 86400000);
let jam = Math.floor((sisa % 86400000) / 3600000);
let menit = Math.floor((sisa % 3600000) / 60000);
reply(`⚠️ @${target.split('@')[0]} sedang dibanned!\n⏳ Sisa: ${hari} hari ${jam} jam ${menit} menit`, { mentions: [target] });
} catch (err) { reply('Error: ' + err.message); }
break;

case 'infogrup':
case 'cekgrup':
try {
await XReaction();
if (!m.isGroup) return reply('❌ Perintah ini khusus grup!');
let meta = await Alice.groupMetadata(m.chat);
let members = await Alice.groupMetadata(m.chat);
let totalAdmin = members.participants.filter(p => p.admin).length;
let totalMember = members.participants.length;
let botIsAdmin = members.participants.some(p => p.id === botNumber && p.admin);
let caption = `📊 INFO GRUP\n\n`;
caption += `📛 Nama: ${meta.subject}\n`;
caption += `🆔 ID: ${m.chat}\n`;
caption += `👥 Member: ${totalMember} orang\n`;
caption += `👑 Admin: ${totalAdmin} orang\n`;
caption += `🤖 Bot Admin: ${botIsAdmin ? '✅ Ya' : '❌ Tidak'}\n`;
caption += `🔒 Status: ${meta.announce ? 'Tertutup' : 'Terbuka'}\n`;
caption += `📝 Edit info: ${meta.locked ? 'Terkunci' : 'Terbuka'}\n`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'infobroadcast':
case 'cekinfo':
try {
await XReaction();
let caption = `📢 INFO BROADCAST & UPDATE\n\n`;
caption += `📌 Untuk mendapatkan info terbaru tentang bot:\n`;
caption += `🔹 Join Channel: ${global.channel || 'Tidak tersedia'}\n`;
caption += `🔹 Grup Update: ${global.groupbot || 'Tidak tersedia'}\n`;
caption += `🔹 Testimoni: ${global.chtesti || 'Tidak tersedia'}\n\n`;
caption += `💡 Tips:\n`;
caption += `• Gunakan ${prefix}report untuk lapor bug\n`;
caption += `• Gunakan ${prefix}req untuk request fitur\n`;
caption += `• Gunakan ${prefix}fiturnew lihat fitur terbaru`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'infoserver':
case 'serverstat':
if (!isOwner) return XRO();
try {
let cpuLoad = os.loadavg();
let memFree = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
let memTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
let disk = fs.statSync('./');
let diskFree = (disk.blocks * disk.blksize / 1024 / 1024 / 1024).toFixed(2);
let caption = `🖥️ INFO SERVER\n\n`;
caption += `💻 Hostname: ${os.hostname()}\n`;
caption += `🐧 OS: ${os.type()} ${os.release()}\n`;
caption += `🧠 CPU: ${os.cpus()[0].model} (${os.cpus().length} core)\n`;
caption += `📊 Load: ${cpuLoad[0].toFixed(2)}, ${cpuLoad[1].toFixed(2)}, ${cpuLoad[2].toFixed(2)}\n`;
caption += `💾 RAM: ${memFree} / ${memTotal} GB (${((1 - memFree/memTotal)*100).toFixed(1)}%)\n`;
caption += `💿 Disk Free: ${diskFree} GB\n`;
caption += `⏱️ Uptime: ${runtime(os.uptime())}`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'linkchannel':
case 'channellink':
try {
await XReaction();
let caption = `📢 LINK CHANNEL & GRUP\n\n`;
caption += `🔗 Channel Utama:\n${global.channel || 'Tidak tersedia'}\n\n`;
caption += `🔗 Grup Update:\n${global.groupbot || 'Tidak tersedia'}\n\n`;
caption += `🔗 Grup Testimoni:\n${global.chtesti || 'Tidak tersedia'}\n\n`;
caption += `📱 Owner: wa.me/${global.owner[0] || 'Tidak tersedia'}\n`;
caption += `📨 Telegram: ${global.sosialmedia?.telegram || 'Tidak tersedia'}`;
reply(caption);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'register':
try {
let userReg = ensureUser(m.sender);
if (userReg.registered) return reply('❌ Kamu sudah terdaftar');
let splitReg = text.includes('|') ? '|' : ',';
let [nameReg, ageReg] = text.split(splitReg);
if (!nameReg || !ageReg) return reply('Format:\n.register nama|umur\natau\n.register nama,umur');
userReg.name = nameReg.trim();
userReg.age = parseInt(ageReg.trim());
userReg.registered = true;
userReg.regTime = Date.now();
let waktuReg = new Date(userReg.regTime).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
reply(`✅ Berhasil daftar!\nNama: ${userReg.name}\nUmur: ${userReg.age}\nRegister: ${waktuReg}`);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'unregister':
try {
let userUnreg = ensureUser(m.sender);
if (!userUnreg.registered) return reply('❌ Kamu belum daftar');
userUnreg.registered = false;
userUnreg.name = '';
userUnreg.age = 0;
reply('✅ Berhasil unregister');
} catch (err) { reply('Error: ' + err.message); }
break;

case 'narrate':
try {
if (!text) return reply('Masukkan teks narasi yang ingin dibacakan.\n\nContoh:\nnarrate Dunia ini dulunya dipenuhi keajaiban...');
let ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=id&client=tw-ob`;
await Alice.sendMessage(m.chat, { audio: { url: ttsUrl }, mimetype: 'audio/mp4', ptt: true, contextInfo: { externalAdreply: { title: `🎙️ Narasi Suara Aktif`, body: `📜 ${text.length > 40 ? text.slice(0, 40) + '...' : text}`, mediaType: 2, thumbnailUrl: thumb, sourceUrl: global.sosialmedia.telegram } } }, { quoted: m });
} catch (err) { reply('Error: ' + err.message); }
break;

case 'mood':
try {
let teksMood = args.join(" ");
if (!teksMood && m.quoted?.text) teksMood = m.quoted.text;
if (!teksMood) return reply("Ketik sesuatu atau reply chat seseorang untuk mendeteksi mood-nya!");
let moodList = [
{ keyword: ['bosan', 'gabut', 'jenuh', 'bete'], mood: 'Bosan 😐', saran: 'Coba cari hiburan ringan.' },
{ keyword: ['sedih', 'kecewa', 'hampa', 'patah', 'menangis', 'nangis'], mood: 'Sedih 😢', saran: 'Nggak apa-apa kok merasa sedih.' },
{ keyword: ['senang', 'bahagia', 'hepi', 'gembira', 'ceria'], mood: 'Bahagia 😊', saran: 'Wah seru! Bagi semangatnya dong.' },
{ keyword: ['marah', 'kesal', 'emosi', 'ngamuk'], mood: 'Marah 😠', saran: 'Tarik napas dulu ya.' },
{ keyword: ['malas', 'mager', 'ngantuk'], mood: 'Lelah 😴', saran: 'Kayaknya butuh recharge.' },
{ keyword: ['semangat', 'motivasi', 'on fire'], mood: 'Termotivasi 🔥', saran: 'Waktunya action!' },
{ keyword: ['takut', 'cemas', 'khawatir', 'panik'], mood: 'Cemas 😟', saran: 'Tenang, kamu nggak sendiri.' },
{ keyword: ['rindu', 'kangen'], mood: 'Rindu 💔', saran: 'Kadang rindu memang berat.' },
{ keyword: ['jatuh cinta', 'sayang', 'baper', 'geer'], mood: 'Jatuh Cinta 💘', saran: 'Aduh manis banget~' }
];
teksMood = teksMood.toLowerCase();
let hasil = moodList.find(m => m.keyword.some(k => teksMood.includes(k)));
if (!hasil) return reply(`Mood kamu agak sulit ditebak 😅`);
reply(`✨ Deteksi Mood: ${hasil.mood}\n\n💬 Kamu nulis: ${teksMood}\n📌 Saran: ${hasil.saran}`);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'cekprem':
try {
const premPath = './AliceDatabase/system-db/premium.json';
if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, '[]');
const premium = JSON.parse(fs.readFileSync(premPath));
const userprem = m.sender.replace(/[^0-9]/g, '');
const now = Math.floor(Date.now() / 1000);
function formatSisaWaktu(seconds) {
const days = Math.floor(seconds / 86400);
seconds %= 86400;
const hours = Math.floor(seconds / 3600);
seconds %= 3600;
const minutes = Math.floor(seconds / 60);
return `${days} hari, ${hours} jam, ${minutes} menit`;
}
const data = premium.find(v => v.id === userprem);
if (!data) return reply(`❌ Kamu belum menjadi user premium.`);
if (data.expired === 0) return reply(`👑 Kamu adalah User Premium Selamanya 🥳`);
if (data.expired < now) return reply(`⚠️ Status premium sudah expired sejak ${new Date(data.expired * 1000).toLocaleString('id-ID')}`);
const sisa = data.expired - now;
const tanggal = new Date(data.expired * 1000).toLocaleString('id-ID');
reply(`👑 Kamu adalah User Premium\n\n📅 Expired: ${tanggal}\n⏳ Sisa: ${formatSisaWaktu(sisa)}`);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'req':
try {
await XReaction();
if (!text) return reply(`Contoh: .req fitur play`);
let teksReq = `📢 REQ FITUR\n\n👤 Versi: ${version}\n💬 Fitur: ${text}\n📅 Waktu: ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })}`;
await Alice.sendMessage(global.owner, { text: teksReq, mentions: [m.sender] }, { quoted: m });
reply('✅ sudah dikirim ke owner. Terima kasih!');
} catch (err) { reply('Error: ' + err.message); }
break;

case 'addf':
if (!isOwner) return XRO();
try {
await XReaction();
if (!text) return reply(`Contoh: .addf fitur play`);
let teksAdd = `📢 FITUR BARU\n\n👤 Versi: ${version}\n💬 Fitur: ${text}\n📅 Waktu: ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })}`;
await Alice.sendMessage("120363402419927276@g.us", { text: teksAdd, mentions: [m.sender] }, { quoted: m });
reply('✅ sudah dikirim ke group update.');
} catch (err) { reply('Error: ' + err.message); }
break;

case 'fix':
if (!isOwner) return XRO();
try {
await XReaction();
if (!text) return reply(`Contoh: .fix fitur play`);
let teksFix = `📢 FIX FITUR\n\n👤 Versi: ${version}\n💬 Fitur: ${text}\n📅 Waktu: ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })}`;
await Alice.sendMessage("120363402419927276@g.us", { text: teksFix, mentions: [m.sender] }, { quoted: m });
reply('✅ sudah dikirim ke group update.');
} catch (err) { reply('Error: ' + err.message); }
break;

case 'rvo':
case 'readvo':
case 'readviewonce':
try {
await XReaction();
const msgVo = m.quoted;
if (!msgVo) return reply('⚠️ Harap reply ke pesan media view once.');
let typeVo = msgVo.mtype;
if (typeVo === 'viewOnceMessageV2' || typeVo === 'viewOnceMessage') {
const innerVo = msgVo.msg || msgVo.message;
if (innerVo?.imageMessage) { typeVo = 'imageMessage'; msgVo.msg = innerVo; }
else if (innerVo?.videoMessage) { typeVo = 'videoMessage'; msgVo.msg = innerVo; }
else if (innerVo?.audioMessage) { typeVo = 'audioMessage'; msgVo.msg = innerVo; }
}
const kindVo = typeVo === 'imageMessage' ? 'image' : typeVo === 'videoMessage' ? 'video' : typeVo === 'audioMessage' ? 'audio' : null;
if (!kindVo) return reply('❌ Jenis pesan tidak didukung.');
const formatBytesVo = (n) => { if (!n && n !== 0) return '-'; const units = ['B','KB','MB','GB']; let i=0, v=Number(n); while(v>=1024 && i<units.length-1){ v/=1024; i++; } return `${v.toFixed(v>=10?0:1)} ${units[i]}`; };
let groupLineVo = 'Private Chat';
try { if (m.isGroup) { let metaVo = await Alice.groupMetadata(m.chat); groupLineVo = `${metaVo.subject} (${metaVo.participants?.length||0} member)`; } } catch(e) {}
const senderNameVo = msgVo?.pushName || m?.pushName || '-';
const baseVo = (kindVo === 'image' ? msgVo?.msg?.imageMessage : kindVo === 'video' ? msgVo?.msg?.videoMessage : msgVo?.msg?.audioMessage) || {};
const streamVo = await downloadContentFromMessage(msgVo, kindVo);
let bufferVo = Buffer.from([]);
for await (const chunk of streamVo) bufferVo = Buffer.concat([bufferVo, chunk]);
let captionVo = `🔒 ViewOnce\n\nType: ${kindVo.toUpperCase()}\nDari: ${senderNameVo}\nAsal: ${groupLineVo}\nUkuran: ${formatBytesVo(baseVo.fileLength)}`;
if (kindVo === 'image') await Alice.sendMessage(m.chat, { image: bufferVo, caption: captionVo }, { quoted: m });
else if (kindVo === 'video') await Alice.sendMessage(m.chat, { video: bufferVo, caption: captionVo }, { quoted: m });
else if (kindVo === 'audio') await Alice.sendMessage(m.chat, { audio: bufferVo, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
reply(`✅ ${kindVo.toUpperCase()} view once berhasil diproses.`);
} catch (err) { reply('❌ Gagal memproses media.'); }
break;

case 'rvo2':
case 'readvo2':
case 'readviewonce2':
try {
await XReaction();
const msgVo2 = m.quoted;
if (!msgVo2) return reply('⚠️ Harap reply ke pesan media view once.');
const typeVo2 = msgVo2.mtype;
const kindVo2 = typeVo2 === 'imageMessage' ? 'image' : typeVo2 === 'videoMessage' ? 'video' : typeVo2 === 'audioMessage' ? 'audio' : null;
if (!kindVo2) return reply('❌ Jenis pesan tidak didukung.');
let groupLineVo2 = 'Private Chat';
try { if (m.isGroup) { let metaVo2 = await Alice.groupMetadata(m.chat); groupLineVo2 = `${metaVo2.subject} (${metaVo2.participants?.length||0} member)`; } } catch(e) {}
const senderNameVo2 = msgVo2?.pushName || m?.pushName || '-';
const targetJidVo2 = (m?.sender || m?.key?.participant || m?.chat || '').replace(/:[0-9]+@/, '@');
const streamVo2 = await downloadContentFromMessage(msgVo2, kindVo2);
let bufferVo2 = Buffer.from([]);
for await (const chunk of streamVo2) bufferVo2 = Buffer.concat([bufferVo2, chunk]);
let captionVo2 = `🔒 ViewOnce V2\n\nType: ${kindVo2.toUpperCase()}\nDari: ${senderNameVo2}\nAsal: ${groupLineVo2}`;
if (kindVo2 === 'image') await Alice.sendMessage(targetJidVo2, { image: bufferVo2, caption: captionVo2 });
else if (kindVo2 === 'video') await Alice.sendMessage(targetJidVo2, { video: bufferVo2, caption: captionVo2 });
else if (kindVo2 === 'audio') { await Alice.sendMessage(targetJidVo2, { audio: bufferVo2, mimetype: 'audio/mpeg', ptt: true }); await Alice.sendMessage(targetJidVo2, { text: captionVo2 }); }
await reply(`✅ ${kindVo2.toUpperCase()} view once dikirim ke chat pribadi.`);
} catch (err) { reply('❌ Gagal memproses media.'); }
break;

case 'q':
case 'quoted':
if (!m.quoted) return reply('Reply dulu pesannya!');
try {
if (typeof q === 'string' && q.trim().length > 0) await Alice.copyNForward(m.chat, m.quoted, true, { quoted: m });
else {
let targetQ = m.quoted;
while (targetQ && targetQ.quoted) targetQ = targetQ.quoted;
await Alice.copyNForward(m.chat, targetQ || m.quoted, true, { quoted: m });
}
} catch (err) { reply('Format Tidak Tersedia!'); }
break;

case "listhadiah":
if (!isOwner) return XRO();
try {
if (db.data.settings.hadiah.length < 1) return reply("Tidak ada code hadiah");
var tek = `*乂 LIST CODE HADIAH*\n\nTotal: ${db.data.settings.hadiah.length}\n\n`;
db.data.settings.hadiah.forEach((e) => { tek += `◦ ${e}\n`; });
reply(tek);
} catch (err) { reply('Error: ' + err.message); }
break;

case "redeemcode":
try {
await XReaction();
if (!args[0]) return reply("Masukkan code!");
if (args[0] !== args[0].toLowerCase()) return reply("Code wajib huruf kecil!");
if (db.data.settings.hadiahkadaluwarsa.includes(args[0])) return reply("Code sudah digunakan!");
if (!db.data.settings.hadiah.includes(args[0])) return reply("Code tidak valid!");
db.data.settings.hadiahkadaluwarsa.push(args[0]);
let idxCode = db.data.settings.hadiah.indexOf(args[0]);
db.data.settings.hadiah.splice(idxCode, 1);
let h1 = Math.floor(Math.random() * (20 - 10 + 1)) + 10;
if (!db.data.users[m.sender]) db.data.users[m.sender] = { limit: 0 };
db.data.users[m.sender].limit += h1;
reply(`Selamat! Kamu mendapatkan ${h1} Limit dari code "${args[0]}"`);
} catch (err) { reply('Error: ' + err.message); }
break;

case "buathadiah":
if (!isOwner) return XRO();
try {
if (isNaN(args[0])) return reply('Masukkan jumlah code!');
for (let i = 0; i < Number(args[0]); i++) db.data.settings.hadiah.push(crypto.randomBytes(4).toString("hex"));
let teks = '\n';
db.data.settings.hadiah.forEach((e) => { teks += `◦ ${e}\n`; });
reply(teks);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'tembak':
try {
await XReaction();
if (!m.isGroup) return XRG();
Alice.jadian = Alice.jadian || {};
let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : (text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'));
if (!text) return reply(`tag/reply seseorang, contoh: ${prefix + command} @628888`);
if (user === m.sender) return reply("gak bisa tembak diri sendiri");
if (user === botNumber) return reply("gak bisa tembak bot");
let pasanganUser = global.db.data.users[user] || {};
let pasanganSender = global.db.data.users[m.sender] || {};
let targetPacar = pasanganUser.pacar;
let myPacar = pasanganSender.pacar;
if (myPacar === user) return reply("itu pacar lu sendiri");
if (targetPacar) return reply(`udah punya pacar @${targetPacar.split("@")[0]}`);
if (myPacar) return reply(`lu udah punya pacar @${myPacar.split("@")[0]}`);
let kataNembak = ["cuma mau bilang, aku suka kamu. mau jadi pacarku?", "aku bukan siapa-siapa, tapi aku ingin jadi seseorang buat kamu.", "capek jadi temen, mau jadi pacar aja.", "aku jatuh cinta sama kamu, terima gak?"];
let pesanCinta = kataNembak[Math.floor(Math.random() * kataNembak.length)];
let teks = `💌 Love Message\n\n> @${m.sender.split("@")[0]} ❤️ @${user.split("@")[0]}\n\n"${pesanCinta}"`;
Alice.jadian[user] = [reply(teks), m.sender];
reply(`kamu mengajak @${user.split("@")[0]} jadian\n\n@${user.split("@")[0]} ketik:\n${prefix}terima atau ${prefix}tolak`);
} catch (err) { reply('Error: ' + err.message); }
break;

case 'terima':
try {
await XReaction();
if (!m.isGroup) return XRG();
if (Alice.jadian[m.sender]) {
let user = Alice.jadian[m.sender][1];
global.db.data.users[user].pacar = m.sender;
global.db.data.users[m.sender].pacar = user;
reply(`horeee\n\n${m.sender.split("@")[0]} jadian dengan\n❤️ ${user.split("@")[0]}\n\nsemoga langgeng 🙈😋`);
delete Alice.jadian[m.sender];
} else reply("anjirr?");
} catch (err) { reply('Error: ' + err.message); }
break;

case 'tolak':
try {
await XReaction();
if (!m.isGroup) return XRG();
if (Alice.jadian[m.sender]) {
let user = Alice.jadian[m.sender][1];
reply(`@${user.split("@")[0]} wowkaowka di tolak`);
delete Alice.jadian[m.sender];
} else reply("anjirr?");
} catch (err) { reply('Error: ' + err.message); }
break;

case 'putus':
try {
await XReaction();
if (!m.isGroup) return XRG();
let pasangan = global.db.data.users[m.sender].pacar;
if (pasangan) {
global.db.data.users[m.sender].pacar = "";
global.db.data.users[pasangan].pacar = "";
reply(`horeee kamu putus sama @${pasangan.split("@")[0]}`);
} else reply("anjirr?");
} catch (err) { reply('Error: ' + err.message); }
break;

case 'cekpacar':
try {
await XReaction();
if (!m.isGroup) return XRG();
let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : "");
if (!user) return reply(`tag/reply seseorang, contoh: ${prefix + command} @628888`);
let pasangan = global.db.data.users[user].pacar;
if (pasangan) reply(`@${user.split("@")[0]} udah ❤️ sama @${pasangan.split("@")[0]}`);
else reply(`@${user.split("@")[0]} masih jomblo`);
} catch (err) { reply(`Error: ${err.message}`); }
break;

case 'gsmarena':
try {
await XReaction();
if (args.length === 0) return reply('Masukkan nama perangkat.');
const response = await axios.get(`https://gsmarena.com/results.php3?sQuickSearch=yes&sName=${q}`);
const $ = cheerio.load(response.data);
let results = [];
$(".makers").find("li").each((i, e) => {
let img = $(e).find("img");
results.push({
id: $(e).find("a").attr("href").replace(".php", ""),
name: $(e).find("span").html().split("<br>").join(" "),
description: img.attr("title")
});
});
if (results.length === 0) return reply('Tidak ditemukan.');
let replyText = `Hasil untuk "${q}":\n\n`;
results.forEach((d, i) => { replyText += `${i+1}. ${d.name}\nDeskripsi: ${d.description}\nLink: https://gsmarena.com/${d.id}.php\n\n`; });
reply(replyText);
} catch (err) { reply('Error saat mencari.'); }
break;

case 'jarak':
case 'rute':
case 'cekjarak':
case 'cekrute':
try {
    await XReaction();
    if (!text.includes('|')) return reply(`Example: ${prefix + command} jakarta|bandung`);
    
    let [from, to] = text.split('|').map(v => v.trim());
    
    const result = await hitungJarak(from, to);
    
    let msg = `📍 Informasi Jarak\n\n`;
    msg += `🚗 Dari: ${result.dari.nama}\n`;
    msg += `📍 Ke: ${result.ke.nama}\n`;
    msg += `📏 Jarak: ${result.jarak}\n`;
    msg += `⏳ Estimasi Waktu:\n`;
    msg += `   • Motor: ${result.estimasi_waktu.motor}\n`;
    msg += `   • Mobil: ${result.estimasi_waktu.mobil}\n`;
    msg += `   • Jalan Kaki: ${result.estimasi_waktu.jalan_kaki}\n`;
    msg += `\n📍 Koordinat:\n`;
    msg += `   • ${result.dari.nama}: ${result.dari.koordinat.lat}, ${result.dari.koordinat.lon}\n`;
    msg += `   • ${result.ke.nama}: ${result.ke.koordinat.lat}, ${result.ke.koordinat.lon}\n`;
    msg += `\n🗺️ Maps URL: https://www.google.com/maps/dir/${result.dari.koordinat.lat},${result.dari.koordinat.lon}/${result.ke.koordinat.lat},${result.ke.koordinat.lon}`;
    
    reply(msg);
} catch (err) { 
    reply(`Terjadi kesalahan: ${err.message}`); 
}
break

case 'getpic':
case 'getpp':
try {
await XReaction();
const defaultAvatar = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
let targetNumber = null;
if (q) targetNumber = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
else if (m.mentionedJid && m.mentionedJid[0]) targetNumber = m.mentionedJid[0];
else if (mentionByreply) targetNumber = mentionByreply;
else targetNumber = m.sender;
try { var ppWong = await Alice.profilePictureUrl(targetNumber, 'image'); }
catch { var ppWong = defaultAvatar; }
await Alice.sendMessage(m.chat, { image: { url: ppWong }, caption: 'Success!!' }, { quoted: m });
} catch (err) { reply('Error: ' + err.message); }
break;

case 'getppgc':
try {
await XReaction();
if (!m.isGroup) return;
try { var ppimg = await Alice.profilePictureUrl(m.chat, 'image'); }
catch { var ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'; }
await Alice.sendMessage(m.chat, { image: { url: ppimg } }, { quoted: m });
} catch (err) { reply('Error: ' + err.message); }
break;

case 'totalfitur':
try {
await XReaction();
const aliceFile = fs.readFileSync(__filename, 'utf8');
const common = (aliceFile.match(/case\s+['"`]/g) || []).length;
const pluginDir = path.join(__dirname, './AlicePlugins');
const pluginFiles = fs.readdirSync(pluginDir).filter(v => v.endsWith('.js'));
let totalPluginCommands = 0;
for (let file of pluginFiles) {
try {
const fileContent = fs.readFileSync(path.join(pluginDir, file), 'utf8');
const handlerMatch = fileContent.match(/handler\.command\s*=\s*\[(.*?)\]/s);
if (handlerMatch) totalPluginCommands += (handlerMatch[1].match(/['"`]([^'"`]+)['"`]/g) || []).length;
else totalPluginCommands += (fileContent.match(/case\s+['"`]/g) || []).length;
} catch(e) {}
}
reply(`📊 Statistik Fitur Bot\n\nCase JS = ${common}\nPlugins JS = ${totalPluginCommands}\nTotal Fitur = ${common + totalPluginCommands}`);
} catch (err) { reply('Gagal membaca statistik fitur'); }
break;
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
// Batas All Case
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\

//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
default:
}
if (budy.startsWith('!')) {
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}
 
if (budy.startsWith('=>')) {
if (!isOwner) return false
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isOwner) return false
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))}}
if (budy.startsWith('$')) {
if(!isOwner) return false
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)})}

if (m.chat.endsWith('@s.whatsapp.net')) {
this.menfes = this.menfes ? this.menfes : {}
let room = Object.values(this.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'CHATTING')
if (room) {
if (/^.*(next|leave|start)/.test(budy)) return
if (['.next', '.leave', '.stop', '.start', 'Cari Partner', 'Keluar', 'Lanjut', 'Stop'].includes(budy)) return
find = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
let other = find.a == m.sender ? find.b : find.a
await m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
participant: other
}} : {})
}}

if (m.chat.endsWith('@s.whatsapp.net')) {
this.anonymous = this.anonymous ? this.anonymous : {}
let room = Object.values(this.anonymous).find(room => [room.a, room.b].includes(m.sender) && room.state === 'CHATTING')
if (room) {
if (/^.*(start|leave|next)/.test(m.text)) return
if (['.start','.leave','.next','.mulai','.keluar','.lanjut','.skip'].includes(m.text)) return
let other = [room.a, room.b].find(user => user !== m.sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}}:{})
}
return !0
}

} catch (e) {

    let ownerName = global.ownername || "Tidak diketahui"
    let waOwner =
      (global.owner && global.owner[0]) ||
      global.sosialmedia?.whatsapp ||
      "Tidak diketahui"
    let tgOwner =
      global.sosialmedia?.telegram ||
      "Tidak diketahui"

    const waktu = moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')

    sendToTelegram(
      `❌ ERROR SYSTEM\n` +
      `━━━━━━━━━━━━━━\n` +
      `• Waktu      : ${waktu}\n` +
      `• Command    : ${command || "unknown"}\n` +
      `━━━━━━━━━━━━━━\n` +
      `• Owner Name : ${ownerName}\n` +
      `• Owner WA   : ${waOwner}\n` +
      `• Owner TG   : ${tgOwner}\n` +
      `━━━━━━━━━━━━━━\n` +
      `• Error Msg  :\n${e.message || e}\n` +
      `━━━━━━━━━━━━━━`
    )

    console.log("====== ERROR DETAIL ======")
    console.log("Command :", command)
    console.log("Time    :", waktu)
    console.log(util.format(e))
    console.log(e.stack)
    console.log("====== END ERROR ======")

}
}

setInterval(async () => {
  ;
  const sewaPath = './AliceDatabase/users-db/sewa.json';
  if (!fs.existsSync(sewaPath)) return;
  const sewa = JSON.parse(fs.readFileSync(sewaPath));
  const now = Math.floor(Date.now() / 1000);

  for (let groupId in sewa) {
    const { expired } = sewa[groupId];
    if (expired !== 0 && expired < now) {
      try {
        await Alice.sendMessage(groupId, { text: '⚠️ Masa sewa bot telah *berakhir*. Bot akan keluar dari grup.\n\nHubungi owner untuk perpanjangan.' });
        await Alice.groupLeave(groupId);
      } catch (err) {
        console.log(`[SEWA] Gagal keluar dari ${groupId}:`, err);
      }
      delete sewa[groupId];
    }
  }

  fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2));
}, 60 * 1000);

//————————————————————————//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Succes Update : '${__filename}'`))
	delete require.cache[file]
	require(file)
})

// Credit : XyrooRynzz
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\
//📈————————————————————— [ © XyrooRynzz ] —————————————————————📉\\