/*
Alice Assistant
© XyrooRynzz 2022 - 2026

Telegram : t.me/whiterascalls
Gmail    : xyroorynzz@gmail.com
Github   : github.com/xyroorynzz

Tiktok   : https://www.tiktok.com/@xyroorynzz
Youtube  : https://youtube.com/@xyroorynzzz
Channel  : https://whatsapp.com/channel/0029Vb7M7jAIXnlhLZxpWT3K

Read readme.md before editing script
*/


const fs = require('fs')
const chalk = require('chalk')

// ========== SYSTEM ==========
global.prefa = ['', '.']
global.usePairingCode = true

// ========== OWNER ==========
global.ownername = 'XyrooRynzz'
global.owner = ["1(343)9021634"]

// ========== THUMBNAIL ==========
global.thumb = "https://aliceecdn.vercel.app/storage/image-033189.jpg"
global.thumbnailReply = "https://aliceecdn.vercel.app/storage/image-687d7c.jpg"

// ========== STICKER ==========
global.packname = 'ᴘowᴇʀᴇᴅ ʙʏ ᴀʟιcᴇ ᴀsιsтᴇɴт ɢᴇɴ 2 🤖'
global.author = '© XyrooRynzz'

// ========== BOT ==========
global.AliceBot = '6283193149397'
global.pairing = 'ALICEEXK'
global.botname = 'Alice Asistent'
global.version = 'GEN 2 V1.0.0'
global.alicewait = "🕐"
global.alicedone = "㊗️"
global.freelimit = 40
global.lz2 = '😂'
global.emojipickx = '┌  ◦ '
global.emojipick = '│  ◦ '
global.emojipickxx = '╰─────────────────────>'
global.runon = 'Panel'
global.baileys = 'whiskeysockets/baileys'
global.tgroup = 'https://t.me/xyroopb2'
global.licevoice = 'https://files.catbox.moe/wpd978.mp3'
global.soundcool = 'https://files.catbox.moe/lrmym6.mp3'
global.gmail = 'xyroorynzz@gmail.com'
global.web = 'https://aliceecdn.vercel.app'
global.telegramBotToken = "8470329127:AAGRjm8WWJyfWnwHhr10Za-Qs-73TZsiGdg"
global.telegramOwnerId = "7750303215"

// ========== SOURCE URL ==========
global.groupbot = "https://chat.whatsapp.com/Btowo9u9VKOLFX0jbOL5Kp"
global.idgroup = "120363420856716977@g.us"
global.idch = "120363402357934798@newsletter"
global.idchtesti = "120363331578871714@newsletter"
global.channel = "https://whatsapp.com/channel/0029Vb7M7jAIXnlhLZxpWT3K"
global.chtesti = "https://whatsapp.com/channel/0029VbCPMN0EwEjxku2D2N18"

// ========== LIMIT ==========
global.limitawal = {
    free: 20,
    premium: 999,
    owner: 999
}

// ========== APIKEY ==========
global.api = {
    alice: 'aliceezuberg',
    velyn: 'xyroorynzz',
    xtermai: 'aliceegen2'
}

// ========== SOSIAL MEDIA ==========
global.sosialmedia = {
    telegram: 'https://t.me/whiterascalls',
    whatsapp: 'https://wa.me/1(343)9021634',
    instagram: 'https://www.instagram.com/xyroorynzz_',
    youtube: 'https://youtube.com/@xyroorynzzz',
    tiktok: 'https://tiktok.com/@xyroorynzz'
}

// ========== PAYMENT ==========
global.payment = {
    qris: 'http://aliceecdn.vercel.app/file/6abeeb6ebe.jpg',
    qris_an: 'XYROORYNZZ STORE',
    dana: '085774293594',
    dana_an: 'WIN****',
    gopay: '085135441066',
    gopay_an: 'WIN****'
}

// ========== ORKUT ==========
global.orkut = {
    username: "",
    token: "",
    id: "",
    codeqr: ''
}

// ========== TOGGLE (true/false) ==========
global.autoswview = true
global.autobio = false
global.anticall = true
global.setwelcome = true
global.antibot = true

// ========== API PANEL PTERODACTYL ==========
global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "https://"
global.apikeyplta = ""
global.capikey = ""

// ========== HOT RELOAD ==========
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`file updated successfully : '${__filename}'`))
    delete require.cache[file]
    require(file)
})