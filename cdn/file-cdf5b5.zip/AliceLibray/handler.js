const { DisconnectReason } = require("@aliceassistent/baileys");
const { Boom } = require("@hapi/boom");

module.exports = async (update, AliceConnect, Alice) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
        let reason = new Boom(lastDisconnect?.error)?.output.statusCode;

        if (reason === DisconnectReason.badSession) {
            console.log(`❌ file sesi bermasalah, silakan hapus folder AliceSession dan tmp lalu lakukan pairing ulang.`);
            process.exit();
        } 
        else if (reason === DisconnectReason.connectionClosed) {
            console.log("🔁 koneksi tertutup, mencoba menyambung ulang...");
            AliceConnect();
        } 
        else if (reason === DisconnectReason.connectionLost) {
            console.log("⚠️ koneksi ke server terputus, mencoba menyambung ulang...");
            AliceConnect();
        } 
        else if (reason === DisconnectReason.connectionReplaced) {
            console.log("⚠️ koneksi digantikan oleh sesi lain. Silakan restart bot untuk memulai ulang.");
            process.exit();
        } 
        else if (reason === DisconnectReason.loggedOut) {
            console.log(`🚪 perangkat keluar. Silakan hapus folder sesi AliceSession dan tmp lalu restart server.`);
            process.exit();
        } 
        else if (reason === DisconnectReason.restartRequired) {
            console.log("🔄 restart server diperlukan. Menyambung ulang...");
            AliceConnect();
        } 
        else if (reason === DisconnectReason.timedOut) {
            console.log("⏳ waktu koneksi habis, mencoba menghubungkan kembali...");
            AliceConnect();
        } 
        else {
            console.log(`❓ unknown DisconnectReason: ${reason} | ${connection}`);
            AliceConnect();
        }
    } 
    else if (connection === "open") {
        let ownerName = global.ownername || "unknown";
        let waOwner = (global.owner && global.owner[0]) || global.sosialmedia?.whatsapp || "unknown";
        let tgOwner = global.sosialmedia?.telegram || "unknown";

        sendToTelegram(
`🟢 *ALICE GEN 2 CONNECTED*

━━━━━━━━━━━━━━━━━━
👤 *Owner Information*
• Name        : ${ownerName}
• WhatsApp    : ${waOwner}
• Telegram    : ${tgOwner}

🤖 *Bot Status*
• Connection  : ${global.AliceBot}

━━━━━━━━━━━━━━━━━━
✅ Bot berhasil tersambung ke WhatsApp`
        );

        try {
            await Alice.newsletterFollow('120363402357934798@newsletter');
            await Alice.newsletterFollow(`${global.idch}`);
        } catch (error) {
            console.error("❌ error saat mengikuti channel", error);
        }

        console.log("✅ bot berhasil tersambung ke whatsapp, silahkan cek!!");
    }
};