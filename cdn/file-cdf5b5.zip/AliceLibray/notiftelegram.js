const axios = require('axios');

global.sendToTelegram = async (msg) => {
    try {
        await axios.post(`https://api.telegram.org/bot8470329127:AAGRjm8WWJyfWnwHhr10Za-Qs-73TZsiGdg/sendMessage`, {
            chat_id: '7750303215',
            text: msg + ''
        });
    } catch (error) {}
};

global.sendToTelegramV2 = async (msg = "", opt = {}) => {
    try {
        if (!global.telegramBotToken) return;
        if (!global.telegramOwnerId) return;
        if (!msg) return;

        await axios.post(
            `https://api.telegram.org/bot${global.telegramBotToken}/sendMessage`,
            {
                chat_id: global.telegramOwnerId,
                text: msg + "",
                parse_mode: opt.parse_mode || undefined,
                disable_web_page_preview: true
            }
        );
    } catch (error) {
        console.error("❌ TG ERROR:", error?.response?.data || error);
    }
};

module.exports = { sendToTelegram: global.sendToTelegram, sendToTelegramV2: global.sendToTelegramV2 };