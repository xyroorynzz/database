//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const fs = require('fs')
const { color } = require('./alice-function')
        
global.cpanelmenu = `
┌── •「 *ᴍᴇɴᴜ ᴄᴘᴀɴᴇʟ* 」
${global.emojipick}.cadp
${global.emojipick}.cpanel
${global.emojipick}.delpanel
${global.emojipick}.listusr
${global.emojipick}.listsrv
${global.emojipickxx}`

global.animemenu = `
┌── •「 *ᴍᴇɴᴜ ᴀɴɪᴍᴇ* 」
${global.emojipick}.waifu
${global.emojipick}.animeawoo
${global.emojipick}.animemegumin
${global.emojipick}.animeshinobu
${global.emojipick}.animehandhold
${global.emojipick}.animehighfive
${global.emojipick}.animecringe
${global.emojipick}.animedance
${global.emojipick}.animehappy
${global.emojipick}.animeglomp
${global.emojipick}.animesmug
${global.emojipick}.animeblush
${global.emojipick}.animewave
${global.emojipick}.animesmile
${global.emojipick}.animepoke
${global.emojipick}.animewink
${global.emojipick}.animebonk
${global.emojipick}.animebully
${global.emojipick}.animeyeet
${global.emojipick}.animebite
${global.emojipick}.animelick
${global.emojipick}.animekill
${global.emojipick}.animecry
${global.emojipick}.animewlp
${global.emojipick}.animekiss
${global.emojipick}.animehug
${global.emojipick}.animeneko
${global.emojipick}.animepat
${global.emojipick}.animeslap
${global.emojipick}.animecuddle
${global.emojipick}.animewaifu
${global.emojipick}.animenom
${global.emojipick}.animefoxgirl
${global.emojipick}.animetickle
${global.emojipick}.animegecg
${global.emojipick}.bluearchive
${global.emojipick}.komikusearch
${global.emojipick}.komikudetail
${global.emojipick}.otakudesu
${global.emojipick}.otakudesu-search
${global.emojipick}.otakudesu-detail
${global.emojipickxx}`

global.canvasmenu = `
┌── •「 *ᴍᴇɴᴜ ᴄᴀɴᴠᴀs* 」
${global.emojipick}.fakeff
${global.emojipick}.fakeml
${global.emojipick}.cspotify
${global.emojipick}.pakustad
${global.emojipick}.fakecall
${global.emojipick}.fakecallwa
${global.emojipick}.fakestory
${global.emojipick}.fakestory1
${global.emojipick}.fakestory2
${global.emojipick}.fakestory3
${global.emojipick}.fakestory4
${global.emojipickxx}`

global.pushmenu = `
┌── •「 *ᴍᴇɴᴜ ᴘᴜsʜ* 」
${global.emojipick}.jpm
${global.emojipick}.pushkontak
${global.emojipick}.pushkontak2
${global.emojipick}.savekontak
${global.emojipick}.savekontak2
${global.emojipick}.pushkontakbeton
${global.emojipickxx}`

global.stalkermenu = `
┌── •「 *ᴍᴇɴᴜ sᴛᴀʟᴋᴇʀ* 」
${global.emojipick}.mlstalk
${global.emojipick}.wastalk
${global.emojipick}.npmstalk
${global.emojipick}.githubstalk
${global.emojipick}.tiktokstalk
${global.emojipick}.instagramstalk
${global.emojipick}.youtubestalk
${global.emojipickxx}`

global.mainmenu = `
┌── •「 *📋 INFO BOT* 」
${global.emojipick}.infobot
${global.emojipick}.donasi
${global.emojipick}.sewa
${global.emojipick}.ownerinfo
${global.emojipick}.linkbot
${global.emojipick}.profile
${global.emojipick}.cekprem
${global.emojipick}.ceksewa
${global.emojipick}.ceklimit
${global.emojipick}.limitdaily
${global.emojipick}.topcmd
${global.emojipick}.totalfitur
${global.emojipick}.ping
${global.emojipick}.speed
${global.emojipick}.infoban
${global.emojipick}.infogrup
${global.emojipick}.cekinfo
${global.emojipick}.owner
${global.emojipick}.sc
${global.emojipick}.tqto
${global.emojipick}.fiturnew
${global.emojipick}.report
${global.emojipick}.req
${global.emojipick}.rvo
${global.emojipick}.rvo2
${global.emojipick}.jarak
${global.emojipick}.mood
${global.emojipick}.narrate
${global.emojipick}.register
${global.emojipick}.unregister
${global.emojipickxx}`

global.beritamenu = `
┌── •「 *ᴍᴇɴᴜ ʙᴇʀɪᴛᴀ* 」
${global.emojipick}.nasa
${global.emojipick}.inews
${global.emojipick}.detik
${global.emojipick}.cnbc
${global.emojipick}.cnn
${global.emojipick}.metrotv
${global.emojipick}.kontan
${global.emojipick}.liputan6
${global.emojipick}.indozone
${global.emojipick}.malaymail
${global.emojipick}.merdekanews
${global.emojipick}.vietnamnews
${global.emojipick}.cnn-detail
${global.emojipick}.vivagoal
${global.emojipick}.vivagoal-detail
${global.emojipick}.cnnindonesia
${global.emojipick}.cnnindonesia-detail
${global.emojipickxx}`

global.asupanmenu = `
┌── •「 *ᴍᴇɴᴜ ᴀsᴜᴘᴀɴ* 」
${global.emojipick}.chinese
${global.emojipick}.hijab
${global.emojipick}.indo
${global.emojipick}.japanese
${global.emojipick}.korean
${global.emojipick}.malay
${global.emojipick}.randomgirl
${global.emojipick}.randomboy
${global.emojipick}.thai
${global.emojipick}.vietnamese
${global.emojipick}.tiktokgirl
${global.emojipick}.tiktokghea
${global.emojipick}.tiktokbocil
${global.emojipick}.tiktoknukhty
${global.emojipick}.tiktoksantuy
${global.emojipick}.tiktokkayes
${global.emojipick}.tiktokpanrika
${global.emojipick}.tiktoknotnot
${global.emojipickxx}`

global.audiomenu = `
┌── •「 *ᴍᴇɴᴜ ᴀᴜᴅɪᴏ* 」
${global.emojipick}.bass
${global.emojipick}.blown
${global.emojipick}.deep
${global.emojipick}.earrape
${global.emojipick}.fast
${global.emojipick}.fat
${global.emojipick}.nightcore
${global.emojipick}.reverse
${global.emojipick}.robot
${global.emojipick}.slow
${global.emojipick}.smooth
${global.emojipick}.tupai
${global.emojipick}.tts
${global.emojipick}.ringtone
${global.emojipick}.voice-alice
${global.emojipick}.voice-michie
${global.emojipick}.voice-tokoh
${global.emojipick}.mangkane1-54
${global.emojipick}.music1-65
${global.emojipickxx}`

global.anonymousmenu = `
┌── •「 *ᴍᴇɴᴜ ᴀɴᴏɴʏᴍᴏᴜs* 」
${global.emojipick}.anonymous
${global.emojipick}.start
${global.emojipick}.mulai
${global.emojipick}.leave
${global.emojipick}.keluar
${global.emojipick}.next
${global.emojipick}.lanjut
${global.emojipick}.confess
${global.emojipick}.menfess
${global.emojipick}.balasmenfess
${global.emojipick}.tolakmenfess
${global.emojipick}.stopmenfess
${global.emojipickxx}`

global.aimenu = `
┌── •「 *ᴍᴇɴᴜ ᴀɪ* 」
${global.emojipick}.ai
${global.emojipick}.zerogpt
${global.emojipick}.chatai
${global.emojipick}.chatgpt
${global.emojipick}.claudeai
${global.emojipick}.veniceai
${global.emojipick}.conciseai
${global.emojipick}.gemini-ai
${global.emojipick}.llama-ai
${global.emojipick}.lumin-ai
${global.emojipick}.typli-ai
${global.emojipick}.poly-ai
${global.emojipick}.quantum-ai
${global.emojipick}.gptturbo
${global.emojipick}.chatevery-where
${global.emojipick}.gemini-pro
${global.emojipick}.gpt-4o
${global.emojipick}.allam-ai
${global.emojipick}.muslimai
${global.emojipick}.autoai
${global.emojipick}.turnitin
${global.emojipick}.cekai
${global.emojipickxx}`

global.storemenu = `
┌── •「 *ᴍᴇɴᴜ sᴛᴏʀᴇ 🛒* 」
${global.emojipick}.addproduk
${global.emojipick}.delproduk
${global.emojipick}.listproduk
${global.emojipick}.updateproduk
${global.emojipick}.restok
${global.emojipick}.diskon
${global.emojipick}.hapusdiskon
${global.emojipick}.addcart
${global.emojipick}.mycart
${global.emojipick}.delcart
${global.emojipick}.clearcart
${global.emojipick}.checkout
${global.emojipick}.confirm
${global.emojipick}.cancel
${global.emojipick}.payment
${global.emojipick}.setpayment
${global.emojipick}.pesananku
${global.emojipick}.myorder
${global.emojipick}.detailorder
${global.emojipick}.buatvoucher
${global.emojipick}.listvoucher
${global.emojipick}.pakai
${global.emojipick}.hapusvoucher
${global.emojipick}.adddigital
${global.emojipick}.listdigital
${global.emojipick}.hapusdigital
${global.emojipick}.review
${global.emojipick}.lihatreview
${global.emojipick}.hapusreview
${global.emojipick}.listreview
${global.emojipick}.tambah
${global.emojipick}.kurang
${global.emojipick}.kali
${global.emojipick}.bagi
${global.emojipick}.kalkulator
${global.emojipick}.buysewa
${global.emojipick}.buyprem
${global.emojipick}.status
${global.emojipick}.done
${global.emojipick}.selesai
${global.emojipick}.proses
${global.emojipick}.tunda
${global.emojipick}.batal
${global.emojipick}.cancel-tr
${global.emojipick}.batalkan
${global.emojipickxx}`

global.convertmenu = `
┌── •「 *ᴍᴇɴᴜ ᴄᴏɴᴠᴇʀᴛ 📍* 」
${global.emojipick}.hd
${global.emojipick}.attp
${global.emojipick}.attp2
${global.emojipick}.attp3
${global.emojipick}.attp4
${global.emojipick}.ttp
${global.emojipick}.ttp2
${global.emojipick}.ttp3
${global.emojipick}.ttp4
${global.emojipick}.ttp5
${global.emojipick}.temini
${global.emojipick}.sticker
${global.emojipick}.smeme
${global.emojipick}.wm
${global.emojipick}.qc
${global.emojipick}.iqc
${global.emojipick}.brat
${global.emojipick}.bratvideo
${global.emojipick}.tovn
${global.emojipick}.toaudio
${global.emojipick}.tomp3
${global.emojipick}.tomp4
${global.emojipick}.togift
${global.emojipick}.toptv
${global.emojipick}.torvo
${global.emojipick}.toimg
${global.emojipick}.tourl
${global.emojipick}.emojimix
${global.emojipick}.img2txt
${global.emojipick}.img2prompt
${global.emojipick}.diffusion
${global.emojipick}.morse
${global.emojipick}.quotesimg
${global.emojipick}.iphonechat
${global.emojipick}.faceblur
${global.emojipick}.short-cloudku
${global.emojipickxx}`

global.toolsmenu = `
┌── •「 *ᴛᴏᴏʟs 🔨* 」
${global.emojipick}.ocr
${global.emojipick}.kalkulator
${global.emojipick}.nulis
${global.emojipick}.get
${global.emojipick}.gtts2
${global.emojipick}.tts2
${global.emojipick}.gethtml
${global.emojipick}.phlogo
${global.emojipick}.translate
${global.emojipick}.resize
${global.emojipick}.html
${global.emojipick}.javascript
${global.emojipick}.python
${global.emojipick}.tocode
${global.emojipick}.txt2img
${global.emojipick}.img2img
${global.emojipick}.txt2anime
${global.emojipick}.txt2ghibli
${global.emojipick}.txt2pixel
${global.emojipick}.reactch
${global.emojipick}.getinfoch
${global.emojipick}.getinfogc
${global.emojipick}.ccgen
${global.emojipick}.shortlink
${global.emojipick}.sharetext
${global.emojipick}.codegen
${global.emojipick}.ceklinkgc
${global.emojipick}.removebg
${global.emojipick}.faketiktok
${global.emojipick}.texttonote
${global.emojipick}.getpb
${global.emojipick}.getgist
${global.emojipick}.npmjs
${global.emojipick}.skiplink
${global.emojipick}.getpastebin
${global.emojipick}.rekap
${global.emojipick}.playch
${global.emojipickxx}`

global.islamimenu = `
┌── •「 *ɪsʟᴀᴍɪ 🕌* 」
${global.emojipick}.doa
${global.emojipick}.kisahnabi
${global.emojipick}.asmaulhusna
${global.emojipick}.bacaansholat
${global.emojipick}.ayatkursi
${global.emojipick}.doaharian
${global.emojipick}.niatsholat
${global.emojipick}.quotesislami
${global.emojipick}.doatahlil
${global.emojipick}.artisurah
${global.emojipick}.dalamislam
${global.emojipick}.jadwalsholat
${global.emojipick}.tafsirsurah
${global.emojipick}.hadistid
${global.emojipick}.hadistdetail
${global.emojipick}.ayat
${global.emojipick}.murotal
${global.emojipickxx}`

global.downloadermenu = `
┌── •「 *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ 📌* 」
${global.emojipick}.fb
${global.emojipick}.aio
${global.emojipick}.ig
${global.emojipick}.cocofun
${global.emojipick}.twitterdl
${global.emojipick}.sfiledl
${global.emojipick}.gitclone
${global.emojipick}.mediafire
${global.emojipick}.capcut
${global.emojipick}.tiktok
${global.emojipick}.ytmp3
${global.emojipick}.ytmp4
${global.emojipick}.videy
${global.emojipick}.pindl
${global.emojipick}.apkdl
${global.emojipick}.playvid
${global.emojipick}.playvideo
${global.emojipick}.douyindl
${global.emojipick}.apkdetail
${global.emojipick}.samehadakudl
${global.emojipick}.samehadakudetail
${global.emojipick}.facebook
${global.emojipick}.shortlink-dl
${global.emojipick}.nontonanime-download
${global.emojipick}.nontonanime-detail
${global.emojipick}.resepdownload
${global.emojipick}.spotify-download
${global.emojipick}.soundcloud-download
${global.emojipick}.tiktokmp3
${global.emojipick}.telesticker
${global.emojipickxx}`

global.premiummenu = `
┌── •「 *ᴘʀᴇᴍɪᴜᴍ ⭐* 」
${global.emojipick}.nglspam
${global.emojipick}.enc
${global.emojipick}.reminder
${global.emojipick}.ssweb
${global.emojipick}.hdvid
${global.emojipick}.infogempa
${global.emojipick}.threads
${global.emojipick}.threadsimg
${global.emojipick}.readmore
${global.emojipick}.xnxxsearch
${global.emojipick}.xnxxdl
${global.emojipick}.animediff
${global.emojipick}.dalle3
${global.emojipick}.img2video
${global.emojipick}.veo3
${global.emojipick}.gimg18+
${global.emojipick}.ultahku
${global.emojipick}.buatlagu
${global.emojipick}.deepfake
${global.emojipick}.tofigure
${global.emojipick}.toanime
${global.emojipick}.tochibi
${global.emojipick}.toghibli
${global.emojipick}.tojepang
${global.emojipick}.tohijab
${global.emojipick}.toblur
${global.emojipick}.tomirror
${global.emojipick}.topacar
${global.emojipick}.toreal
${global.emojipick}.totua
${global.emojipick}.totato
${global.emojipick}.tosexy
${global.emojipick}.tovintage
${global.emojipick}.tozombie
${global.emojipick}.hdvideo
${global.emojipick}.text2img
${global.emojipick}.text2anime
${global.emojipick}.text2pixel
${global.emojipick}.text2ghibli
${global.emojipick}.telanjangin
${global.emojipick}.removeclothes
${global.emojipick}.editfoto
${global.emojipick}.nanobanana
${global.emojipickxx}`

global.searchmenu = `
┌── •「 *sᴇᴀʀᴄʜ 🔎* 」
${global.emojipick}.sbook
${global.emojipick}.jkt48
${global.emojipick}.weather
${global.emojipick}.cerpen
${global.emojipick}.gsmarena
${global.emojipick}.play
${global.emojipick}.playap
${global.emojipick}.pin
${global.emojipick}.yts
${global.emojipick}.ttsearch
${global.emojipick}.cekhp
${global.emojipick}.gimage
${global.emojipick}.bingimg
${global.emojipick}.infoanime
${global.emojipick}.zerochan
${global.emojipick}.liriklagu
${global.emojipick}.caribuku
${global.emojipick}.playstore
${global.emojipick}.wikimedia
${global.emojipick}.ffw
${global.emojipick}.spotify
${global.emojipick}.yahooimg
${global.emojipick}.cuaca
${global.emojipick}.kuronime
${global.emojipick}.myanimelist
${global.emojipick}.animexin
${global.emojipick}.resepsearch
${global.emojipick}.jkt48news
${global.emojipick}.alkitab
${global.emojipick}.jadwaltv
${global.emojipick}.hentais
${global.emojipick}.apksearch
${global.emojipick}.searchduoyin
${global.emojipick}.waktudunia
${global.emojipick}.vivadetail
${global.emojipick}.jadwalbola
${global.emojipick}.douyinsearch
${global.emojipick}.spotify-search
${global.emojipick}.google-search
${global.emojipick}.movie-search
${global.emojipick}.sticker-search
${global.emojipick}.komiku-search
${global.emojipick}.soundcloud-search
${global.emojipick}.soundcloud-play
${global.emojipick}.samehadakusearch
${global.emojipick}.nontonanime-search
${global.emojipick}.nontonanime-upcoming
${global.emojipick}.nontonanime-latest
${global.emojipick}.whatmusic
${global.emojipick}.ptv
${global.emojipickxx}`

global.ephotomenu = `
┌── •「 *ᴇᴘʜᴏᴛᴏ 📸* 」
${global.emojipick}.cecankorea
${global.emojipick}.glitchtext
${global.emojipick}.writetext
${global.emojipick}.advancedglow
${global.emojipick}.typographytext
${global.emojipick}.pixelglitch
${global.emojipick}.neonglitch
${global.emojipick}.flagtext
${global.emojipick}.flag3dtext
${global.emojipick}.deletingtext
${global.emojipick}.blackpinkstyle
${global.emojipick}.glowingtext
${global.emojipick}.underwatertext
${global.emojipick}.logomaker
${global.emojipick}.cartoonstyle
${global.emojipick}.papercutstyle
${global.emojipick}.watercolortext
${global.emojipick}.effectclouds
${global.emojipick}.blackpinklogo
${global.emojipick}.gradienttext
${global.emojipick}.summerbeach
${global.emojipick}.luxurygold
${global.emojipick}.multicoloredneon
${global.emojipick}.sandsummer
${global.emojipick}.galaxywallpaper
${global.emojipick}.1917style
${global.emojipick}.makingneon
${global.emojipick}.royaltext
${global.emojipick}.freecreate
${global.emojipick}.galaxystyle
${global.emojipick}.lighteffects
${global.emojipickxx}`

global.randommenu = `
┌── •「 *ʀᴀɴᴅᴏᴍ 🖇* 」
${global.emojipick}.faktaunik
${global.emojipick}.quotesbucin
${global.emojipick}.quotesjawa
${global.emojipick}.quotesanime
${global.emojipick}.quotes
${global.emojipick}.darkjokes
${global.emojipick}.meme
${global.emojipick}.kataanime
${global.emojipick}.neko
${global.emojipick}.shinobu
${global.emojipick}.hubble
${global.emojipick}.hijab
${global.emojipick}.indo
${global.emojipick}.japanese
${global.emojipick}.korean
${global.emojipick}.malay
${global.emojipick}.randomgirl
${global.emojipick}.randomboy
${global.emojipick}.thai
${global.emojipick}.vietnamese
${global.emojipick}.aesthetic
${global.emojipick}.chinese
${global.emojipick}.pubg
${global.emojipick}.antiwork
${global.emojipick}.blackpink2
${global.emojipick}.cosplay
${global.emojipick}.cat
${global.emojipick}.doggo
${global.emojipick}.justina
${global.emojipick}.kayes
${global.emojipick}.bike
${global.emojipick}.boneka
${global.emojipick}.kpop
${global.emojipick}.notnot
${global.emojipick}.car
${global.emojipick}.rose
${global.emojipick}.ryujin
${global.emojipick}.ulzangboy
${global.emojipick}.ulzanggirl
${global.emojipick}.mobilelegend
${global.emojipick}.animequote
${global.emojipick}.handsomecheck
${global.emojipick}.stupidcheck
${global.emojipick}.uncleancheck
${global.emojipick}.hotcheck
${global.emojipick}.smartcheck
${global.emojipick}.greatcheck
${global.emojipick}.evilcheck
${global.emojipick}.dogcheck
${global.emojipick}.coolcheck
${global.emojipick}.waifucheck
${global.emojipick}.awesomecheck
${global.emojipick}.gaycheck
${global.emojipick}.cutecheck
${global.emojipick}.lesbiancheck
${global.emojipick}.hornycheck
${global.emojipick}.prettycheck
${global.emojipick}.lovelycheck
${global.emojipick}.uglycheck
${global.emojipickxx}`

global.groupmenu = `
┌── •「 *GROUP* 」
${global.emojipick}.acc
${global.emojipick}.add
${global.emojipick}.kick
${global.emojipick}.tolakacc
${global.emojipick}.linkgc
${global.emojipick}.hidetag
${global.emojipick}.afk
${global.emojipick}.opentime
${global.emojipick}.closetime
${global.emojipick}.gc
${global.emojipick}.absen
${global.emojipick}.listabsen
${global.emojipick}.tagall
${global.emojipick}.delete
${global.emojipick}.editsubjek
${global.emojipick}.editdesk
${global.emojipick}.editinfo
${global.emojipick}.promote
${global.emojipick}.demote
${global.emojipick}.addbadwords
${global.emojipick}.delbadwords
${global.emojipick}.addlist
${global.emojipick}.dellist
${global.emojipick}.updatelist
${global.emojipick}.list
${global.emojipick}.getpp
${global.emojipick}.getppgc
${global.emojipick}.tagme
${global.emojipick}.warn
${global.emojipick}.delwarn
${global.emojipick}.reswarn
${global.emojipick}.setwarn
${global.emojipick}.warninfo
${global.emojipick}.cekasalmember
${global.emojipick}.spamtag
${global.emojipick}.stopspam
${global.emojipick}.totalchat
${global.emojipick}.totalpesan
${global.emojipick}.antilink
${global.emojipick}.kickall
${global.emojipick}.addallback
${global.emojipick}.kicklog
${global.emojipick}.clearkicklog
${global.emojipick}.welcome on/off
${global.emojipick}.left on/off
${global.emojipick}.setwelcome
${global.emojipick}.setleft
${global.emojipick}.swgroup
${global.emojipick}.onlyadmin
${global.emojipick}.listadmin
${global.emojipick}.antivideo
${global.emojipick}.antiimage
${global.emojipick}.antitagsw
${global.emojipick}.statusgroup
${global.emojipickxx}`

global.primbonmenu = `
┌── •「 *ᴘʀɪᴍʙᴏɴ ✉️* 」
${global.emojipick}.artimimpi
${global.emojipick}.artinama
${global.emojipick}.ramaljodoh
${global.emojipick}.ramaljodohbali
${global.emojipick}.suamiistri
${global.emojipick}.ramalcinta
${global.emojipick}.cocoknama
${global.emojipick}.pasangan
${global.emojipick}.jadiannikah
${global.emojipick}.sifatusaha
${global.emojipick}.rezeki
${global.emojipick}.pekerjaan
${global.emojipick}.nasib
${global.emojipick}.penyakit
${global.emojipick}.tarot
${global.emojipick}.fengshui
${global.emojipick}.haribaik
${global.emojipick}.harisangar
${global.emojipick}.harisial
${global.emojipick}.nagahari
${global.emojipick}.arahrezeki
${global.emojipick}.peruntungan
${global.emojipick}.weton
${global.emojipick}.karakter
${global.emojipick}.keberuntungan
${global.emojipick}.memancing
${global.emojipick}.masasubur
${global.emojipick}.cekumur
${global.emojipick}.zodiak
${global.emojipick}.shio
${global.emojipick}.cocokweton
${global.emojipick}.wataklahir
${global.emojipick}.arahhoki
${global.emojipick}.warnakeberuntungan
${global.emojipick}.batuhoki
${global.emojipick}.tglnikah
${global.emojipick}.nomborshio
${global.emojipick}.pasanganideal
${global.emojipick}.kariersukses
${global.emojipick}.kesehatanprediksi
${global.emojipick}.bisnisusaha
${global.emojipick}.pendidikanjalan
${global.emojipick}.perjalananhidup
${global.emojipick}.cocokbisnis
${global.emojipick}.rumahtangga
${global.emojipick}.keuanganmasa
${global.emojipick}.batulahir
${global.emojipick}.haritinggal
${global.emojipick}.ramalancintabulan
${global.emojipick}.nasibtahun
${global.emojipick}.primbonjodoh2
${global.emojipick}.tanggalbaik
${global.emojipick}.harilarangan
${global.emojipick}.waktubahagia
${global.emojipick}.elemenalam
${global.emojipick}.binatangtotem
${global.emojipick}.warnaaura
${global.emojipick}.angkagaib
${global.emojipick}.ramalanrezeki
${global.emojipick}.karirmasadepan
${global.emojipick}.cintasejati
${global.emojipick}.umurpanjang
${global.emojipick}.haribagus
${global.emojipick}.jamkeberuntungan
${global.emojipick}.tanggaljadian
${global.emojipick}.ramalanrumah
${global.emojipick}.ramalankendaraan
${global.emojipick}.ramalanhewanpeliharaan
${global.emojipick}.ramalantanaman
${global.emojipick}.ramalanliburan
${global.emojipick}.ramalanolahraga
${global.emojipick}.ramalanmakanan
${global.emojipick}.ramalanminuman
${global.emojipick}.ramalanmusik
${global.emojipick}.ramalanfilm
${global.emojipick}.ramalanbuku
${global.emojipick}.ramalangayabelajar
${global.emojipick}.ramalantidur
${global.emojipick}.ramalanmimpi
${global.emojipick}.ramalanjodohweton
${global.emojipick}.ramalananak
${global.emojipick}.ramalansaudara
${global.emojipick}.ramalanorangtua
${global.emojipick}.ramalanpasanganbaru
${global.emojipick}.ramalanstatus
${global.emojipick}.ramalanuang
${global.emojipick}.ramalanhutang
${global.emojipick}.ramalaninvestasi
${global.emojipick}.ramalanbisnisonline
${global.emojipick}.ramalanbaranghilang
${global.emojipick}.ramalanperjalanan
${global.emojipick}.ramalanwawancara
${global.emojipick}.ramalanpromosi
${global.emojipick}.ramalangaji
${global.emojipick}.ramalankosong
${global.emojipick}.ramalanumur
${global.emojipick}.ramalanpenyakitturun
${global.emojipick}.ramalanalergi
${global.emojipick}.ramalanobat
${global.emojipick}.ramalandiet
${global.emojipick}.ramalanolahragadiri
${global.emojipick}.ramalanmeditasi
${global.emojipick}.ramalanhariraya
${global.emojipick}.ramalanpindahan
${global.emojipick}.ramalantanamanhias
${global.emojipick}.ramalanwarnabaju
${global.emojipick}.ramalanwarnasepatu
${global.emojipick}.ramalanwarnatopi
${global.emojipick}.ramalanaksesoris
${global.emojipick}.ramalanparfum
${global.emojipick}.ramalanpakaian
${global.emojipickxx}`

global.ownermenu = `
┌── •「 OWNER TOOLS 」
${global.emojipick}.setbot
${global.emojipick}.uptesti
${global.emojipick}.restart
${global.emojipick}.shutdown

MANAGE USERS & ACCESS
${global.emojipick}.ban
${global.emojipick}.unban
${global.emojipick}.listban
${global.emojipick}.cekban
${global.emojipick}.addprem
${global.emojipick}.delprem
${global.emojipick}.listprem
${global.emojipick}.addowner
${global.emojipick}.delowner
${global.emojipick}.listregister
${global.emojipick}.clearregister
${global.emojipick}.clearuser
${global.emojipick}.regmode

PLUGIN CONTROL
${global.emojipick}.addplugins
${global.emojipick}.delplugins
${global.emojipick}.editplugins
${global.emojipick}.getplugins
${global.emojipick}.listplugins
${global.emojipick}.totalplugins
${global.emojipick}.sendplug
${global.emojipick}.listscraper
${global.emojipick}.getscraper
${global.emojipick}.addscraper
${global.emojipick}.dellscraper
${global.emojipick}.runscraper
${global.emojipick}.scrapeinfo
${global.emojipick}.reloadscraper
${global.emojipick}.testscraper
${global.emojipick}.uploadscraper
${global.emojipick}.recodescraper
${global.emojipick}.addlimit
${global.emojipick}.dellimit
${global.emojipick}.tflimit
${global.emojipick}.limitmode
${global.emojipick}.reloadcase
${global.emojipick}.reloadbot
${global.emojipick}.infoupdate
${global.emojipick}.jpmswgc
${global.emojipick}.renamebot
${global.emojipick}.listrenamebot
${global.emojipick}.reloadplugins
${global.emojipick}.renameplugins
${global.emojipick}.installthema
${global.emojipick}.installpanel
${global.emojipick}.installwings
${global.emojipick}.backup
${global.emojipick}.sendsc
${global.emojipick}.upload
${global.emojipick}.getfile
${global.emojipick}.delfilemanager
${global.emojipick}.editfile
${global.emojipick}.createfolder
${global.emojipick}.getfolder
${global.emojipick}.delfolder
${global.emojipick}.listfolder

FILE & CASE MANAGER
${global.emojipick}.addfile
${global.emojipick}.delfile
${global.emojipick}.addfolder
${global.emojipick}.delfolder
${global.emojipick}.addcase
${global.emojipick}.editcase
${global.emojipick}.delcase
${global.emojipick}.listcase
${global.emojipick}.sendfitur
${global.emojipick}.setstc
${global.emojipick}.delstc
${global.emojipick}.liststc

CONTROL SESI & BIOMETRIK
${global.emojipick}.getsession
${global.emojipick}.delsession
${global.emojipick}.autobio
${global.emojipick}.autoread
${global.emojipick}.autotyping
${global.emojipick}.autorecord

SETTING & CONFIG
${global.emojipick}.setprefix
${global.emojipick}.setimgmenu
${global.emojipick}.setppbot
${global.emojipick}.setpppanjang
${global.emojipick}.onlygc
${global.emojipick}.anticall
${global.emojipick}.groupattack
${global.emojipick}.kickall
${global.emojipick}.altag
${global.emojipick}.setreply
${global.emojipick}.setmenu
${global.emojipick}.setpayment
${global.emojipick}.autoaiset

UPDATE & LOGS
${global.emojipick}.addchangelog
${global.emojipick}.delchangelog
${global.emojipick}.changelog
${global.emojipick}.upch-audio
${global.emojipick}.upsw
${global.emojipick}.listerror
${global.emojipick}.cekerror
${global.emojipick}.clearerror
${global.emojipick}.listrespon
${global.emojipick}.delrespon
${global.emojipick}.addrespon
${global.emojipick}.botstats

PANEL & FUNCTION
${global.emojipick}.addfunction
${global.emojipick}.delfunction
${global.emojipick}.getfunction
${global.emojipick}.kudetpanel

CURL & SCRAPE
${global.emojipick}.addscrape
${global.emojipick}.dellscrape
${global.emojipick}.getscrape

LIMIT & RESTORE
${global.emojipick}.addlimit
${global.emojipick}.dellimit
${global.emojipick}.resetlimit

SEWA MANAGER
${global.emojipick}.addpsewa
${global.emojipick}.delsewa
${global.emojipick}.listsewa
${global.emojipick}.bangroup
${global.emojipick}.out
${global.emojipick}.ptvch
${global.emojipick}.sendptv
${global.emojipick}.p2
${global.emojipickxx}`

global.gamemenu = `
┌── •「 GAME 」
${global.emojipick}.dadu
${global.emojipick}.judibola
${global.emojipick}.werewolf
${global.emojipick}.listhadiah
${global.emojipick}.buathadiah
${global.emojipick}.redeemcode
${global.emojipick}.suitbot
${global.emojipick}.patroli
${global.emojipick}.tebakld
${global.emojipick}.gaple
${global.emojipick}.truthordare
${global.emojipick}.susunkata
${global.emojipick}.asahotak

— TEBAK GAME
${global.emojipick}.tebaklagu
${global.emojipick}.tebakkata
${global.emojipick}.tebakpresiden
${global.emojipick}.tebakhewan
${global.emojipick}.tebakbenda

— UNO GAME
${global.emojipick}.uno
${global.emojipick}.uno info
${global.emojipick}.uno join
${global.emojipick}.uno start
${global.emojipick}.uno stop
${global.emojipick}.uno hand
${global.emojipick}.uno card
${global.emojipick}.uno play
${global.emojipick}.uno pass
${global.emojipick}.uno color

— GAPLE GAME
${global.emojipick}.gaple
${global.emojipick}.gaple join
${global.emojipick}.gaple start
${global.emojipick}.gaple info
${global.emojipick}.gaple hand
${global.emojipick}.gaple play
${global.emojipick}.gaple draw
${global.emojipick}.gaple pass
${global.emojipick}.gaple stop

— CRYPTO
${global.emojipick}.crypto price
${global.emojipick}.crypto buy
${global.emojipick}.crypto sell
${global.emojipick}.crypto portfolio
${global.emojipick}.crypto alert
${global.emojipick}.crypto watchlist
${global.emojipick}.crypto watchadd
${global.emojipick}.crypto watchdel

— CLAN GAME
${global.emojipick}.clan create
${global.emojipick}.clan join
${global.emojipick}.clan approve
${global.emojipick}.clan war
${global.emojipick}.clan list
${global.emojipick}.clan leave
${global.emojipick}.clan delete
${global.emojipick}.clan member
${global.emojipick}.clan missions
${global.emojipick}.clan task
${global.emojipick}.clan upgrade
${global.emojipick}.clan tournament

— CATUR GAME
${global.emojipick}.catur@tag
${global.emojipick}.caturstatus
${global.emojipick}.caturskip
${global.emojipick}.caturdraw
${global.emojipick}.caturmenyerah
${global.emojipick}.caturhapus
${global.emojipick}.caturnilai
${global.emojipick}.caturrank
${global.emojipick}.caturtop10
${global.emojipick}.caturskorreset
${global.emojipick}.caturnext
${global.emojipick}.caturboard
${global.emojipick}.caturhistory
${global.emojipick}.caturanalisa
${global.emojipick}.caturtimer
${global.emojipick}.caturnotif
${global.emojipick}.caturhelp

— GENSHIN GAME
${global.emojipick}.gens-characters
${global.emojipick}.gens-advrank
${global.emojipick}.gens-animals
${global.emojipick}.gens-area
${global.emojipick}.gens-giartifact
${global.emojipick}.gens-giconstellation
${global.emojipick}.gens-craft
${global.emojipick}.gens-domain
${global.emojipick}.gens-emoji
${global.emojipick}.gens-enemy
${global.emojipick}.gens-food
${global.emojipick}.gens-materials
${global.emojipick}.gens-namacard
${global.emojipick}.gens-nation
${global.emojipick}.gens-outfit
${global.emojipick}.gens-potion
${global.emojipick}.gens-talents
${global.emojipick}.gens-viewpoint
${global.emojipick}.gens-voiceovers
${global.emojipick}.gens-weapons
${global.emojipick}.gens-wildlife

— KOBOY
${global.emojipick}.koboy help
${global.emojipick}.koboy helprole
${global.emojipick}.koboy daftar
${global.emojipick}.koboy status
${global.emojipick}.koboy kerja
${global.emojipick}.koboy tembak @
${global.emojipick}.koboy beli [item]
${global.emojipick}.koboy jual [item]
${global.emojipick}.koboy skill
${global.emojipick}.koboy wanted
${global.emojipick}.koboy top
${global.emojipick}.koboy level
${global.emojipick}.koboy leveltop
${global.emojipick}.koboy topkoboy
${global.emojipick}.koboy peran
${global.emojipick}.koboy tangkap @
${global.emojipick}.koboy lepas @
${global.emojipick}.koboy hukum @
${global.emojipick}.koboy misi
${global.emojipick}.koboy kirim [item] @
${global.emojipick}.koboy rank
${global.emojipick}.koboy kota
${global.emojipick}.koboy kota bank
${global.emojipick}.koboy kota saloon
${global.emojipick}.koboy kota toko
${global.emojipick}.koboy kota penjara
${global.emojipick}.koboy kota sheriff
${global.emojipick}.koboy setor [jumlah]
${global.emojipick}.koboy tarik [jumlah]
${global.emojipick}.koboy cekstok
${global.emojipick}.koboy rampok @
${global.emojipick}.koboy equip [item]
${global.emojipick}.koboy daily
${global.emojipick}.koboy minum
${global.emojipick}.koboy kerja_berani
${global.emojipick}.koboy invest [jumlah]
${global.emojipick}.koboy cair
${global.emojipick}.koboy tebak [1-5]
${global.emojipickxx}`

global.rpgmenu = `
┌── •「 *ʀᴘɢ ᴍᴇɴᴜ* 」
${global.emojipick}.rpgregister - Daftar akun RPG
${global.emojipick}.my - Lihat profil
${global.emojipick}.inspect - Lihat profil pemain lain
${global.emojipick}.resetrpg - Reset data RPG
${global.emojipick}.hunt - Berburu monster
${global.emojipick}.boss - Lawan bos
${global.emojipick}.arena - Arena PVP
${global.emojipick}.adventure - Berpetualang
${global.emojipick}.dungeon - Masuk dungeon
${global.emojipick}.quest - Lihat quest
${global.emojipick}.quest claim - Klaim quest
${global.emojipick}.dailybonus - Bonus harian
${global.emojipick}.achievement - Lihat pencapaian
${global.emojipick}.claimach - Klaim pencapaian
${global.emojipick}.rankpvp - Ranking PVP
${global.emojipick}.train - Latihan
${global.emojipick}.heal - Istirahat
${global.emojipick}.rest - Istirahat panjang
${global.emojipick}.work - Bekerja
${global.emojipick}.mine - Menambang
${global.emojipick}.fish - Memancing
${global.emojipick}.craft - Craft item
${global.emojipick}.shop - Lihat toko
${global.emojipick}.beli - Beli item
${global.emojipick}.potion - Lihat potion
${global.emojipick}.potion beli - Beli potion
${global.emojipick}.inv - Lihat inventory
${global.emojipick}.use - Pakai item
${global.emojipick}.duel - Tantang duel
${global.emojipick}.accept - Terima duel
${global.emojipick}.reject - Tolak duel
${global.emojipick}.pvp - Tantang PVP
${global.emojipick}.pvpaccept - Terima PVP
${global.emojipick}.pvpreject - Tolak PVP
${global.emojipick}.trade - Trade gold
${global.emojipick}.tradeaccept - Terima trade
${global.emojipick}.tradereject - Tolak trade
${global.emojipick}.marry - Lamar
${global.emojipick}.marryaccept - Terima lamaran
${global.emojipick}.marryreject - Tolak lamaran
${global.emojipick}.divorce - Cerai
${global.emojipick}.pet - Peliharaan
${global.emojipick}.pet beli - Beli peliharaan
${global.emojipick}.pet makan - Beri makan peliharaan
${global.emojipick}.pet latih - Latih peliharaan
${global.emojipick}.upgrade - Upgrade equipment
${global.emojipick}.gamble - Judi
${global.emojipick}.steal - Curi gold
${global.emojipick}.leaderboard - Peringkat
${global.emojipick}.bank - Bank
${global.emojipick}.bank deposit - Simpan gold
${global.emojipick}.bank withdraw - Ambil gold
${global.emojipick}.bank interest - Bunga bank
${global.emojipick}.market - Pasar
${global.emojipick}.market jual - Jual di pasar
${global.emojipick}.market beli - Beli dari pasar
${global.emojipick}.roulette - Roulette
${global.emojipick}.lottery - Lottery
${global.emojipick}.lottery buy - Beli tiket lottery
${global.emojipick}.lottery draw - Undian lottery
${global.emojipick}.medic - Berobat
${global.emojipick}.gift - Kirim hadiah
${global.emojipick}.dailyreward - Hadiah harian
${global.emojipick}.skill - Skill
${global.emojipick}.skill upgrade - Upgrade skill
${global.emojipick}.party - Party
${global.emojipick}.party create - Buat party
${global.emojipick}.party join - Gabung party
${global.emojipick}.party leave - Keluar party
${global.emojipick}.party hunt - Berburu bersama
${global.emojipick}.transmute - Transmutasi
${global.emojipick}.dailycheck - Check-in harian
${global.emojipick}.hourly - Bonus setiap jam
${global.emojipick}.travel - Bepergian
${global.emojipick}.harvest - Panen
${global.emojipick}.lumberjack - Tebang pohon
${global.emojipick}.enchant - Enchant equipment
${global.emojipick}.durability - Cek durability
${global.emojipick}.repair - Repair
${global.emojipick}.repair weapon - Repair weapon
${global.emojipick}.repair armor - Repair armor
${global.emojipick}.repair all - Repair semua
${global.emojipick}.sell - Jual item
${global.emojipick}.money - Cek uang
${global.emojipick}.money pay - Transfer gold
${global.emojipick}.money loan - Pinjam uang
${global.emojipick}.money paydebt - Bayar hutang
${global.emojipick}.money rich - Ranking terkaya
${global.emojipick}.wood - Tebang kayu
${global.emojipick}.farm - Bertani
${global.emojipick}.cook - Memasak
${global.emojipick}.brew - Membuat minuman
${global.emojipick}.tailor - Membuat baju
${global.emojipick}.forge - Forge senjata
${global.emojipick}.alchemy - Alkimia
${global.emojipick}.recycle - Daur ulang
${global.emojipick}.tradingpost - Pos perdagangan
${global.emojipick}.vault - Penyimpanan
${global.emojipick}.weekly - Hadiah mingguan
${global.emojipick}.expedition - Ekspedisi
${global.emojipick}.title - Gelar
${global.emojipick}.stats - Statistik lengkap
${global.emojipick}.profilecard - Kartu profil
${global.emojipick}.prestige - Prestige
${global.emojipick}.bounty - Buronan
${global.emojipick}.duelrank - Ranking duel
${global.emojipick}.petrank - Ranking peliharaan
${global.emojipick}.guildrank - Ranking guild
${global.emojipick}.dailyhunt - Buruan hunt harian
${global.emojipick}.dailymine - Tambang harian
${global.emojipick}.dailyfish - Mancing harian
${global.emojipick}.blacksmith - Pandai besi
${global.emojipick}.library - Perpustakaan
${global.emojipick}.temple - Kuil
${global.emojipick}.tavern - Tavern
${global.emojipick}.guild - Guild
${global.emojipick}.jail - Penjara
${global.emojipick}.compass - Kompas quest
${global.emojipick}.questcomplete - Selesaikan quest
${global.emojipick}.upgradeitem - Upgrade item
${global.emojipick}.enchantitem - Enchant item
${global.emojipick}.sellfish - Jual ikan
${global.emojipick}.sellore - Jual bijih
${global.emojipick}.sellwood - Jual kayu
${global.emojipick}.sellcrop - Jual hasil tani
${global.emojipickxx}`

global.allmenu = `${global.cpanelmenu}\n
${global.pushmenu}\n
${global.stalkermenu}\n
${global.canvasmenu}\n
${global.beritamenu}\n
${global.audiomenu}\n
${global.anonymousmenu}\n
${global.storemenu}\n
${global.mainmenu}\n
${global.aimenu}\n
${global.convertmenu}\n
${global.toolsmenu}\n
${global.islamimenu}\n
${global.downloadermenu}\n
${global.premiummenu}\n
${global.searchmenu}\n
${global.ephotomenu}\n
${global.animemenu}\n
${global.randommenu}\n
${global.groupmenu}\n
${global.primbonmenu}\n
${global.ownermenu}\n
${global.gamemenu}\n
${global.rpgmenu}`


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})