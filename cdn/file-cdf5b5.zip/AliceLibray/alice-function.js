//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const { proto, getContentType, downloadContentFromMessage, areJidsSameUser, generateWAMessage } = require('@whiskeysockets/baileys')
const fs = require('fs')
const axios = require('axios')
const moment = require('moment-timezone')
const chalk = require('chalk')
const Jimp = require('jimp')
const { sizeFormatter } = require('human-readable')
const crypto = require('crypto')
const util = require('util')
const cheerio = require('cheerio')
const { fromBuffer } = require('file-type')
const FormData = require('form-data')
const child_process = require('child_process')
const { unlink } = require('fs').promises
const path = require('path')
const { Octokit } = require("@octokit/rest")
const { defaultMaxListeners } = require('stream')

const unixTimestampSeconds = (date = new Date()) => Math.floor(date.getTime() / 1000)
const sleepy = (ms) => new Promise(resolve => setTimeout(resolve, ms))

exports.unixTimestampSeconds = unixTimestampSeconds

exports.generateMessageTag = (epoch) => {
    let tag = unixTimestampSeconds().toString()
    if (epoch) tag += '.--' + epoch
    return tag
}

exports.processTime = (timestamp, now) => moment.duration(now - moment(timestamp * 1000)).asSeconds()

exports.runtime = (seconds) => {
    seconds = Number(seconds)
    const d = Math.floor(seconds / (3600 * 24))
    const h = Math.floor(seconds % (3600 * 24) / 3600)
    const m = Math.floor(seconds % 3600 / 60)
    const s = Math.floor(seconds % 60)
    return `${d > 0 ? d + (d == 1 ? " day, " : " days, ") : ""}${h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : ""}${m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : ""}${s} second${s != 1 ? 's' : ''}`
}

exports.clockString = (ms) => {
    const h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    const m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    const s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

exports.sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))
exports.delay = exports.sleep

exports.getTime = (format, date) => {
    if (date) return moment(date).locale('id').format(format)
    return moment.tz('Asia/Jakarta').locale('id').format(format)
}

exports.formatDate = (n, locale = 'id') => {
    const d = new Date(n)
    return d.toLocaleDateString(locale, {
        weekday: 'long', day: 'numeric', month: 'long',
        year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric'
    })
}

exports.tanggal = (numer) => {
    const myMonths = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    const myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum’at', 'Sabtu']
    const tgl = new Date(numer)
    return `${myDays[tgl.getDay()]}, ${tgl.getDate()} - ${myMonths[tgl.getMonth()]} - ${tgl.getYear() < 1000 ? tgl.getYear() + 1900 : tgl.getYear()}`
}

exports.getRandom = (ext) => `${Math.floor(Math.random() * 10000)}${ext}`

exports.makeid = (length) => {
    let result = ''
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    for (let i = 0; i < length; i++) result += chars.charAt(Math.floor(Math.random() * chars.length))
    return result
}

exports.randomString = (len, charSet) => {
    charSet = charSet || 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let str = ''
    for (let i = 0; i < len; i++) str += charSet.charAt(Math.floor(Math.random() * charSet.length))
    return str
}

exports.pickRandom = (list) => list[Math.floor(Math.random() * list.length)]

exports.randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min

exports.randomNumber = (min, max = null) => {
    if (max !== null) return Math.floor(Math.random() * (max - min + 1)) + min
    return Math.floor(Math.random() * min) + 1
}

exports.randomNomor = exports.randomNumber

exports.randomKarakter = (jumlah) => {
    const huruf = 'abcdefghijklmnopqrstuvwxyz'
    let hasil = ''
    for (let i = 0; i < jumlah; i++) {
        let h = huruf[Math.floor(Math.random() * huruf.length)]
        h = Math.random() < 0.5 ? h.toUpperCase() : h
        hasil += h
    }
    return hasil
}

exports.generateToken = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*'
    let token = ''
    for (let i = 0; i < 8; i++) token += chars.charAt(Math.floor(Math.random() * chars.length))
    return token
}

exports.generateAuthToken = (size) => crypto.randomBytes(size).toString('hex').slice(0, size)

exports.getHashedPassword = (password) => crypto.createHash('sha256').update(password).digest('base64')

exports.batasiTeks = (teks, batas) => teks.length <= batas ? teks : teks.substring(0, batas) + '...'

exports.randomText = (len) => {
    const pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'.split('')
    const result = []
    for (let i = 0; i < len; i++) result.push(pool[Math.floor(Math.random() * pool.length)])
    return result.join('')
}

exports.capital = (string) => string.charAt(0).toUpperCase() + string.slice(1)

exports.toIDR = async (x) => {
    x = x.toString()
    const pattern = /(-?\d+)(\d{3})/
    while (pattern.test(x)) x = x.replace(pattern, "$1.$2")
    return x
}

exports.isUrl = (url) => url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))

exports.isNumber = (number) => !isNaN(parseInt(number))

exports.isEmoji = (str) => /[\u{1F000}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u.test(str)

exports.getBuffer = async (url, options = {}) => {
    try {
        const res = await axios({ method: "get", url, ...options, responseType: 'arraybuffer' })
        return res.data
    } catch (err) { return err }
}

exports.fetchBuffer = exports.getBuffer
exports.getImg = exports.getBuffer

exports.fetchJson = async (url, options = {}) => {
    try {
        const res = await axios({ method: 'GET', url, ...options })
        return res.data
    } catch (err) { return err }
}

exports.fetchUrl = exports.fetchJson

exports.WAVersion = async () => {
    const get = await exports.fetchUrl("https://web.whatsapp.com/check-update?version=1&platform=web")
    return [get.currentVersion.replace(/[.]/g, ", ")]
}

exports.formatp = sizeFormatter({ std: 'JEDEC', decimalPlaces: 2, keepTrailingZeroes: false, render: (literal, symbol) => `${literal} ${symbol}B` })

exports.bytesToSize = (bytes, decimals = 2) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + ' ' + sizes[i]
}

exports.FileSize = (number) => {
    const postfixes = ["B", " KB", " MB", " GB", " TB", " PB", " EB"]
    const tier = Math.log10(Math.abs(number)) / 3 | 0
    if (tier == 0) return number
    const scaled = number / Math.pow(10, tier * 3)
    let formatted = scaled.toFixed(1)
    if (/\.0$/.test(formatted)) formatted = formatted.substr(0, formatted.length - 2)
    return formatted + postfixes[tier]
}

exports.getSizeMedia = async (path) => {
    if (/http/.test(path)) {
        const res = await axios.get(path)
        const length = parseInt(res.headers['content-length'])
        if (!isNaN(length)) return exports.bytesToSize(length, 3)
    } else if (Buffer.isBuffer(path)) {
        const length = Buffer.byteLength(path)
        if (!isNaN(length)) return exports.bytesToSize(length, 3)
    }
    return '0 Bytes'
}

exports.toRupiah = (angka) => {
    let saldo = ''
    const rev = angka.toString().split('').reverse().join('')
    for (let i = 0; i < rev.length; i++) if (i % 3 == 0) saldo += rev.substr(i, 3) + '.'
    return saldo.split('', saldo.length - 1).reverse().join('')
}

exports.toDolar = (rupiah) => {
    const dolar = rupiah / 15000
    const parts = dolar.toFixed(2).split('.')
    return '$' + parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + parts[1]
}

exports.formatNumber = (integer) => Number(parseInt(integer)).toLocaleString().replace(/,/g, '.')

exports.h2k = (integer) => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(parseInt(integer))

exports.json = (string) => JSON.stringify(string, null, 2)
exports.jsonformat = exports.json

exports.monospace = (string) => '```' + string + '```'

exports.color = (text, color) => chalk.keyword(color || 'green')(text)

exports.parseMention = (text = '') => [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')

exports.getGroupAdmins = (participants) => {
    const admins = []
    for (const i of participants) {
        if (i.admin === 'superadmin' || i.admin === 'admin') admins.push(i.id)
    }
    return admins
}

exports.generateProfilePicture = async (buffer) => {
    const jimp = await Jimp.read(buffer)
    const min = jimp.getWidth()
    const max = jimp.getHeight()
    const cropped = jimp.crop(0, 0, min, max)
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
        preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
    }
}

exports.reSize = async (buffer, width, height) => {
    const img = await Jimp.read(buffer)
    return await img.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
}

exports.resize = exports.reSize

exports.toHD = async (image) => {
    const read = await Jimp.read(image)
    const result = await read.resize(read.bitmap.width * 4, read.bitmap.height * 4).getBufferAsync(Jimp.MIME_JPEG)
    return result
}

exports.logic = (check, inp, out) => {
    if (inp.length !== out.length) throw new Error('Input and Output must have same length')
    for (const i in inp) if (util.isDeepStrictEqual(check, inp[i])) return out[i]
    return null
}

exports.sort = (property, ascending = true) => {
    if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
    return (...args) => args[ascending & 1] - args[!ascending & 1]
}

exports.TelegraPh = (Path) => new Promise(async (resolve, reject) => {
    if (!fs.existsSync(Path)) return reject(new Error("File not Found"))
    const form = new FormData()
    form.append("file", fs.createReadStream(Path))
    const data = await axios({ url: "https://telegra.ph/upload", method: "POST", headers: { ...form.getHeaders() }, data: form })
    resolve("https://telegra.ph" + data.data[0].src)
})

exports.GIFBufferToVideoBuffer = async (image) => {
    const filename = `${Math.random().toString(36)}`
    await fs.writeFileSync(`./tmp/${filename}.gif`, image)
    child_process.exec(`ffmpeg -i ./tmp/${filename}.gif -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ./tmp/${filename}.mp4`)
    await sleepy(4000)
    const buffer = await fs.readFileSync(`./tmp/${filename}.mp4`)
    await Promise.all([unlink(`./tmp/${filename}.mp4`), unlink(`./tmp/${filename}.gif`)])
    return buffer
}

exports.buffergif = exports.GIFBufferToVideoBuffer

exports.webp2mp4File = async (path) => {
    return new Promise((resolve, reject) => {
        const form = new FormData()
        form.append('new-image-url', '')
        form.append('new-image', fs.createReadStream(path))
        axios({ method: 'post', url: 'https://s6.ezgif.com/webp-to-mp4', data: form, headers: { 'Content-Type': `multipart/form-data; boundary=${form._boundary}` } })
            .then(({ data }) => {
                const bodyFormThen = new FormData()
                const $ = cheerio.load(data)
                const file = $('input[name="file"]').attr('value')
                bodyFormThen.append('file', file)
                bodyFormThen.append('convert', "Convert WebP to MP4!")
                axios({ method: 'post', url: 'https://ezgif.com/webp-to-mp4/' + file, data: bodyFormThen, headers: { 'Content-Type': `multipart/form-data; boundary=${bodyFormThen._boundary}` } })
                    .then(({ data }) => {
                        const $ = cheerio.load(data)
                        resolve('https:' + $('div#output > p.outfile > video > source').attr('src'))
                    }).catch(reject)
            }).catch(reject)
    })
}

exports.happymod = (query) => new Promise((resolve, reject) => {
    axios.get(`https://www.happymod.com/search.html?q=${query}`).then((tod) => {
        const $ = cheerio.load(tod.data)
        const hasil = []
        $("div.pdt-app-box").each((c, d) => {
            hasil.push({
                icon: $(d).find("img.lazy").attr('data-original'),
                name: $(d).find("a").text().trim(),
                link: `https://www.happymod.com${$(d).find("a").attr('href')}`
            })
        })
        resolve(hasil)
    }).catch(reject)
})

exports.readFileTxt = (file) => new Promise((resolve) => {
    const data = fs.readFileSync(file, 'utf8')
    const arr = data.toString().split('\n')
    resolve(arr[Math.floor(Math.random() * arr.length)].replace('\r', ''))
})

exports.readFileJson = (file) => new Promise((resolve) => {
    const json = JSON.parse(fs.readFileSync(file))
    resolve(json[Math.floor(Math.random() * json.length)])
})

exports.getTypeUrlMedia = async (url) => {
    const buffer = await axios.get(url, { responseType: 'arraybuffer' })
    const type = buffer.headers['content-type'] || (await fromBuffer(buffer.data)).mime
    return { type, url }
}

exports.getAllHTML = async (urls) => {
    const htmlArr = []
    for (const url of urls) htmlArr.push((await axios.get(url)).data)
    return htmlArr
}

exports.checkBandwidth = async () => {
    let ind = 0, out = 0
    for (const i of await require('node-os-utils').netstat.stats()) {
        ind += parseInt(i.inputBytes)
        out += parseInt(i.outputBytes)
    }
    return { download: exports.bytesToSize(ind), upload: exports.bytesToSize(out) }
}

exports.cekMenfes = (tag, nomer, db_menfes) => {
    let x1 = false
    Object.keys(db_menfes).forEach((i) => { if (db_menfes[i].id == nomer) x1 = i })
    if (x1 !== false) {
        if (tag == 'id') return db_menfes[x1].id
        if (tag == 'teman') return db_menfes[x1].teman
    }
    return null
}

exports.webApi = (a, b, c, d, e, f) => a + b + c + d + e + f

exports.nebal = (angka) => Math.floor(angka)

exports.syntaxFetch = async (ms) => "Chrome v20.0.04"

exports.getUserInput = (query) => {
    const rl = require('readline').createInterface({ input: process.stdin, output: process.stdout })
    return new Promise((resolve) => rl.question(query, resolve))
}

exports.question = (text) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout,
    })
    return new Promise((resolve) => {
        rl.question(text, resolve)
    })
}

exports.smsg = (conn, m, store) => {
    if (!m) return m
    const M = proto.WebMessageInfo

    if (m.key) {
        m.id = m.key.id
        m.isBaileys = m.id && (m.id.startsWith('BAE5') && m.id.length === 16) || (m.id && m.id.length === 22) || (m.id && m.id.startsWith('3EB0') && m.id.length === 22) || false
        m.chat = conn.decodeJid(m.key.remoteJid || m.message?.senderKeyDistributionMessage?.groupId || '')
        m.messageTimestamp = Math.floor(Date.now() / 1000)
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = m.isGroup ? conn.decodeJid(m.key?.participantAlt || m.key?.participant) : conn.decodeJid(m.key.remoteJid)
        m.fromMe = m.key.fromMe
        m.from = m.key.remoteJid
        if (m.isGroup) m.participant = conn.decodeJid(m.key.participant) || ''
    }

    if (m.message) {
        m.mtype = getContentType(m.message)
        m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype])
        m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == 'listResponseMessage' && m.msg.singleSelectReply?.selectedRowId) || (m.mtype == 'buttonsResponseMessage' && m.msg.selectedButtonId) || (m.mtype == 'viewOnceMessage' && m.msg.caption) || m.text

        const quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null
        m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []

        if (m.quoted) {
            let type = Object.keys(quoted)[0]
            m.quoted = quoted[type]
            if (type === 'productMessage') {
                type = Object.keys(m.quoted)[0]
                m.quoted = m.quoted[type]
            }
            if (typeof m.quoted === 'string') m.quoted = { text: m.quoted }

            m.quoted.mtype = type
            m.quoted.id = m.msg.contextInfo.stanzaId
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
            m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
            m.quoted.sender = conn.decodeJid(m.msg.contextInfo.participant)
            m.quoted.fromMe = m.quoted.sender === (conn.user && conn.user.id)
            m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
            m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []

            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false
                const q = await store.loadMessage(m.chat, m.quoted.id, conn)
                return exports.smsg(conn, q, store)
            }

            const vM = m.quoted.fakeObj = M.fromObject({
                key: { remoteJid: m.quoted.chat, fromMe: m.quoted.fromMe, id: m.quoted.id },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            })

            m.quoted.delete = () => conn.sendMessage(m.quoted.chat, { delete: vM.key })
            m.quoted.copyNForward = (jid, forceForward = false, options = {}) => conn.copyNForward(jid, vM, forceForward, options)
            m.quoted.download = () => conn.downloadMediaMessage(m.quoted)
        }
    }

    if (m.msg && m.msg.url) m.download = () => conn.downloadMediaMessage(m.msg)
    m.text = m.msg?.text || m.msg?.caption || m.message?.conversation || m.msg?.contentText || m.msg?.selectedDisplayText || m.msg?.title || ''
    m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? conn.sendMedia(chatId, text, 'file', '', m, { ...options }) : conn.sendText(chatId, text, m, { ...options })
    m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)))
    m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => conn.copyNForward(jid, m, forceForward, options)

    conn.appenTextMessage = async (text, chatUpdate) => {
        const messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, { userJid: conn.user.id, quoted: m.quoted && m.quoted.fakeObj })
        messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        const msg = { ...chatUpdate, messages: [proto.WebMessageInfo.fromObject(messages)], type: 'append' }
        conn.ev.emit('messages.upsert', msg)
    }

    return m
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    delete require.cache[file]
    require(file)
})