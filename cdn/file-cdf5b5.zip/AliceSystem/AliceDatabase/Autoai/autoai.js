/*
Alice Assistant
© XyrooRynzz 2022 - 2026

Telegram : t.me/whiterascalls
Gmail    : xyroorynzz@gmail.com
Github   : github.com/xyroorynzz

Tiktok   : https://www.tiktok.com/@xyroorynzz
Youtube  : https://youtube.com/@xyroorynzzz
Channel  : https://whatsapp.com/channel/0029Vb7M7jAIXnlhLZxpWT3K

Read readme.md before editing script
*/

const fs = require('fs')
const axios = require('axios')
const path = require("path")
const chalk = require('chalk')
const FormData = require('form-data')
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys")

const dbPath = './AliceSystem/AliceDatabase/Autoai/autoai.json'
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, "{}")
let db = JSON.parse(fs.readFileSync(dbPath))

function saveDb() {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}

const autoaiGroupFile = path.join(__dirname, 'autoai_group.json')
if (!fs.existsSync(autoaiGroupFile)) {
    fs.writeFileSync(autoaiGroupFile, JSON.stringify([], null, 2))
}

const getAutoAIGroup = () => JSON.parse(fs.readFileSync(autoaiGroupFile))
const saveAutoAIGroup = (data) => fs.writeFileSync(autoaiGroupFile, JSON.stringify(data, null, 2))

let bot = global.botname || 'Bot'
let own = global.ownername || 'Owner'

async function XReaction(Alice, m, waitEmoji = "🕐", doneEmoji = "✨") {
    try {
        await Alice.sendMessage(m.chat, { react: { text: waitEmoji, key: m.key } })
        await new Promise(r => setTimeout(r, 150))
        await Alice.sendMessage(m.chat, { react: { text: doneEmoji, key: m.key } })
    } catch (e) {
        console.log("ReactionErr:", e.message)
    }
}

function isReplyToBot(Alice, m) {
    try {
        let ctx = m.message?.extendedTextMessage?.contextInfo ||
                  m.message?.imageMessage?.contextInfo ||
                  m.message?.videoMessage?.contextInfo ||
                  m.message?.stickerMessage?.contextInfo ||
                  m.message?.audioMessage?.contextInfo ||
                  m.message?.documentMessage?.contextInfo

        if (!ctx) return false

        let botId = Alice.user.id.split(':')[0]
        let quoted = ctx.participant?.split(':')[0]

        if (quoted && quoted.includes(botId)) return true
        if (ctx?.remoteJid === Alice.user.id) return true

        return false
    } catch {
        return false
    }
}

function blockedCmd(t) {
    t = t.toLowerCase()

    const bad = [
        "rm -rf", "hapus sistem", "delete system", "format", "wipe",
        "shutdown", "restart server", "matikan server",
        "porn", "porno", "bokep", "bugil", "telanjang",
        "sex", "seks", "hentai", "anal", "bdsm",
        "fetish", "playboy", "payudara", "vagina",
        "penis", "testis", "masturbasi", "coli",
        "raba tubuh", "jilmek", "ngewe",
        "tete", "toket", "memek", "kontol",
        "nge nude", "nudes", "send nudes", "pap spicy",
        "ganti nama bot", "ubah nama bot",
        "ubah owner", "ganti owner",
        "hapus prompt", "hilangkan aturan",
        "abaikan aturan", "ignore rules",
        "reset personality", "ganti kepribadian"
    ]

    return bad.some(v => t.includes(v))
}

async function imageToDataUrl(buffer, mimeType) {
    const base64 = buffer.toString('base64')
    return `data:${mimeType};base64,${base64}`
}

async function gpt4o(prompt, imageDataUrl = null) {
    try {
        const content = []

        if (imageDataUrl) {
            content.push({
                type: "image_url",
                image_url: { url: imageDataUrl }
            })
        }

        content.push({ type: "text", text: prompt })

        const res = await axios.post(
            "https://api-faa.my.id/faa/gpt4o",
            { messages: [{ role: "user", content }] },
            { timeout: 60000 }
        )

        return res.data?.result || res.data?.data?.result || res.data?.response || "Hmm, aku belum nemu jawabannya"

    } catch (e) {
        console.log("GPT4O Error:", e.response?.data || e.message)
        return "maaf kak… AI lagi error 😔"
    }
}

async function askAI(text, m) {
    try {
        if (!text) return "maaf kak… teksnya kosong 😔"

        let url = `https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(text)}`
        let r = await axios.get(url, { timeout: 30000 })
        let j = r.data

        return j?.result || j?.data?.result || j?.response || "Hmm, aku belum nemu jawabannya"

    } catch (e) {
        console.log("FAA ERROR:", e.response?.data || e.message)
        return "maaf kak… ada gangguan jaringan 😔"
    }
}

const voiceMap = {
    [global.botname]: "bella",
    "michie": "michi_jkt48",
    "adam": "adam",
    "prabowo": "prabowo",
    "thomas_shelby": "thomas_shelby",
    "jokowi": "jokowi",
    "megawati": "megawati",
    "echilling": "echilling",
    "nokotan": "nokotan",
    "boboiboy": "boboiboy",
    "yanzgpt": "yanzgpt",
    "keqing": "keqing",
    "yanami_anna": "yanami_anna"
}

function detectVoice(text) {
    let t = text.toLowerCase()
    for (let name in voiceMap) {
        if (t.includes(name.toLowerCase())) return voiceMap[name]
    }
    return voiceMap[global.botname] || "bella"
}

async function generateCustomVN(text, voice) {
    try {
        let r = await axios.get("https://api.termai.cc/api/text2speech/elevenlabs", {
            params: { text, voice, key: global.api.xtermai },
            responseType: "arraybuffer"
        })
        return Buffer.from(r.data)
    } catch (e) {
        console.log("CustomVN Error:", e.message)
        return null
    }
}

async function uploadToAliceCdn(buffer, fileName, mimeType) {
    const form = new FormData()
    form.append('cdnFile', buffer, { filename: fileName, contentType: mimeType })

    const res = await axios.post(
        'https://aliceecdn.vercel.app/upload',
        form,
        { headers: form.getHeaders(), maxBodyLength: Infinity }
    )

    return res.data
}

function isUploadQuery(t) {
    t = t.toLowerCase()
    const keys = ["upload", "unggah", "simpan ke url", "jadikan url", "buat link", "convert to url", "cdn", "telegraph", "ubah jadi link", "jadikan link", "kirim ke cdn"]
    return keys.some(v => t.includes(v))
}

async function getPinterest(q) {
    try {
        let x = await axios.get(`https://api-faa.my.id/faa/pinterest?q=${encodeURIComponent(q)}`)
        if (x.data?.result?.length) return x.data.result
    } catch {}

    try {
        let y = await axios.get(`https://api.zenzzx.my.id/api/search/pinterest?query=${encodeURIComponent(q)}`)
        if (y.data?.data?.length) return y.data.data.map(v => v.directLink)
    } catch {}

    return []
}

function isPinterestQuery(t) {
    t = t.toLowerCase()
    const keys = [
        "pinterest", "pin ", "pindirset", "pinteres",
        "cari foto", "carikan foto", "tolong cari foto",
        "minta foto", "minta gambar", "carikan gambar",
        "cari gambar", "cariin gambar", "cariin foto",
        "kirimin foto", "kirimin gambar", "kasih foto",
        "kasih gambar", "ambilin foto", "ambilin gambar",
        "carikan aku foto", "carikan aku gambar",
        "boleh minta foto", "boleh minta gambar",
        "wallpaper", "background", "bg aesthetic",
        "foto aesthetic", "gambar aesthetic",
        "gambar ", "foto ", "pic ", "picture", "image",
    ]
    return keys.some(v => t.includes(v))
}

function extractPinterestKeyword(text) {
    let t = text.toLowerCase()

    const removeList = [
        "pinterest", "pin", "pinteres", "pindirset", "pintrerest",
        "carikan aku foto", "carikan aku gambar",
        "carikan foto", "carikan gambar",
        "cari foto", "cari gambar",
        "cariin foto", "cariin gambar",
        "tolong cari foto", "tolong cari gambar",
        "minta foto", "minta gambar",
        "beri aku foto", "beri aku gambar",
        "kasih foto", "kasih gambar",
        "kirimin foto", "kirimin gambar",
        "ambilin foto", "ambilin gambar",
        "foto", "gambar", "pic", "picture", "image",
        "wallpaper", "background",
        "dong", "ya", "nih", "deh", "kok", "tau",
        "tolong", "please", "pls", "boleh", "bisa", "ga", "nggak",
        "kan", "lah", "itu"
    ]

    removeList.forEach(word => {
        t = t.replace(new RegExp("\\b" + word + "\\b", "gi"), "")
    })

    t = t.replace(/di pinterest/gi, "").replace(/ke pinterest/gi, "")
    t = t.replace(/\s+/g, " ").trim()

    if (!t) t = "aesthetic wallpaper"

    return t
}

async function sendPinterest(Alice, m, reply, text) {
    let results = await getPinterest(text)
    if (!results.length) return reply("❌ Tidak ditemukan hasil kak.")

    let img = results[Math.floor(Math.random() * results.length)]

    await Alice.sendMessage(m.chat, {
        image: { url: img },
        caption: `📌 *Pinterest Result*\n\n✨ Keyword: *${text}*`,
        footer: `Pinterest Search Engine by ${bot}`,
        buttons: [
            { buttonId: `pinterest ${text}`, buttonText: { displayText: '🔄 Next' }, type: 1 }
        ],
        headerType: 4
    }, { quoted: m })
}

function isBratQuery(t) {
    t = t.toLowerCase()
    return (
        t.startsWith("brat ") ||
        t.includes("bikin brat") ||
        t.includes("buat brat") ||
        t.includes("jadiin brat") ||
        t.includes("ubah jadi brat") ||
        t.includes("sticker brat") ||
        t.includes("stiker brat") ||
        t.includes("bratify")
    )
}

function extractBratText(t) {
    const original = t

    const patterns = [
        /buatkan?\s+brat\s+(.+)/i,
        /bikin\s+brat\s+(.+)/i,
        /buatin\s+brat\s+(.+)/i,
        /bikinin\s+brat\s+(.+)/i,
        /bratify\s+(.+)/i,
        /brat\s+(.+)/i,
        /sticker\s+brat\s+(.+)/i,
        /stiker\s+brat\s+(.+)/i
    ]

    for (const pattern of patterns) {
        const match = original.match(pattern)
        if (match && match[1]) {
            let result = match[1].trim()
            const endWords = ["dong", "ya", "tolong", "please", "plis", "deh", "lah", "dongs"]
            endWords.forEach(word => {
                result = result.replace(new RegExp(`\\s+${word}\\s*$`, "i"), "")
            })
            if (result.length > 0) return result
        }
    }

    const words = original.split(/\s+/)
    let startIndex = -1

    for (let i = 0; i < words.length; i++) {
        const word = words[i].toLowerCase()
        if (word === "brat" || word === "bratify" ||
            (word === "sticker" && words[i + 1]?.toLowerCase() === "brat") ||
            (word === "stiker" && words[i + 1]?.toLowerCase() === "brat")) {
            startIndex = i + 1
            if (word === "sticker" || word === "stiker") startIndex++
            break
        }
    }

    if (startIndex > 0 && startIndex < words.length) {
        let result = words.slice(startIndex).join(" ").trim()
        if (result.toLowerCase().startsWith("video ")) result = result.substring(6).trim()
        const endWords = ["dong", "ya", "tolong", "please", "plis", "deh", "lah"]
        endWords.forEach(word => {
            if (result.toLowerCase().endsWith(` ${word}`)) {
                result = result.substring(0, result.length - word.length - 1).trim()
            }
        })
        if (result.length > 0) return result
    }

    return "hai"
}

function isBratVideoQuery(t) {
    t = t.toLowerCase()
    return (
        t.startsWith("bratvideo ") ||
        t.includes("brat video") ||
        t.includes("video brat") ||
        t.includes("bikin bratvideo") ||
        t.includes("buat bratvideo") ||
        t.includes("jadiin bratvideo") ||
        t.includes("brat vid") ||
        t.includes("stiker video brat") ||
        t.includes("sticker video brat")
    )
}

function extractBratVideoText(t) {
    const original = t

    const patterns = [
        /buatkan?\s+(?:brat\s+)?video\s+(.+)/i,
        /bikin\s+(?:brat\s+)?video\s+(.+)/i,
        /buatin\s+(?:brat\s+)?video\s+(.+)/i,
        /bikinin\s+(?:brat\s+)?video\s+(.+)/i,
        /brat\s+video\s+(.+)/i,
        /video\s+brat\s+(.+)/i,
        /bratvideo\s+(.+)/i,
        /brat\s+vid\s+(.+)/i
    ]

    for (const pattern of patterns) {
        const match = original.match(pattern)
        if (match && match[1]) {
            let result = match[1].trim()
            const endWords = ["dong", "ya", "tolong", "please", "plis", "deh", "lah", "dongs"]
            endWords.forEach(word => {
                result = result.replace(new RegExp(`\\s+${word}\\s*$`, "i"), "")
            })
            if (result.length > 0) {
                if (result.length > 250) result = result.substring(0, 250)
                return result
            }
        }
    }

    const words = original.split(/\s+/)

    for (let i = 0; i < words.length; i++) {
        const word = words[i].toLowerCase()
        if (word === "video" || word === "vid" || word === "bratvideo") {
            let result = words.slice(i + 1).join(" ").trim()
            if (result.length === 0 && i > 0) {
                for (let j = 0; j < i; j++) {
                    if (words[j].toLowerCase() === "brat") {
                        result = words.slice(j + 1).join(" ").trim()
                        result = result.replace(/video\s+/i, "")
                        break
                    }
                }
            }
            const endWords = ["dong", "ya", "tolong", "please", "plis"]
            endWords.forEach(word => {
                if (result.toLowerCase().endsWith(` ${word}`)) {
                    result = result.substring(0, result.length - word.length - 1).trim()
                }
            })
            if (result.length > 0) {
                if (result.length > 250) result = result.substring(0, 250)
                return result
            }
        }
    }

    const wordsAll = original.split(/\s+/)
    if (wordsAll.length >= 2) {
        let result = wordsAll.slice(-2).join(" ").trim()
        if (result.length > 250) result = result.substring(0, 250)
        return result
    }

    return "hai bang"
}

async function autoAICommand(m, args, reply) {
    if (!m.isGroup) return reply("Hanya untuk grup kak.")

    let id = m.chat
    if (!db[id]) db[id] = { autoai: false, autovn: false, history: [] }

    let a = (args[0] || "").toLowerCase()
    let b = (args[1] || "").toLowerCase()

    if (a === "status") {
        let s1 = db[id].autoai ? "ON" : "OFF"
        let s2 = db[id].autovn ? "ON" : "OFF"
        return reply(`Status AutoAI\nchat: ${s1}\nvn: ${s2}`)
    }

    if (a === "on") {
        db[id].autoai = true
        db[id].autovn = false
        saveDb()
        return reply("AutoAI mode chat diaktifkan kak ✨")
    }

    if (a === "off") {
        db[id].autoai = false
        db[id].autovn = false
        saveDb()
        return reply("AutoAI dimatikan kak ✨")
    }

    if (a === "vn") {
        if (b === "on") {
            db[id].autoai = true
            db[id].autovn = true
            saveDb()
            return reply("AutoAI mode voice note aktif kak 🎤")
        }
        if (b === "off") {
            db[id].autovn = false
            saveDb()
            return reply("AutoAI VN dimatikan kak ✨")
        }
        return reply("autoai vn on/off kak")
    }

    reply("autoai on/off | autoai vn on/off | autoai status")
}

async function autoAIReply(Alice, m, reply) {
    if (!m.chat.endsWith('@g.us')) return

    let autoGroups = getAutoAIGroup()
    if (!autoGroups.includes(m.chat)) return

    let id = m.chat
    db[id] = db[id] || { history: [] }

    let text = m.text ||
               m.message?.conversation ||
               m.message?.extendedTextMessage?.text ||
               ""

    if (!text) return

    let blockPrefix = ['.', '/', '!', '#', '*']
    if (blockPrefix.includes(text.trim()[0])) return

    let botId = Alice.user.id.split(":")[0]
    let isReply = isReplyToBot(Alice, m)
    let isTag = m?.message?.extendedTextMessage?.text?.includes(botId)

    if (!isReply && !isTag) return

    if (blockedCmd(text)) return reply("waduh itu agak berbahaya kak, aku nggak bisa bantu ya 😊")

    const tl = text.toLowerCase()

    if (isUploadQuery(tl) && m.message && (m.message.imageMessage || m.message.videoMessage || m.message.audioMessage)) {
        await XReaction(Alice, m, "🕐", "✨")

        try {
            const targetMsg = m
            let mimeType = ""
            let mediaBuffer = null

            if (m.message.imageMessage) {
                mimeType = m.message.imageMessage.mimetype || "image/jpeg"
                const tmp = await Alice.downloadAndSaveMediaMessage(m.message.imageMessage)
                mediaBuffer = fs.readFileSync(tmp)
                fs.unlinkSync(tmp)
            } else if (m.message.videoMessage) {
                mimeType = m.message.videoMessage.mimetype || "video/mp4"
                const tmp = await Alice.downloadAndSaveMediaMessage(m.message.videoMessage)
                mediaBuffer = fs.readFileSync(tmp)
                fs.unlinkSync(tmp)
            } else if (m.message.audioMessage) {
                mimeType = m.message.audioMessage.mimetype || "audio/mpeg"
                const tmp = await Alice.downloadAndSaveMediaMessage(m.message.audioMessage)
                mediaBuffer = fs.readFileSync(tmp)
                fs.unlinkSync(tmp)
            }

            if (!mediaBuffer) return reply("❌ Media tidak valid kak.")

            const extMap = {
                'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png',
                'image/webp': 'webp', 'image/gif': 'gif',
                'video/mp4': 'mp4', 'video/mpeg': 'mpeg', 'video/quicktime': 'mov', 'video/webm': 'webm',
                'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/ogg': 'ogg',
                'audio/wav': 'wav', 'audio/aac': 'aac', 'audio/mp4': 'm4a'
            }

            const ext = extMap[mimeType] || mimeType.split('/')[1] || 'bin'
            const fileName = `${Date.now()}.${ext}`

            const result = await uploadToAliceCdn(mediaBuffer, fileName, mimeType)

            if (!result?.url) return reply("❌ Upload gagal kak.")

            const caption =
                `✅ *UPLOAD BERHASIL*\n\n` +
                `🌐 URL:\n${result.url}\n\n` +
                `📦 Type: ${mimeType}\n` +
                `⏳ Expired: Permanent`

            const buttons = [{
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "📋 Copy URL",
                    id: result.url,
                    copy_code: result.url
                })
            }]

            if (/image/.test(mimeType)) {
                await Alice.sendInteractive(m.chat, buttons, result.url, bot, caption, m)
            } else if (/video/.test(mimeType)) {
                await Alice.sendMessage(m.chat, { video: { url: result.url }, caption }, { quoted: m })
                await Alice.sendButtonProto(m.chat, '📋 Copy URL di bawah ini', bot, buttons, m)
            } else if (/audio/.test(mimeType)) {
                await Alice.sendMessage(m.chat, { audio: { url: result.url }, mimetype: mimeType, ptt: false }, { quoted: m })
                await Alice.sendButtonProto(m.chat, caption, bot, buttons, m)
            }

            return
        } catch (e) {
            console.log("UploadError:", e.message)
            return reply(`⚠️ Error: ${e.message || e}`)
        }
    }

    if (isPinterestQuery(tl)) {
        let key = extractPinterestKeyword(text)
        await XReaction(Alice, m, "🕐", "✨")
        return await sendPinterest(Alice, m, reply, key)
    }

    if (isBratVideoQuery(tl)) {
        let q = extractBratVideoText(text)
        if (q.length > 250) return reply("Kebanyakan kak, maksimal 250 karakter 😳")

        await XReaction(Alice, m, "🕐", "✨")

        try {
            let res = await axios.get(
                `https://api.yupra.my.id/api/video/bratv?text=${encodeURIComponent(q)}`,
                { responseType: "arraybuffer" }
            )

            const tmp = path.join(process.cwd(), "tmp")
            if (!fs.existsSync(tmp)) fs.mkdirSync(tmp)
            let loc = path.join(tmp, `brat-${Date.now()}.mp4`)
            fs.writeFileSync(loc, res.data)

            await Alice.sendImageAsSticker(m.chat, loc, m, { packname: bot, author: "BratV Maker" })

            setTimeout(() => { if (fs.existsSync(loc)) fs.unlinkSync(loc) }, 4000)
            return
        } catch (e) {
            console.log("BratVideoErr:", e.message)
            return reply("Gagal membuat Brat Video kak 😔")
        }
    }

    if (isBratQuery(tl)) {
        let q = extractBratText(text)
        await XReaction(Alice, m, "🕐", "✨")

        try {
            let res = await axios.get(
                `https://api-faa.my.id/faa/brathd?text=${encodeURIComponent(q)}`,
                { responseType: 'arraybuffer' }
            )

            let buffer = Buffer.from(res.data)
            await Alice.sendImageAsSticker(m.chat, buffer, m, { packname: bot, author: own })
            return
        } catch (e) {
            console.log("BratErr:", e.message)
            return reply("❌ API brat HD lagi error / maintenance kak 😔")
        }
    }

    const isImageMsg = m.mtype === 'imageMessage' || !!m.message?.imageMessage
    const isQuotedImage = m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage

    if (isImageMsg || isQuotedImage) {
        await XReaction(Alice, m, "🕐", "✨")
        reply(`🖼️ *AI Vision Mode*\n⏳ Menganalisis gambar, mohon tunggu sebentar...`)

        try {
            let imgBuffer, mimeType

            if (isImageMsg) {
                const imgMsg = m.message.imageMessage
                mimeType = imgMsg.mimetype || "image/jpeg"
                const tmp = await Alice.downloadAndSaveMediaMessage(imgMsg)
                imgBuffer = fs.readFileSync(tmp)
                fs.unlinkSync(tmp)
            } else {
                const quotedImg = m.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage
                mimeType = quotedImg.mimetype || "image/jpeg"
                const tmp = await Alice.downloadAndSaveMediaMessage(quotedImg)
                imgBuffer = fs.readFileSync(tmp)
                fs.unlinkSync(tmp)
            }

            const imageDataUrl = await imageToDataUrl(imgBuffer, mimeType)
            const prompt = text || "Jelaskan gambar ini"
            const hasil = await gpt4o(prompt, imageDataUrl)

            return reply(`💭 *AI - Hasil Analisis Gambar:*\n\n${hasil}`)
        } catch (e) {
            console.log("VisionErr:", e.message)
            return reply(`❌ *Error:* ${e.message || 'Layanan AI sedang sibuk'}`)
        }
    }

    await XReaction(Alice, m, "🕐", "✨")

    let ans = await askAI(text, m)
    db[id].history.push({ u: text, a: ans })
    if (db[id].history.length > 10) db[id].history.shift()
    saveDb()

    const triggerVN = ["vn", "voice", "suara", "bacain", "bacakan", "ucapkan", "bilang", "tolong bacakan", "minta vn"]
    const wantVN = triggerVN.some(v => tl.includes(v))
    const voice = detectVoice(text)

    if (wantVN) {
        let vn = await generateCustomVN(ans, voice)
        if (!vn) return reply("maaf kak, VN nya gagal dibuat 😔")
        return await Alice.sendMessage(m.chat, { audio: vn, mimetype: "audio/mpeg", ptt: true }, { quoted: m })
    }

    return reply(ans)
}

module.exports = {
    autoAICommand,
    autoAIReply,
    getAutoAIGroup,
    saveAutoAIGroup
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`[ UPDATE ] ${__filename}`))
    delete require.cache[file]
    require(file)
})
