const fs = require('fs')
const path = require('path')

const baseDir = __dirname
const dbPath = path.join(baseDir, 'respon.json')
const mediaDir = path.join(baseDir, 'media')

if (!fs.existsSync(mediaDir)) fs.mkdirSync(mediaDir, { recursive: true })
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]))

const loadDB = () => JSON.parse(fs.readFileSync(dbPath))
const saveDB = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2))

const getRespon = (key) => loadDB().find(v => v.key === key)

const addRespon = (key, type, content) => {
    let data = loadDB()
    data.push({ key, type, content })
    saveDB(data)
}

const delRespon = (key) => {
    let data = loadDB().filter(v => v.key !== key)
    saveDB(data)
}

const listRespon = () => loadDB()

module.exports = {
    getRespon,
    addRespon,
    delRespon,
    listRespon,
    mediaDir
}