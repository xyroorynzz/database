
const fs = require('fs')
const path = require('path')

const dataPath = path.join(__dirname, 'users.json')
const duelDataPath = path.join(__dirname, 'duel.json')
const partyDataPath = path.join(__dirname, 'party.json')
const guildDataPath = path.join(__dirname, 'guild.json')
const jailDataPath = path.join(__dirname, 'jail.json')
const tournamentDataPath = path.join(__dirname, 'tournament.json')

let users = {}

function loadData() {
    try {
        if (fs.existsSync(dataPath)) {
            const data = fs.readFileSync(dataPath, 'utf8')
            users = JSON.parse(data)
        }
    } catch (err) {
        console.error('Gagal load data:', err)
        users = {}
    }
}

function saveData() {
    try {
        fs.writeFileSync(dataPath, JSON.stringify(users, null, 2))
    } catch (err) {
        console.error('Gagal save data:', err)
    }
}

function getUser(id) {
    return users[id] || null
}

function createUser(id, data) {
    if (users[id]) return false
    users[id] = data
    saveData()
    return true
}

function updateUser(id, data) {
    if (!users[id]) return false
    users[id] = data
    saveData()
    return true
}

function deleteUser(id) {
    if (!users[id]) return false
    delete users[id]
    saveData()
    return true
}

function getAllUsers() {
    return users
}

function userExists(id) {
    return !!users[id]
}

function getLeaderboard(type = 'level') {
    let sorted = Object.values(users)
    if (type === 'level') {
        sorted.sort((a, b) => b.level - a.level)
    } else if (type === 'gold') {
        sorted.sort((a, b) => b.gold - a.gold)
    } else if (type === 'arena') {
        sorted.sort((a, b) => b.arenaWin - a.arenaWin)
    }
    return sorted
}

function getDuelData() {
    try {
        if (fs.existsSync(duelDataPath)) {
            return JSON.parse(fs.readFileSync(duelDataPath, 'utf-8'))
        }
        return {}
    } catch (err) {
        return {}
    }
}

function saveDuelData(data) {
    fs.writeFileSync(duelDataPath, JSON.stringify(data, null, 2))
}

function getPartyData() {
    try {
        if (fs.existsSync(partyDataPath)) {
            return JSON.parse(fs.readFileSync(partyDataPath, 'utf-8'))
        }
        return {}
    } catch (err) {
        return {}
    }
}

function savePartyData(data) {
    fs.writeFileSync(partyDataPath, JSON.stringify(data, null, 2))
}

function getGuildData() {
    try {
        if (fs.existsSync(guildDataPath)) {
            return JSON.parse(fs.readFileSync(guildDataPath, 'utf-8'))
        }
        return {}
    } catch (err) {
        return {}
    }
}

function saveGuildData(data) {
    fs.writeFileSync(guildDataPath, JSON.stringify(data, null, 2))
}

function getJailData() {
    try {
        if (fs.existsSync(jailDataPath)) {
            return JSON.parse(fs.readFileSync(jailDataPath, 'utf-8'))
        }
        return {}
    } catch (err) {
        return {}
    }
}

function saveJailData(data) {
    fs.writeFileSync(jailDataPath, JSON.stringify(data, null, 2))
}

function getTournamentData() {
    try {
        if (fs.existsSync(tournamentDataPath)) {
            return JSON.parse(fs.readFileSync(tournamentDataPath, 'utf-8'))
        }
        return {}
    } catch (err) {
        return {}
    }
}

function saveTournamentData(data) {
    fs.writeFileSync(tournamentDataPath, JSON.stringify(data, null, 2))
}

loadData()

module.exports = { 
    getUser, 
    createUser, 
    updateUser, 
    getAllUsers, 
    deleteUser, 
    userExists,
    getLeaderboard,
    getDuelData,
    saveDuelData,
    getPartyData,
    savePartyData,
    getGuildData,
    saveGuildData,
    getJailData,
    saveJailData,
    getTournamentData,
    saveTournamentData
}