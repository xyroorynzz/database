//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require("axios");
const crypto = require("crypto");
const https = require("https");

class ZAIClient {
  constructor() {
    this.baseURL = "https://chat.z.ai";
    this.staticKey = "key-@@@@)))()((9))-xxxx&&&%%%%%";
    this.feVersion = "prod-fe-1.0.239";

    this.token = null;
    this.user = null;
    this.chatId = null;
    this.lastMessageId = null;

    this.http = axios.create({
      baseURL: this.baseURL,
      httpsAgent: new https.Agent({ keepAlive: true }),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "X-FE-Version": this.feVersion
      }
    });
  }

  /* ================= ERROR HANDLER ================= */

  handleError(error, context) {
    console.error(`\n--- ❌ [${context}] Error ---`);
    if (error.response) {
      console.error(error.response.data);
    } else {
      console.error(error.message);
    }
    console.error(`----------------------------\n`);
    throw error;
  }

  /* ================= HMAC ================= */

  hmac(key, data) {
    return crypto
      .createHmac("sha256", key)
      .update(data)
      .digest("hex");
  }

  generateSignature({ requestId, timestamp, user_id, prompt }) {
    const windowTime = Math.floor(timestamp / 300000);

    const intermediateKey = this.hmac(
      this.staticKey,
      String(windowTime)
    );

    const sortedPayload =
      `requestId,${requestId},timestamp,${timestamp},user_id,${user_id}`;

    const base64Prompt = Buffer
      .from(prompt, "utf-8")
      .toString("base64");

    const dataToSign =
      `${sortedPayload}|${base64Prompt}|${timestamp}`;

    return this.hmac(intermediateKey, dataToSign);
  }

  /* ================= SESSION ================= */

  async initSession() {
    try {
      const res = await this.http.get("/api/v1/auths/");

      this.token = res.data.token;
      this.user = res.data;

      this.http.defaults.headers.Authorization =
        `Bearer ${this.token}`;

      return res.data;
    } catch (error) {
      this.handleError(error, "InitSession");
    }
  }

  /* ================= CREATE CHAT ================= */

  async createChat(message = "Halo", model = "glm-5") {
    if (!this.token) await this.initSession();

    const timestamp = Date.now();
    const msgId = crypto.randomUUID();

    const payload = {
      chat: {
        id: "",
        title: "New Chat",
        models: [model],
        params: {},
        history: {
          messages: {
            [msgId]: {
              id: msgId,
              parentId: null,
              childrenIds: [],
              role: "user",
              content: message,
              timestamp: Math.floor(timestamp / 1000),
              models: [model]
            }
          },
          currentId: msgId
        },
        tags: [],
        flags: [],
        features: [],
        enable_thinking: true,
        auto_web_search: false,
        timestamp
      }
    };

    try {
      const res = await this.http.post(
        "/api/v1/chats/new",
        payload
      );

      this.chatId = res.data.id;
      this.lastMessageId = msgId;

      return res.data;
    } catch (error) {
      this.handleError(error, "CreateChat");
    }
  }

  /* ================= SEND MESSAGE ================= */

  async sendMessage(
    message,
    model = "glm-5",
    options = { thinking: false, search: true }
  ) {
    if (!this.token) await this.initSession();
    if (!this.chatId)
      await this.createChat(message, model);

    const timestamp = Date.now();
    const requestId = crypto.randomUUID();
    const userId = this.user.id;

    const signature = this.generateSignature({
      requestId,
      timestamp,
      user_id: userId,
      prompt: message
    });

    const query = new URLSearchParams({
      requestId,
      timestamp,
      user_id: userId,
      version: "0.0.1",
      platform: "web",
      token: this.token,
      language: "id-ID",
      timezone: "Asia/Jakarta"
    }).toString();

    const payload = {
      stream: true,
      model,
      messages: [{ role: "user", content: message }],
      features: {
        web_search: options.search,
        auto_web_search: options.search,
        enable_thinking: options.thinking
      },
      chat_id: this.chatId,
      id: crypto.randomUUID()
    };

    try {
      const response = await this.http.post(
        `/api/v2/chat/completions?${query}`,
        payload,
        {
          responseType: "stream",
          headers: {
            "X-Signature": signature,
            Referer: `${this.baseURL}/c/${this.chatId}`
          }
        }
      );

      return new Promise((resolve, reject) => {
        let fullText = "";
        let buffer = "";

        response.data.on("data", chunk => {
          buffer += chunk.toString();
          const lines = buffer.split("\n");
          buffer = lines.pop();

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;

            const dataStr = line
              .replace("data: ", "")
              .trim();

            if (dataStr === "[DONE]") continue;

            try {
              const json = JSON.parse(dataStr);
              const content =
                json.choices?.[0]?.delta?.content ||
                json.data?.delta_content;

              if (content)
                fullText += content;

            } catch {}
          }
        });

        response.data.on("end", () => {
          const simple =
            formatChatStyle(fullText);
          resolve(simple);
        });

        response.data.on("error", reject);
      });

    } catch (error) {
      this.handleError(error, "SendMessage");
    }
  }
}

/* ================= FORMATTER ================= */

function formatChatStyle(text) {
  if (!text) return "Tidak ada hasil.";

  const clean = text
    .replace(/https?:\/\/\S+/g, "")
    .replace(/Baca juga:.*/gi, "")
    .replace(/Tags?:.*/gi, "");

  const lines = clean
    .split("\n")
    .map(l => l.trim())
    .filter(l =>
      l &&
      !l.toLowerCase().includes("tag") &&
      !l.toLowerCase().includes("baca")
    );

  const title = lines[0] || "Berita";

  const body = lines
    .slice(1)
    .join(" ")
    .split(". ")
    .slice(0, 2)
    .join(". ")
    .trim();

  return `📰 ${title}

${body}

Sumber: Web Realtime`;
}

module.exports = ZAIClient;