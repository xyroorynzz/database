//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const acrcloud = require('acrcloud')

const acr = new acrcloud({
  host: 'identify-ap-southeast-1.acrcloud.com',
  access_key: 'ee1b81b47cf98cd73a0072a761558ab1',
  access_secret: 'ya9OPe8onFAnNkyf9xMTK8qRyMGmsghfuHrIMmUI'
})

function toTime(ms) {
  const m = Math.floor(ms / 60000) % 60
  const s = Math.floor(ms / 1000) % 60
  return [m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

async function whatmusic(buffer) {
  if (!buffer) throw new Error('Audio tidak ditemukan')

  const data = (await acr.identify(buffer)).metadata
  if (!data?.music || data.music.length === 0)
    throw new Error('Lagu tidak ditemukan')

  return data.music.map(a => ({
    title: a?.title || 'Unknown',
    artist: a?.artists?.[0]?.name || 'Unknown',
    duration: a?.duration_ms ? toTime(a.duration_ms) : '00:00',
    release: a?.release_date
      ? new Date(a.release_date).toLocaleDateString('id-ID')
      : 'Unknown',
    score: a?.score || 0,
    url: Object.keys(a?.external_metadata || {})
      .map(i => {
        if (i === 'youtube')
          return 'https://youtu.be/' + a.external_metadata[i].vid
        if (i === 'spotify')
          return 'https://open.spotify.com/track/' + a.external_metadata[i].track.id
        if (i === 'deezer')
          return 'https://www.deezer.com/us/track/' + a.external_metadata[i].track.id
        return ''
      })
      .filter(Boolean)
  }))
}

module.exports = whatmusic