//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')
const cheerio = require('cheerio')

async function tiktokdl(url){
  try{
    const r = await axios.post(
     'https://savetik.co/api/ajaxSearch',
    new URLSearchParams({ q:url, lang:'id' }).toString(),
      {
        headers:{
       'User-Agent':'Mozilla/5.0 (Linux; Android 10)',
       'Content-Type':'application/x-www-form-urlencoded',
      'X-Requested-With':'XMLHttpRequest',
        origin:'https://savetik.co',
        referer:'https://savetik.co/id1'
      }
     }
    )

    const $ = cheerio.load(r.data.data)

    return{
      title: $('h3').first().text().trim() || null,
      thumbnail: $('.image-tik img').attr('src') || $('.thumbnail img').attr('src') || null,
      mp4: $('.dl-action a:contains("MP4")').not(':contains("HD")').attr('href') || null,
      mp4_hd: $('.dl-action a:contains("HD")').attr('href') || null,
      mp3: $('.dl-action a:contains("MP3")').attr('href') || null,
      foto: $('.photo-list a[href*="snapcdn"]').map((_,e)=>$(e).attr('href')).get()
    }

  }catch(e){
    return{ status:'error', msg:e.message }
  }
}

module.exports = tiktokdl;
