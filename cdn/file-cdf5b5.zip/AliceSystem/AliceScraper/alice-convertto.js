//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require("axios")

async function convertTo(type, url) {
    let endpoint = `https://api-faa.my.id/faa/${type}?url=${encodeURIComponent(url)}`
    let res = await axios.get(endpoint, { responseType: "arraybuffer" })
    let ct = res.headers["content-type"] || ""

    if (ct.includes("image")) {
        return Buffer.from(res.data)
    }

    let data
    try {
        data = JSON.parse(res.data.toString())
    } catch {
        throw new Error("Respon bukan JSON / image")
    }

    let out =
        data.url ||
        data.result ||
        data.image ||
        (data.data && data.data.url) ||
        data.data

    if (!out) throw new Error("Gambar ga dapet dari API")

    let img = await axios.get(out, { responseType: "arraybuffer" })
    return Buffer.from(img.data)
}

module.exports = { convertTo }