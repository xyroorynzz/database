//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const crypto = require('crypto')
const fetch = require('node-fetch')
const FormData = require('form-data')

async function hdvideo(buffer) {
  const baseApi = 'https://api.unblurimage.ai'
  const productSerial = crypto.randomUUID().replace(/-/g, '')

  if (!buffer) throw new Error('Videonya mana')

  const sleep = ms => new Promise(r => setTimeout(r, ms))

  async function jsonFetch(url, options = {}) {
    const res = await fetch(url, options)
    const text = await res.text()
    let json
    try {
      json = text ? JSON.parse(text) : null
    } catch {
      throw new Error('Response bukan JSON')
    }
    if (!res.ok) throw new Error(JSON.stringify(json))
    return json
  }

  try {
    const uploadForm = new FormData()
    uploadForm.append('video_file_name', `cli-${Date.now()}.mp4`)

    const uploadResp = await jsonFetch(
      `${baseApi}/api/upscaler/v1/ai-video-enhancer/upload-video`,
      {
        method: 'POST',
        body: uploadForm,
        headers: uploadForm.getHeaders()
      }
    )

    if (uploadResp.code !== 100000) throw new Error('Upload gagal')

    const { url: uploadUrl, object_name } = uploadResp.result

    const put = await fetch(uploadUrl, {
      method: 'PUT',
      headers: { 'content-type': 'video/mp4' },
      body: buffer
    })

    if (!put.ok) throw new Error('Upload video gagal')

    const cdnUrl = `https://cdn.unblurimage.ai/${object_name}`

    const jobForm = new FormData()
    jobForm.append('original_video_file', cdnUrl)
    jobForm.append('resolution', '2k')
    jobForm.append('is_preview', 'false')

    const createJob = await jsonFetch(
      `${baseApi}/api/upscaler/v2/ai-video-enhancer/create-job`,
      {
        method: 'POST',
        body: jobForm,
        headers: {
          ...jobForm.getHeaders(),
          'product-serial': productSerial
        }
      }
    )

    if (createJob.code !== 100000) throw new Error('Create job gagal')

    const jobId = createJob.result.job_id
    const start = Date.now()

    while (true) {
      const job = await jsonFetch(
        `${baseApi}/api/upscaler/v2/ai-video-enhancer/get-job/${jobId}`,
        {
          headers: { 'product-serial': productSerial }
        }
      )

      if (job.code === 100000 && job.result?.output_url) {
        return job.result
      }

      if (Date.now() - start > 300000)
        throw new Error('Timeout proses')

      await sleep(10000)
    }

  } catch (e) {
    throw new Error(e.message)
  }
}

module.exports = hdvideo