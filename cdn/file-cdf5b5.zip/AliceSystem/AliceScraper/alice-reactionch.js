//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')

const tokens = [
  "814de8a635650b0a90803587fcf54b94fd1e6059d9ba782d0041f4b863a1834b",
  "986ce2378f5235330763c5a5e1c55645302aa393c2b7b987147b39c5d57c5d10"
]

async function reactionchannel(postUrl, reacts) {
  let idx = 0
  let tries = 0

  while (tries < tokens.length) {
    try {
      const res = await axios({
        method: 'POST',
        url: `https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post?apiKey=${tokens[idx]}`,
        headers: {
          'authority': 'foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app',
          'accept': 'application/json, text/plain, */*',
          'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'content-type': 'application/json',
          'origin': 'https://asitha.top',
          'referer': 'https://asitha.top/',
          'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
          'sec-ch-ua-mobile': '?1',
          'sec-ch-ua-platform': '"Android"',
          'sec-fetch-dest': 'empty',
          'sec-fetch-mode': 'cors',
          'sec-fetch-site': 'cross-site',
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
        },
        data: {
          post_link: postUrl,
          reacts
        }
      })

      return {
        status: true,
        data: res.data
      }

    } catch (e) {
      const s = e.response?.status
      const m = e.response?.data?.message || ''

      if (s === 402 || m.toLowerCase().includes('limit')) {
        idx++
        tries++
        continue
      }

      return {
        status: false,
        error: e.response?.data || e.message,
        code: s
      }
    }
  }

  return {
    status: false,
    error: 'All tokens limited',
    code: 402
  }
}

module.exports = reactionchannel