//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')
const cheerio = require('cheerio')

async function searchCity(query) {
  const url = 'https://www.jadwalsholat.org/jadwal-sholat/monthly.php'
  const { data: html } = await axios.get(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }
  })

  const $ = cheerio.load(html)
  const cities = []

  $('select[name=kota] option').each((_, el) => {
    const id = $(el).attr('value')
    const name = $(el).text().trim()
    if (id && name) {
      cities.push({
        id,
        name,
        search: name.toLowerCase()
      })
    }
  })

  const q = query.toLowerCase()
  return cities.find(v => v.search.includes(q)) || null
}

async function getPrayerSchedule(cityId) {
  const url = `https://www.jadwalsholat.org/jadwal-sholat/monthly.php?id=${cityId}`
  const { data: html } = await axios.get(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }
  })

  const $ = cheerio.load(html)
  const cityName = $('select[name=kota] option[selected]').text().trim()
  const today = new Date().getDate()
  let jadwal = null

  $('tr[class^="table_"]').each((_, row) => {
    const td = $(row).find('td')
    if (td.length === 9) {
      const tgl = parseInt(td.eq(0).text().trim())
      if (tgl === today) {
        jadwal = {
          imsyak: td.eq(1).text().trim(),
          subuh: td.eq(2).text().trim(),
          terbit: td.eq(3).text().trim(),
          dhuha: td.eq(4).text().trim(),
          dzuhur: td.eq(5).text().trim(),
          ashar: td.eq(6).text().trim(),
          maghrib: td.eq(7).text().trim(),
          isya: td.eq(8).text().trim()
        }
      }
    }
  })

  if (!jadwal) return null

  return {
    kota: cityName,
    jadwal
  }
}

async function jadwalsholat(kota) {
  if (!kota) throw new Error('Nama kota belum diisi')

  const city = await searchCity(kota)
  if (!city) throw new Error(`Kota "${kota}" tidak ditemukan`)

  const schedule = await getPrayerSchedule(city.id)
  if (!schedule) throw new Error('Gagal mengambil jadwal sholat')

  return schedule
}

module.exports = jadwalsholat