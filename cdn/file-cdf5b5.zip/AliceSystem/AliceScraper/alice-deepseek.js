//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const crypto = require("node:crypto")
const fs = require("node:fs/promises")

const BASE = "https://deep-seek.ai"
const CHAT_PAGE = `${BASE}/chat`
const API = `${BASE}/api/chat`

const MODELS = {
chat31: "deepseek/deepseek-chat-v3.1",
r1: "deepseek/deepseek-r1",
v32: "deepseek/deepseek-v3.2"
}

const UA =
"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36"

function splitSetCookie(value) {
if (!value) return []

return value
.split(/,(?=\s*[^;,]+=)/g)
.map(v => v.trim())
.filter(Boolean)
}

function getSetCookies(headers) {
if (typeof headers.getSetCookie === "function") {
return headers.getSetCookie()
}

return splitSetCookie(
headers.get("set-cookie")
)
}

function cookiePair(setCookie) {
return setCookie.split(";")[0]
}

function parseCookieName(pair) {
return pair.split("=")[0]
}

function mergeCookies(oldCookie = "", setCookies = []) {
const map = new Map()

for (const part of oldCookie
.split(";")
.map(v => v.trim())
.filter(Boolean)) {
map.set(parseCookieName(part), part)
}

for (const item of setCookies) {
const pair = cookiePair(item)

if (pair.includes("=")) {
map.set(parseCookieName(pair), pair)
}
}

return [...map.values()].join("; ")
}

function getCookie(cookie, name) {
const found = cookie
.split(";")
.map(v => v.trim())
.find(v => v.startsWith(`${name}=`))

if (!found) return ""

return found.slice(name.length + 1)
}

function decodeCookieValue(value) {
try {
return decodeURIComponent(value)
} catch {
return value
}
}

function findCsrf(html) {
const patterns = [
/<meta[^>]+name=["']csrf-token["'][^>]+content=["']([^"']+)["']/i,
/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']csrf-token["']/i,
/csrfToken["']?\s*[:=]\s*["']([^"']+)["']/i,
/csrf_token["']?\s*[:=]\s*["']([^"']+)["']/i
]

for (const pattern of patterns) {
const match = html.match(pattern)

if (match?.[1]) {
return match[1]
}
}

return ""
}

async function createSession() {
return {
sessionId: crypto.randomUUID(),
cookie: "",
csrfToken: "",
messages: []
}
}

async function refreshSession(session) {
const response = await fetch(CHAT_PAGE, {
method: "GET",
headers: {
"user-agent": UA,
accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
cookie: session.cookie,
referer: BASE
}
})

const html = await response.text()

const setCookies = getSetCookies(
response.headers
)

session.cookie = mergeCookies(
session.cookie,
setCookies
)

const csrfFromHtml = findCsrf(html)

const xsrfCookie = decodeCookieValue(
getCookie(
session.cookie,
"XSRF-TOKEN"
)
)

session.csrfToken =
csrfFromHtml ||
session.csrfToken ||
xsrfCookie

if (!session.csrfToken) {
throw new Error("CSRF token tidak ditemukan")
}

return session
}

async function deepseek(prompt, model = "v32") {
const selectedModel =
MODELS[model] || model

const session =
await refreshSession(
await createSession()
)

const messages = [
{
role: "user",
content: prompt
}
]

const body = {
model: selectedModel,
messages
}

const headers = {
"sec-ch-ua-platform": `"Android"`,
"x-csrf-token": session.csrfToken,
"user-agent": UA,
"sec-ch-ua": `"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"`,
"content-type": "application/json",
"sec-ch-ua-mobile": "?1",
accept: "*/*",
origin: BASE,
"sec-fetch-site": "same-origin",
"sec-fetch-mode": "cors",
"sec-fetch-dest": "empty",
referer: CHAT_PAGE,
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
cookie: session.cookie
}

const response = await fetch(API, {
method: "POST",
headers,
body: JSON.stringify(body)
})

if (!response.ok) {
throw new Error(
`HTTP Error ${response.status}`
)
}

const textResult = await response.text()

let answer = ""

const lines =
textResult.split(/\r?\n/)

for (const rawLine of lines) {
const line = rawLine.trim()

if (!line.startsWith("data:")) {
continue
}

const data =
line.slice(5).trim()

if (!data || data === "[DONE]") {
continue
}

try {
const json = JSON.parse(data)

const content =
json.choices?.[0]?.delta?.content

if (typeof content === "string") {
answer += content
}
} catch {}
}

return answer.trim()
}

module.exports = {
deepseek
}