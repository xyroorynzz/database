//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const fs = require("fs/promises");
const crypto = require("crypto");
const path = require("path");

const API = "https://api.easemate.ai";
const ORIGIN = "https://www.easemate.ai";
const WASM_SOURCE = "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/chat_generatorrr.wasm";
const SESSION_FILE = path.join("/tmp", "kimi-session.json");
const MAX_USE_PER_DEVICE = 4;
const MODEL_ID = 10;
const USER_AGENT = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (Chrome/147.0.0.0) Mobile Safari/537.36";
const DEVICE_PLATFORM = "Android,Chrome";
const LANG = "id";
const LANGUAGE = "id-ID";
const SITE = "www.easemate.ai";
const CLIENT_NAME = "chatpdf";
const PRODUCT_CODE = "888";

let wasmBytesCache = null;
let sessionCache = null;

function createDeviceUUID() {
    return crypto.randomBytes(16).toString("hex");
}

async function loadSession() {
    if (sessionCache) return sessionCache;
    
    try {
        const raw = await fs.readFile(SESSION_FILE, "utf8");
        const json = JSON.parse(raw);
        
        if (!json.deviceUUID || typeof json.usedCount !== "number") {
            throw new Error("Invalid session");
        }
        
        if (json.usedCount >= MAX_USE_PER_DEVICE) {
            sessionCache = {
                deviceUUID: createDeviceUUID(),
                identityId: "",
                usedCount: 0,
                rotatedAt: new Date().toISOString()
            };
            await saveSession(sessionCache);
            return sessionCache;
        }
        
        sessionCache = json;
        return sessionCache;
    } catch {
        sessionCache = {
            deviceUUID: createDeviceUUID(),
            identityId: "",
            usedCount: 0,
            rotatedAt: new Date().toISOString()
        };
        await saveSession(sessionCache);
        return sessionCache;
    }
}

async function saveSession(session) {
    sessionCache = session;
    await fs.writeFile(SESSION_FILE, JSON.stringify(session, null, 2));
}

async function markSessionUsed(session, identityId) {
    session.identityId = identityId || session.identityId || "";
    session.usedCount = (session.usedCount || 0) + 1;
    session.updatedAt = new Date().toISOString();
    await saveSession(session);
}

async function loadWasmBytes() {
    if (wasmBytesCache) return wasmBytesCache;
    
    const res = await fetch(WASM_SOURCE, {
        headers: {
            "user-agent": USER_AGENT,
            accept: "application/wasm,*/*"
        }
    });
    
    if (!res.ok) {
        throw new Error(`Gagal download WASM: HTTP ${res.status}`);
    }
    
    wasmBytesCache = new Uint8Array(await res.arrayBuffer());
    return wasmBytesCache;
}

function epochNanoseconds() {
    const hrTime = process.hrtime.bigint();
    return `${BigInt(Date.now()) * 1_000_000n + (hrTime % 1_000_000n)}`;
}

class EaseMateWasmSigner {
    constructor({ wasmBytes, origin = ORIGIN, visitorId, identityId = "" }) {
        this.wasmBytes = wasmBytes;
        this.origin = origin;
        this.visitorId = visitorId;
        this.identityId = identityId;
        this.wasm = null;
        this.WASM_VECTOR_LEN = 0;
        this.cachedUint8ArrayMemory0 = null;
        this.cachedDataViewMemory0 = null;
        this.decoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
        this.encoder = new TextEncoder();
        this.store = new Map();
        this.refreshLocalStorage();
    }
    
    refreshLocalStorage() {
        this.store.set("app-main", JSON.stringify({
            visitorId: this.visitorId,
            identityId: this.identityId
        }));
    }
    
    setIdentityId(identityId) {
        this.identityId = identityId || "";
        this.refreshLocalStorage();
    }
    
    getUint8ArrayMemory0() {
        if (this.cachedUint8ArrayMemory0 === null || this.cachedUint8ArrayMemory0.byteLength === 0) {
            this.cachedUint8ArrayMemory0 = new Uint8Array(this.wasm.memory.buffer);
        }
        return this.cachedUint8ArrayMemory0;
    }
    
    getDataViewMemory0() {
        if (this.cachedDataViewMemory0 === null || this.cachedDataViewMemory0.buffer !== this.wasm.memory.buffer) {
            this.cachedDataViewMemory0 = new DataView(this.wasm.memory.buffer);
        }
        return this.cachedDataViewMemory0;
    }
    
    getStringFromWasm0(ptr, len) {
        ptr = ptr >>> 0;
        return this.decoder.decode(this.getUint8ArrayMemory0().subarray(ptr, ptr + len));
    }
    
    passStringToWasm0(arg, malloc, realloc) {
        if (realloc === undefined) {
            const buf = this.encoder.encode(arg);
            const ptr = malloc(buf.length, 1) >>> 0;
            this.getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
            this.WASM_VECTOR_LEN = buf.length;
            return ptr;
        }
        
        let len = arg.length;
        let ptr = malloc(len, 1) >>> 0;
        const mem = this.getUint8ArrayMemory0();
        let offset = 0;
        
        for (; offset < len; offset++) {
            const code = arg.charCodeAt(offset);
            if (code > 0x7f) break;
            mem[ptr + offset] = code;
        }
        
        if (offset !== len) {
            if (offset !== 0) arg = arg.slice(offset);
            ptr = realloc(ptr, len, (len = offset + arg.length * 3), 1) >>> 0;
            const view = this.getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
            const ret = this.encoder.encodeInto(arg, view);
            offset += ret.written || 0;
            ptr = realloc(ptr, len, offset, 1) >>> 0;
        }
        
        this.WASM_VECTOR_LEN = offset;
        return ptr;
    }
    
    addToExternrefTable0(obj) {
        const idx = this.wasm.__externref_table_alloc();
        this.wasm.__wbindgen_export_2.set(idx, obj);
        return idx;
    }
    
    handleError(fn, args) {
        try {
            return fn.apply(null, args);
        } catch (err) {
            const idx = this.addToExternrefTable0(err);
            this.wasm.__wbindgen_exn_store(idx);
            return undefined;
        }
    }
    
    async init() {
        const fakeWindow = {};
        const localStorage = { getItem: (key) => this.store.get(key) ?? null };
        
        class Window {}
        Object.setPrototypeOf(fakeWindow, Window.prototype);
        fakeWindow.location = { origin: this.origin };
        fakeWindow.localStorage = localStorage;
        
        globalThis.Window = Window;
        globalThis.window = fakeWindow;
        globalThis.self = fakeWindow;
        
        const imports = { wbg: {} };
        
        imports.wbg.__wbg_call_13410aac570ffff7 = (...args) =>
            this.handleError((fn, thisArg) => fn.call(thisArg), args);
        
        imports.wbg.__wbg_getItem_9fc74b31b896f95a = (...args) =>
            this.handleError((retptr, obj, ptr, len) => {
                const key = this.getStringFromWasm0(ptr, len);
                const value = obj.getItem(key);
                const ptr0 = value == null ? 0 : this.passStringToWasm0(value, this.wasm.__wbindgen_malloc, this.wasm.__wbindgen_realloc);
                const len0 = this.WASM_VECTOR_LEN;
                this.getDataViewMemory0().setInt32(retptr + 4, len0, true);
                this.getDataViewMemory0().setInt32(retptr + 0, ptr0, true);
            }, args);
        
        imports.wbg.__wbg_instanceof_Window_12d20d558ef92592 = (arg) => arg instanceof Window;
        imports.wbg.__wbg_location_92d89c32ae076cab = (arg) => arg.location;
        imports.wbg.__wbg_localStorage_9330af8bf39365ba = (...args) =>
            this.handleError((arg) => {
                const value = arg.localStorage;
                return value == null ? 0 : this.addToExternrefTable0(value);
            }, args);
        
        imports.wbg.__wbg_newnoargs_254190557c45b4ec = (ptr, len) => new Function(this.getStringFromWasm0(ptr, len));
        
        imports.wbg.__wbg_origin_00892013881c6e2b = (...args) =>
            this.handleError((retptr, obj) => {
                const value = obj.origin;
                const ptr0 = this.passStringToWasm0(value, this.wasm.__wbindgen_malloc, this.wasm.__wbindgen_realloc);
                const len0 = this.WASM_VECTOR_LEN;
                this.getDataViewMemory0().setInt32(retptr + 4, len0, true);
                this.getDataViewMemory0().setInt32(retptr + 0, ptr0, true);
            }, args);
        
        imports.wbg.__wbg_static_accessor_GLOBAL_8921f820c2ce3f12 = () => this.addToExternrefTable0(globalThis);
        imports.wbg.__wbg_static_accessor_GLOBAL_THIS_f0a4409105898184 = () => this.addToExternrefTable0(globalThis);
        imports.wbg.__wbg_static_accessor_SELF_995b214ae681ff99 = () => this.addToExternrefTable0(fakeWindow);
        imports.wbg.__wbg_static_accessor_WINDOW_cde3890479c675ea = () => this.addToExternrefTable0(fakeWindow);
        imports.wbg.__wbg_stringify_b98c93d0a190446a = (...args) => this.handleError((arg) => JSON.stringify(arg), args);
        imports.wbg.__wbg_wbindgenisnull_f3037694abe4d97a = (arg) => arg === null;
        imports.wbg.__wbg_wbindgenisobject_307a53c6bd97fbf8 = (arg) => typeof arg === "object" && arg !== null;
        imports.wbg.__wbg_wbindgenisstring_d4fa939789f003b0 = (arg) => typeof arg === "string";
        imports.wbg.__wbg_wbindgenisundefined_c4b71d073b92f3c5 = (arg) => arg === undefined;
        
        imports.wbg.__wbg_wbindgenstringget_0f16a6ddddef376f = (retptr, arg) => {
            const value = typeof arg === "string" ? arg : undefined;
            let ptr0 = 0;
            let len0 = 0;
            if (value !== undefined) {
                ptr0 = this.passStringToWasm0(value, this.wasm.__wbindgen_malloc, this.wasm.__wbindgen_realloc);
                len0 = this.WASM_VECTOR_LEN;
            }
            this.getDataViewMemory0().setInt32(retptr + 4, len0, true);
            this.getDataViewMemory0().setInt32(retptr + 0, ptr0, true);
        };
        
        imports.wbg.__wbg_wbindgenthrow_451ec1a8469d7eb6 = (ptr, len) => {
            throw new Error(this.getStringFromWasm0(ptr, len));
        };
        
        imports.wbg.__wbindgen_cast_2241b6af4c4b2941 = (ptr, len) => this.getStringFromWasm0(ptr, len);
        
        imports.wbg.__wbindgen_init_externref_table = () => {
            const table = this.wasm.__wbindgen_export_2;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        };
        
        const { instance } = await WebAssembly.instantiate(this.wasmBytes, imports);
        this.wasm = instance.exports;
        this.cachedUint8ArrayMemory0 = null;
        this.cachedDataViewMemory0 = null;
        this.wasm.__wbindgen_start?.();
    }
    
    getSigns(body, forcedTimestamp = "") {
        if (!this.wasm) {
            throw new Error("WASM belum di-init.");
        }
        
        const timestamp = forcedTimestamp || epochNanoseconds();
        const ptr = this.passStringToWasm0(timestamp, this.wasm.__wbindgen_malloc, this.wasm.__wbindgen_realloc);
        const len = this.WASM_VECTOR_LEN;
        const ret = this.wasm.get_signs(body, ptr, len);
        const retPtr = ret[0];
        const retLen = ret[1];
        const text = this.getStringFromWasm0(retPtr, retLen);
        this.wasm.__wbindgen_free(retPtr, retLen, 1);
        return JSON.parse(text);
    }
}

function baseHeaders({ signer, sign, timestamp, accept = "application/json" }) {
    const headers = {
        language: LANGUAGE,
        timestamp,
        lang: LANG,
        "device-type": "web",
        "device-uuid": signer.visitorId,
        accept,
        "content-type": "application/json;charset=UTF-8",
        sign,
        site: SITE,
        "client-type": "web",
        "device-platform": DEVICE_PLATFORM,
        "user-agent": USER_AGENT,
        "client-name": CLIENT_NAME,
        origin: ORIGIN,
        referer: `${ORIGIN}/`
    };
    
    if (signer.visitorId) {
        headers["device-identifier"] = signer.visitorId;
    }
    
    if (signer.identityId) {
        headers["identity-id"] = signer.identityId;
    }
    
    if (accept.includes("text/event-stream")) {
        headers["cache-control"] = "no-cache";
    } else {
        headers["product-code"] = PRODUCT_CODE;
    }
    
    return headers;
}

async function apiPostJson(path, body, signer) {
    const { sign, timestamp } = signer.getSigns(body);
    
    const res = await fetch(`${API}${path}`, {
        method: "POST",
        headers: baseHeaders({ signer, sign, timestamp, accept: "application/json" }),
        body: JSON.stringify(body)
    });
    
    const text = await res.text();
    let json = null;
    try {
        json = JSON.parse(text);
    } catch {}
    
    return { ok: res.ok, status: res.status, text, json };
}

async function getIdentityId(signer) {
    const res = await apiPostJson("/api2/task/identity_id", {}, signer);
    const identityId = res.json?.data?.identity_id;
    
    if (res.ok && res.json?.code === 200 && identityId) {
        signer.setIdentityId(identityId);
        return identityId;
    }
    
    throw new Error(`Gagal ambil identity-id: ${res.text.slice(0, 500)}`);
}

async function createPureSession(signer) {
    const body = { model_id: MODEL_ID };
    const res = await apiPostJson("/api2/task/create_pure_session", body, signer);
    const sessionId = res.json?.data?.session_id;
    
    if (res.ok && res.json?.code === 200 && sessionId) {
        return sessionId;
    }
    
    throw new Error(`Gagal create session: ${res.text.slice(0, 500)}`);
}

function parseSSE(raw) {
    let answer = "";
    let inference = "";
    
    for (const line of raw.split(/\r?\n/)) {
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
            const outer = JSON.parse(payload);
            const inner = typeof outer.data === "string" ? JSON.parse(outer.data) : outer.data;
            if (typeof inner?.answer === "string") answer += inner.answer;
            if (typeof inner?.inference === "string") inference += inner.inference;
            if (typeof inner?.message === "string" && !inner.answer) answer += inner.message;
        } catch {}
    }
    
    return answer || inference;
}

async function execOperation({ signer, sessionId, question }) {
    const body = {
        model_id: MODEL_ID,
        session_id: sessionId,
        operation_info: { operation: question, id: 10000 },
        parameters: JSON.stringify({ webSearch: false, isThinking: true })
    };
    
    const { sign, timestamp } = signer.getSigns(body);
    
    const res = await fetch(`${API}/api2/stream/exec_operation`, {
        method: "POST",
        headers: baseHeaders({ signer, sign, timestamp, accept: "text/event-stream, text/event-stream" }),
        body: JSON.stringify(body)
    });
    
    const raw = await res.text();
    return { ok: res.ok, status: res.status, answer: parseSSE(raw), raw };
}

async function kimiAI(question) {
    const sessionStore = await loadSession();
    const wasmBytes = await loadWasmBytes();
    
    const signer = new EaseMateWasmSigner({
        wasmBytes,
        visitorId: sessionStore.deviceUUID,
        identityId: sessionStore.identityId || ""
    });
    
    await signer.init();
    
    if (!signer.identityId) {
        await getIdentityId(signer);
        sessionStore.identityId = signer.identityId;
        await saveSession(sessionStore);
    }
    
    const sessionId = await createPureSession(signer);
    const completion = await execOperation({ signer, sessionId, question });
    
    await markSessionUsed(sessionStore, signer.identityId);
    
    if (!completion.ok || !completion.answer) {
        throw new Error(`Gagal: ${completion.status}`);
    }
    
    return completion.answer;
}

module.exports = { kimiAI };