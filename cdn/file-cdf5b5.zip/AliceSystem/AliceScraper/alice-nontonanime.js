//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const axios = require("axios")
const cheerio = require("cheerio")

const base = {
  latest: "https://nontonanime.live/",
  orderAnime: "https://nontonanime.live/anime/?status&type&order",
  search: "https://nontonanime.live/?s=",
}

const nontonAnime = {
  latest: async () => {
    const { data } = await axios.get(base.latest)
    const $ = cheerio.load(data)
    return $(".listupd.normal .bsx a").map((_, el) => ({
      title: $(el).attr("title"),
      url: $(el).attr("href"),
      episode: $(el).find(".bt .epx").text().trim(),
      type: $(el).find(".limit .typez").text().trim(),
      thumbnail: $(el).find(".lazyload").attr("data-src") || $(el).find("img").attr("src"),
    })).get()
  },

  upcoming: async () => {
    const { data } = await axios.get(base.orderAnime)
    const $ = cheerio.load(data)
    return $(".listupd .bsx a").map((_, el) => {
      const episode = $(el).find(".bt .epx").text().trim()
      if (episode.toLowerCase() !== "upcoming") return null
      return {
        title: $(el).attr("title"),
        url: $(el).attr("href"),
        episode,
        type: $(el).find(".limit .typez").text().trim(),
        thumbnail: $(el).find(".lazyload").attr("data-src") || $(el).find("img").attr("src"),
      }
    }).get().filter(Boolean)
  },

  search: async (q) => {
    const { data } = await axios.get(base.search + encodeURIComponent(q))
    const $ = cheerio.load(data)
    return $(".bsx a").map((_, el) => ({
      title: $(el).attr("title"),
      url: $(el).attr("href"),
      episode: $(el).find(".bt .epx").text().trim(),
      type: $(el).find(".limit .typez").text().trim(),
      thumbnail: $(el).find(".lazyload").attr("data-src") || $(el).find("img").attr("src"),
    })).get()
  },

  details: async (url) => {
    const { data } = await axios.get(url)
    const $ = cheerio.load(data)
    return {
      title: $("h1.entry-title").text().trim(),
      thumbnail: $(".bigcover .lazyload").attr("data-src") || $(".bigcover img").attr("src"),
      synopsis: $(".entry-content p").first().text().trim(),
      status: $(".info-content .spe span:contains('Status')").text().replace("Status:", "").trim(),
      studio: $(".info-content .spe span:contains('Studio') a").text().trim(),
      season: $(".info-content .spe span:contains('Season') a").text().trim(),
      type: $(".info-content .spe span:contains('Type')").text().replace("Type:", "").trim(),
    }
  },

  download: async (url) => {
    const { data } = await axios.get(url)
    const $ = cheerio.load(data)
    const links = []

    $(".mirror option").each((_, el) => {
      const val = $(el).attr("value")
      if (val) {
        const buf = Buffer.from(val, "base64").toString("utf-8")
        const link = buf.includes("<iframe")
          ? cheerio.load(buf)("iframe").attr("src")
          : buf
        links.push(`• ${$(el).text().trim()}:\n${link}`)
      }
    })

    return links
  }
}

module.exports = nontonAnime