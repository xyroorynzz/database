//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')
const qs = require('qs')

const SpotifyDl = async (url) => {
    try {
        if (!url?.includes('spotify')) {
            return {
                status: false,
                message: 'Link Spotify tidak valid'
            };
        }

        const req = await axios.get('https://spotmate.online/en1');
        const html = req.data;

        const csrfMatch = html.match(/<meta[^>]+name="csrf-token"[^>]+content="([^"]+)"/i);
        const token = csrfMatch?.[1];

        const cookie = req.headers['set-cookie']
            .map(v => v.split(';')[0])
            .join('; ');

        const headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'x-csrf-token': token,
            'cookie': cookie,
            'x-requested-with': 'XMLHttpRequest',
            'origin': 'https://spotmate.online',
            'referer': 'https://spotmate.online/en1',
            'user-agent': 'Mozilla/5.0'
        };

        const [meta, conv] = await Promise.all([
            axios.post('https://spotmate.online/getTrackData',
                qs.stringify({ spotify_url: url }),
                { headers }
            ),
            axios.post('https://spotmate.online/convert',
                qs.stringify({ urls: url }),
                { headers }
            )
        ]);

        const m = meta.data;
        const dl = conv.data;

        if (!dl?.url) {
            return {
                status: false,
                message: 'Download gagal'
            };
        }

        return {
            status: true,
            result: {
                title: m.name,
                artist: m.artists,
                album: m.album,
                duration_ms: m.duration_ms,
                spotify: m.external_urls?.spotify,
                download: dl.url
            }
        };

    } catch (e) {
        return {
            status: false,
            message: e.message
        };
    }
};

module.exports = { SpotifyDl };