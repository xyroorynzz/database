//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const cheerio = require('cheerio')
const axios = require('axios')
const fetch = require('node-fetch')

async function mediafiredl(link) {
  if (!link) throw new Error('Link MediaFire kosong')
  if (!/www\.mediafire\.com/.test(link))
    throw new Error('Link bukan MediaFire')

  const f = await fetch(link, {
    headers: {
      'accept-encoding': 'gzip, deflate, br, zstd',
      'user-agent':
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
    }
  })

  if (!f.ok) throw new Error('Gagal membuka halaman MediaFire')

  const html = await f.text()
  const $ = cheerio.load(html)

  const url = $('.input.popsok').attr('href')
  if (!url || !/\/\/download\d+\.mediafire\.com\//.test(url))
    throw new Error('Link download tidak ditemukan')

  const name = $('.intro .filename').text()
  const size = $('.details li:nth-child(1) span').text()
  const date = $('.details li:nth-child(2) span').text()
  const type = $('.intro .filetype').text()

  const cont = {
    af: 'Africa',
    an: 'Antarctica',
    as: 'Asia',
    eu: 'Europe',
    na: 'North America',
    oc: 'Oceania',
    sa: 'South America'
  }

  const $lo = $('.DLExtraInfo-uploadLocation')

  const continent = $lo
    .find('.DLExtraInfo-uploadLocationRegion')
    .attr('data-lazyclass')
    ?.replace('continent-', '')

  const location = $lo
    .find('.DLExtraInfo-sectionDetails p')
    .text()
    .match(/from (.*?) on/)?.[1]

  const flag = $lo
    .find('.flag')
    .attr('data-lazyclass')
    ?.replace('flag-', '')

  return {
    name,
    size,
    date,
    type,
    continent: cont[continent] || 'Unknown',
    location: location || '-',
    flag: flag || '-',
    url
  }
}

module.exports = mediafiredl