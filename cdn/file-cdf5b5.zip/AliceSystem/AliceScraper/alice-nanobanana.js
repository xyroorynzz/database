//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require("axios")
const FormData = require("form-data")

function rand(max) {
  return Math.floor(Math.random() * max)
}

function spoof(extra = {}) {
  const ip = [10, rand(256), rand(256), rand(256)].join(".")
  return {
    "x-forwarded-for": ip,
    "x-real-ip": ip,
    "client-ip": ip,
    "x-client-ip": ip,
    "x-cluster-client-ip": ip,
    "x-original-forwarded-for": ip,
    ...extra
  }
}

const base = "https://caku.ai"

const api = axios.create({
  baseURL: base,
  headers: {
    accept: "*/*",
    "accept-language": "id-ID",
    origin: base,
    referer: base + "/text-to-image",
    "user-agent": "Mozilla/5.0 (Linux; Android 10)",
    ...spoof()
  }
})

let cookies = []

api.interceptors.request.use(c => {
  if (cookies.length) {
    c.headers.cookie = cookies.join("; ")
  }
  return c
})

api.interceptors.response.use(res => {
  const set = res.headers["set-cookie"]
  if (set) {
    const ck = set.map(v => v.split(";")[0])
    cookies = [...new Set([...cookies, ...ck])]
  }
  return res
})

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}

async function poll(id) {
  for (let i = 0; i < 60; i++) {
    await sleep(3000)
    try {
      const { data } = await api.get("/api/image/status/" + id)
      if (data?.status === 1) return data.outputImage
    } catch {}
  }
  throw "timeout"
}

async function nanobanana(buffer, prompt) {
  const form = new FormData()

  form.append("prompt", prompt)
  form.append("addWatermark", "false")
  form.append("inputMode", "upload")
  form.append("model", "nano-banana")

  form.append("images", buffer, {
    filename: "img.jpg",
    contentType: "image/jpeg"
  })

  const { data } = await api.post("/api/image/generate", form, {
    headers: {
      ...form.getHeaders(),
      referer: base + "/dashboard"
    }
  })

  if (!data?.taskId) {
    console.log("debug:", data)
    throw "gagal dapet task"
  }

  const result = await poll(data.taskId)

  return {
    image: result
  }
}

module.exports = { nanobanana }