//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios');
const cheerio = require('cheerio');

class CNNNews {
  constructor() {
    this.baseUrl = 'https://www.cnnindonesia.com';
  }

  async scrape() {
    const homeResponse = await axios.get(this.baseUrl);
    const $ = cheerio.load(homeResponse.data);

    const newsList = [];

    $('.nhl-list article').each((i, el) => {
      const article = $(el);
      const link = article.find('a').first();
      const url = link.attr('href');

      if (url && url !== '#') {
        newsList.push({
          url,
          title: link.find('h2').text().trim(),
          image: article.find('img').attr('src') || '',
          category:
            article
              .find('.text-cnn_red')
              .first()
              .text()
              .trim() || ''
        });
      }
    });

    const results = [];

    for (const item of newsList.slice(0, 5)) {
      try {
        const articleResponse =
          await axios.get(item.url);

        const $$ = cheerio.load(
          articleResponse.data
        );

        const content = [];

        $$('.detail-text p').each(
          (i, el) => {
            const text = $$(el)
              .text()
              .trim();

            if (
              text &&
              !text.includes('BACA JUGA:')
            )
              content.push(text);
          }
        );

        results.push({
          title: item.title,
          url: item.url,
          image: item.image,
          category: item.category,
          date:
            $$('.text-cnn_grey.text-sm')
              .first()
              .text()
              .trim() || '',
          author:
            $$('.text-cnn_red')
              .first()
              .text()
              .trim() || '',
          content: content.slice(0, 3)
        });

      } catch {
        continue;
      }
    }

    return results;
  }
}

module.exports = CNNNews;
