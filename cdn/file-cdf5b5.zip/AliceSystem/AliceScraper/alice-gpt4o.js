//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const crypto = require("node:crypto")

const API = "https://aga-api.aichatting.net/aigc/chat/v2/professional/stream"

const MODEL = "gpt-4o-mini"

const PUBLIC_KEY_BASE64 =
"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCAdf/EyIbLBxjGqmh7qLU6/CPCzru+75+82OSPZ+nf4BFvg88drpZ6KigNW0J8TNgxe6Yms1irCZNVDyu+RXsl4y/7c2KOHc4OGTzHB5fUMiMasFUvcEs2P70e6yA/sKHZfBLG1XPhlb84Ibs3nhD3W5e2SuC+4EuVkaqzN08LQIDAQAB"

const ua =
"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36"

function makePublicKey() {
const wrapped = PUBLIC_KEY_BASE64.match(/.{1,64}/g).join("\n")

return `-----BEGIN PUBLIC KEY-----\n${wrapped}\n-----END PUBLIC KEY-----`
}

function encryptVisitorId(visitorId) {
const encrypted = crypto.publicEncrypt(
{
key: makePublicKey(),
padding: crypto.constants.RSA_PKCS1_PADDING,
},
Buffer.from(visitorId)
)

return encrypted.toString("base64")
}

function makeVisitorId() {
return crypto.randomBytes(16).toString("hex")
}

function makeConversationId() {
return crypto.randomInt(10000000, 99999999)
}

function cleanAnswer(text) {
return String(text || "")
.replace(/-=-\s*--/g, " ")
.replace(/--@DONE@--/g, "")
.replace(/\s+/g, " ")
.trim()
}

async function imageToDataUrl(buffer, mimetype) {
return `data:${mimetype};base64,${buffer.toString("base64")}`
}

async function gpt4o(prompt, imageDataUrl = "") {
const visitorId = makeVisitorId()

const userContent = [
{
type: "text",
text: prompt,
},
]

if (imageDataUrl) {
userContent.push({
type: "image_url",
image_url: {
url: imageDataUrl,
},
})
}

const body = {
spaceHandle: true,
roleId: 0,
messages: [
{
role: "user",
content: userContent,
},
],
conversationId: makeConversationId(),
model: MODEL,
}

const headers = {
"sec-ch-ua-platform": `"Android"`,
lang: "en",
"sec-ch-ua": `"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"`,
"sec-ch-ua-mobile": "?1",
vtoken: encryptVisitorId(visitorId),
source: "web",
"user-agent": ua,
accept: "text/event-stream,application/json, text/event-stream",
"content-type": "application/json",
origin: "https://www.aichatting.net",
referer: "https://www.aichatting.net/",
"sec-fetch-site": "same-site",
"sec-fetch-mode": "cors",
"sec-fetch-dest": "empty",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
priority: "u=1, i",
}

const response = await fetch(API, {
method: "POST",
headers,
body: JSON.stringify(body),
})

if (!response.ok) {
throw new Error(`HTTP Error ${response.status}`)
}

const textResult = await response.text()

let answer = ""

const lines = textResult.split(/\r?\n/)

for (const rawLine of lines) {
const line = rawLine.trim()

if (!line.startsWith("data:")) continue

const data = line.slice(5)

if (!data.trim()) continue
if (data.includes("--@DONE@--")) continue

answer += data
}

return cleanAnswer(answer)
}

module.exports = {
gpt4o,
imageToDataUrl
}