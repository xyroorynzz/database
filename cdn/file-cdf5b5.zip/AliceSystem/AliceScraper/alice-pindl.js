//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')

async function PinDL(url) {
  if (!url || (!url.includes('pin.it') && !url.includes('pinterest.com'))) {
    return {
      success: false,
      message: 'URL harus dari Pinterest / pin.it'
    }
  }

  try {

    const response = await axios.get(
      `https://savepinmedia.com/php/api/api.php?url=${encodeURIComponent(url)}`,
      {
        headers: {
          'Accept': '*/*',
          'X-Requested-With': 'XMLHttpRequest',
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      }
    )

    const html = response.data

    if (!html || !html.includes('button-download')) {
      return {
        success: false,
        message: 'Gagal mengambil data dari savepinmedia.com'
      }
    }

    const authorMatch = html.match(
      /<span>Penulis:<a[^>]*>(.*?)<\/a><\/span>/
    )

    const mediaRaw = [
      ...html.matchAll(/href="\/download\.php\?id=([^"]+)"/g)
    ].map(m => m[1])

    if (!mediaRaw.length) {
      return {
        success: false,
        message: 'Media tidak ditemukan.'
      }
    }

    const type =
      (html.includes('.mp4') || html.includes('fa-file-video-o')) &&
      !html.includes('JPEG')
        ? 'video'
        : 'image'

    return {
      success: true,
      code: 200,
      data: {
        type,
        title: '-',
        author: authorMatch
          ? authorMatch[1].trim()
          : '-',
        media: mediaRaw.map(id =>
          `https://savepinmedia.com/download.php?id=${id}`
        ),
        pinterest_url: url
      }
    }

  } catch (e) {

    return {
      success: false,
      message: e.message
    }

  }
}

module.exports = {
  PinDL
}