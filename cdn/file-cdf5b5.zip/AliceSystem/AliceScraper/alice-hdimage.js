//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')
const fs = require('fs')
const FormData = require('form-data')
const path = require('path')

const config = ['2', '4']

async function getToken() {
  const html = await axios
    .get('https://www.iloveimg.com/upscale-image')
    .then(r => r.data)

  const token = html.match(/"token":"(eyJ[^"]+)"/)?.[1]
  const task = html.match(/ilovepdfConfig\.taskId\s*=\s*'([^']+)'/)?.[1]

  if (!token || !task) throw 'Gagal ambil token'
  return { token, task }
}

async function uploadImage(imgPath, token, task) {
  const form = new FormData()
  form.append('name', path.basename(imgPath))
  form.append('chunk', '0')
  form.append('chunks', '1')
  form.append('task', task)
  form.append('preview', '1')
  form.append('v', 'web.0')
  form.append('file', fs.createReadStream(imgPath))

  const r = await axios.post(
    'https://api29g.iloveimg.com/v1/upload',
    form,
    {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${token}`,
        Origin: 'https://www.iloveimg.com',
        Referer: 'https://www.iloveimg.com/'
      }
    }
  )

  return r.data.server_filename
}

async function doUpscale(serverFilename, token, task, scale) {
  if (!config.includes(String(scale))) throw 'Invalid scale'

  const form = new FormData()
  form.append('task', task)
  form.append('server_filename', serverFilename)
  form.append('scale', scale)

  const r = await axios.post(
    'https://api29g.iloveimg.com/v1/upscale',
    form,
    {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${token}`,
        Origin: 'https://www.iloveimg.com',
        Referer: 'https://www.iloveimg.com/'
      },
      responseType: 'arraybuffer'
    }
  )

  return r.data
}

/**
 * @param {Buffer} buffer
 * @param {Number} scale 2 / 4
 */
async function aliceHdImage(buffer, scale = 4) {
  try {
    const tmp = `./tmp_${Date.now()}.jpg`
    const out = `./out_${Date.now()}.png`

    fs.writeFileSync(tmp, buffer)

    const { token, task } = await getToken()
    const serverFilename = await uploadImage(tmp, token, task)
    const result = await doUpscale(serverFilename, token, task, scale)

    fs.writeFileSync(out, result)
    fs.unlinkSync(tmp)

    return {
      status: true,
      output: out
    }
  } catch (e) {
    return {
      status: false,
      msg: String(e)
    }
  }
}

module.exports = aliceHdImage