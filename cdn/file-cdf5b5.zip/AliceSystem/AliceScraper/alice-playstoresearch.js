//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const fetch = require('node-fetch')

async function PlaystoreSearch(query) {

    const safeGet = function (obj, ...keys) {
        return keys.reduce((acc, key) => {
            if (acc === null || acc === undefined) return null
            if (Array.isArray(acc) && typeof key === 'number' && key < acc.length) {
                return acc[key]
            }
            return null
        }, obj)
    }

    const extractApps = function (content) {

        const lines = content.split('\n')
        const outer = JSON.parse(lines[2])

        const innerStr = outer[0][2]
        const inner = JSON.parse(innerStr)

        const apps = inner[0][1][0][0][0]

        const result = apps.map((app, i) => {

            const iconUrl     = safeGet(app, 1, 1, 0, 3, 2)
            const name        = safeGet(app, 2)
            const developer   = safeGet(app, 4, 0, 0, 0)
            const description = safeGet(app, 4, 1, 1, 1, 1)
            const ratingText  = safeGet(app, 6, 0, 2, 1, 0)
            const ratingValue = safeGet(app, 6, 0, 2, 1, 1)
            const storePath   = safeGet(app, 9, 4, 2)
            const storeUrl    = storePath
                ? `https://play.google.com${storePath}`
                : null

            const packageId = safeGet(app, 12, 0)

            return {
                no: i + 1,
                name,
                developer,
                description,
                rating: ratingText,
                rating_value: ratingValue,
                package_id: packageId,
                play_store_url: storeUrl,
                icon_url: iconUrl
            }

        })

        return {
            total_apps: result.length,
            source: 'Google Play Store',
            apps: result
        }

    }

    const data = new URLSearchParams()

    data.append(
        'f.req',
        `[[["lGYRle","[[[],[[10,[10,50]],true,null,[96],[null,null,[[null,null,[[[]]]]],[[[[7,1],[[1]]]]]]],[\\"${query}\\"],4,[null,1],null,null,[]]]",null,"generic"]]]`
    )

    const options = {
        method: 'POST',
        headers: {
            'User-Agent': 'okhttp/5.3.2',
            'Accept-Encoding': 'gzip',
            'content-type': 'application/x-www-form-urlencoded;charset=utf-8',
            'origin': 'https://play.google.com'
        },
        body: data
    }

    try {

        const response = await fetch(
            'https://play.google.com/_/PlayStoreUi/data/batchexecute?hl=en&gl=ID',
            options
        )

        const text = await response.text()

        return extractApps(text)

    } catch (error) {

        return {
            status: false,
            message: error.message || String(error)
        }

    }

}

module.exports = { PlaystoreSearch }