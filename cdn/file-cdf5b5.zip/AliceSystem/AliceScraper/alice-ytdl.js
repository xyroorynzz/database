//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//

const axios = require('axios')

const sleep = ms => new Promise(r => setTimeout(r, ms))

function extractId(url) {
  const p = [
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /watch\?v=([a-zA-Z0-9_-]{11})/,
    /shorts\/([a-zA-Z0-9_-]{11})/,
    /live\/([a-zA-Z0-9_-]{11})/,
    /embed\/([a-zA-Z0-9_-]{11})/
  ]
  for (const r of p) {
    const m = url.match(r)
    if (m) return m[1]
  }
  throw new Error('invalid youtube url')
}

/* ===============================
   SCRAPER 1 (ETACLOUD)
=============================== */

let json = null
const gB = Buffer.from('ZXRhY2xvdWQub3Jn', 'base64').toString()

const headers1 = {
  origin: 'https://v1.y2mate.nu',
  referer: 'https://v1.y2mate.nu/',
  'user-agent': 'Mozilla/5.0',
  accept: '*/*'
}

function ts() {
  return Math.floor(Date.now() / 1000)
}

async function getjson() {
  if (json) return json
  const get = await axios.get('https://v1.y2mate.nu')
  const html = get.data
  const m = /var json = JSON\.parse\('([^']+)'\)/.exec(html)
  json = JSON.parse(m[1])
  return json
}

function authorization() {
  let e = ''
  for (let i = 0; i < json[0].length; i++) {
    e += String.fromCharCode(
      json[0][i] - json[2][json[2].length - (i + 1)]
    )
  }
  if (json[1]) e = e.split('').reverse().join('')
  return e.length > 32 ? e.slice(0, 32) : e
}

async function init() {
  const key = String.fromCharCode(json[6])
  const url = `https://eta.${gB}/api/v1/init?${key}=${authorization()}&t=${ts()}`
  const res = await axios.get(url, { headers: headers1 })
  return res.data
}

async function scraper1(url, format) {
  await getjson()

  const id = extractId(url)
  const initRes = await init()

  let res = await axios.get(
    initRes.convertURL +
    '&v=' + id +
    '&f=' + format +
    '&t=' + ts() +
    '&_=' + Math.random(),
    { headers: headers1 }
  )

  let data = res.data

  if (data.redirect === 1 && data.redirectURL) {
    const r2 = await axios.get(data.redirectURL + '&t=' + ts(), { headers: headers1 })
    data = r2.data
  }

  if (data.downloadURL) {
    return {
      id,
      title: data.title,
      format,
      download: data.downloadURL
    }
  }

  for (;;) {
    await sleep(3000)

    const progressRes = await axios.get(
      data.progressURL + '&t=' + ts(),
      { headers: headers1 }
    )

    const p = progressRes.data

    if (p.progress === 3) {
      return {
        id,
        title: p.title,
        format,
        download: data.downloadURL
      }
    }
  }
}

/* ===============================
   SCRAPER 2 (CNV.CX)
=============================== */

const headers2 = {
  'User-Agent': 'Mozilla/5.0',
  'Origin': 'https://iframe.y2meta-uk.com',
  'Referer': 'https://iframe.y2meta-uk.com/'
}

async function metadata(videoId) {
  const r = await axios.get(
    `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
  )

  return {
    title: r.data.title,
    author: r.data.author_name,
    thumbnail: `https://i.ytimg.com/vi/${videoId}/0.jpg`
  }
}

async function getkey() {
  const r = await axios.get('https://cnv.cx/v2/sanity/key', { headers: headers2 })
  return r.data.key
}

async function createjob(id, format, quality) {

  const key = await getkey()

  const r = await axios.post(
    'https://cnv.cx/v2/converter',
    new URLSearchParams({
      link: `https://youtu.be/${id}`,
      format,
      audioBitrate: '320',
      videoQuality: '720',
      filenameStyle: 'pretty',
      vCodec: 'h264'
    }).toString(),
    { headers: { ...headers2, key } }
  )

  return r.data
}

async function getJob(jobId) {
  const r = await axios.get(`https://cnv.cx/v2/status/${jobId}`, { headers: headers2 })
  return r.data
}

async function scraper2(url, format) {

  const id = extractId(url)
  const meta = await metadata(id)

  const job = await createjob(id, format)

  if (job.status === 'tunnel') {
    return {
      id,
      title: meta.title,
      format,
      download: job.url
    }
  }

  if (job.status === 'processing') {

    for (let i = 0; i < 30; i++) {

      await sleep(2000)

      const s = await getJob(job.jobId)

      if (s.status === 'completed') {
        return {
          id,
          title: meta.title,
          format,
          download: s.url
        }
      }
    }
  }
}

/* ===============================
   MAIN FALLBACK
=============================== */

async function ytdl(url, format = 'mp3') {

  try {
    return await scraper1(url, format)
  } catch (e) {
    console.log('scraper1 fail')
  }

  try {
    return await scraper2(url, format)
  } catch (e) {
    console.log('scraper2 fail')
  }

  throw new Error('all scraper failed')
}

module.exports = {
  ytdl
}