//═══════════════════════════════════════════════//
//           🚀 Alice Assistent - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
const axios = require("axios")

async function getToken() {
  const url = "https://fbdownloader.to/id"

  const { data: html } = await axios.get(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
      "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    }
  })

  const regex = /k_exp="(.*?)".*?k_token="(.*?)"/s
  const match = html.match(regex)

  if (!match) throw new Error("Token tidak ditemukan")

  return {
    k_exp: match[1],
    k_token: match[2]
  }
}

async function fbDownloader(fbUrl) {

  const { k_exp, k_token } = await getToken()

  const payload = new URLSearchParams({
    k_exp,
    k_token,
    p: "home",
    q: fbUrl,
    lang: "id",
    v: "v2",
    W: ""
  })

  const { data } = await axios.post(
    "https://fbdownloader.to/api/ajaxSearch",
    payload,
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest",
        "Origin": "https://fbdownloader.to",
        "Referer": "https://fbdownloader.to/id"
      },
      timeout: 20000
    }
  )

  if (!data || !data.data) throw new Error("Gagal mengambil data")

  const html = data.data
  const results = []

  const rowRegex = /<td class="video-quality">(.*?)<\/td>[\s\S]*?(?:href="(.*?)"|data-videourl="(.*?)")/g

  let match
  while ((match = rowRegex.exec(html)) !== null) {

    const quality = match[1].trim()
    const url = (match[2] || match[3] || "").trim()

    if (quality && url) {
      results.push({ quality, url })
    }
  }

  if (!results.length) throw new Error("Link download tidak ditemukan")

  return results
}

function pickBestQuality(results = []) {

  const parseScore = (q) => {
    const m = q.match(/(\d+)\s*p/i)
    if (m) return parseInt(m[1])

    if (/HD/i.test(q)) return 721
    if (/SD/i.test(q)) return 361

    return 0
  }

  const valid = results.filter(r => /^https?:\/\//i.test(r.url))
  if (!valid.length) return null

  valid.sort((a, b) => parseScore(b.quality) - parseScore(a.quality))

  return valid[0]
}

module.exports = { fbDownloader, pickBestQuality }