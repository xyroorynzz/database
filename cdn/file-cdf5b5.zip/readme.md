──────────────────────────────
🌸  ALICE ASSISTENT OFFICIAL INFO
──────────────────────────────

👨‍💻 Developer  : XyrooRynzz  
📜 Script Asli  : Alice Assistent GEN 2
🗓️ Dibuat       : 02 Juli 2023  
🛍️ Rilis Resmi  : 07 Juli 2024  

🌐 API       : https://aliceeapis.vercel.app
📁 CDN       : https://aliceecdn.vercel.app
📝 Report    : https://alicereport.vercel.app

──────────────────────────────
🚀 CARA MENJALANKAN SCRIPT
──────────────────────────────
1. buka panel pterodactyl kamu
2. upload file script di menu ""Files""
3. klik titik tiga (⋮) → pilih ""Unarchive""
4. masuk ke menu ""Startup""
   - jika Node.js masih versi 18, ubah ke versi 20 atau 23.  
     (disarankan Node.js versi di atas 22)
5. scroll ke bawah dan lihat ""Startup"":  
   - jika masih tertulis `npm start`, ubah jadi `npm install`.
6. pergi ke ""Console Panel"", lalu klik ""Start"".  
   - tunggu hingga muncul teks *“60 second ago”*.
7. kembali ke ""Startup"", ubah `npm install` ke `npm start`.  
8. jalankan kembali lewat ""Console"".  

──────────────────────────────
⚙️ PANDUAN SETTING
──────────────────────────────
edit file ""AliceSet.js"" untuk pengaturan dasar:

- `global.AliceBot` → nomor bot kalian
- `global.owner` → nomor owner utama
- `global.botname` → nama bot
- `global.ownername` → nama owner
- lainnya opsional, bisa kalian ubah sesuai kebutuhan

──────────────────────────────
📌 RULES (PERATURAN)
──────────────────────────────
🗓️ update rutin setiap tanggal 4
❌ dilarang menjual script (kecuali reseller resmi)
✅ boleh recode/rename script ( taro kredit base alice! )
☑️ nomor wajib di-ACC untuk masuk dalam list database
💼 diperbolehkan jual jasa sewa bot (sewabot)
🚫 dilarang menyebarluaskan & memberi code yang ada di dalam source
⚠️ jika sudah menjadi reseller/owner Alice:  
   - dilarang keras melakukan rip/scam  
   - jika ada laporan penipuan, langsung dihapus & blacklist tanpa konpensasi  
   → *ini merupakan rules utama role reseller dan owner Alice dan wajib dipatuhi.*

──────────────────────────────
⚠️ LARANGAN PENYUNTINGAN (WAJIB DIBACA)
──────────────────────────────
""DILARANG KERAS"" mengubah atau mengedit file-file berikut:
- `package.json` (library bawaan sistem)  
- `index.js`  
- `readme.md`  

sistem dilengkapi ""proteksi otomatis"".  
jika file di atas diubah — bahkan sedikit saja — maka:
- 🔒 sistem akan mendeteksi modifikasi  
- ⚠️ akses dan script akan otomatis dihentikan  
- ⛔ bot tidak akan berjalan hingga file dikembalikan ke kondisi asli

langkah ini dilakukan demi keamanan, stabilitas, dan pencegahan penyalahgunaan script.

──────────────────────────────
🔧 JIKA TERJADI KESALAHAN / FILE TEREDIT
──────────────────────────────
1. kembalikan file yang diubah ke versi asli (re-upload file original)
   - gunakan file asli dari seller/dev
2. jika tidak punya file asli, hubungi developer untuk bantuan ( sertakan bukti )  
   - telegram: https://t.me/XyrooRynzz  
3. jangan pernah mengunduh patch/script dari luar sumber resmi.  
4. jika akses terkunci, hubungi admin grup resmi untuk verifikasi dan pemulihan.

──────────────────────────────
🛒 REKOMENDASI PANEL & PROMO MEMBER
──────────────────────────────
💡 ""Rekomendasi pembelian panel:""
sangat disarankan beli panel langsung ke ""XyrooRynzz""  
– kualitas terjamin, uptime tinggi, dan dukungan penuh untuk user Alice Assistent.  

🔥 ""Promo special untuk member Alice!""  
setiap hari ada ""promo unlimited 30 hari hanya 12K fullgar"" 💥  
> promo hanya berlaku untuk member resmi Alice

📈 ""Upgrade Role Reseller & Owner:""  
• untuk menjadi ""reseller resmi"", langsung hubungi ""XyrooRynzz"" ataupun user role ""Owner""
• bila ingin naik menjadi ""owner Alice"", bisa juga langsung tanyakan ke ""XyrooRynzz""  
→ semua proses resmi dan transparan melalui kontak resmi yang tercantum di bawah.

──────────────────────────────
📢 INFORMASI TAMBAHAN
──────────────────────────────
• semua update resmi hanya diumumkan di ""Group WhatsApp"" yang ada nomor XyrooRynzz
• tidak ada update melalui platform lain  
• semua admin grup ""Alice Updated"" sudah terverifikasi dan aman untuk transaksi
• minta link group update ke seller resmi kalian

──────────────────────────────
👑 CONTACT DEVELOPER
──────────────────────────────
📞 Telegram Utama     : https://t.me/XyrooRynzz  
📢 Channel Informasi  : https://t.me/xyrooinformations  
💬 Channel Testimoni  : https://t.me/xyrootestimoni  
💚 Channel WhatsApp   : https://whatsapp.com/channel/0029Vb7M7jAIXnlhLZxpWT3K

👤 Developer Resmi © XyrooRynzz 2026

──────────────────────────────
💖 TERIMA KASIH UNTUK SEMUA MEMBER
──────────────────────────────
terima kasih kepada seluruh ""member dan reseller Alice""  
yang telah mempercayai, mendukung, dan membeli ""Alice Assistent"".  
berkat kalian, Alice terus berkembang dan menjadi lebih baik setiap harinya.
jika ada error jangan sungkan untuk lapor ke developer/group update resminya.
semoga selalu membawa manfaat, keberkahan, dan kesuksesan untuk kita semua 🌸

──────────────────────────────
