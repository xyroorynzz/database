
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 10) return reply("❤️ Stamina kurang! Butuh 10 stamina untuk menebang pohon.\nKetik .heal untuk istirahat.")

    let woods = [
        { name: "Kayu Biasa", minGold: 10, maxGold: 30, exp: 6, chance: 50 },
        { name: "Kayu Jati", minGold: 30, maxGold: 60, exp: 12, chance: 25 },
        { name: "Kayu Cendana", minGold: 50, maxGold: 100, exp: 20, chance: 15 },
        { name: "Kayu Hitam", minGold: 80, maxGold: 150, exp: 30, chance: 8 },
        { name: "Kayu Ajaib", minGold: 150, maxGold: 300, exp: 50, chance: 2 }
    ]

    let totalChance = woods.reduce((sum, wood) => sum + wood.chance, 0)
    let random = Math.random() * totalChance
    let cumulative = 0
    let selectedWood = woods[woods.length - 1]

    for (let wood of woods) {
        cumulative += wood.chance
        if (random <= cumulative) {
            selectedWood = wood
            break
        }
    }

    let goldGain = Math.floor(Math.random() * (selectedWood.maxGold - selectedWood.minGold + 1) + selectedWood.minGold)
    let expGain = selectedWood.exp

    user.stamina -= 10
    user.gold += goldGain
    user.exp += expGain
    user.woodcutting = (user.woodcutting || 0) + 1

    if (!user.inventory[selectedWood.name]) user.inventory[selectedWood.name] = 0
    user.inventory[selectedWood.name] += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🪓 *MENEBANG POHON* 🪓\n\n`
    msg += `✨ Kamu mendapatkan: *${selectedWood.name}*\n`
    msg += `📦 +1 ${selectedWood.name} (inventory)\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -10 (${user.stamina}/${user.maxStamina})\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["wood"]
handler.tags = ["rpg"]
handler.command = ["wood", "tebang"]

module.exports = handler