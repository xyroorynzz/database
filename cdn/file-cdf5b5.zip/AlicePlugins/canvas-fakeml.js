const moment = require("moment-timezone");
const axios = require("axios");
const FormData = require('form-data');

async function uploadToAliceCdn(buffer, fileName) {
  if (!Buffer.isBuffer(buffer)) {
    throw new Error('File bukan buffer');
  }

  const form = new FormData();
  form.append('cdnFile', buffer, {
    filename: fileName,
    contentType: 'application/octet-stream'
  });

  try {
    const res = await axios.post(
      'https://aliceecdn.vercel.app/upload',
      form,
      {
        headers: {
          ...form.getHeaders(),
          'Content-Length': form.getLengthSync()
        }
      }
    );

    if (res.data?.url) return res.data.url;
    throw new Error('Upload gagal: ' + JSON.stringify(res.data));
  } catch (err) {
    throw new Error(
      `Upload error: ${err.response?.data?.message || err.message}`
    );
  }
}

let handler = async (m, { Alice, text, args, reply, XReaction, prefix, command }) => {
  const name = text?.trim();

  if (!name) {
    return reply(
      `🎮 *FAKE ML PROFILE*\n\n` +
      `Gunakan perintah ini untuk membuat kartu profil Mobile Legends palsu.\n\n` +
      `*Cara penggunaan:*\n` +
      `• Kirim gambar + teks: ${prefix + command} NamaKamu\n` +
      `• Balas gambar dengan: ${prefix + command} NamaKamu\n` +
      `• Tanpa gambar akan menggunakan foto profil kamu\n\n` +
      `*Contoh:* ${prefix + command} MLBB Player\n\n` +
      `_Pastikan gambar yang dikirim jelas untuk hasil terbaik_`
    );
  }

  let buffer = null;
  let avatarUrl = null;

  if (
    m.quoted &&
    (m.quoted.type === "imageMessage" || m.quoted.mtype === "imageMessage")
  ) {
    try {
      buffer = await m.quoted.download();
    } catch (e) {
      reply(`Gagal mengambil gambar dari pesan yang dibalas`);
    }
  } else if (m.isMedia && m.type === "imageMessage") {
    try {
      buffer = await m.download();
    } catch (e) {
      reply(`Gagal mengambil gambar yang dikirim`);
    }
  } else {
    try {
      let pplu = await Alice.profilePictureUrl(m.sender, 'image');
      avatarUrl = pplu;
    } catch (error) {
      avatarUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
    }
  }

  if (!buffer && !avatarUrl) {
    return reply(`❌ Tidak ada gambar yang bisa diproses. Kirim atau balas gambar terlebih dahulu.`);
  }

  await XReaction("🕕");

  try {
    let finalUrl;
    
    if (buffer) {
      const uploadedUrl = await uploadToAliceCdn(buffer, "image.jpg");
      finalUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(uploadedUrl)}&nickname=${encodeURIComponent(name)}`;
    } else {
      finalUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(avatarUrl)}&nickname=${encodeURIComponent(name)}`;
    }

    const response = await axios.get(finalUrl, {
      responseType: "arraybuffer",
    });

    await Alice.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: `✅ Fake ML Profile untuk *${name}*`,
    }, { quoted: m });

    await XReaction("✅");
  } catch (error) {
    await XReaction("❌");
    reply(`Error: ${error.message}`);
  }
}

handler.help = ["fakeml", "mlbbfake", "mlcard", "mlfake"];
handler.tags = ["canvas"];
handler.command = ["fakeml", "mlbbfake", "mlcard", "mlfake"];

module.exports = handler;