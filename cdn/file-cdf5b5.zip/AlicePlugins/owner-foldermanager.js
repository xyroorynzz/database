const fs = require("fs")
const path = require("path")
const archiver = require("archiver")

let handler = async (m, { Alice, command, text, reply }) => {

const root = process.cwd()

// create folder
if (command === "createfolder") {

if (!text) return reply("contoh: .createfolder plugins/test")

let folder = path.join(root, text)

if (fs.existsSync(folder)) return reply("folder sudah ada")

fs.mkdirSync(folder, { recursive: true })

return reply(`📁 folder berhasil dibuat\n${text}`)
}

// delete folder
if (command === "delfolder") {

if (!text) return reply("contoh: .delfolder plugins/test")

let folder = path.join(root, text)

if (!fs.existsSync(folder)) return reply("folder tidak ditemukan")

fs.rmSync(folder, { recursive: true, force: true })

return reply(`🗑 folder dihapus\n${text}`)
}

// get folder
if (command === "getfolder") {

if (!text) return reply("contoh: .getfolder plugins")

let folder = path.join(root, text)

if (!fs.existsSync(folder)) return reply("folder tidak ditemukan")

let zipPath = path.join(root, `${Date.now()}.zip`)

let output = fs.createWriteStream(zipPath)
let archive = archiver("zip", { zlib: { level: 9 } })

archive.pipe(output)

archive.directory(folder, false)

await archive.finalize()

output.on("close", async () => {

await Alice.sendMessage(m.chat, {
document: fs.readFileSync(zipPath),
fileName: `${path.basename(folder)}.zip`,
mimetype: "application/zip"
}, { quoted: m })

fs.unlinkSync(zipPath)

})

}

}

handler.help = ["createfolder","delfolder","getfolder"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["createfolder","delfolder","getfolder"]

module.exports = handler