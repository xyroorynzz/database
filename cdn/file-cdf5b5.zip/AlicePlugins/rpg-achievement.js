const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let achievements = [
        { name: "🏆 Pemburu Pemula", req: 10, current: user.totalHunt || 0, reward: 500, claimed: user.achHunt },
        { name: "🏆 Pemburu Handal", req: 50, current: user.totalHunt || 0, reward: 2000, claimed: user.achHunt2 },
        { name: "🏆 Pemburu Legenda", req: 100, current: user.totalHunt || 0, reward: 5000, claimed: user.achHunt3 },
        { name: "⛏️ Penambang Pemula", req: 10, current: user.mining || 0, reward: 500, claimed: user.achMine },
        { name: "⛏️ Penambang Profesional", req: 50, current: user.mining || 0, reward: 2000, claimed: user.achMine2 },
        { name: "🎣 Nelayan Pemula", req: 10, current: user.fishing || 0, reward: 500, claimed: user.achFish },
        { name: "🎣 Nelayan Expert", req: 50, current: user.fishing || 0, reward: 2000, claimed: user.achFish2 },
        { name: "💼 Pekerja Keras", req: 20, current: user.workCount || 0, reward: 1000, claimed: user.achWork },
        { name: "⚔️ Jagoan Arena", req: 10, current: user.arenaWin || 0, reward: 2000, claimed: user.achArena },
        { name: "👑 Raja Arena", req: 50, current: user.arenaWin || 0, reward: 10000, claimed: user.achArena2 }
    ]

    let msg = `🏅 *ACHIEVEMENTS* 🏅\n\n`

    for (let ach of achievements) {
        let status = ach.claimed ? "✅" : (ach.current >= ach.req ? "🎯" : "🔒")
        msg += `${status} ${ach.name}\n`
        msg += `   📊 ${ach.current}/${ach.req} | 🎁 ${ach.reward} gold\n\n`
    }

    msg += `Ketik .claimach <nama> untuk klaim hadiah achievement`
    reply(msg)
}

handler.help = ["achievement"]
handler.tags = ["rpg"]
handler.command = ["achievement", "ach"]

module.exports = handler