const { Client } = require("ssh2")

let handler = async (m, { text, reply }) => {

if (!text) return reply(`contoh:
.installthema ipvps,password`)

let [ip, pw] = text.split(",")

if (!ip || !pw) return reply("Format salah! pastikan ip,password")

let ssh = new Client()

try {

ssh.on("ready", () => {

reply("🚀 Memulai instalasi Theme Elysium...")

ssh.exec("bash <(curl -s https://www.itzky.xyz/api/pterodactyl)", (err, stream) => {
if (err) throw err

stream.on("close", () => {
ssh.end()
reply("✅ Theme Elysium berhasil dipasang.")
})

stream.on("data", (data) => {
let t = data.toString()

if (t.includes("Pilih opsi")) stream.write("1\n")
if (t.includes("Yakin install")) stream.write("y\n")

})

})

}).on("error", () => {
reply("❌ IP atau password salah")
}).connect({
host: ip.trim(),
port: 22,
username: "root",
password: pw.trim()
})

} catch (e) {
console.log(e)
reply("❌ Terjadi error saat install.")
}

}

handler.help = ["installthema"]
handler.tags = ["owner"]
handler.command = ["installthema"]
handler.owner = true

module.exports = handler