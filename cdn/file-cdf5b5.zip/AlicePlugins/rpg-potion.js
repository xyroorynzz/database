const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🧪 *SHOP POTION* 🧪\n\n`
        msg += `• potion kecil - 50 gold (heal 30)\n`
        msg += `• potion sedang - 80 gold (heal 50)\n`
        msg += `• potion besar - 150 gold (heal 100)\n`
        msg += `• elixir - 500 gold (heal 200)\n\n`
        msg += `Cara pakai: .potion beli <jenis> <jumlah>\n`
        msg += `Contoh: .potion beli kecil 5\n\n`
        msg += `Atau langsung pakai dari inventory:\n.use <item>`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "beli") {
        let jenis = args[1]
        let jumlah = parseInt(args[2]) || 1

        let potions = {
            "kecil": { price: 50, heal: 30, name: "Potion Kecil" },
            "sedang": { price: 80, heal: 50, name: "Potion Sedang" },
            "besar": { price: 150, heal: 100, name: "Potion Besar" },
            "elixir": { price: 500, heal: 200, name: "Elixir" }
        }

        if (!potions[jenis]) return reply("❌ Jenis potion tidak valid!\nPilihan: kecil, sedang, besar, elixir")

        let totalPrice = potions[jenis].price * jumlah
        if (user.gold < totalPrice) return reply(`💰 Gold tidak cukup! Butuh ${totalPrice} gold`)

        user.gold -= totalPrice

        if (!user.inventory[potions[jenis].name]) user.inventory[potions[jenis].name] = 0
        user.inventory[potions[jenis].name] += jumlah

        db.updateUser(m.sender, user)

        reply(`🧪 *BELI POTION*\n\n✅ Kamu membeli ${jumlah} ${potions[jenis].name}\n💰 Harga: ${totalPrice} gold\n📦 Gold tersisa: ${user.gold}\n\nKetik .inv untuk lihat inventory.`)
    } else {
        reply(`❌ Perintah tidak dikenal!\n\n.potion beli <jenis> <jumlah>`)
    }
}

handler.help = ["potion"]
handler.tags = ["rpg"]
handler.command = ["potion"]

module.exports = handler