
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let guildData = db.getGuildData()
    let guildRanks = []

    for (let name in guildData) {
        let guild = guildData[name]
        let totalLevel = 0
        for (let member of guild.members) {
            let user = db.getUser(member)
            if (user) totalLevel += user.level
        }
        guildRanks.push({
            name: name,
            owner: guild.owner,
            members: guild.members.length,
            totalLevel: totalLevel,
            gold: guild.gold
        })
    }

    guildRanks.sort((a, b) => b.totalLevel - a.totalLevel)

    let top10 = guildRanks.slice(0, 10)
    let msg = `🏰 *RANKING GUILD* 🏰\n\n`

    for (let i = 0; i < top10.length; i++) {
        let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
        msg += `${medal} ${i+1}. ${top10[i].name}\n`
        msg += `   👑 ${top10[i].owner.split('@')[0]}\n`
        msg += `   👥 ${top10[i].members} member | 💰 ${top10[i].gold} gold\n\n`
    }

    reply(msg)
}

handler.help = ["guildrank"]
handler.tags = ["rpg"]
handler.command = ["guildrank"]

module.exports = handler