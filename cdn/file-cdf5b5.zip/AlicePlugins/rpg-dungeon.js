const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let dungeonCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (dungeonCooldown[m.sender] && now - dungeonCooldown[m.sender] < 7200000) {
        let remaining = Math.ceil((7200000 - (now - dungeonCooldown[m.sender])) / 60000)
        return reply(`⏰ Kamu sudah masuk dungeon! Tunggu ${remaining} menit lagi untuk masuk kembali.`)
    }

    if (user.stamina < 50) return reply("❤️ Stamina kurang! Butuh 50 stamina untuk masuk dungeon.\nKetik .heal atau .rest untuk istirahat.")

    let dungeons = [
        { name: "🏰 Goblin Cave", level: 1, minExp: 100, maxExp: 200, minGold: 150, maxGold: 300, minItem: 1, maxItem: 3, minDamage: 20, maxDamage: 40 },
        { name: "🐉 Dragon Lair", level: 3, minExp: 200, maxExp: 400, minGold: 300, maxGold: 600, minItem: 2, maxItem: 5, minDamage: 40, maxDamage: 70 },
        { name: "🧙 Wizard Tower", level: 5, minExp: 300, maxExp: 600, minGold: 500, maxGold: 1000, minItem: 3, maxItem: 7, minDamage: 60, maxDamage: 100 },
        { name: "💀 Undead Crypt", level: 7, minExp: 400, maxExp: 800, minGold: 700, maxGold: 1500, minItem: 4, maxItem: 10, minDamage: 80, maxDamage: 130 },
        { name: "👹 Demon Gate", level: 10, minExp: 600, maxExp: 1200, minGold: 1000, maxGold: 2000, minItem: 5, maxItem: 15, minDamage: 100, maxDamage: 180 }
    ]

    let availableDungeons = dungeons.filter(d => user.level >= d.level)
    let dungeon = availableDungeons.length > 0 ? availableDungeons[availableDungeons.length - 1] : dungeons[0]
    
    let weaponBonus = 0
    let armorBonus = 0
    
    if (user.weapon === "🗡️ Pedang Kayu") weaponBonus = 5
    else if (user.weapon === "⚔️ Pedang Besi") weaponBonus = 10
    else if (user.weapon === "🗡️ Pedang Baja") weaponBonus = 15
    else if (user.weapon === "⚔️ Excalibur") weaponBonus = 25
    
    if (user.armor === "👕 Baju Biasa") armorBonus = 3
    else if (user.armor === "🛡️ Baju Kulit") armorBonus = 6
    else if (user.armor === "⚔️ Baju Besi") armorBonus = 12
    else if (user.armor === "🛡️ Armor Dewa") armorBonus = 20
    
    let userPower = (user.level * 10) + weaponBonus + armorBonus
    let dungeonPower = (dungeon.level * 15) + 30
    
    let winChance = (userPower / (userPower + dungeonPower)) * 100
    let random = Math.random() * 100
    
    let expGain, goldGain, itemCount, damage, win
    
    if (random < winChance) {
        expGain = Math.floor(Math.random() * (dungeon.maxExp - dungeon.minExp + 1) + dungeon.minExp)
        goldGain = Math.floor(Math.random() * (dungeon.maxGold - dungeon.minGold + 1) + dungeon.minGold)
        itemCount = Math.floor(Math.random() * (dungeon.maxItem - dungeon.minItem + 1) + dungeon.minItem)
        damage = Math.floor(Math.random() * (dungeon.maxDamage - dungeon.minDamage + 1) + dungeon.minDamage)
        win = true
        
        user.exp += expGain
        user.gold += goldGain
        
        let rewardItems = ["Potion Besar", "Elixir", "Kunci Emas", "Batu Bertuah"]
        for (let i = 0; i < itemCount; i++) {
            let item = rewardItems[Math.floor(Math.random() * rewardItems.length)]
            if (!user.inventory[item]) user.inventory[item] = 0
            user.inventory[item] += 1
        }
    } else {
        expGain = Math.floor(Math.random() * 50) + 20
        goldGain = Math.floor(Math.random() * 100) + 50
        damage = Math.floor(Math.random() * (dungeon.maxDamage - dungeon.minDamage + 1) + dungeon.minDamage) * 1.5
        itemCount = 0
        win = false
        
        user.exp += expGain
        user.gold -= Math.floor(goldGain / 2)
        if (user.gold < 0) user.gold = 0
    }
    
    user.stamina -= 50
    if (user.stamina < 0) user.stamina = 0

    if (!user.dungeonCount) user.dungeonCount = 0
    user.dungeonCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    dungeonCooldown[m.sender] = now

    let msg = `🏯 *DUNGEON EXPLORATION* 🏯\n\n`
    msg += `📍 Dungeon: ${dungeon.name}\n`
    
    if (win) {
        msg += `✨ KAMU BERHASIL MELEWATI DUNGEON!\n\n`
        msg += `📈 EXP +${expGain}\n`
        msg += `💰 Gold +${goldGain}\n`
        msg += `📦 Item +${itemCount} item langka\n`
    } else {
        msg += `💀 KAMU GAGAL MELEWATI DUNGEON!\n\n`
        msg += `📈 EXP +${expGain} (hiburan)\n`
        msg += `💰 Gold -${Math.floor(goldGain / 2)}\n`
        msg += `💔 Kamu terluka parah!\n`
    }
    
    msg += `💔 Damage diterima: ${Math.floor(damage)}\n`
    msg += `❤️ Stamina -50 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Masuk Dungeon: ${user.dungeonCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .dungeon lagi setelah 2 jam!`

    reply(msg)
}

handler.help = ["dungeon"]
handler.tags = ["rpg"]
handler.command = ["dungeon"]

module.exports = handler