const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const REVIEW_FILE = path.join(STORE_DIR, 'reviews.json');
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getProducts() {
    ensureDir();
    if (!fs.existsSync(PRODUCT_FILE)) fs.writeFileSync(PRODUCT_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(PRODUCT_FILE));
}

let handler = async (m, { command, text, reply, prefix, Alice, isOwner }) => {
    const sender = m.sender;
    let reviews = loadJSON(REVIEW_FILE);

    if (command === 'review') {
        if (!text) return reply(`Contoh: ${prefix}review indomie|5|enak banget`);
        let [productName, rating, comment] = text.split('|').map(v => v.trim());
        const products = getProducts();
        const product = products.find(p => p.nama.toLowerCase() === productName.toLowerCase());
        if (!product) return reply(`Produk "${productName}" tidak ditemukan!`);
        let star = parseInt(rating);
        if (isNaN(star) || star < 1 || star > 5) return reply('Rating harus angka 1-5 bintang!');
        let history = loadJSON(HISTORY_FILE);
        if (!Array.isArray(history)) history = [];
        const pernahBeli = history.some(t => t.buyer === sender && t.items && t.items.some(i => i.nama && i.nama.toLowerCase() === productName.toLowerCase()) && t.status === 'success');
        if (!pernahBeli && !isOwner) return reply('❌ Kamu belum pernah membeli produk ini!');
        const existingReview = reviews.find(r => r.user === sender && r.produk.toLowerCase() === productName.toLowerCase());
        if (existingReview) {
            existingReview.rating = star;
            existingReview.komentar = comment || '-';
            existingReview.tanggal = new Date().toISOString();
            reply(`✅ Review produk "${productName}" berhasil diupdate!`);
        } else {
            reviews.push({
                user: sender,
                produk: product.nama,
                rating: star,
                komentar: comment || '-',
                tanggal: new Date().toISOString()
            });
            reply(`✅ Terima kasih! Review untuk "${productName}" telah ditambahkan!`);
        }
        saveJSON(REVIEW_FILE, reviews);
    }
    
    else if (command === 'lihatreview') {
        if (!text) return reply(`Contoh: ${prefix}lihatreview indomie`);
        const productName = text.trim().toLowerCase();
        const productReviews = reviews.filter(r => r.produk.toLowerCase() === productName);
        if (productReviews.length === 0) return reply(`Belum ada review untuk produk "${text}".`);
        let totalRating = 0;
        let teks = `⭐ REVIEW PRODUK: ${text.toUpperCase()}\n━━━━━━━━━━━━━━━━━━\n`;
        productReviews.forEach((r, i) => {
            const stars = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
            teks += `${i+1}. @${r.user.split('@')[0]} ${stars} (${r.rating}/5)\n`;
            teks += `   💬 "${r.komentar}"\n`;
            teks += `   📅 ${new Date(r.tanggal).toLocaleDateString('id-ID')}\n\n`;
            totalRating += r.rating;
        });
        const avgRating = (totalRating / productReviews.length).toFixed(1);
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `📊 Rata-rata rating: ${avgRating}/5 (${productReviews.length} review)`;
        await Alice.sendMessage(m.chat, { text: teks, mentions: productReviews.map(r => r.user) }, { quoted: m });
    }
    
    else if (command === 'hapusreview') {
        const ownerListPath = './AliceDatabase/owner.json';
        let ownerList = [];
        if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
        const isRealOwner = ownerList.includes(m.sender.split('@')[0]) || (global.owner && global.owner.includes(m.sender.split('@')[0]));
        if (!isRealOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${prefix}hapusreview 1`);
        const index = parseInt(text) - 1;
        let allReviews = loadJSON(REVIEW_FILE);
        if (isNaN(index) || index < 0 || index >= allReviews.length) {
            return reply('Nomor review tidak valid!');
        }
        const removed = allReviews.splice(index, 1);
        saveJSON(REVIEW_FILE, allReviews);
        await Alice.sendMessage(m.chat, { text: `🗑️ Review untuk produk "${removed[0].produk}" dari @${removed[0].user.split('@')[0]} telah dihapus.`, mentions: [removed[0].user] }, { quoted: m });
    }
    
    else if (command === 'listreview') {
        const ownerListPath = './AliceDatabase/owner.json';
        let ownerList = [];
        if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
        const isRealOwner = ownerList.includes(m.sender.split('@')[0]) || (global.owner && global.owner.includes(m.sender.split('@')[0]));
        if (!isRealOwner) return reply('❌ Khusus owner!');
        let allReviews = loadJSON(REVIEW_FILE);
        if (allReviews.length === 0) return reply('Belum ada review.');
        let teks = `📋 SEMUA REVIEW\n━━━━━━━━━━━━━━━━━━\n`;
        allReviews.forEach((r, i) => {
            teks += `${i+1}. @${r.user.split('@')[0]} - ${r.produk}\n`;
            teks += `   ⭐ ${r.rating}/5 - "${r.komentar.slice(0, 30)}${r.komentar.length > 30 ? '...' : ''}"\n`;
            teks += `   📅 ${new Date(r.tanggal).toLocaleDateString('id-ID')}\n\n`;
        });
        await Alice.sendMessage(m.chat, { text: teks, mentions: allReviews.map(r => r.user) }, { quoted: m });
    }
};

handler.command = ['review', 'lihatreview', 'hapusreview', 'listreview'];
handler.tags = ['store'];

module.exports = handler;