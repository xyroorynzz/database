
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null
    let itemName = null
    let qty = 1

    if (m.quoted) {
        target = m.quoted.sender
        itemName = args[0]
        qty = parseInt(args[1]) || 1
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
        itemName = args[1]
        qty = parseInt(args[2]) || 1
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                itemName = args[i+1]
                qty = parseInt(args[i+2]) || 1
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply penerima gift!\nContoh: .gift @6285252512178 potion kecil 5")
    if (target === m.sender) return reply("❌ Tidak bisa gift ke diri sendiri!")

    if (!itemName) return reply("Cara pakai: .gift @user <item> <jumlah>\nContoh: .gift @user potion kecil 5")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    let userQty = user.inventory[itemName] || 0
    if (userQty < qty) return reply(`❌ Item "${itemName}" tidak cukup! Kamu punya ${userQty}`)

    user.inventory[itemName] -= qty
    if (user.inventory[itemName] === 0) delete user.inventory[itemName]

    if (!targetUser.inventory[itemName]) targetUser.inventory[itemName] = 0
    targetUser.inventory[itemName] += qty

    db.updateUser(m.sender, user)
    db.updateUser(target, targetUser)

    reply(`🎁 *GIFT BERHASIL*\n\n📦 ${qty} ${itemName} dikirim ke @${target.split('@')[0]}\n💵 Gold kamu: ${user.gold}`, { mentions: [target] })
}

handler.help = ["gift"]
handler.tags = ["rpg"]
handler.command = ["gift", "hadiah"]

module.exports = handler