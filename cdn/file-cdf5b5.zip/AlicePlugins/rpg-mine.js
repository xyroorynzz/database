
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 15) return reply("❤️ Stamina kurang! Butuh 15 stamina untuk menambang.\nKetik .heal untuk istirahat.")

    let ores = [
        { name: "Batu Biasa", minGold: 5, maxGold: 15, exp: 5, chance: 40 },
        { name: "Batu Bara", minGold: 15, maxGold: 30, exp: 10, chance: 25 },
        { name: "Bijih Besi", minGold: 30, maxGold: 60, exp: 15, chance: 15 },
        { name: "Bijih Emas", minGold: 60, maxGold: 120, exp: 25, chance: 10 },
        { name: "Kristal", minGold: 100, maxGold: 200, exp: 40, chance: 6 },
        { name: "Permata", minGold: 200, maxGold: 500, exp: 60, chance: 3 },
        { name: "Batu Bertuah", minGold: 500, maxGold: 1000, exp: 100, chance: 1 }
    ]

    let totalChance = ores.reduce((sum, ore) => sum + ore.chance, 0)
    let random = Math.random() * totalChance
    let cumulative = 0
    let selectedOre = ores[ores.length - 1]

    for (let ore of ores) {
        cumulative += ore.chance
        if (random <= cumulative) {
            selectedOre = ore
            break
        }
    }

    let goldGain = Math.floor(Math.random() * (selectedOre.maxGold - selectedOre.minGold + 1) + selectedOre.minGold)
    let expGain = selectedOre.exp

    user.stamina -= 15
    user.gold += goldGain
    user.exp += expGain
    user.mining = (user.mining || 0) + 1

    if (!user.inventory[selectedOre.name]) user.inventory[selectedOre.name] = 0
    user.inventory[selectedOre.name] += 1

    if (!user.dailyMineProgress) user.dailyMineProgress = 0
    user.dailyMineProgress += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `⛏️ *MENAMBANG* ⛏️\n\n`
    msg += `✨ Kamu mendapatkan: *${selectedOre.name}*\n`
    msg += `📦 +1 ${selectedOre.name} (inventory)\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -15 (${user.stamina}/${user.maxStamina})\n`
    msg += `📊 Daily Mine Progress: ${user.dailyMineProgress}/10\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["mine"]
handler.tags = ["rpg"]
handler.command = ["mine", "tambang"]

module.exports = handler