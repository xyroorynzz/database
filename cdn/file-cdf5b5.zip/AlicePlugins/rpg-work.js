const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let workCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (workCooldown[m.sender] && now - workCooldown[m.sender] < 600000) {
        let remaining = Math.ceil((600000 - (now - workCooldown[m.sender])) / 60000)
        return reply(`⏰ Kamu baru saja bekerja! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina < 10) return reply("❤️ Stamina kurang! Butuh 10 stamina untuk bekerja.\nKetik .heal untuk istirahat.")

    let jobs = [
        { name: "👨‍🌾 Petani", minGold: 30, maxGold: 70, minExp: 5, maxExp: 15 },
        { name: "👨‍🍳 Koki", minGold: 40, maxGold: 80, minExp: 8, maxExp: 18 },
        { name: "🛡️ Penjaga Kota", minGold: 50, maxGold: 100, minExp: 10, maxExp: 20 },
        { name: "🔨 Pandai Besi", minGold: 60, maxGold: 120, minExp: 12, maxExp: 22 },
        { name: "📜 Pedagang", minGold: 70, maxGold: 150, minExp: 15, maxExp: 25 },
        { name: "🧙 Penyihir", minGold: 80, maxGold: 180, minExp: 18, maxExp: 30 }
    ]

    let job = jobs[Math.floor(Math.random() * jobs.length)]
    let goldGain = Math.floor(Math.random() * (job.maxGold - job.minGold + 1) + job.minGold)
    let expGain = Math.floor(Math.random() * (job.maxExp - job.minExp + 1) + job.minExp)

    user.stamina -= 10
    user.gold += goldGain
    user.exp += expGain

    if (!user.workCount) user.workCount = 0
    user.workCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    workCooldown[m.sender] = now

    let msg = `💼 *BEKERJA* 💼\n\n`
    msg += `📋 Pekerjaan: ${job.name}\n`
    msg += `💰 Gaji: +${goldGain} gold\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -10 (${user.stamina}/${user.maxStamina})\n`
    msg += `📊 Total Bekerja: ${user.workCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\n⏰ Cooldown 10 menit`

    reply(msg)
}

handler.help = ["work"]
handler.tags = ["rpg"]
handler.command = ["work", "kerja"]

module.exports = handler