
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let marryData = {}

let handler = async (m, { reply }) => {
    let pelamar = null

    for (let [id, data] of Object.entries(marryData[m.chat] || {})) {
        if (data.target === m.sender && data.status === "pending") {
            pelamar = id
            break
        }
    }

    if (!pelamar) return reply("❌ Tidak ada lamaran untukmu!")

    delete marryData[m.chat][pelamar]

    reply(`❌ @${m.sender.split('@')[0]} menolak lamaran pernikahan!`, { mentions: [m.sender, pelamar] })
}

handler.help = ["marryreject"]
handler.tags = ["rpg"]
handler.command = ["marryreject", "tolaklamar"]

module.exports = handler