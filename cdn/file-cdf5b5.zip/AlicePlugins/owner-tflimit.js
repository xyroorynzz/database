let handler = async (m, { reply, text, mentionedJid }) => {

if (!text) return reply(`contoh:
tflimit @user 10
tflimit 628xxx 10`)

let args = text.trim().split(/ +/)

let target = m.mentionedJid[0]
  ? m.mentionedJid[0]
  : m.quoted
  ? m.quoted.sender
  : args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"

let jumlah = parseInt(args[1])

if (!target) return reply("tag / reply / isi nomor")
if (isNaN(jumlah)) return reply("jumlah harus angka!")
if (jumlah < 1) return reply("minimal 1")

if (target === m.sender) return reply("gabisa transfer ke diri sendiri")

let senderUser = global.limitDB[m.sender]
let targetUser = global.limitDB[target]

if (!senderUser) {
  senderUser = global.limitDB[m.sender] = {
    limit: global.limitawal.free,
    lastReset: Date.now(),
    lastClaim: 0
  }
}

if (!targetUser) {
  targetUser = global.limitDB[target] = {
    limit: 0,
    lastReset: Date.now(),
    lastClaim: 0
  }
}

if (senderUser.limit < jumlah) {
  return reply(`❌ Limit kamu tidak cukup!

🎯 Limit kamu: ${senderUser.limit}`)
}

senderUser.limit -= jumlah
targetUser.limit += jumlah

global.saveLimit()

reply(`✅ Transfer limit berhasil!

👤 Dari: @${m.sender.split("@")[0]}
👤 Ke: @${target.split("@")[0]}

➖ -${jumlah}
➕ +${jumlah}

🎯 Sisa kamu: ${senderUser.limit}`, null, {
  mentions: [m.sender, target]
})

}

handler.help = ["tflimit"]
handler.tags = ["main"]
handler.command = ["tflimit","transferlimit"]

module.exports = handler