
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let marryData = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let pelamar = null

    for (let [id, data] of Object.entries(marryData[m.chat] || {})) {
        if (data.target === m.sender && data.status === "pending") {
            pelamar = id
            break
        }
    }

    if (!pelamar) return reply("❌ Tidak ada lamaran untukmu!")

    let pelamarUser = db.getUser(pelamar)
    if (!pelamarUser) {
        delete marryData[m.chat][pelamar]
        return reply("❌ Pelamar tidak ditemukan!")
    }

    if (pelamarUser.gold < 5000) {
        delete marryData[m.chat][pelamar]
        return reply(`💰 Gold pelamar tidak cukup untuk biaya pernikahan! Lamaran dibatalkan.`)
    }

    pelamarUser.gold -= 5000
    pelamarUser.married = m.sender
    user.married = pelamar

    db.updateUser(pelamar, pelamarUser)
    db.updateUser(m.sender, user)

    delete marryData[m.chat][pelamar]

    let msg = `💍 *PERNIKAHAN BERHASIL*\n\n`
    msg += `🎉 @${pelamar.split('@')[0]} dan @${m.sender.split('@')[0]} resmi menikah! 🎉\n\n`
    msg += `Biaya pernikahan 5000 gold telah dipotong dari @${pelamar.split('@')[0]}\n\n`
    msg += `Ketik .my untuk lihat status pernikahan.`

    reply(msg, { mentions: [pelamar, m.sender] })
}

handler.help = ["marryaccept"]
handler.tags = ["rpg"]
handler.command = ["marryaccept", "terimalamar"]

module.exports = handler