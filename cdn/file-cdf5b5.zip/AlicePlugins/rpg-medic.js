
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let medicCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (medicCooldown[m.sender] && now - medicCooldown[m.sender] < 3600000) {
        let remaining = Math.ceil((3600000 - (now - medicCooldown[m.sender])) / 60000)
        return reply(`⏰ Kamu baru saja ke dokter! Tunggu ${remaining} menit lagi.`)
    }

    let cost = 500
    if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold untuk berobat`)

    if (user.stamina >= user.maxStamina) {
        return reply(`❤️ Stamina sudah penuh! (${user.stamina}/${user.maxStamina})`)
    }

    user.gold -= cost
    user.stamina = user.maxStamina
    medicCooldown[m.sender] = now

    db.updateUser(m.sender, user)

    reply(`🏥 *BEROBAT KE DOKTER* 🏥\n\n💰 Gold -${cost}\n❤️ Stamina pulih penuh! (${user.stamina}/${user.maxStamina})\n\nKetik .medic lagi setelah 1 jam`)
}

handler.help = ["medic"]
handler.tags = ["rpg"]
handler.command = ["medic", "dokter"]

module.exports = handler