const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) return reply("Cara pakai: .claimach <nama>\nContoh: .claimach pemburu")

    let achievements = [
        { name: "pemburu pemula", req: 10, current: user.totalHunt || 0, reward: 500, claimed: user.achHunt, field: "achHunt" },
        { name: "pemburu handal", req: 50, current: user.totalHunt || 0, reward: 2000, claimed: user.achHunt2, field: "achHunt2" },
        { name: "pemburu legenda", req: 100, current: user.totalHunt || 0, reward: 5000, claimed: user.achHunt3, field: "achHunt3" },
        { name: "penambang pemula", req: 10, current: user.mining || 0, reward: 500, claimed: user.achMine, field: "achMine" },
        { name: "penambang profesional", req: 50, current: user.mining || 0, reward: 2000, claimed: user.achMine2, field: "achMine2" },
        { name: "nelayan pemula", req: 10, current: user.fishing || 0, reward: 500, claimed: user.achFish, field: "achFish" },
        { name: "nelayan expert", req: 50, current: user.fishing || 0, reward: 2000, claimed: user.achFish2, field: "achFish2" },
        { name: "pekerja keras", req: 20, current: user.workCount || 0, reward: 1000, claimed: user.achWork, field: "achWork" },
        { name: "jagoan arena", req: 10, current: user.arenaWin || 0, reward: 2000, claimed: user.achArena, field: "achArena" },
        { name: "raja arena", req: 50, current: user.arenaWin || 0, reward: 10000, claimed: user.achArena2, field: "achArena2" }
    ]

    let input = args.join(" ").toLowerCase()
    let ach = achievements.find(a => a.name === input)

    if (!ach) return reply(`❌ Achievement "${args.join(" ")}" tidak ditemukan!\nKetik .achievement untuk lihat daftar.`)

    if (ach.claimed) return reply("❌ Achievement sudah pernah diklaim!")

    if (ach.current < ach.req) return reply(`❌ Achievement belum selesai! Progress: ${ach.current}/${ach.req}`)

    user.gold += ach.reward
    user[ach.field] = true

    db.updateUser(m.sender, user)

    reply(`🏅 *ACHIEVEMENT CLAIMED* 🏅\n\n✅ ${ach.name}\n💰 Gold +${ach.reward}\n\nGold sekarang: ${user.gold}`)
}

handler.help = ["claimach"]
handler.tags = ["rpg"]
handler.command = ["claimach"]

module.exports = handler