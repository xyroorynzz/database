const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 20) return reply("❤️ Stamina kurang! Butuh 20 stamina untuk berpetualang.\nKetik .heal untuk istirahat.")

    let events = [
        { name: "🌳 Hutan Ajaib", minExp: 20, maxExp: 50, minGold: 30, maxGold: 80, minDamage: 5, maxDamage: 20, successRate: 70 },
        { name: "🏔️ Gunung Es", minExp: 30, maxExp: 60, minGold: 40, maxGold: 100, minDamage: 10, maxDamage: 30, successRate: 60 },
        { name: "🏜️ Gurun Pasir", minExp: 25, maxExp: 55, minGold: 35, maxGold: 90, minDamage: 8, maxDamage: 25, successRate: 65 },
        { name: "🌊 Lautan Dalam", minExp: 35, maxExp: 70, minGold: 50, maxGold: 120, minDamage: 15, maxDamage: 40, successRate: 55 },
        { name: "🏰 Kastil Tua", minExp: 40, maxExp: 80, minGold: 60, maxGold: 150, minDamage: 20, maxDamage: 50, successRate: 50 },
        { name: "🌋 Gunung Berapi", minExp: 45, maxExp: 90, minGold: 70, maxGold: 180, minDamage: 25, maxDamage: 60, successRate: 45 },
        { name: "🧙 Menara Sihir", minExp: 50, maxExp: 100, minGold: 80, maxGold: 200, minDamage: 30, maxDamage: 70, successRate: 40 },
        { name: "🕯️ Kuburan Tua", minExp: 55, maxExp: 110, minGold: 90, maxGold: 220, minDamage: 35, maxDamage: 80, successRate: 35 }
    ]

    let event = events[Math.floor(Math.random() * events.length)]
    
    let random = Math.random() * 100
    let expGain, goldGain, damage, success
    
    if (random < event.successRate) {
        expGain = Math.floor(Math.random() * (event.maxExp - event.minExp + 1) + event.minExp)
        goldGain = Math.floor(Math.random() * (event.maxGold - event.minGold + 1) + event.minGold)
        damage = Math.floor(Math.random() * (event.maxDamage - event.minDamage + 1) + event.minDamage)
        success = true
        
        user.exp += expGain
        user.gold += goldGain
    } else {
        expGain = Math.floor(Math.random() * 20) + 10
        goldGain = Math.floor(Math.random() * 30) + 15
        damage = Math.floor(Math.random() * (event.maxDamage - event.minDamage + 1) + event.minDamage) * 1.5
        success = false
        
        user.exp += expGain
        user.gold -= Math.floor(goldGain / 2)
        if (user.gold < 0) user.gold = 0
    }
    
    user.stamina -= 20
    if (user.stamina < 0) user.stamina = 0

    if (!user.adventureCount) user.adventureCount = 0
    user.adventureCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🧭 *BERPETUALANG* 🧭\n\n`
    msg += `📍 Lokasi: ${event.name}\n`
    
    if (success) {
        msg += `🎉 ${event.desc}\n\n`
        msg += `📈 EXP +${expGain}\n`
        msg += `💰 Gold +${goldGain}\n`
    } else {
        msg += `💀 Petualangan gagal! Kamu terjebak bahaya!\n\n`
        msg += `📈 EXP +${expGain} (pengalaman berharga)\n`
        msg += `💰 Gold -${Math.floor(goldGain / 2)}\n`
    }
    
    msg += `💔 Damage diterima: ${Math.floor(damage)}\n`
    msg += `❤️ Stamina -20 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Petualangan: ${user.adventureCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["adventure"]
handler.tags = ["rpg"]
handler.command = ["adventure", "petualang", "jelajah"]

module.exports = handler