const fs = require('fs')
const path = require('path')
const archiver = require('archiver')
const fetch = require('node-fetch')
const FormData = require('form-data')

async function sendTelegram(filePath, chatId, caption = '') {
  const url = `https://api.telegram.org/bot${global.telegramBotToken}/sendDocument`

  const form = new FormData()
  form.append('chat_id', chatId)
  form.append('caption', caption)
  form.append('document', fs.createReadStream(filePath))

  await fetch(url, {
    method: 'POST',
    body: form
  })
}

let handler = async (m, { reply, text, command }) => {

  if (!global.telegramBotToken || !global.telegramOwnerId) {
    return reply(`❌ Telegram belum disetting!

Isi dulu:
global.telegramBotToken = ""
global.telegramOwnerId = "7750303215"`)
  }

  let targetId

  if (command === 'backup') {
    targetId = global.telegramOwnerId
  } else if (command === 'sendsc') {
    if (!text) return reply('contoh:\nsendsc 123456789')
    targetId = text.trim()
  }

  const rootDir = process.cwd()
  const zipPath = path.join(rootDir, 'backup.zip')

  reply('proses backup...')

  const output = fs.createWriteStream(zipPath)
  const archive = archiver('zip', { zlib: { level: 9 } })

  output.on('close', async () => {
    try {
      const nomor = m.sender.split('@')[0]

      await sendTelegram(
        zipPath,
        targetId,
        `Backup script dari ${nomor}`
      )

      fs.unlinkSync(zipPath)
      reply(`✅ Backup berhasil dikirim ke Telegram ID: ${targetId}`)
    } catch (e) {
      reply('❌ Gagal kirim ke Telegram\n' + e)
    }
  })

  archive.on('error', () => reply('❌ Gagal membuat zip'))

  archive.pipe(output)

  archive.glob('**/*', {
    cwd: rootDir,
    dot: true,
    ignore: [
      'node_modules/**',
      'node-modules/**',
      'AliceSessions/**',
      '.git/**',
      '.pm2/**',
      'tmp/**',
      'package-lock.json',
      'backup.zip',
      'generateIntegrity.js'
    ]
  })

  archive.finalize()
}

handler.help = [
  'backup',
  'sendsc <id_telegram>'
]
handler.tags = ['owner']
handler.owner = true
handler.command = ['backup', 'sendsc']

module.exports = handler