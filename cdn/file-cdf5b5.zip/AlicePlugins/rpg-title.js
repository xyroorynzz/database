
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let titles = [
        { name: "Pemula", req: 0, type: "level", desc: "Gelar awal" },
        { name: "Petualang", req: 10, type: "level", desc: "Mencapai level 10" },
        { name: "Pemburu", req: 50, type: "hunt", desc: "Membunuh 50 monster" },
        { name: "Penambang", req: 50, type: "mine", desc: "Menambang 50 kali" },
        { name: "Nelayan", req: 50, type: "fish", desc: "Memancing 50 kali" },
        { name: "Kaya Raya", req: 50000, type: "gold", desc: "Memiliki 50k gold" }
    ]

    if (!args.length) {
        let msg = `🏆 *GELAR PEMAIN* 🏆\n\n`
        msg += `Gelar saat ini: ${user.title || "Tidak ada"}\n\n`
        for (let t of titles) {
            let owned = user.unlockedTitles?.includes(t.name) ? "✅" : "🔒"
            msg += `${owned} *${t.name}*\n   ${t.desc}\n\n`
        }
        msg += `Ketik .title list - Lihat daftar gelar\n`
        msg += `.title set <nama> - Pakai gelar\n`
        msg += `.title check - Cek gelar yang bisa di-unlock`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "check") {
        let unlocked = []
        for (let t of titles) {
            let condition = false
            if (t.type === "level" && user.level >= t.req) condition = true
            if (t.type === "hunt" && (user.totalHunt || 0) >= t.req) condition = true
            if (t.type === "mine" && (user.mining || 0) >= t.req) condition = true
            if (t.type === "fish" && (user.fishing || 0) >= t.req) condition = true
            if (t.type === "gold" && user.gold >= t.req) condition = true

            if (condition && !user.unlockedTitles?.includes(t.name)) {
                unlocked.push(t.name)
                if (!user.unlockedTitles) user.unlockedTitles = []
                user.unlockedTitles.push(t.name)
            }
        }

        if (unlocked.length > 0) {
            db.updateUser(m.sender, user)
            reply(`🎉 *GELAR BARU TERBUKA!* 🎉\n\n✅ ${unlocked.join(", ")}\n\nKetik .title set <nama> untuk memakainya.`)
        } else {
            reply(`📋 Belum ada gelar baru yang bisa di-unlock. Lanjutkan bermain!`)
        }
    }
    else if (action === "set") {
        let titleName = args.slice(1).join(" ")
        let title = titles.find(t => t.name.toLowerCase() === titleName.toLowerCase())

        if (!title) return reply(`❌ Gelar "${args.slice(1).join(" ")}" tidak ditemukan!`)

        if (!user.unlockedTitles?.includes(title.name)) return reply(`❌ Gelar "${title.name}" belum ter-unlock!`)

        user.title = title.name
        db.updateUser(m.sender, user)

        reply(`🏆 *GELAR DIUBAH* 🏆\n\n✅ Gelar sekarang: ${user.title}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.title check\n.title set <nama>\n.title list`)
    }
}

handler.help = ["title"]
handler.tags = ["rpg"]
handler.command = ["title"]

module.exports = handler