const fs = require('fs');
const path = require('path');
const axios = require('axios');

const STORE_DIR = './AliceDatabase/store-db/';
const TRANS_FILE = path.join(STORE_DIR, 'transaksi.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadTrans() {
    ensureDir();
    if (!fs.existsSync(TRANS_FILE)) fs.writeFileSync(TRANS_FILE, JSON.stringify({}));
    return JSON.parse(fs.readFileSync(TRANS_FILE));
}

function saveTrans(data) {
    ensureDir();
    fs.writeFileSync(TRANS_FILE, JSON.stringify(data, null, 2));
}

function formatmoney(amount) {
    return new Intl.NumberFormat('id-ID').format(amount);
}

let handler = async (m, { command, text, reply, prefix, Alice }) => {
    if (command === 'buyprem') {
        let args = text.trim().split(' ');
        if (args.length < 1) return reply(`Contoh: ${prefix}buyprem 7d`);
        
        const durasi = args[0].toLowerCase();
        const waktuMap = {
            '1d': { ms: 86400000, harga: 1 },
            '3d': { ms: 86400000 * 3, harga: 7000 },
            '7d': { ms: 86400000 * 7, harga: 10000 },
            '1w': { ms: 86400000 * 7, harga: 10000 },
            '1m': { ms: 86400000 * 30, harga: 20000 },
            '1y': { ms: 86400000 * 365, harga: 100000 }
        };
        
        if (!waktuMap[durasi]) return reply('Durasi tidak valid!\nContoh: 1d, 3d, 7d, 1m, 1y');
        
        let requestAmount = waktuMap[durasi].harga;
        let feeServer = Math.floor(Math.random() * 11);
        let nominal = requestAmount + feeServer;
        
        try {
            const qrisUrl = `https://www.itzky.xyz/api/tools/create/qris?nominal=${nominal}&baseQrString=${global.orkut?.codeqr || ''}`;
            const paymentInfo = `PEMBAYARAN PREMIUM\n━━━━━━━━━━━━━━━━━━\nMetode: QRIS\nBerlaku: ±10 menit\nDurasi: ${durasi}\nBiaya: Rp${formatmoney(requestAmount)}\nFee: Rp${formatmoney(feeServer)}\nTotal: Rp${formatmoney(nominal)}\n━━━━━━━━━━━━━━━━━━\n\nKetik .status untuk cek pembayaran\nKetik .cancel untuk batalkan`;
            
            const qrisMsg = await Alice.sendMessage(m.chat, { image: { url: qrisUrl }, caption: paymentInfo }, { quoted: m });
            
            let trans = loadTrans();
            trans[m.sender] = {
                jenis: 'buyprem',
                harga: nominal,
                durasi,
                key: qrisMsg.key
            };
            saveTrans(trans);
            
            let done = false;
            while (!done) {
                try {
                    const res = await axios.post("https://www.itzky.xyz/api/orderkuota/qris/history", {
                        auth_username: global.orkut?.username || '',
                        user_id: global.orkut?.id || '',
                        auth_token: global.orkut?.token || ''
                    }, { headers: { "Content-Type": "application/json" } });
                    
                    if (res.data?.result?.qris_history?.results?.length > 0) {
                        const latest = res.data.result.qris_history.results[0];
                        let kredit = parseInt(latest.kredit.replace(/\./g, ""));
                        if (latest.status === "IN" && kredit === nominal) {
                            done = true;
                            if (qrisMsg.key) await Alice.sendMessage(m.chat, { delete: qrisMsg.key });
                            
                            const premPath = './AliceDatabase/system-db/premium.json';
                            let db = fs.existsSync(premPath) ? JSON.parse(fs.readFileSync(premPath)) : {};
                            const now = Date.now(), selesai = now + waktuMap[durasi].ms;
                            
                            db[m.sender] = { expired: selesai, duration: durasi };
                            fs.writeFileSync(premPath, JSON.stringify(db, null, 2));
                            delete trans[m.sender];
                            saveTrans(trans);
                            
                            reply(`🎉 Premium aktif hingga ${new Date(selesai).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`);
                        }
                    }
                } catch (e) {
                    console.error("Error cek pembayaran:", e);
                }
                if (!done) await new Promise(r => setTimeout(r, 10000));
            }
        } catch (err) {
            console.error('QRIS error:', err);
            reply('❌ Gagal membuat atau memproses QRIS.');
        }
    }
};

handler.command = ['buyprem'];
handler.tags = ['store'];

module.exports = handler;