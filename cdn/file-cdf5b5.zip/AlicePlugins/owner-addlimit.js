let handler = async (m, { reply, text, mentionedJid }) => {

if (!text) return reply("contoh:\naddlimit @user 10\naddlimit 628xxx 10")

let args = text.trim().split(/ +/)

let target = (mentionedJid && mentionedJid[0]) 
  ? mentionedJid[0]
  : m.quoted 
  ? m.quoted.sender
  : args[0] 
  ? args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
  : null

let jumlah = parseInt(args[1])

if (!target) return reply("tag / reply / isi nomor")
if (isNaN(jumlah)) return reply("jumlahnya?")

let user = global.limitDB[target]

if (!user) {
  user = global.limitDB[target] = {
    limit: 0,
    lastReset: Date.now(),
    lastClaim: 0
  }
}

user.limit += jumlah

reply(`✅ Berhasil tambah limit

👤 User: @${target.split("@")[0]}
➕ +${jumlah}
🎯 Total: ${user.limit}`, null, {
  mentions: [target]
})

}

handler.help = ["addlimit @user 10", "addlimit 628xxx 10"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["addlimit"]

module.exports = handler