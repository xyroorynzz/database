const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🔧 *UPGRADE EQUIPMENT* 🔧\n\n`
        msg += `• upgrade weapon - ${user.level * 500} gold (meningkatkan damage)\n`
        msg += `• upgrade armor - ${user.level * 400} gold (meningkatkan defense)\n\n`
        msg += `Cara pakai: .upgrade weapon\n`
        msg += `Atau: .upgrade armor\n\n`
        msg += `⚠️ Setiap upgrade meningkatkan level equipment +1`
        return reply(msg)
    }

    let type = args[0].toLowerCase()

    if (type === "weapon") {
        let cost = user.level * 500
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold untuk upgrade weapon`)

        if (!user.weaponLevel) user.weaponLevel = 1
        user.weaponLevel += 1
        user.gold -= cost

        let weaponNames = ["🗡️ Pedang Kayu", "⚔️ Pedang Besi", "🗡️ Pedang Baja", "⚔️ Excalibur"]
        let newWeapon = weaponNames[Math.min(user.weaponLevel - 1, weaponNames.length - 1)]
        user.weapon = newWeapon

        db.updateUser(m.sender, user)

        reply(`⚔️ *UPGRADE WEAPON BERHASIL* ⚔️\n\n✅ Weapon sekarang: ${user.weapon} (Lv.${user.weaponLevel})\n💰 Biaya: ${cost} gold\n📊 Sisa gold: ${user.gold}\n\nDamage meningkat!`)
    } 
    else if (type === "armor") {
        let cost = user.level * 400
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold untuk upgrade armor`)

        if (!user.armorLevel) user.armorLevel = 1
        user.armorLevel += 1
        user.gold -= cost

        let armorNames = ["👕 Baju Biasa", "🛡️ Baju Kulit", "⚔️ Baju Besi", "🛡️ Armor Dewa"]
        let newArmor = armorNames[Math.min(user.armorLevel - 1, armorNames.length - 1)]
        user.armor = newArmor

        db.updateUser(m.sender, user)

        reply(`🛡️ *UPGRADE ARMOR BERHASIL* 🛡️\n\n✅ Armor sekarang: ${user.armor} (Lv.${user.armorLevel})\n💰 Biaya: ${cost} gold\n📊 Sisa gold: ${user.gold}\n\nDefense meningkat!`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.upgrade weapon\n.upgrade armor`)
    }
}

handler.help = ["upgrade"]
handler.tags = ["rpg"]
handler.command = ["upgrade"]

module.exports = handler