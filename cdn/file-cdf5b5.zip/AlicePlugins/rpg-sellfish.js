
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let fishPrices = {
    "Ikan Kecil": 15,
    "Ikan Mas": 30,
    "Ikan Lele": 40,
    "Ikan Gurame": 60,
    "Ikan Salmon": 100,
    "Ikan Hiu": 200,
    "Ikan Naga": 600
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🐟 *TOKO IKAN* 🐟\n\n`
        for (let [fish, price] of Object.entries(fishPrices)) {
            msg += `• ${fish} = ${price} gold\n`
        }
        msg += `\nCara pakai: .sellfish <ikan> <jumlah>`
        return reply(msg)
    }

    let fishName = args.slice(0, -1).join(" ")
    let qty = parseInt(args[args.length - 1]) || 1

    if (!fishPrices[fishName]) return reply(`❌ Ikan "${fishName}" tidak bisa dijual!`)

    let have = user.inventory[fishName] || 0
    if (have < qty) return reply(`❌ ${fishName} tidak cukup! Kamu punya ${have}`)

    let totalGold = fishPrices[fishName] * qty

    user.inventory[fishName] -= qty
    if (user.inventory[fishName] === 0) delete user.inventory[fishName]
    user.gold += totalGold

    db.updateUser(m.sender, user)

    reply(`🐟 *PENJUALAN IKAN* 🐟\n\n✅ ${qty} ${fishName} terjual!\n💰 Gold +${totalGold}\n💵 Total gold: ${user.gold}`)
}

handler.help = ["sellfish"]
handler.tags = ["rpg"]
handler.command = ["sellfish"]

module.exports = handler