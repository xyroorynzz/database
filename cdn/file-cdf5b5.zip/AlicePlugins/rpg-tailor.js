
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let tailorRecipes = {
    "baju kulit": { need: { "Kayu Biasa": 5, "Batu Bara": 2 }, result: { name: "🛡️ Baju Kulit", defense: 3, desc: "Pertahanan +3" } },
    "baju besi": { need: { "Bijih Besi": 8, "Kayu Jati": 3 }, result: { name: "⚔️ Baju Besi", defense: 7, desc: "Pertahanan +7" } },
    "armor dewa": { need: { "Bijih Emas": 10, "Kristal": 5, "Permata": 2 }, result: { name: "🛡️ Armor Dewa", defense: 15, desc: "Pertahanan +15" } }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🧵 *RESEP ARMOR* 🧵\n\n`
        for (let [item, data] of Object.entries(tailorRecipes)) {
            msg += `• ${item}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Hasil: ${data.result.name} (${data.result.desc})\n\n`
        }
        msg += `Cara pakai: .tailor baju kulit`
        return reply(msg)
    }

    let itemName = args.join(" ").toLowerCase()
    let recipe = tailorRecipes[itemName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    user.armor = recipe.result.name
    user.exp += 30

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🧵 *MEMBUAT ARMOR* 🧵\n\n`
    msg += `✅ ${recipe.result.name} berhasil dibuat!\n`
    msg += `📊 ${recipe.result.desc}\n`
    msg += `📈 EXP +30\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["tailor"]
handler.tags = ["rpg"]
handler.command = ["tailor", "buatbaju"]

module.exports = handler