
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let duelData = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let challenger = null

    for (let [id, data] of Object.entries(duelData[m.chat] || {})) {
        if (data.opponent === m.sender && data.status === "pending") {
            challenger = id
            break
        }
    }

    if (!challenger) return reply("❌ Tidak ada tantangan duel untukmu!")

    let challengerUser = db.getUser(challenger)
    if (!challengerUser) {
        delete duelData[m.chat][challenger]
        return reply("❌ Penantang tidak ditemukan!")
    }

    if (user.stamina < 25) return reply("❤️ Stamina kamu kurang! Butuh 25 stamina untuk duel.\nKetik .heal untuk istirahat.")
    if (challengerUser.stamina < 25) return reply("❤️ Stamina penantang kurang! Duel dibatalkan.")

    let bet = 100
    if (user.gold < bet) return reply(`💰 Gold kamu tidak cukup untuk taruhan ${bet} gold!`)
    if (challengerUser.gold < bet) return reply(`💰 Gold penantang tidak cukup untuk taruhan ${bet} gold! Duel dibatalkan.`)

    let powerChallenger = (challengerUser.level * 10)
    let powerUser = (user.level * 10)

    let challengerWinChance = powerChallenger / (powerChallenger + powerUser) * 100
    let random = Math.random() * 100

    let winner, loser
    if (random < challengerWinChance) {
        winner = challenger
        loser = m.sender
    } else {
        winner = m.sender
        loser = challenger
    }

    let winnerUser = db.getUser(winner)
    let loserUser = db.getUser(loser)

    winnerUser.gold += bet
    loserUser.gold -= bet
    winnerUser.stamina -= 25
    loserUser.stamina -= 25
    winnerUser.exp += 50
    loserUser.exp += 25

    winnerUser.duelWin = (winnerUser.duelWin || 0) + 1
    loserUser.duelLose = (loserUser.duelLose || 0) + 1

    let winnerLevelUp = false
    while (winnerUser.exp >= winnerUser.expNeeded) {
        winnerUser.exp -= winnerUser.expNeeded
        winnerUser.level++
        winnerUser.expNeeded = Math.floor(winnerUser.expNeeded * 1.5)
        winnerUser.maxStamina += 10
        winnerUser.stamina = winnerUser.maxStamina
        winnerLevelUp = true
    }

    let loserLevelUp = false
    while (loserUser.exp >= loserUser.expNeeded) {
        loserUser.exp -= loserUser.expNeeded
        loserUser.level++
        loserUser.expNeeded = Math.floor(loserUser.expNeeded * 1.5)
        loserUser.maxStamina += 10
        loserUser.stamina = loserUser.maxStamina
        loserLevelUp = true
    }

    db.updateUser(winner, winnerUser)
    db.updateUser(loser, loserUser)

    delete duelData[m.chat][challenger]

    let msg = `⚔️ *HASIL DUEL* ⚔️\n\n`
    msg += `🏆 Pemenang: @${winner.split('@')[0]}\n`
    msg += `💀 Yang Kalah: @${loser.split('@')[0]}\n\n`
    msg += `💰 @${winner.split('@')[0]} mendapat +${bet} gold\n`
    msg += `💰 @${loser.split('@')[0]} kehilangan -${bet} gold\n`
    msg += `📈 EXP +50 untuk pemenang\n`
    msg += `📈 EXP +25 untuk yang kalah\n`
    msg += `❤️ Stamina kedua pemain -25\n`
    msg += `🏆 Duel Record: ${winnerUser.duelWin}W/${winnerUser.duelLose}L\n`
    if (winnerLevelUp) msg += `\n🎉 *LEVEL UP! ${winnerUser.name} Level ${winnerUser.level}!* 🎉`
    if (loserLevelUp) msg += `\n🎉 *LEVEL UP! ${loserUser.name} Level ${loserUser.level}!* 🎉`

    reply(msg, { mentions: [winner, loser] })
}

handler.help = ["accept"]
handler.tags = ["rpg"]
handler.command = ["accept", "terima"]

module.exports = handler