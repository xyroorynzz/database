const moment = require("moment-timezone")
const PhoneNumber = require("awesome-phonenumber")

let handler = async (m, { Alice, text, args, reply }) => {

  let regionNames = new Intl.DisplayNames(['en'], { type: 'region' })

  let num = m.quoted?.sender || m.mentionedJid?.[0] || args[0]
  if (!num) return reply("contoh: .wastalk 628xxxx")

  num = num.replace(/\D/g, '') + "@s.whatsapp.net"

  try {

    let cek = await Alice.onWhatsApp(num)
    if (!cek[0]?.exists) return reply("user tidak ditemukan")

    let pp = await Alice.profilePictureUrl(num, "image")
      .catch(() => "https://files.catbox.moe/nwvkbt.png")

    let bio = await Alice.fetchStatus(num).catch(() => null)
    let name = await Alice.getName(num)
    let business = await Alice.getBusinessProfile(num).catch(() => null)

    let format = new PhoneNumber("+" + num.split("@")[0])
    let country = regionNames.of(format.getRegionCode("international"))

    let txt = `*[ WhatsApp Stalker ]*

° Country : ${country || "-"}
° Name : ${name || "-"}
° Number : ${format.getNumber("international")}
° Link : wa.me/${num.split("@")[0]}
° Mention : @${num.split("@")[0]}
° Status : ${bio?.status || "-"}
° Update : ${bio?.setAt ? moment(bio.setAt).locale("id").format("LL") : "-"}

${business ? `*[ WhatsApp Business ]*

° BusinessId : ${business.wid}
° Website : ${business.website || "-"}
° Email : ${business.email || "-"}
° Category : ${business.category}
° Address : ${business.address || "-"}
° Timezone : ${business?.business_hours?.timezone || "-"}
° Description : ${business.description || "-"}
` : "*Standard WhatsApp Account*"}
`

    await Alice.sendMessage(m.chat, {
      image: { url: pp },
      caption: txt,
      mentions: [num]
    }, { quoted: m })

  } catch (e) {
    reply("gagal ambil data whatsapp")
  }
}

handler.help = ["wastalk", "whatsappstalk"]
handler.tags = ["stalker"]
handler.command = ["wastalk", "whatsappstalk"]

module.exports = handler