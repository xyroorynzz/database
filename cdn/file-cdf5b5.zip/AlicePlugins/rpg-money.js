const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `💰 *MONEY SYSTEM* 💰\n\n`
        msg += `💵 Cash: ${user.gold}\n`
        msg += `🏦 Bank: ${user.bank || 0}\n`
        msg += `📊 Total Wealth: ${user.gold + (user.bank || 0)}\n`
        msg += `💳 Debt: ${user.debt || 0}\n\n`
        msg += `Command:\n`
        msg += `.money - Cek uang\n`
        msg += `.pay @user <jumlah> - Bayar ke pemain lain\n`
        msg += `.loan <jumlah> - Pinjam uang (bunga 10%)\n`
        msg += `.paydebt - Bayar hutang\n`
        msg += `.rich - Top 10 terkaya`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "pay") {
        let target = null
        let amount = null

        if (m.quoted) {
            target = m.quoted.sender
            amount = parseInt(args[1])
        } else if (m.mentionedJid && m.mentionedJid.length > 0) {
            target = m.mentionedJid[0]
            amount = parseInt(args[1])
        } else {
            for (let i = 1; i < args.length; i++) {
                let match = args[i].match(/@(\d+)/)
                if (match) {
                    target = match[1] + '@s.whatsapp.net'
                    amount = parseInt(args[i+1])
                    break
                }
            }
        }

        if (!target) return reply("⚠️ Tag/reply pemain yang ingin dibayar!\nContoh: .pay @6285252512178 5000")

        if (target === m.sender) return reply("❌ Tidak bisa bayar ke diri sendiri!")

        if (isNaN(amount) || amount < 1) return reply("💰 Masukkan jumlah gold yang benar!\nContoh: .pay @user 5000")

        if (user.gold < amount) return reply(`💰 Cash tidak cukup! Kamu hanya punya ${user.gold} gold`)

        let targetUser = db.getUser(target)
        if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

        user.gold -= amount
        targetUser.gold += amount

        db.updateUser(m.sender, user)
        db.updateUser(target, targetUser)

        reply(`💸 *PEMBAYARAN BERHASIL*\n\n📤 @${m.sender.split('@')[0]} membayar ${amount} gold ke @${target.split('@')[0]}\n💵 Sisa cash: ${user.gold}`, { mentions: [target] })
    }
    else if (action === "loan") {
        let amount = parseInt(args[1])
        if (isNaN(amount) || amount < 100) return reply("💰 Minimal pinjam 100 gold!")
        if (amount > 10000) return reply("💰 Maksimal pinjam 10000 gold!")

        let now = Date.now()
        let cooldown = 7 * 24 * 60 * 60 * 1000

        if (user.lastLoan && now - user.lastLoan < cooldown) {
            let remaining = Math.ceil((cooldown - (now - user.lastLoan)) / (24 * 60 * 60 * 1000))
            return reply(`⏰ Kamu sudah pinjam! Tunggu ${remaining} hari lagi.`)
        }

        let interest = Math.floor(amount * 0.1)
        user.gold += amount
        user.debt = (user.debt || 0) + amount + interest
        user.lastLoan = now

        db.updateUser(m.sender, user)

        reply(`💳 *PINJAMAN BERHASIL*\n\n💰 +${amount} gold\n📝 Hutang: ${user.debt} gold (termasuk bunga 10%)\n📅 Jatuh tempo: 7 hari\n\nKetik .paydebt untuk bayar hutang`)
    }
    else if (action === "paydebt") {
        if (!user.debt || user.debt <= 0) return reply("✅ Kamu tidak punya hutang!")

        let amount = parseInt(args[1]) || user.debt
        if (amount > user.debt) amount = user.debt

        if (user.gold < amount) return reply(`💰 Cash tidak cukup! Butuh ${amount} gold untuk bayar hutang`)

        user.gold -= amount
        user.debt -= amount

        db.updateUser(m.sender, user)

        reply(`💳 *BAYAR HUTANG*\n\n💰 -${amount} gold\n📝 Sisa hutang: ${user.debt || 0}\n💵 Sisa cash: ${user.gold}`)
    }
    else if (action === "rich") {
        let users = db.getAllUsers()
        let richList = []
        
        for (let id in users) {
            let u = users[id]
            let total = (u.gold || 0) + (u.bank || 0)
            richList.push({ name: u.name, total: total, id: id })
        }
        
        richList.sort((a, b) => b.total - a.total)
        let top10 = richList.slice(0, 10)
        
        let msg = `👑 *TOP 10 TERKAYA* 👑\n\n`
        for (let i = 0; i < top10.length; i++) {
            let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
            msg += `${medal} ${i+1}. ${top10[i].name}\n`
            msg += `   💰 ${top10[i].total} gold\n\n`
        }
        reply(msg)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.money - Cek uang\n.pay @user <jumlah>\n.loan <jumlah>\n.paydebt\n.rich`)
    }
}

handler.help = ["money"]
handler.tags = ["rpg"]
handler.command = ["money", "rich"]

module.exports = handler