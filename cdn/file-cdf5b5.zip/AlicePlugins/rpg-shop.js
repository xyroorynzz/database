
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let shopItems = {
    "pedang besi": { price: 300, type: "weapon", name: "⚔️ Pedang Besi", desc: "Serangan +5" },
    "pedang baja": { price: 600, type: "weapon", name: "🗡️ Pedang Baja", desc: "Serangan +10" },
    "excalibur": { price: 2000, type: "weapon", name: "⚔️ Excalibur", desc: "Serangan +20" },
    "baju kulit": { price: 250, type: "armor", name: "🛡️ Baju Kulit", desc: "Pertahanan +3" },
    "baju besi": { price: 550, type: "armor", name: "⚔️ Baju Besi", desc: "Pertahanan +7" },
    "armor dewa": { price: 1500, type: "armor", name: "🛡️ Armor Dewa", desc: "Pertahanan +15" },
    "potion kecil": { price: 50, type: "consumable", name: "Potion Kecil", heal: 30, desc: "Pulihkan 30 stamina" },
    "potion sedang": { price: 80, type: "consumable", name: "Potion Sedang", heal: 50, desc: "Pulihkan 50 stamina" },
    "potion besar": { price: 150, type: "consumable", name: "Potion Besar", heal: 100, desc: "Pulihkan 100 stamina" },
    "elixir": { price: 500, type: "consumable", name: "Elixir", heal: 200, desc: "Pulihkan 200 stamina" }
}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let list = `🏪 *TOKO RPG* 🏪\n\n`
    for (let [item, data] of Object.entries(shopItems)) {
        let merchantBonus = 1
        let finalPrice = data.price
        if (user.skills && user.skills.merchant) {
            merchantBonus = 1 - (user.skills.merchant * 0.02)
            finalPrice = Math.floor(data.price * merchantBonus)
        }
        let discText = (user.skills && user.skills.merchant && finalPrice < data.price) ? ` (Diskon ${user.skills.merchant * 2}%)` : ""
        list += `• *${item}*\n  💰 ${finalPrice} gold${discText} | ${data.desc}\n\n`
    }
    list += `Cara pakai: .beli <item>`

    reply(list)
}

handler.help = ["shop"]
handler.tags = ["rpg"]
handler.command = ["shop", "toko"]

module.exports = handler