
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let skills = {
    "kritikal": { level: 1, desc: "Meningkatkan damage 2x", cost: 1000, maxLevel: 5 },
    "defender": { level: 1, desc: "Mengurangi damage masuk 30%", cost: 1000, maxLevel: 5 },
    "healer": { level: 1, desc: "Memulihkan stamina 20% lebih banyak", cost: 1000, maxLevel: 5 },
    "hunter": { level: 1, desc: "EXP berburu +20%", cost: 1000, maxLevel: 5 },
    "merchant": { level: 1, desc: "Gold berburu +20%", cost: 1000, maxLevel: 5 }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.skills) user.skills = {}

    if (!args.length) {
        let msg = `✨ *SKILL TREE* ✨\n\n`
        for (let [name, data] of Object.entries(skills)) {
            let level = user.skills[name] || 1
            msg += `• *${name}* (Lv.${level}/${data.maxLevel})\n`
            msg += `  ${data.desc}\n`
            msg += `  🔧 Upgrade: ${data.cost * level} gold\n\n`
        }
        msg += `Ketik .skill upgrade <nama> untuk upgrade skill`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "upgrade") {
        let skillName = args[1]
        let skill = skills[skillName]

        if (!skill) return reply(`❌ Skill "${args[1]}" tidak ditemukan!`)

        let currentLevel = user.skills[skillName] || 1
        if (currentLevel >= skill.maxLevel) return reply(`❌ Skill ${skillName} sudah mencapai level maksimal!`)

        let cost = skill.cost * currentLevel
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold untuk upgrade`)

        user.gold -= cost
        user.skills[skillName] = currentLevel + 1

        db.updateUser(m.sender, user)

        reply(`✨ *SKILL UPGRADE* ✨\n\n✅ ${skillName} naik ke level ${currentLevel + 1}\n💰 Gold -${cost}\n📊 ${skill.desc}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.skill upgrade <nama>`)
    }
}

handler.help = ["skill"]
handler.tags = ["rpg"]
handler.command = ["skill"]

module.exports = handler