const axios = require('axios');

async function handler(m, { Alice, text, reply, XReaction, prefix, command }) {
    const nama = text?.trim();
    
    if (!nama) {
        return reply(
            `🎮 *FAKE FREE FIRE*\n\n` +
            `Gunakan perintah ini untuk membuat kartu profil Free Fire palsu.\n\n` +
            `*Cara penggunaan:*\n` +
            `• ${prefix + command} NamaKamu\n\n` +
            `*Contoh:* ${prefix + command} LordFF\n\n` +
            `_Hasil jadi kartu profil Free Fire keren_`
        );
    }
    
    await XReaction('🕕');
    
    try {
        const response = await axios.get(`https://api.nexray.web.id/maker/fakelobyff?nickname=${encodeURIComponent(nama)}`, {
            responseType: 'arraybuffer'
        });
        
        await Alice.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `✅ Fake Free Fire Profile untuk *${nama}*`,
        }, { quoted: m });
        
        await XReaction('✅');
        
    } catch (error) {
        await XReaction('❌');
        reply(`Error: ${error.message}`);
    }
}

handler.help = ['fakeff', 'fakefreefire'];
handler.tags = ['canvas'];
handler.command = ['fakeff', 'fakefreefire'];

module.exports = handler;