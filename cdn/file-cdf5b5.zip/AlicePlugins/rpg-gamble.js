const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let amount = parseInt(args[0])
    if (isNaN(amount) || amount < 50) return reply("💰 Masukkan jumlah taruhan minimal 50 gold!\nContoh: .gamble 100")

    if (amount > user.gold) return reply(`💰 Gold tidak cukup! Kamu hanya punya ${user.gold} gold`)

    let chance = Math.random() * 100
    let multiplier = 0

    if (chance < 5) {
        multiplier = 5
        let winAmount = amount * multiplier
        user.gold += winAmount
        reply(`🎰 *JACKPOT!* 🎰\n\n✨ Kamu mendapatkan ${multiplier}x lipat!\n💰 Menang: ${winAmount} gold\n💰 Total gold: ${user.gold}`)
    } else if (chance < 20) {
        multiplier = 2
        let winAmount = amount * multiplier
        user.gold += winAmount
        reply(`🎲 *MENANG!* 🎲\n\n✨ Kamu mendapatkan ${multiplier}x lipat!\n💰 Menang: ${winAmount} gold\n💰 Total gold: ${user.gold}`)
    } else if (chance < 40) {
        multiplier = 1.5
        let winAmount = Math.floor(amount * multiplier)
        user.gold += winAmount
        reply(`🍀 *MENANG KECIL* 🍀\n\n✨ Kamu mendapatkan ${multiplier}x lipat!\n💰 Menang: ${winAmount} gold\n💰 Total gold: ${user.gold}`)
    } else {
        user.gold -= amount
        reply(`💔 *KALAH* 💔\n\n❌ Kamu kehilangan ${amount} gold\n💰 Sisa gold: ${user.gold}\n📊 Coba lagi lain kali!`)
    }

    if (!user.gambleCount) user.gambleCount = 0
    user.gambleCount += 1

    db.updateUser(m.sender, user)
}

handler.help = ["gamble"]
handler.tags = ["rpg"]
handler.command = ["gamble", "judi"]

module.exports = handler