const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.pet) {
        user.pet = { name: "tidak punya", level: 0, exp: 0 }
    }

    if (!args.length) {
        let msg = `🐾 *PELIHARAAN KAMU*\n\n`
        msg += `Nama: ${user.pet.name}\n`
        msg += `Level: ${user.pet.level}\n`
        msg += `EXP: ${user.pet.exp}/${user.pet.level * 100 + 100}\n\n`
        msg += `Command:\n.pet beli <nama> - Beli peliharaan (1000 gold)\n.pet makan - Beri makan (+20 exp, -50 gold)\n.pet latih - Latih peliharaan (+50 exp, -100 gold)\n\nDaftar peliharaan: kucing, anjing, kelinci, burung`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "beli") {
        let petName = args[1]
        let validPets = ["kucing", "anjing", "kelinci", "burung"]

        if (!petName || !validPets.includes(petName.toLowerCase())) {
            return reply(`❌ Peliharaan tidak valid!\nDaftar: ${validPets.join(", ")}`)
        }

        if (user.pet.name !== "tidak punya") {
            return reply("❌ Kamu sudah punya peliharaan! Reset dulu dengan .resetrpg")
        }

        if (user.gold < 1000) return reply(`💰 Gold tidak cukup! Butuh 1000 gold\nGold kamu: ${user.gold}`)

        user.gold -= 1000
        user.pet = { name: petName.toLowerCase(), level: 1, exp: 0 }

        db.updateUser(m.sender, user)
        reply(`🐾 *BELI PELIHARAAN BERHASIL*\n\nKamu membeli ${petName}!\nKetik .pet untuk lihat status peliharaan.`)
    }

    else if (action === "makan") {
        if (user.pet.name === "tidak punya") return reply("❌ Kamu belum punya peliharaan! Ketik .pet beli <nama>")

        if (user.gold < 50) return reply(`💰 Gold tidak cukup! Butuh 50 gold\nGold kamu: ${user.gold}`)

        user.gold -= 50
        user.pet.exp += 20

        let levelUp = false
        let neededExp = user.pet.level * 100 + 100
        while (user.pet.exp >= neededExp) {
            user.pet.exp -= neededExp
            user.pet.level++
            neededExp = user.pet.level * 100 + 100
            levelUp = true
        }

        db.updateUser(m.sender, user)

        let msg = `🍖 *MEMBERI MAKAN PELIHARAAN*\n\n`
        msg += `🐾 ${user.pet.name} mendapat +20 EXP!\n`
        if (levelUp) msg += `🎉 *PELIHARAAN LEVEL UP! Level ${user.pet.level}!* 🎉`
        reply(msg)
    }

    else if (action === "latih") {
        if (user.pet.name === "tidak punya") return reply("❌ Kamu belum punya peliharaan! Ketik .pet beli <nama>")

        if (user.gold < 100) return reply(`💰 Gold tidak cukup! Butuh 100 gold\nGold kamu: ${user.gold}`)

        user.gold -= 100
        user.pet.exp += 50

        let levelUp = false
        let neededExp = user.pet.level * 100 + 100
        while (user.pet.exp >= neededExp) {
            user.pet.exp -= neededExp
            user.pet.level++
            neededExp = user.pet.level * 100 + 100
            levelUp = true
        }

        db.updateUser(m.sender, user)

        let msg = `🏋️ *MELATIH PELIHARAAN*\n\n`
        msg += `🐾 ${user.pet.name} mendapat +50 EXP!\n`
        if (levelUp) msg += `🎉 *PELIHARAAN LEVEL UP! Level ${user.pet.level}!* 🎉`
        reply(msg)
    }

    else {
        reply(`❌ Perintah tidak dikenal!\n\nCommand:\n.pet beli <nama>\n.pet makan\n.pet latih`)
    }
}

handler.help = ["pet"]
handler.tags = ["rpg"]
handler.command = ["pet"]

module.exports = handler