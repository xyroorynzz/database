
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let pvpData = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let challenger = null
    let bet = 0

    for (let [id, data] of Object.entries(pvpData[m.chat] || {})) {
        if (data.opponent === m.sender && data.status === "pending") {
            challenger = id
            bet = data.bet
            break
        }
    }

    if (!challenger) return reply("❌ Tidak ada tantangan PVP untukmu!")

    let challengerUser = db.getUser(challenger)
    if (!challengerUser) {
        delete pvpData[m.chat][challenger]
        return reply("❌ Penantang tidak ditemukan!")
    }

    if (user.stamina < 30) return reply("❤️ Stamina kamu kurang! Butuh 30 stamina untuk PVP.\nKetik .heal untuk istirahat.")
    if (challengerUser.stamina < 30) return reply("❤️ Stamina penantang kurang! PVP dibatalkan.")

    if (user.gold < bet) return reply(`💰 Gold kamu tidak cukup untuk taruhan ${bet} gold!`)
    if (challengerUser.gold < bet) return reply(`💰 Gold penantang tidak cukup untuk taruhan ${bet} gold! PVP dibatalkan.`)

    let weaponBonus = (w) => {
        if (w === "🗡️ Pedang Kayu") return 5
        if (w === "⚔️ Pedang Besi") return 10
        if (w === "🗡️ Pedang Baja") return 15
        if (w === "⚔️ Excalibur") return 25
        return 0
    }
    let armorBonus = (a) => {
        if (a === "👕 Baju Biasa") return 3
        if (a === "🛡️ Baju Kulit") return 6
        if (a === "⚔️ Baju Besi") return 12
        if (a === "🛡️ Armor Dewa") return 20
        return 0
    }

    let powerChallenger = (challengerUser.level * 8) + weaponBonus(challengerUser.weapon) + armorBonus(challengerUser.armor)
    let powerUser = (user.level * 8) + weaponBonus(user.weapon) + armorBonus(user.armor)

    let challengerWinChance = powerChallenger / (powerChallenger + powerUser) * 100
    let random = Math.random() * 100

    let winner, loser
    if (random < challengerWinChance) {
        winner = challenger
        loser = m.sender
    } else {
        winner = m.sender
        loser = challenger
    }

    let winnerUser = db.getUser(winner)
    let loserUser = db.getUser(loser)

    winnerUser.gold += bet
    loserUser.gold -= bet
    winnerUser.stamina -= 30
    loserUser.stamina -= 30
    winnerUser.exp += 75
    loserUser.exp += 35
    winnerUser.arenaWin = (winnerUser.arenaWin || 0) + 1
    loserUser.arenaLose = (loserUser.arenaLose || 0) + 1

    let winnerLevelUp = false
    while (winnerUser.exp >= winnerUser.expNeeded) {
        winnerUser.exp -= winnerUser.expNeeded
        winnerUser.level++
        winnerUser.expNeeded = Math.floor(winnerUser.expNeeded * 1.5)
        winnerUser.maxStamina += 10
        winnerUser.stamina = winnerUser.maxStamina
        winnerLevelUp = true
    }

    let loserLevelUp = false
    while (loserUser.exp >= loserUser.expNeeded) {
        loserUser.exp -= loserUser.expNeeded
        loserUser.level++
        loserUser.expNeeded = Math.floor(loserUser.expNeeded * 1.5)
        loserUser.maxStamina += 10
        loserUser.stamina = loserUser.maxStamina
        loserLevelUp = true
    }

    db.updateUser(winner, winnerUser)
    db.updateUser(loser, loserUser)

    delete pvpData[m.chat][challenger]

    let msg = `⚔️ *HASIL PVP* ⚔️\n\n`
    msg += `🏆 Pemenang: @${winner.split('@')[0]}\n`
    msg += `💀 Yang Kalah: @${loser.split('@')[0]}\n\n`
    msg += `💰 @${winner.split('@')[0]} mendapat +${bet} gold\n`
    msg += `💰 @${loser.split('@')[0]} kehilangan -${bet} gold\n`
    msg += `📈 EXP +75 untuk pemenang\n`
    msg += `📈 EXP +35 untuk yang kalah\n`
    msg += `❤️ Stamina kedua pemain -30\n`
    if (winnerLevelUp) msg += `\n🎉 *LEVEL UP! ${winnerUser.name} Level ${winnerUser.level}!* 🎉`
    if (loserLevelUp) msg += `\n🎉 *LEVEL UP! ${loserUser.name} Level ${loserUser.level}!* 🎉`

    reply(msg, { mentions: [winner, loser] })
}

handler.help = ["pvpaccept"]
handler.tags = ["rpg"]
handler.command = ["pvpaccept", "pvpterima"]

module.exports = handler