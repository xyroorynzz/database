const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let hasItem = false
        let list = `📦 *INVENTORY ${user.name}*\n\n`
        
        for (let [item, qty] of Object.entries(user.inventory)) {
            if (qty > 0) {
                hasItem = true
                list += `• ${item}: ${qty}\n`
            }
        }
        
        if (!hasItem) {
            list += `   Kosong\n`
        }
        
        list += `\nKetik .use <item> untuk pakai item\nContoh: .use Potion Kecil`
        return reply(list)
    }

    let itemName = args.join(" ")
    let itemQty = user.inventory[itemName]

    if (!itemQty || itemQty <= 0) return reply(`❌ Item "${itemName}" tidak ada di inventory!`)

    if (itemName.toLowerCase().includes("potion")) {
        let healAmount = 0
        if (itemName === "Potion Kecil") healAmount = 30
        else if (itemName === "Potion Sedang") healAmount = 50
        else if (itemName === "Potion Besar") healAmount = 100
        else if (itemName === "Elixir") healAmount = 200
        else return reply("❌ Item tidak bisa digunakan!")

        if (user.stamina >= user.maxStamina) {
            return reply(`❤️ Stamina sudah penuh! (${user.stamina}/${user.maxStamina})`)
        }
        
        user.stamina = Math.min(user.stamina + healAmount, user.maxStamina)
        user.inventory[itemName] -= 1
        if (user.inventory[itemName] === 0) delete user.inventory[itemName]
        
        db.updateUser(m.sender, user)
        
        reply(`🧪 *MENGGUNAKAN ${itemName}*\n\n❤️ Stamina pulih +${healAmount}\n💪 Stamina sekarang: ${user.stamina}/${user.maxStamina}`)
    } else {
        reply(`❌ Item ${itemName} tidak bisa digunakan.`)
    }
}

handler.help = ["inv", "use"]
handler.tags = ["rpg"]
handler.command = ["inv", "inventory", "use", "pakai"]

module.exports = handler