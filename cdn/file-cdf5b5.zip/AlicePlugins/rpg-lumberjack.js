
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let lumberCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (lumberCooldown[m.sender] && now - lumberCooldown[m.sender] < 3600000) {
        let remaining = Math.ceil((3600000 - (now - lumberCooldown[m.sender])) / 60000)
        return reply(`⏰ Hutan masih tumbuh! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina < 15) return reply("❤️ Stamina kurang! Butuh 15 stamina untuk menebang pohon.\nKetik .heal untuk istirahat.")

    let woods = [
        { name: "🌲 Kayu Biasa", minGold: 20, maxGold: 50, exp: 8 },
        { name: "🌳 Kayu Jati", minGold: 40, maxGold: 80, exp: 15 },
        { name: "🍃 Kayu Cendana", minGold: 60, maxGold: 120, exp: 22 },
        { name: "🪵 Kayu Hitam", minGold: 80, maxGold: 160, exp: 30 },
        { name: "✨ Kayu Ajaib", minGold: 150, maxGold: 300, exp: 50 }
    ]

    let wood = woods[Math.floor(Math.random() * woods.length)]
    let goldGain = Math.floor(Math.random() * (wood.maxGold - wood.minGold + 1) + wood.minGold)

    user.stamina -= 15
    user.gold += goldGain
    user.exp += wood.exp

    if (!user.lumberCount) user.lumberCount = 0
    user.lumberCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    lumberCooldown[m.sender] = now

    let msg = `🪓 *MENEBANG POHON* 🪓\n\n`
    msg += `🪵 Hasil: ${wood.name}\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${wood.exp}\n`
    msg += `❤️ Stamina -15 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Tebangan: ${user.lumberCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .lumber lagi setelah 1 jam!`

    reply(msg)
}

handler.help = ["lumberjack"]
handler.tags = ["rpg"]
handler.command = ["lumberjack", "tebang"]

module.exports = handler