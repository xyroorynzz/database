let { tiktokStalker } = require("../AliceSystem/AliceScraper/alice-tiktokStalker")

let handler = async (m, { args, reply }) => {
  if (!args[0]) return reply("contoh: .ttstalk username")

  try {
    let res = await tiktokStalker(args[0])
    let r = res.result

    reply(`
「 TIKTOK STALKER 」

Username   : ${r.username}
Name       : ${r.name}
Bio        : ${r.bio || "-"}
Followers  : ${r.followers}
Following  : ${r.following}
Likes      : ${r.likes}
Videos     : ${r.videoCount}
Avatar     : ${r.avatar}
`)
  } catch (e) {
    reply("error: " + e)
  }
}

handler.help = ["ttstalk", "tiktokstalk"]
handler.tags = ["stalker"]
handler.command = ["ttstalk", "tiktokstalk"]

module.exports = handler