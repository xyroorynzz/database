const truth = [
"siapa orang yang lagi kamu suka sekarang?",
"pernah kepikiran balikan sama mantan?",
"siapa orang terakhir yang kamu chat?",
"pernah baper sama seseorang di grup ini?",
"siapa di grup ini yang menurut kamu paling menarik?",
"kalau mantan tiba tiba chat kamu sekarang, kamu bakal jawab apa?",
"pernah sengaja liat story seseorang terus berharap dia chat duluan?",
"siapa orang yang paling sering kamu stalk?",
"pernah pura pura sibuk biar ga bales chat seseorang?",
"pernah cemburu padahal bukan siapa siapa?",
"kalau disuruh confess sekarang, kamu bakal pilih siapa?",
"siapa orang yang paling bikin kamu nyaman chat?",
"pernah suka sama teman sendiri?",
"hal paling memalukan yang pernah kamu lakukan demi gebetan?",
"pernah chat orang cuma karena kesepian?",
"siapa orang yang paling kamu pengen chat sekarang?",
"pernah nyesel putus sama seseorang?",
"pernah kirim chat tapi langsung dihapus karena malu?",
"pernah baca chat lama sama mantan?",
"siapa orang yang paling sering kamu pikirin akhir akhir ini?",
"pernah berharap seseorang di grup ini suka sama kamu?",
"siapa yang menurut kamu paling lucu di grup ini?",
"siapa yang paling pengen kamu ajak jalan?",
"pernah stalking ig seseorang sampai jauh banget?",
"siapa orang yang paling bikin kamu deg degan waktu chat?",
"pernah sengaja bikin story cuma buat seseorang?",
"siapa yang paling kamu kangenin sekarang?",
"kalau mantan ngajak balikan sekarang kamu mau ga?",
"pernah bohong soal perasaan kamu?",
"siapa yang menurut kamu paling perhatian ke kamu?",
"pernah pura pura ga lihat chat seseorang?",
"siapa yang paling kamu pengen peluk sekarang?",
"siapa yang menurut kamu paling misterius di grup ini?",
"pernah suka sama pacar orang?",
"siapa orang pertama yang kamu chat kalau lagi sedih?",
"siapa yang menurut kamu paling manis di grup ini?",
"pernah berharap seseorang nembak kamu duluan?",
"siapa orang yang paling sering muncul di pikiran kamu?",
"kalau boleh jujur siapa yang paling pengen kamu chat sekarang?",
"pernah kangen seseorang tapi gengsi buat chat?"
]

const dare = [
"tag seseorang di grup dan bilang kamu kangen dia",
"chat mantan kamu 'hai masih ingat aku?'",
"kirim voice note nyanyi 5 detik",
"kirim stiker lucu 5 kali",
"kirim emoji ❤️ ke chat terakhir kamu",
"tag seseorang dan bilang dia orang baik",
"chat seseorang 'lagi apa?' tanpa konteks",
"kirim pesan ke seseorang 'aku kepikiran kamu tadi'",
"spam emoji 😳 5 kali di grup",
"kirim gif random ke grup",
"tag orang yang menurut kamu paling lucu",
"chat seseorang 'aku gabut temenin ngobrol'",
"kirim voice note bilang 'aku bosan banget'",
"tag seseorang dan bilang 'kamu perhatian juga ya'",
"kirim emoji 😏 ke seseorang yang kamu chat terakhir",
"kirim stiker paling memalukan yang kamu punya",
"chat seseorang 'aku mimpiin kamu tadi'",
"tag seseorang dan bilang 'aku curiga kamu suka aku'",
"kirim pesan random 'kamu lucu juga ya'",
"tag seseorang dan bilang 'aku lagi kepikiran kamu'",
"spam stiker 3 kali sekarang",
"kirim emoji 🤭 ke orang terakhir kamu chat",
"tag seseorang dan bilang 'aku kangen ngobrol sama kamu'",
"chat seseorang 'lagi sibuk ga?'",
"kirim pesan 'aku butuh curhat'",
"tag seseorang dan bilang 'aku rasa kamu orang baik'",
"kirim voice note ketawa 3 detik",
"kirim pesan ke seseorang 'aku lagi bosan banget'",
"tag seseorang dan bilang 'aku curiga kamu perhatian sama aku'",
"kirim emoji 😶‍🌫️ ke chat terakhir",
"tag seseorang dan bilang 'aku rasa kamu lucu'",
"chat seseorang 'aku lagi kepikiran sesuatu'",
"kirim stiker random sekarang",
"tag seseorang dan bilang 'aku senang kenal kamu'",
"kirim pesan 'lagi apa sekarang?' ke seseorang",
"kirim emoji 🙃 ke orang terakhir kamu chat",
"tag seseorang dan bilang 'aku curiga kamu diam diam baik'",
"chat seseorang 'temenin ngobrol dong'",
"kirim pesan random 'aku lagi gabut banget'",
"spam emoji 😂 5 kali"
]

let handler = async (m, { reply }) => {

let type = Math.random() < 0.5 ? "truth" : "dare"

if (type === "truth") {
let t = truth[Math.floor(Math.random() * truth.length)]
reply(`truth\n\n${t}`)
} else {
let d = dare[Math.floor(Math.random() * dare.length)]
reply(`dare\n\n${d}`)
}

}

handler.help = ["tod"]
handler.tags = ["game"]
handler.command = ["dare","truth","truthordare"]

module.exports = handler