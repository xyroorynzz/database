
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let compassCost = 500
    if (user.gold < compassCost) return reply(`💰 Gold tidak cukup! Butuh ${compassCost} gold untuk membeli kompas.`)

    let quests = [
        { name: "Misi Tersembunyi", rewardGold: 2000, rewardExp: 300, desc: "Temukan harta karun di hutan" },
        { name: "Panggilan Petualang", rewardGold: 3000, rewardExp: 500, desc: "Bantu penduduk desa" },
        { name: "Legenda Kuno", rewardGold: 5000, rewardExp: 800, desc: "Cari artefak kuno" }
    ]

    let quest = quests[Math.floor(Math.random() * quests.length)]

    user.gold -= compassCost
    user.activeQuest = quest
    user.questExpires = Date.now() + (24 * 60 * 60 * 1000)

    db.updateUser(m.sender, user)

    let msg = `🧭 *KOMPAS PETUALANG* 🧭\n\n`
    msg += `💰 Gold -${compassCost}\n\n`
    msg += `📜 *${quest.name}*\n`
    msg += `${quest.desc}\n\n`
    msg += `🎁 Reward: ${quest.rewardGold} gold, ${quest.rewardExp} EXP\n`
    msg += `⏰ Berlaku 24 jam\n\n`
    msg += `Ketik .questcomplete setelah menyelesaikan misi!`

    reply(msg)
}

handler.help = ["compass"]
handler.tags = ["rpg"]
handler.command = ["compass"]

module.exports = handler