
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let enchantCooldown = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🔮 *ENCHANT ITEM* 🔮\n\n`
        msg += `Command:\n.enchant weapon - Enchant weapon (5000 gold)\n`
        msg += `.enchant armor - Enchant armor (5000 gold)\n\n`
        msg += `Enchant memberikan bonus stat acak +1 sampai +10`
        return reply(msg)
    }

    let now = Date.now()
    if (enchantCooldown[m.sender] && now - enchantCooldown[m.sender] < 86400000) {
        let remaining = Math.ceil((86400000 - (now - enchantCooldown[m.sender])) / 3600000)
        return reply(`⏰ Enchant sudah dilakukan! Tunggu ${remaining} jam lagi.`)
    }

    let type = args[0].toLowerCase()
    let cost = 5000

    if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold untuk enchant`)

    let bonus = Math.floor(Math.random() * 10) + 1
    user.gold -= cost

    if (type === "weapon") {
        user.weaponBonus = (user.weaponBonus || 0) + bonus
        reply(`⚔️ *ENCHANT WEAPON BERHASIL* ⚔️\n\n✨ Weapon mendapat +${bonus} damage!\n💰 Gold -${cost}\n💪 Total bonus weapon: +${user.weaponBonus}`)
    } else if (type === "armor") {
        user.armorBonus = (user.armorBonus || 0) + bonus
        reply(`🛡️ *ENCHANT ARMOR BERHASIL* 🛡️\n\n✨ Armor mendapat +${bonus} defense!\n💰 Gold -${cost}\n💪 Total bonus armor: +${user.armorBonus}`)
    } else {
        return reply(`❌ Pilihan tidak valid!\n.enchant weapon\n.enchant armor`)
    }

    enchantCooldown[m.sender] = now
    db.updateUser(m.sender, user)
}

handler.help = ["enchant"]
handler.tags = ["rpg"]
handler.command = ["enchant"]

module.exports = handler