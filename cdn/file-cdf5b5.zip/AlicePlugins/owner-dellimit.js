let handler = async (m, { reply, text, mentionedJid }) => {

if (!text) return reply("contoh:\ndellimit @user 10\ndellimit 628xxx 10")

let args = text.trim().split(/ +/)

let target = (mentionedJid && mentionedJid[0]) 
  ? mentionedJid[0]
  : m.quoted 
  ? m.quoted.sender
  : args[0] 
  ? args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
  : null

let jumlah = parseInt(args[1])

if (!target) return reply("tag / reply / isi nomor")
if (isNaN(jumlah)) return reply("jumlahnya?")

let user = global.limitDB[target]
if (!user) return reply("user belum ada di database")

user.limit -= jumlah
if (user.limit < 0) user.limit = 0

reply(`❌ Berhasil kurangi limit

👤 User: @${target.split("@")[0]}
➖ -${jumlah}
🎯 Sisa: ${user.limit}`, null, {
  mentions: [target]
})

}

handler.help = ["dellimit @user 10", "dellimit 628xxx 10"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["dellimit"]

module.exports = handler