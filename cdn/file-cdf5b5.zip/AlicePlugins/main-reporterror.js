const axios = require("axios");

let handler = async (m, { text, reply }) => {

    if (!text) return reply("Contoh: .report fitur tovideo error");

    try {
        let laporan = `
📢 *REPORT ERROR BOT*

👤 User : ${m.pushName || "-"}
📱 Nomor : m.sender
💬 Chat  : ${m.chat}

📝 Pesan :
${text}
`;

        await axios.post(`https://api.telegram.org/bot${global.telegramBotToken}/sendMessage`, {
            chat_id: global.telegramOwnerId,
            text: laporan,
            parse_mode: "Markdown"
        });

        reply("✅ Report berhasil dikirim ke owner.");

    } catch (e) {
        console.log(e);
        reply("❌ Gagal mengirim report.");
    }
};

handler.help = ["report"];
handler.tags = ["main"];
handler.command = ["report", "lapor"];

module.exports = handler;