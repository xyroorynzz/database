
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.weaponDurability) user.weaponDurability = 100
    if (!user.armorDurability) user.armorDurability = 100

    let msg = `🔧 *DURABILITAS EQUIPMENT* 🔧\n\n`
    msg += `⚔️ Weapon: ${user.weaponDurability}/100\n`
    msg += `🛡️ Armor: ${user.armorDurability}/100\n\n`
    msg += `Jika durability habis, equipment tidak memberikan bonus.\n`
    msg += `Ketik .repair untuk memperbaiki (100 gold per 10 durability)`

    reply(msg)
}

handler.help = ["durability"]
handler.tags = ["rpg"]
handler.command = ["durability", "durabilitas"]

module.exports = handler