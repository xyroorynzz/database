const fs = require("fs")
const path = require("path")

let handler = async (m, { command, reply }) => {

const file = path.join(process.cwd(), "./AliceZuberg.txt")

if (!fs.existsSync(file))
return reply("file alicezuberg.txt tidak ditemukan.")

const txt = fs.readFileSync(file, "utf-8")

const ambilSection = (start, end) => {
let s = txt.indexOf(start)
if (s === -1) return ""

let e = txt.indexOf(end, s)
if (e === -1) e = txt.length

return txt.slice(s, e)
}

const parseFeatures = (section) => {

let plugins = []
let cases = []
let mode = ""

section.split("\n").forEach(line => {

line = line.trim().toLowerCase()

if (line === "[plugins]") {
mode = "plugins"
return
}

if (line === "[case]") {
mode = "case"
return
}

if (line.startsWith("-")) {

let fitur = line.replace("-", "").trim()

if (mode === "plugins") plugins.push(fitur)
if (mode === "case") cases.push(fitur)

}

})

return { plugins, cases }

}

if (command === "fiturnew") {

let fiturBaruRaw = ambilSection(
"🌟 PENAMBAHAN FITUR BARU",
"🗑 FITUR YANG DIHAPUS"
)

let { plugins, cases } = parseFeatures(fiturBaruRaw)

let waktu = new Date().toLocaleString('id-ID', {
timeZone: 'Asia/Jakarta',
weekday: 'long',
day: '2-digit',
month: 'long',
year: 'numeric',
hour: '2-digit',
minute: '2-digit',
second: '2-digit'
})

let teks = `
🌟 *fitur baru bot*

🕒 ${waktu}

📦 plugins (${plugins.length})
${plugins.map(v => `- ${v}`).join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

⚙️ case features (${cases.length})
${cases.map(v => `- ${v}`).join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

total fitur baru : ${plugins.length + cases.length}
`.trim()

return reply(teks)

}

if (command === "infoupdate") {

const perubahan = ambilSection(
"🚀 PERUBAHAN & PEMBARUAN UTAMA",
"🌟 PENAMBAHAN FITUR BARU"
).match(/•.+/g) || []

const fiturBaruRaw = ambilSection(
"🌟 PENAMBAHAN FITUR BARU",
"🗑 FITUR YANG DIHAPUS"
)

const fiturHapus = ambilSection(
"🗑 FITUR YANG DIHAPUS",
"🔧 PERBAIKAN FITUR LAMA"
).match(/-.+/g) || []

const perbaikan = ambilSection(
"🔧 PERBAIKAN FITUR LAMA",
"⚡ Powered"
).match(/-.+/g) || []

const { plugins, cases } = parseFeatures(fiturBaruRaw)

let waktu = new Date().toLocaleString('id-ID', {
timeZone: 'Asia/Jakarta',
weekday: 'long',
day: '2-digit',
month: 'long',
year: 'numeric',
hour: '2-digit',
minute: '2-digit',
second: '2-digit'
})

let teks = `
📦 *update bot*

🕒 ${waktu}

━━━━━━━━━━━━━━━━━━

🚀 major changes (${perubahan.length})
${perubahan.join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

🆕 new plugins (${plugins.length})
${plugins.map(v => `- ${v}`).join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

🧩 new case features (${cases.length})
${cases.map(v => `- ${v}`).join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

🛠 fixed features (${perbaikan.length})
${perbaikan.join("\n") || "- tidak ada"}

━━━━━━━━━━━━━━━━━━

🗑 removed features (${fiturHapus.length})
${fiturHapus.join("\n") || "- tidak ada"}
`.trim()

return reply(teks)

}

}

handler.help = ["fiturnew","infoupdate"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["fiturnew","infoupdate"]

module.exports = handler