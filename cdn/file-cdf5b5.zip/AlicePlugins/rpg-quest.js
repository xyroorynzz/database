
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let quests = [
        { id: 1, name: "Pemburu Goblin", req: 5, rewardExp: 100, rewardGold: 200, type: "hunt", progress: user.questHunt || 0 },
        { id: 2, name: "Penambang Handal", req: 10, rewardExp: 150, rewardGold: 300, type: "mine", progress: user.questMine || 0 },
        { id: 3, name: "Nelayan Ulung", req: 10, rewardExp: 150, rewardGold: 300, type: "fish", progress: user.questFish || 0 },
        { id: 4, name: "Pekerja Keras", req: 15, rewardExp: 200, rewardGold: 500, type: "work", progress: user.questWork || 0 },
        { id: 5, name: "Petualang Sejati", req: 20, rewardExp: 300, rewardGold: 800, type: "adventure", progress: user.questAdventure || 0 }
    ]

    if (!args.length) {
        let msg = `📜 *DAFTAR QUEST* 📜\n\n`
        for (let q of quests) {
            let status = q.progress >= q.req ? "✅" : "⏳"
            msg += `${status} *${q.name}*\n`
            msg += `   📊 Progress: ${q.progress}/${q.req}\n`
            msg += `   🎁 Reward: ${q.rewardExp} EXP, ${q.rewardGold} Gold\n\n`
        }
        msg += `Ketik .quest claim <nomor> untuk klaim hadiah`
        return reply(msg)
    }

    if (args[0] === "claim") {
        let id = parseInt(args[1]) - 1
        if (isNaN(id) || id < 0 || id >= quests.length) return reply("❌ Nomor quest tidak valid!")

        let quest = quests[id]
        if (quest.progress < quest.req) return reply(`❌ Quest "${quest.name}" belum selesai! Progress: ${quest.progress}/${quest.req}`)

        if (user.questClaimed && user.questClaimed.includes(quest.id)) return reply("❌ Quest sudah pernah diklaim!")

        user.exp += quest.rewardExp
        user.gold += quest.rewardGold
        user.questCompleted = (user.questCompleted || 0) + 1

        if (!user.questClaimed) user.questClaimed = []
        user.questClaimed.push(quest.id)

        if (quest.type === "hunt") user.questHunt = 0
        if (quest.type === "mine") user.questMine = 0
        if (quest.type === "fish") user.questFish = 0
        if (quest.type === "work") user.questWork = 0
        if (quest.type === "adventure") user.questAdventure = 0

        let levelUp = false
        while (user.exp >= user.expNeeded) {
            user.exp -= user.expNeeded
            user.level++
            user.expNeeded = Math.floor(user.expNeeded * 1.5)
            user.maxStamina += 10
            user.stamina = user.maxStamina
            levelUp = true
        }

        db.updateUser(m.sender, user)

        let msg = `🎉 *QUEST COMPLETED* 🎉\n\n`
        msg += `✅ ${quest.name} selesai!\n`
        msg += `📈 EXP +${quest.rewardExp}\n`
        msg += `💰 Gold +${quest.rewardGold}\n`
        msg += `🏆 Total Quest Completed: ${user.questCompleted}\n`
        if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n\n`
        msg += `Ketik .quest untuk lihat quest lain!`

        reply(msg)
    }
}

handler.help = ["quest"]
handler.tags = ["rpg"]
handler.command = ["quest"]

module.exports = handler