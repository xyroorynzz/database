const { createCanvas, loadImage } = require("canvas")

function drawRoundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath()
    ctx.moveTo(x + radius, y)
    ctx.lineTo(x + width - radius, y)
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius)
    ctx.lineTo(x + width, y + height - radius)
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
    ctx.lineTo(x + radius, y + height)
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius)
    ctx.lineTo(x, y + radius)
    ctx.quadraticCurveTo(x, y, x + radius, y)
    ctx.closePath()
}

let handler = async (m, { Alice, text, reply }) => {
    if (!m.quoted) return reply("Contoh:\n.cspotify I Wanna Be Yours - Arctic Monkeys (sambil reply foto album)")
    if (!/image/.test(m.quoted.mimetype)) return reply("Reply foto untuk dijadikan album art!")

    let [title, artist] = text.split("-").map(v => v.trim())
    
    if (!title) title = "Unknown Title"
    if (!artist) artist = "Unknown Artist"

    let img = await m.quoted.download()
    let photo = await loadImage(img)

    const w = 720
    const h = 1280
    const canvas = createCanvas(w, h)
    const ctx = canvas.getContext("2d")

    ctx.fillStyle = "#000000"
    ctx.fillRect(0, 0, w, h)

    let cardW = 640
    let cardH = 970
    let cardX = 40
    let cardY = 155
    let cardRadius = 45

    drawRoundRect(ctx, cardX, cardY, cardW, cardH, cardRadius)
    ctx.fillStyle = "#1a1a1a"
    ctx.fill()
    ctx.save()
    ctx.clip()
    ctx.globalAlpha = 0.3 
    ctx.drawImage(photo, cardX, cardY, cardW, cardH)
    ctx.globalAlpha = 1.0
    
    let grad = ctx.createLinearGradient(0, cardY, 0, cardY + cardH)
    grad.addColorStop(0, "rgba(20, 20, 20, 0.4)")
    grad.addColorStop(1, "rgba(10, 10, 10, 0.95)")
    ctx.fillStyle = grad
    ctx.fillRect(cardX, cardY, cardW, cardH)
    ctx.restore()

    let artX = cardX + 40
    let artY = cardY + 40
    let artW = cardW - 80
    drawRoundRect(ctx, artX, artY, artW, artW, 20)
    ctx.save()
    ctx.clip()
    ctx.drawImage(photo, artX, artY, artW, artW)
    ctx.restore()

    let textY = artY + artW + 45
    ctx.fillStyle = "#ffffff"
    ctx.font = "bold 18px Helvetica, Arial, sans-serif"
    ctx.fillText("iPhone", artX, textY)

    ctx.font = "bold 32px Helvetica, Arial, sans-serif"
    ctx.fillText(title, artX, textY + 40)

    ctx.fillStyle = "#b3b3b3"
    ctx.font = "24px Helvetica, Arial, sans-serif"
    ctx.fillText(artist, artX, textY + 75)

    let barY = textY + 125
    ctx.fillStyle = "rgba(255, 255, 255, 0.25)"
    drawRoundRect(ctx, artX, barY, artW, 6, 3)
    ctx.fill()

    ctx.fillStyle = "#ffffff"
    drawRoundRect(ctx, artX, barY, artW * 0.3, 6, 3)
    ctx.fill()

    ctx.beginPath()
    ctx.arc(artX + artW * 0.3, barY + 3, 6, 0, Math.PI * 2)
    ctx.fill()

    ctx.font = "14px Helvetica, Arial, sans-serif"
    ctx.fillStyle = "#b3b3b3"
    ctx.fillText("0:56", artX, barY + 30)
    let endText = "-2:08"
    let endWidth = ctx.measureText(endText).width
    ctx.fillText(endText, artX + artW - endWidth, barY + 30)

    let ctrlY = barY + 85
    let cx = cardX + cardW / 2
    ctx.fillStyle = "#ffffff"

    ctx.beginPath()
    ctx.moveTo(cx - 15, ctrlY - 22)
    ctx.lineTo(cx + 22, ctrlY)
    ctx.lineTo(cx - 15, ctrlY + 22)
    ctx.fill()

    let px = cx - 110
    ctx.fillRect(px - 22, ctrlY - 14, 4, 28) 
    ctx.beginPath()
    ctx.moveTo(px - 14, ctrlY)
    ctx.lineTo(px + 6, ctrlY - 14)
    ctx.lineTo(px + 6, ctrlY + 14)
    ctx.fill()
    ctx.beginPath()
    ctx.moveTo(px + 6, ctrlY)
    ctx.lineTo(px + 26, ctrlY - 14)
    ctx.lineTo(px + 26, ctrlY + 14)
    ctx.fill()

    let nx = cx + 110
    ctx.fillRect(nx + 18, ctrlY - 14, 4, 28) 
    ctx.beginPath()
    ctx.moveTo(nx + 14, ctrlY)
    ctx.lineTo(nx - 6, ctrlY - 14)
    ctx.lineTo(nx - 6, ctrlY + 14)
    ctx.fill()
    ctx.beginPath()
    ctx.moveTo(nx - 6, ctrlY)
    ctx.lineTo(nx - 26, ctrlY - 14)
    ctx.lineTo(nx - 26, ctrlY + 14)
    ctx.fill()

    let ax = artX + artW - 15
    let ay = ctrlY + 5
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 2
    ctx.beginPath(); ctx.arc(ax, ay, 10, Math.PI, 0); ctx.stroke()
    ctx.beginPath(); ctx.arc(ax, ay, 16, Math.PI, 0); ctx.stroke()
    ctx.beginPath(); ctx.arc(ax, ay, 22, Math.PI, 0); ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(ax, ay - 6)
    ctx.lineTo(ax + 12, ay + 12)
    ctx.lineTo(ax - 12, ay + 12)
    ctx.fill()

    let volY = ctrlY + 80
    ctx.fillStyle = "#999999"
    
    let vMinX = artX + 5
    ctx.beginPath()
    ctx.moveTo(vMinX, volY - 3); ctx.lineTo(vMinX + 5, volY - 3)
    ctx.lineTo(vMinX + 10, volY - 7); ctx.lineTo(vMinX + 10, volY + 7)
    ctx.lineTo(vMinX + 5, volY + 3); ctx.lineTo(vMinX, volY + 3)
    ctx.fill()

    let vMaxX = artX + artW - 15
    ctx.beginPath()
    ctx.moveTo(vMaxX - 10, volY - 4); ctx.lineTo(vMaxX - 5, volY - 4)
    ctx.lineTo(vMaxX, volY - 9); ctx.lineTo(vMaxX, volY + 9)
    ctx.lineTo(vMaxX - 5, volY + 4); ctx.lineTo(vMaxX - 10, volY + 4)
    ctx.fill()
    ctx.strokeStyle = "#999999"
    ctx.lineWidth = 1.5
    ctx.beginPath(); ctx.arc(vMaxX + 2, volY, 4, -Math.PI/3, Math.PI/3); ctx.stroke()
    ctx.beginPath(); ctx.arc(vMaxX + 2, volY, 8, -Math.PI/3, Math.PI/3); ctx.stroke()

    let volBarX = artX + 35
    let volBarW = artW - 75
    ctx.fillStyle = "rgba(255, 255, 255, 0.25)"
    drawRoundRect(ctx, volBarX, volY - 2, volBarW, 4, 2)
    ctx.fill()
    
    ctx.fillStyle = "#ffffff"
    drawRoundRect(ctx, volBarX, volY - 2, volBarW * 0.8, 4, 2)
    ctx.fill()
    
    ctx.beginPath()
    ctx.arc(volBarX + volBarW * 0.8, volY, 5, 0, Math.PI * 2)
    ctx.fill()

    let buffer = canvas.toBuffer()
    await Alice.sendMessage(m.chat, { image: buffer }, { quoted: m })
}

handler.help = ["cspotify"]
handler.tags = ["maker"]
handler.command = ["cspotify"]

module.exports = handler