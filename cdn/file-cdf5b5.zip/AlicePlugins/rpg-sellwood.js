
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let woodPrices = {
    "Kayu Biasa": 10,
    "Kayu Jati": 30,
    "Kayu Cendana": 50,
    "Kayu Hitam": 80,
    "Kayu Ajaib": 150
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🪵 *TOKO KAYU* 🪵\n\n`
        for (let [wood, price] of Object.entries(woodPrices)) {
            msg += `• ${wood} = ${price} gold\n`
        }
        msg += `\nCara pakai: .sellwood <kayu> <jumlah>`
        return reply(msg)
    }

    let woodName = args.slice(0, -1).join(" ")
    let qty = parseInt(args[args.length - 1]) || 1

    if (!woodPrices[woodName]) return reply(`❌ Kayu "${woodName}" tidak bisa dijual!`)

    let have = user.inventory[woodName] || 0
    if (have < qty) return reply(`❌ ${woodName} tidak cukup! Kamu punya ${have}`)

    let totalGold = woodPrices[woodName] * qty

    user.inventory[woodName] -= qty
    if (user.inventory[woodName] === 0) delete user.inventory[woodName]
    user.gold += totalGold

    db.updateUser(m.sender, user)

    reply(`🪵 *PENJUALAN KAYU* 🪵\n\n✅ ${qty} ${woodName} terjual!\n💰 Gold +${totalGold}\n💵 Total gold: ${user.gold}`)
}

handler.help = ["sellwood"]
handler.tags = ["rpg"]
handler.command = ["sellwood"]

module.exports = handler