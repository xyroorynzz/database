
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let stealCooldown = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply pemain yang ingin dicuri!\nContoh: .steal @6285252512178")
    if (target === m.sender) return reply("❌ Tidak bisa mencuri dari diri sendiri!")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    let now = Date.now()
    if (stealCooldown[m.sender] && now - stealCooldown[m.sender] < 300000) {
        let remaining = Math.ceil((300000 - (now - stealCooldown[m.sender])) / 60000)
        return reply(`⏰ Kamu baru saja mencuri! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina < 20) return reply("❤️ Stamina kurang! Butuh 20 stamina untuk mencuri.\nKetik .heal untuk istirahat.")

    let successChance = 40 - (targetUser.level - user.level) * 2
    successChance = Math.min(70, Math.max(10, successChance))

    let random = Math.random() * 100

    if (random < successChance) {
        let stealAmount = Math.floor(Math.random() * (targetUser.gold * 0.2)) + 10
        stealAmount = Math.min(stealAmount, targetUser.gold, 500)

        if (stealAmount < 1) return reply("💰 Target terlalu miskin untuk dicuri!")

        user.gold += stealAmount
        targetUser.gold -= stealAmount
        user.stamina -= 20

        if (!user.stealSuccess) user.stealSuccess = 0
        user.stealSuccess += 1

        db.updateUser(m.sender, user)
        db.updateUser(target, targetUser)
        stealCooldown[m.sender] = now

        reply(`🦹 *MENcuri BERHASIL* 🦹\n\n✅ Kamu berhasil mencuri ${stealAmount} gold dari @${target.split('@')[0]}!\n💰 Gold kamu sekarang: ${user.gold}\n❤️ Stamina -20 (${user.stamina}/${user.maxStamina})\n📊 Total curian berhasil: ${user.stealSuccess}`, { mentions: [target] })
    } else {
        user.stamina -= 20
        db.updateUser(m.sender, user)
        stealCooldown[m.sender] = now

        reply(`😱 *MENcuri GAGAL* 😱\n\n❌ Kamu ketahuan mencuri dari @${target.split('@')[0]}!\n❤️ Stamina tetap berkurang -20 (${user.stamina}/${user.maxStamina})\n📊 Coba lagi nanti!`, { mentions: [target] })
    }
}

handler.help = ["steal"]
handler.tags = ["rpg"]
handler.command = ["steal", "curi"]

module.exports = handler