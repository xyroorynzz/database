
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let shopItems = {
    "pedang besi": { price: 300, type: "weapon", name: "⚔️ Pedang Besi", desc: "Serangan +5" },
    "pedang baja": { price: 600, type: "weapon", name: "🗡️ Pedang Baja", desc: "Serangan +10" },
    "excalibur": { price: 2000, type: "weapon", name: "⚔️ Excalibur", desc: "Serangan +20" },
    "baju kulit": { price: 250, type: "armor", name: "🛡️ Baju Kulit", desc: "Pertahanan +3" },
    "baju besi": { price: 550, type: "armor", name: "⚔️ Baju Besi", desc: "Pertahanan +7" },
    "armor dewa": { price: 1500, type: "armor", name: "🛡️ Armor Dewa", desc: "Pertahanan +15" },
    "potion kecil": { price: 50, type: "consumable", name: "Potion Kecil", heal: 30, desc: "Pulihkan 30 stamina" },
    "potion sedang": { price: 80, type: "consumable", name: "Potion Sedang", heal: 50, desc: "Pulihkan 50 stamina" },
    "potion besar": { price: 150, type: "consumable", name: "Potion Besar", heal: 100, desc: "Pulihkan 100 stamina" },
    "elixir": { price: 500, type: "consumable", name: "Elixir", heal: 200, desc: "Pulihkan 200 stamina" }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) return reply("Cara pakai: .beli pedang besi")

    let itemName = args.join(" ").toLowerCase()
    let item = shopItems[itemName]

    if (!item) return reply(`❌ Item "${args.join(" ")}" tidak tersedia!\nKetik .shop untuk lihat daftar item.`)

    let merchantBonus = 1
    let finalPrice = item.price
    if (user.skills && user.skills.merchant) {
        merchantBonus = 1 - (user.skills.merchant * 0.02)
        finalPrice = Math.floor(item.price * merchantBonus)
    }

    if (user.gold < finalPrice) return reply(`💰 Gold tidak cukup!\nButuh: ${finalPrice} gold\nGold kamu: ${user.gold}`)

    user.gold -= finalPrice

    let discText = (user.skills && user.skills.merchant && finalPrice < item.price) ? ` (Diskon ${user.skills.merchant * 2}%)` : ""

    if (item.type === "weapon") {
        user.weapon = item.name
        reply(`⚔️ *PEMBELIAN BERHASIL*\n\nKamu membeli ${item.name}\n${item.desc}\n💰 Harga: ${finalPrice}${discText}\nGold tersisa: ${user.gold}`)
    } else if (item.type === "armor") {
        user.armor = item.name
        reply(`🛡️ *PEMBELIAN BERHASIL*\n\nKamu membeli ${item.name}\n${item.desc}\n💰 Harga: ${finalPrice}${discText}\nGold tersisa: ${user.gold}`)
    } else if (item.type === "consumable") {
        if (!user.inventory[item.name]) user.inventory[item.name] = 0
        user.inventory[item.name] += 1
        reply(`🧪 *PEMBELIAN BERHASIL*\n\nKamu membeli ${item.name}\n${item.desc}\n💰 Harga: ${finalPrice}${discText}\nGold tersisa: ${user.gold}\n\nKetik .inv untuk lihat inventory.`)
    }

    db.updateUser(m.sender, user)
}

handler.help = ["beli"]
handler.tags = ["rpg"]
handler.command = ["beli", "buy"]

module.exports = handler