
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let marryData = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply pemain yang ingin dilamar!\nContoh: .marry @6285252512178")
    if (target === m.sender) return reply("❌ Tidak bisa menikah dengan diri sendiri!")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    if (user.married && user.married !== "tidak") return reply("❌ Kamu sudah menikah!")
    if (targetUser.married && targetUser.married !== "tidak") return reply("❌ Target sudah menikah!")

    if (user.gold < 5000) return reply(`💰 Gold tidak cukup! Butuh 5000 gold untuk biaya pernikahan\nGold kamu: ${user.gold}`)

    if (!marryData[m.chat]) marryData[m.chat] = {}

    if (marryData[m.chat][m.sender]) return reply("⚠️ Kamu sedang dalam proses lamaran!")
    if (marryData[m.chat][target]) return reply("⚠️ Target sedang dalam proses lamaran!")

    marryData[m.chat][m.sender] = { target: target, status: "pending" }

    let msg = `💍 *LAMARAN PERNIKAHAN*\n\n`
    msg += `@${m.sender.split('@')[0]} melamar @${target.split('@')[0]}!\n`
    msg += `Biaya pernikahan: 5000 gold (akan dipotong dari pelamar)\n\n`
    msg += `Ketik .marryaccept untuk menerima\n`
    msg += `Ketik .marryreject untuk menolak\n\n`
    msg += `Waktu habis dalam 60 detik.`

    reply(msg, { mentions: [m.sender, target] })

    setTimeout(() => {
        if (marryData[m.chat][m.sender] && marryData[m.chat][m.sender].status === "pending") {
            delete marryData[m.chat][m.sender]
            reply(`⏰ Waktu habis! Lamaran antara @${m.sender.split('@')[0]} dan @${target.split('@')[0]} dibatalkan.`, { mentions: [m.sender, target] })
        }
    }, 60000)
}

handler.help = ["marry"]
handler.tags = ["rpg"]
handler.command = ["marry", "lamar"]

module.exports = handler