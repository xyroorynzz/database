
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🌟 *PRESTIGE SYSTEM* 🌟\n\n`
        msg += `Prestige level: ${user.prestige || 0}\n`
        msg += `Syarat: Level 50, Gold 100000\n\n`
        msg += `Bonus prestige:\n`
        msg += `• +50 max stamina\n`
        msg += `• +10000 gold\n`
        msg += `• +50 skill point\n`
        msg += `• Title keren\n\n`
        msg += `Ketik .prestige confirm untuk prestige`
        return reply(msg)
    }

    if (args[0] === "confirm") {
        if (user.level < 50) return reply("❌ Level minimal 50 untuk prestige!")
        if (user.gold < 100000) return reply("💰 Gold minimal 100000 untuk prestige!")

        let prestigeLevel = (user.prestige || 0) + 1

        user.prestige = prestigeLevel
        user.level = 1
        user.exp = 0
        user.expNeeded = 100
        user.gold = 10000
        user.maxStamina += 50
        user.stamina = user.maxStamina

        db.updateUser(m.sender, user)

        reply(`🌟 *PRESTIGE BERHASIL!* 🌟\n\n🎉 Selamat! Kamu naik ke prestige level ${prestigeLevel}!\n💰 Bonus: +10000 gold\n❤️ Max stamina +50\n🔄 Level direset ke 1\n\nKetik .my untuk lihat status baru!`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n.prestige confirm untuk prestige`)
    }
}

handler.help = ["prestige"]
handler.tags = ["rpg"]
handler.command = ["prestige"]

module.exports = handler