
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastBounty && now - user.lastBounty < oneDay) {
        let remaining = oneDay - (now - user.lastBounty)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        return reply(`⏰ Buronan sudah diambil! Tunggu ${hours} jam lagi.`)
    }

    let bounties = [
        { name: "Goblin Lord", reward: 2000, exp: 150, staminaCost: 30 },
        { name: "Orc Warlord", reward: 5000, exp: 300, staminaCost: 40 },
        { name: "Dragon Tamer", reward: 10000, exp: 500, staminaCost: 50 },
        { name: "Dark Knight", reward: 15000, exp: 750, staminaCost: 60 },
        { name: "Demon King", reward: 25000, exp: 1000, staminaCost: 80 }
    ]

    let bounty = bounties[Math.floor(Math.random() * bounties.length)]

    if (user.stamina < bounty.staminaCost) return reply(`❤️ Stamina kurang! Butuh ${bounty.staminaCost} stamina untuk memburu ${bounty.name}`)

    user.stamina -= bounty.staminaCost
    user.gold += bounty.reward
    user.exp += bounty.exp
    user.lastBounty = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `💰 *BURONAN: ${bounty.name}* 💰\n\n`
    msg += `✨ BERHASIL DITANGKAP!\n\n`
    msg += `💰 Gold +${bounty.reward}\n`
    msg += `📈 EXP +${bounty.exp}\n`
    msg += `❤️ Stamina -${bounty.staminaCost} (${user.stamina}/${user.maxStamina})\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .bounty lagi besok!`

    reply(msg)
}

handler.help = ["bounty"]
handler.tags = ["rpg"]
handler.command = ["bounty"]

module.exports = handler