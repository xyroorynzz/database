
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)

    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (args[0] === 'force') {
        db.deleteUser(m.sender)
        return reply("✅ Data RPG berhasil direset! Silakan register ulang dengan .rpgregister")
    }

    if (!args.length || args[0] !== "konfirmasi") {
        return reply(`⚠️ *PERINGATAN*\n\nKamu akan mereset semua data RPG-mu!\nKetik .reset konfirmasi untuk melanjutkan.\n\nAtau ketik .reset force untuk paksa reset.`)
    }

    db.deleteUser(m.sender)
    reply(`🗑️ *DATA RPG DIHAPUS*\n\nKetik .rpgregister untuk mendaftar ulang.`)
}

handler.help = ["reset"]
handler.tags = ["rpg"]
handler.command = ["reset", "resetrpg", "hapusrpg"]

module.exports = handler