const fs = require("fs")
const path = require("path")

let handler = async (m, { reply }) => {

let dir = __dirname
let files = fs.readdirSync(dir).filter(v => v.endsWith(".js"))

let totalPlugin = files.length
let totalFitur = 0
let kategori = {}

for (let file of files) {
    try {
        let plugin = require(path.join(dir, file))

        let tags = plugin.tags || ["no-tag"]
        let help = plugin.help || []

        totalFitur += help.length

        tags.forEach(tag => {
            if (!kategori[tag]) kategori[tag] = 0
            kategori[tag] += help.length
        })

    } catch (e) {
        console.log("Error di plugin:", file)
    }
}

let txt = `📊 TOTAL PLUGINS\n\n`
txt += `📦 Total Plugin: ${totalPlugin}\n`
txt += `⚙️ Total Fitur: ${totalFitur}\n\n`
txt += `📂 DETAIL PER KATEGORI:\n`

for (let k in kategori) {
    txt += `• ${k} = ${kategori[k]} fitur\n`
}

reply(txt)

}

handler.help = ["totalplugins"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["totalplugins", "totalp"]

module.exports = handler