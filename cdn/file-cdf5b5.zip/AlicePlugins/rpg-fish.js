
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 8) return reply("❤️ Stamina kurang! Butuh 8 stamina untuk memancing.\nKetik .heal untuk istirahat.")

    let fishes = [
        { name: "Ikan Kecil", minGold: 5, maxGold: 15, exp: 4, chance: 35 },
        { name: "Ikan Mas", minGold: 15, maxGold: 30, exp: 8, chance: 25 },
        { name: "Ikan Lele", minGold: 20, maxGold: 40, exp: 10, chance: 20 },
        { name: "Ikan Gurame", minGold: 30, maxGold: 60, exp: 15, chance: 12 },
        { name: "Ikan Salmon", minGold: 50, maxGold: 100, exp: 20, chance: 5 },
        { name: "Ikan Hiu", minGold: 100, maxGold: 200, exp: 35, chance: 2 },
        { name: "Ikan Naga", minGold: 300, maxGold: 600, exp: 60, chance: 1 }
    ]

    let totalChance = fishes.reduce((sum, fish) => sum + fish.chance, 0)
    let random = Math.random() * totalChance
    let cumulative = 0
    let selectedFish = fishes[fishes.length - 1]

    for (let fish of fishes) {
        cumulative += fish.chance
        if (random <= cumulative) {
            selectedFish = fish
            break
        }
    }

    let goldGain = Math.floor(Math.random() * (selectedFish.maxGold - selectedFish.minGold + 1) + selectedFish.minGold)
    let expGain = selectedFish.exp

    user.stamina -= 8
    user.gold += goldGain
    user.exp += expGain
    user.fishing = (user.fishing || 0) + 1

    if (!user.inventory[selectedFish.name]) user.inventory[selectedFish.name] = 0
    user.inventory[selectedFish.name] += 1

    if (!user.dailyFishProgress) user.dailyFishProgress = 0
    user.dailyFishProgress += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎣 *MEMANCING* 🎣\n\n`
    msg += `✨ Kamu mendapatkan: *${selectedFish.name}*\n`
    msg += `📦 +1 ${selectedFish.name} (inventory)\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -8 (${user.stamina}/${user.maxStamina})\n`
    msg += `📊 Daily Fish Progress: ${user.dailyFishProgress}/10\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["fish"]
handler.tags = ["rpg"]
handler.command = ["fish", "mancing"]

module.exports = handler