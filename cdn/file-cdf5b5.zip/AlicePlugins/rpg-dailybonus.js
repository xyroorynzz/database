const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyBonus && now - user.lastDailyBonus < oneDay) {
        let remaining = oneDay - (now - user.lastDailyBonus)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        let minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
        return reply(`⏰ Bonus harian sudah diambil!\nTunggu ${hours} jam ${minutes} menit lagi.`)
    }

    let streak = user.dailyStreak || 0
    if (user.lastDailyBonus && now - user.lastDailyBonus < oneDay + 86400000) {
        streak += 1
    } else {
        streak = 1
    }

    let bonusGold = 500 + (streak * 50) + (user.level * 20)
    let bonusExp = 100 + (streak * 10) + (user.level * 5)
    let bonusStamina = 30 + streak

    user.gold += bonusGold
    user.exp += bonusExp
    user.stamina = Math.min(user.stamina + bonusStamina, user.maxStamina)
    user.lastDailyBonus = now
    user.dailyStreak = streak

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎁 *DAILY BONUS* 🎁\n\n`
    msg += `🔥 Streak: ${streak} hari\n\n`
    msg += `💰 Gold +${bonusGold}\n`
    msg += `📈 EXP +${bonusExp}\n`
    msg += `❤️ Stamina +${bonusStamina}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKembali besok untuk bonus lanjutan!`

    reply(msg)
}

handler.help = ["dailybonus"]
handler.tags = ["rpg"]
handler.command = ["dailybonus", "bonus"]

module.exports = handler