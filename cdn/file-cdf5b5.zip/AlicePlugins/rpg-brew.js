
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let brewRecipes = {
    "jus wortel": { need: { "Wortel": 2 }, result: { name: "Jus Wortel", heal: 25, sell: 60 } },
    "sup tomat": { need: { "Tomat": 3 }, result: { name: "Sup Tomat", heal: 40, sell: 90 } },
    "ramuan sayur": { need: { "Wortel": 1, "Kentang": 1, "Tomat": 1 }, result: { name: "Ramuan Sayur", heal: 60, sell: 150 } }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🍺 *RESEP MINUMAN* 🍺\n\n`
        for (let [resep, data] of Object.entries(brewRecipes)) {
            msg += `• ${resep}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Hasil: ${data.result.name} (heal +${data.result.heal})\n\n`
        }
        msg += `Cara pakai: .brew jus wortel`
        return reply(msg)
    }

    let recipeName = args.join(" ").toLowerCase()
    let recipe = brewRecipes[recipeName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    if (!user.inventory[recipe.result.name]) user.inventory[recipe.result.name] = 0
    user.inventory[recipe.result.name] += 1
    user.exp += 20

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🍺 *MEMBUAT MINUMAN* 🍺\n\n`
    msg += `✅ ${recipe.result.name} berhasil dibuat!\n`
    msg += `📦 ${recipe.result.name} sekarang: ${user.inventory[recipe.result.name]}\n`
    msg += `📈 EXP +20\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["brew"]
handler.tags = ["rpg"]
handler.command = ["brew", "buatminuman"]

module.exports = handler