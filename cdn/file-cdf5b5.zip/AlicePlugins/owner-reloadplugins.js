const fs = require("fs")
const path = require("path")

let handler = async (m, { reply }) => {

let files = fs.readdirSync(__dirname).filter(v => v.endsWith(".js"))

let total = 0

for (let file of files) {

let loc = path.join(__dirname,file)

delete require.cache[require.resolve(loc)]

try{
require(loc)
total++
}catch(e){
console.log(e)
}

}

reply(`♻️ ${total} plugins berhasil direload`)

}

handler.help = ["reloadp"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["reloadp","recodep","recodeplugins"]

module.exports = handler