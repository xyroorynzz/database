
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `⚒️ *BLACKSMITH* ⚒️\n\n`
        msg += `Weapon: ${user.weapon} (Level ${user.weaponLevel || 1})\n`
        msg += `Armor: ${user.armor} (Level ${user.armorLevel || 1})\n\n`
        msg += `Command:\n`
        msg += `.blacksmith upgrade weapon - Upgrade weapon (5000 gold + 10 Bijih Besi)\n`
        msg += `.blacksmith upgrade armor - Upgrade armor (5000 gold + 10 Bijih Besi)\n`
        msg += `.blacksmith repair - Repair semua equipment (1000 gold)`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "upgrade") {
        let type = args[1]
        let costGold = 5000
        let needOre = 10

        if (user.gold < costGold) return reply(`💰 Gold tidak cukup! Butuh ${costGold} gold`)
        
        let haveOre = user.inventory["Bijih Besi"] || 0
        if (haveOre < needOre) return reply(`❌ Bijih Besi tidak cukup! Butuh ${needOre}, kamu punya ${haveOre}`)

        user.gold -= costGold
        user.inventory["Bijih Besi"] -= needOre
        if (user.inventory["Bijih Besi"] === 0) delete user.inventory["Bijih Besi"]

        if (type === "weapon") {
            user.weaponLevel = (user.weaponLevel || 1) + 1
            reply(`⚔️ *UPGRADE WEAPON BERHASIL* ⚔️\n\n✅ Weapon level sekarang: ${user.weaponLevel}\n💰 Gold -${costGold}\n🔧 Bijih Besi -${needOre}`)
        } else if (type === "armor") {
            user.armorLevel = (user.armorLevel || 1) + 1
            reply(`🛡️ *UPGRADE ARMOR BERHASIL* 🛡️\n\n✅ Armor level sekarang: ${user.armorLevel}\n💰 Gold -${costGold}\n🔧 Bijih Besi -${needOre}`)
        } else {
            return reply(`❌ Pilihan tidak valid!\n.blacksmith upgrade weapon\n.blacksmith upgrade armor`)
        }
    }
    else if (action === "repair") {
        let costGold = 1000
        if (user.gold < costGold) return reply(`💰 Gold tidak cukup! Butuh ${costGold} gold`)

        user.weaponDurability = 100
        user.armorDurability = 100
        user.gold -= costGold

        db.updateUser(m.sender, user)
        reply(`🔧 *REPAIR BERHASIL*\n\n✅ Weapon & Armor durability pulih ke 100!\n💰 Gold -${costGold}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.blacksmith upgrade weapon\n.blacksmith upgrade armor\n.blacksmith repair`)
    }
}

handler.help = ["blacksmith"]
handler.tags = ["rpg"]
handler.command = ["blacksmith"]

module.exports = handler