
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let skills = [
        { name: "Critical Strike", desc: "Meningkatkan chance critical hit 20%", cost: 10000, skill: "critical" },
        { name: "Double EXP", desc: "EXP berburu +20%", cost: 15000, skill: "doublexp" },
        { name: "Gold Rush", desc: "Gold berburu +20%", cost: 15000, skill: "goldrush" },
        { name: "Iron Skin", desc: "Mengurangi damage masuk 15%", cost: 20000, skill: "ironskin" }
    ]

    if (!args.length) {
        let msg = `📚 *LIBRARY* 📚\n\n`
        for (let s of skills) {
            let owned = user.learnedSkills?.includes(s.skill) ? "✅" : "❌"
            msg += `${owned} *${s.name}*\n`
            msg += `   ${s.desc}\n`
            msg += `   💰 Harga: ${s.cost} gold\n\n`
        }
        msg += `Cara pakai: .library learn <nama skill>`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "learn") {
        let skillName = args.slice(1).join(" ").toLowerCase()
        let skill = skills.find(s => s.name.toLowerCase() === skillName)

        if (!skill) return reply(`❌ Skill "${args.slice(1).join(" ")}" tidak ditemukan!`)

        if (user.learnedSkills?.includes(skill.skill)) return reply("❌ Kamu sudah mempelajari skill ini!")

        if (user.gold < skill.cost) return reply(`💰 Gold tidak cukup! Butuh ${skill.cost} gold`)

        user.gold -= skill.cost
        if (!user.learnedSkills) user.learnedSkills = []
        user.learnedSkills.push(skill.skill)

        db.updateUser(m.sender, user)

        reply(`📚 *BELAJAR SKILL* 📚\n\n✅ Kamu mempelajari ${skill.name}!\n💰 Gold -${skill.cost}\n✨ ${skill.desc}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.library learn <nama skill>`)
    }
}

handler.help = ["library"]
handler.tags = ["rpg"]
handler.command = ["library"]

module.exports = handler