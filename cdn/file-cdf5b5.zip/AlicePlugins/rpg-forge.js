const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let forgeRecipes = {
        "pedang besi": { need: { "Bijih Besi": 5, "Batu Bara": 3 }, result: "⚔️ Pedang Besi", cost: 500 },
        "pedang baja": { need: { "Bijih Besi": 10, "Batu Bara": 5 }, result: "🗡️ Pedang Baja", cost: 1000 },
        "baju besi": { need: { "Bijih Besi": 8, "Batu Bara": 4 }, result: "⚔️ Baju Besi", cost: 800 },
        "excalibur": { need: { "Bijih Emas": 10, "Kristal": 5, "Permata": 3 }, result: "⚔️ Excalibur", cost: 5000 }
    }

    if (!args.length) {
        let msg = `⚒️ *FORGE SENJATA* ⚒️\n\n`
        for (let [item, data] of Object.entries(forgeRecipes)) {
            msg += `• ${item}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Biaya: ${data.cost} gold\n\n`
        }
        msg += `Cara pakai: .forge pedang besi`
        return reply(msg)
    }

    let itemName = args.join(" ").toLowerCase()
    let recipe = forgeRecipes[itemName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    if (user.gold < recipe.cost) return reply(`💰 Gold tidak cukup! Butuh ${recipe.cost} gold`)

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    user.gold -= recipe.cost
    user.weapon = recipe.result

    db.updateUser(m.sender, user)

    reply(`⚒️ *FORGE BERHASIL*\n\n✅ ${recipe.result} berhasil dibuat!\n⚔️ Weapon sekarang: ${user.weapon}\n💰 Sisa gold: ${user.gold}`)
}

handler.help = ["forge"]
handler.tags = ["rpg"]
handler.command = ["forge", "tempa"]

module.exports = handler