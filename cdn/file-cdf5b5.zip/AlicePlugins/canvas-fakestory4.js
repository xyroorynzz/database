const { createCanvas, loadImage, Path2D } = require('@napi-rs/canvas');
const axios = require('axios');

const canvasConfig = {
    width: 720,
    cardBg: '#121212',
    textColor: '#ffffff',
    cornerRadius: 35,
};

const icons = {
    heart: "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z",
    comment: "M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z",
    share: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z",
    options: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
};

function roundedRectPath(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
}

function drawAvatar(ctx, img, x, y, size) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, x, y, size, size);
    ctx.restore();
}

function drawCoverImage(ctx, img, x, y, w, h) {
    const imgRatio = img.width / img.height;
    const canvasRatio = w / h;
    let drawW, drawH, drawX, drawY;

    if (imgRatio > canvasRatio) {
        drawH = h;
        drawW = h * imgRatio;
        drawX = x - (drawW - w) / 2;
        drawY = y;
    } else {
        drawW = w;
        drawH = w / imgRatio;
        drawX = x;
        drawY = y - (drawH - h) / 2;
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    ctx.drawImage(img, drawX, drawY, drawW, drawH);
    ctx.restore();
}

function drawBlurredBackground(ctx, canvas, imgTop, imgBottom) {
    const w = canvas.width;
    const h = canvas.height;
    
    ctx.save();
    ctx.filter = 'blur(30px) brightness(30%)';
    const bleed = 40;
    drawCoverImage(ctx, imgTop, -bleed, -bleed, w + (bleed * 2), (h / 2) + bleed);
    drawCoverImage(ctx, imgBottom, -bleed, h / 2, w + (bleed * 2), (h / 2) + bleed);
    ctx.restore();
}

async function createFakeStory(username, avatarBuffer, imageTopBuffer, imageBottomBuffer) {
    const height = 1150;
    const canvas = createCanvas(canvasConfig.width, height);
    const ctx = canvas.getContext('2d');

    const avatar = await loadImage(avatarBuffer);
    const imgTop = await loadImage(imageTopBuffer);
    const imgBottom = await loadImage(imageBottomBuffer);

    drawBlurredBackground(ctx, canvas, imgTop, imgBottom);

    const cardMarginX = 25;
    const cardMarginY = 60;
    const cardW = canvasConfig.width - (cardMarginX * 2);
    const cardH = height - (cardMarginY * 2);
    const cardX = cardMarginX;
    const cardY = cardMarginY;

    ctx.save();
    roundedRectPath(ctx, cardX, cardY, cardW, cardH, canvasConfig.cornerRadius);
    ctx.fillStyle = canvasConfig.cardBg;
    ctx.fill();
    ctx.clip();

    const headerHeight = 90;
    const avatarSize = 45;
    
    drawAvatar(ctx, avatar, cardX + 20, cardY + 22, avatarSize);

    ctx.font = 'bold 18px Arial';
    ctx.fillStyle = canvasConfig.textColor;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(username, cardX + 80, cardY + 45);

    ctx.save();
    ctx.translate(cardX + cardW - 40, cardY + 45);
    ctx.rotate(90 * Math.PI / 180);
    const pOpts = new Path2D(icons.options);
    ctx.fillStyle = 'white';
    ctx.fill(pOpts);
    ctx.restore();

    const footerHeight = 70;
    const contentAvailableHeight = cardH - headerHeight - footerHeight;
    const singleImageHeight = contentAvailableHeight / 2;

    drawCoverImage(ctx, imgTop, cardX, cardY + headerHeight, cardW, singleImageHeight);
    drawCoverImage(ctx, imgBottom, cardX, cardY + headerHeight + singleImageHeight, cardW, singleImageHeight);

    const iconY = cardY + cardH - (footerHeight / 2);
    
    function drawSvgOutline(pathData, x, y, scale) {
        ctx.save();
        ctx.translate(x, y);
        ctx.scale(scale, scale);
        ctx.translate(-12, -12);
        const p = new Path2D(pathData);
        ctx.strokeStyle = 'white';
        ctx.lineWidth = 1.8;
        ctx.stroke(p);
        ctx.restore();
    }

    drawSvgOutline(icons.heart, cardX + 40, iconY, 1.3);
    drawSvgOutline(icons.comment, cardX + 100, iconY, 1.2);
    drawSvgOutline(icons.share, cardX + 160, iconY, 1.2);
    
    ctx.restore();

    return await canvas.encode('png');
}

const DEFAULT_PP_URL = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';

async function downloadImage(url) {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
    return Buffer.from(res.data);
}

async function getAvatarBuffer(Alice, jid) {
    try {
        let ppUrl = await Alice.profilePictureUrl(jid, 'image');
        return await downloadImage(ppUrl);
    } catch (error) {
        return await downloadImage(DEFAULT_PP_URL);
    }
}

let handler = async (m, { Alice, text, args, reply, XReaction, prefix, command }) => {
    const username = text?.trim() || m.pushName || 'User';
    
    await XReaction('🕕');
    
    try {
        const avatarBuffer = await getAvatarBuffer(Alice, m.sender);
        
        let imageTopBuffer = null;
        let imageBottomBuffer = null;
        
        if (m.type === "imageMessage") {
            try {
                imageTopBuffer = await m.download();
                if (m.quoted && (m.quoted.type === "imageMessage" || m.quoted.mtype === "imageMessage")) {
                    imageBottomBuffer = await m.quoted.download();
                } else {
                    imageBottomBuffer = imageTopBuffer;
                }
            } catch (e) {}
        }
        else if (m.quoted && (m.quoted.type === "imageMessage" || m.quoted.mtype === "imageMessage")) {
            try {
                imageTopBuffer = await m.quoted.download();
                imageBottomBuffer = imageTopBuffer;
            } catch (e) {}
        }
        
        if (!imageTopBuffer) {
            await XReaction('❌');
            return reply(
                `📷 *FAKE STORY 4*\n\n` +
                `Gunakan perintah ini untuk membuat fake Instagram story dengan 2 gambar berbeda.\n\n` +
                `*Cara penggunaan:*\n` +
                `• Kirim 1 gambar + teks: ${prefix + command} Nama\n` +
                `• Kirim gambar + reply gambar lain: ${prefix + command} Nama\n` +
                `• Reply 1 gambar: ${prefix + command} Nama\n\n` +
                `*Contoh:* ${prefix + command} Misaki\n\n` +
                `*Tips:* Kirim gambar sambil reply gambar lain untuk hasil 2 gambar berbeda`
            );
        }
        
        const resultBuffer = await createFakeStory(
            username,
            avatarBuffer,
            imageTopBuffer,
            imageBottomBuffer
        );
        
        await Alice.sendMessage(m.chat, {
            image: resultBuffer,
            caption: `📷 *FAKE STORY*\n\n> ᴜsᴇʀɴᴀᴍᴇ: \`${username}\``
        }, { quoted: m });
        
        await XReaction('✅');
        
    } catch (error) {
        await XReaction('❌');
        reply(`Error: ${error.message}`);
    }
};

handler.help = ['fakestory4', 'fstory4', 'igstory4', 'albumstory'];
handler.tags = ['canvas'];
handler.command = ['fakestory4', 'fstory4', 'igstory4', 'albumstory'];

module.exports = handler;