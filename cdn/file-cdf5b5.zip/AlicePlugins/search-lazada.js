const { searchLazada } = require('../AliceSystem/AliceScraper/alice-lazada.js');

let handler = async (m, { Alice, text, reply, prefix, command, XReaction }) => {
    if (!text) return reply(`Contoh: ${prefix + command} sepatu\nAtau: ${prefix + command} sepatu 2`);

    await XReaction();

    let keyword = text.trim();
    let page = 1;

    let pageMatch = text.match(/\s(\d+)$/);
    if (pageMatch) {
        page = parseInt(pageMatch[1]);
        keyword = text.replace(/\s\d+$/, '');
    }

    if (page < 1) page = 1;
    if (page > 10) page = 10;

    try {
        await reply(`🔍 *Mencari:* ${keyword} (halaman ${page})...`);

        let result = await searchLazada(keyword, page);

        if (!result.success) {
            return reply(`❌ *Error:* ${result.error}`);
        }

        if (result.data.items.length === 0) {
            return reply(`😞 Tidak ada produk ditemukan untuk *${keyword}*`);
        }

        let responseText = `🛍️ *LAZADA SEARCH*\n`;
        responseText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        responseText += `🔎 *Keyword:* ${keyword}\n`;
        responseText += `📄 *Halaman:* ${result.data.page}\n`;
        responseText += `📦 *Total:* ${result.data.total_results}\n`;
        responseText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

        result.data.items.forEach((item, idx) => {
            responseText += `${idx + 1}. *${item.name.substring(0, 60)}${item.name.length > 60 ? '...' : ''}*\n`;
            responseText += `   💰 Harga: ${item.price}\n`;
            if (item.originalPrice !== item.price) {
                responseText += `   🏷️ Diskon: ${item.discount}\n`;
            }
            responseText += `   ⭐ Rating: ${item.rating}\n`;
            responseText += `   📍 Lokasi: ${item.location}\n`;
            responseText += `   🏪 Toko: ${item.seller}\n`;
            responseText += `   🔗 Link: ${item.productUrl}\n\n`;
        });

        responseText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        responseText += `📌 *Gunakan:* ${prefix + command} ${keyword} 2\n`;
        responseText += `📌 *Halaman:* 1-10\n`;

        await Alice.sendMessage(m.chat, { text: responseText }, { quoted: m });

    } catch (error) {
        console.error(error);
        reply(`❌ Gagal mengambil data dari Lazada.\nError: ${error.message}`);
    }
};

handler.help = ["lazada *keyword*", "lazada *keyword* *page*"];
handler.tags = ["search"];
handler.command = ["lazada", "lzd", "lazadasearch", "lazada-search", "search-lazada"];

module.exports = handler;