let handler = async (m, { command, text, reply }) => {
    if (!text) return reply(`Contoh: ${command} 10 + 5`);
    
    let operators = ['+', '-', 'x', '*', '/', ':'];
    let operator = null;
    let parts = [];
    
    for (let op of operators) {
        if (text.includes(op)) {
            operator = op;
            parts = text.split(op);
            break;
        }
    }
    
    if (!operator || parts.length !== 2) {
        return reply('Gunakan operator +, -, x, atau /\nContoh: 10 + 5');
    }
    
    let a = parseFloat(parts[0].trim());
    let b = parseFloat(parts[1].trim());
    
    if (isNaN(a) || isNaN(b)) return reply('Masukkan angka yang valid!');
    
    let hasil;
    if (operator === '+') hasil = a + b;
    else if (operator === '-') hasil = a - b;
    else if (operator === 'x' || operator === '*') hasil = a * b;
    else if (operator === '/' || operator === ':') hasil = a / b;
    
    reply(`🔢 Hasil: ${a} ${operator} ${b} = ${hasil}`);
};

handler.command = ['tambah', 'kurang', 'kali', 'bagi', 'kalkulator'];
handler.tags = ['tools'];

module.exports = handler;