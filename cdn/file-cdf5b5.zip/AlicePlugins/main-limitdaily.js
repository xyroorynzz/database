let handler = async (m, { reply }) => {

let user = global.limitDB[m.sender]

if (!user) {
  user = global.limitDB[m.sender] = {
    limit: global.limitawal.free,
    lastReset: Date.now(),
    lastClaim: 0
  }
}

let now = Date.now()
let oneDay = 86400000

if (now - user.lastClaim < oneDay) {
  let sisa = oneDay - (now - user.lastClaim)
  let jam = Math.floor(sisa / 3600000)
  return reply(`⏳ Sudah claim hari ini!
Tunggu ${jam} jam lagi`)
}

// reward
let add = 10
user.limit += add
user.lastClaim = now

reply(`✅ Berhasil claim limit harian +${add}

🎯 Limit sekarang: ${user.limit}`)
}

handler.help = ["limitdaily","claim"]
handler.tags = ["main"]
handler.command = ["limitdaily","claim"]

module.exports = handler