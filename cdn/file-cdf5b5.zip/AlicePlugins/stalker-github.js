let { githubStalker } = require("../AliceSystem/AliceScraper/alice-githubStalker")

let handler = async (m, { args, reply }) => {
  if (!args[0]) return reply("contoh: .ghstalk username")

  try {
    let res = await githubStalker(args[0])
    let data = res.result
    let p = data.profile
    let repos = data.repository || []

    let txt = `
「 GITHUB STALKER 」

Username   : ${p.username}
Name       : ${p.name || "-"}
Bio        : ${p.bio || "-"}
Company    : ${p.company || "-"}
Location   : ${p.location || "-"}
Website    : ${p.website || "-"}

Followers  : ${p.followers}
Following  : ${p.following}
Repos      : ${p.public_repos}
Gists      : ${p.public_gists}
Created    : ${p.created_at}

Link       : ${p.profile_url}

───────────────
Repository List:
`

    if (!repos.length) {
      txt += "\n- Tidak ada repository"
    } else {
      repos.forEach((v, i) => {
        txt += `

${i + 1}. ${v.name}
   Desc  : ${v.description || "-"}
   Stars : ${v.stars}
   Forks : ${v.forks}
   Lang  : ${v.language || "-"}
   Link  : ${v.url}
`
      })
    }

    reply(txt)
  } catch (e) {
    reply("error: " + (typeof e === "object" ? JSON.stringify(e) : e))
  }
}

handler.help = ["ghstalk", "githubstalk"]
handler.tags = ["stalker"]
handler.command = ["ghstalk", "githubstalk"]

module.exports = handler