
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let tradeData = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null
    let amount = null

    if (m.quoted) {
        target = m.quoted.sender
        amount = parseInt(args[0])
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
        amount = parseInt(args[1])
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                amount = parseInt(args[i+1])
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply pemain yang ingin diajak trade!\nContoh: .trade @6285252512178 500")
    if (target === m.sender) return reply("❌ Tidak bisa trade dengan diri sendiri!")

    if (isNaN(amount) || amount < 1) return reply("💰 Masukkan jumlah gold yang benar!\nContoh: .trade @user 500")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    if (user.gold < amount) return reply(`💰 Gold kamu tidak cukup! Hanya punya ${user.gold} gold`)

    if (!tradeData[m.chat]) tradeData[m.chat] = {}

    if (tradeData[m.chat][m.sender]) return reply("⚠️ Kamu sedang dalam sesi trade!")
    if (tradeData[m.chat][target]) return reply("⚠️ Target sedang dalam sesi trade!")

    tradeData[m.chat][m.sender] = { target: target, amount: amount, status: "pending", type: "send" }

    let msg = `💰 *TRADE REQUEST*\n\n`
    msg += `@${m.sender.split('@')[0]} ingin mengirim ${amount} gold ke @${target.split('@')[0]}\n\n`
    msg += `Ketik .tradeaccept untuk menerima\n`
    msg += `Ketik .tradereject untuk menolak\n\n`
    msg += `Waktu habis dalam 60 detik.`

    reply(msg, { mentions: [m.sender, target] })

    setTimeout(() => {
        if (tradeData[m.chat][m.sender] && tradeData[m.chat][m.sender].status === "pending") {
            delete tradeData[m.chat][m.sender]
            reply(`⏰ Waktu habis! Trade antara @${m.sender.split('@')[0]} dan @${target.split('@')[0]} dibatalkan.`, { mentions: [m.sender, target] })
        }
    }, 60000)
}

handler.help = ["trade"]
handler.tags = ["rpg"]
handler.command = ["trade"]

module.exports = handler