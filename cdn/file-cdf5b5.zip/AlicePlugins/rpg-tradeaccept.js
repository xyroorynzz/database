
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let tradeData = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let trader = null
    let amount = 0

    for (let [id, data] of Object.entries(tradeData[m.chat] || {})) {
        if (data.target === m.sender && data.status === "pending") {
            trader = id
            amount = data.amount
            break
        }
    }

    if (!trader) return reply("❌ Tidak ada trade request untukmu!")

    let traderUser = db.getUser(trader)
    if (!traderUser) {
        delete tradeData[m.chat][trader]
        return reply("❌ Pengirim trade tidak ditemukan!")
    }

    if (traderUser.gold < amount) {
        delete tradeData[m.chat][trader]
        return reply(`💰 Gold pengirim tidak cukup! Trade dibatalkan.`)
    }

    traderUser.gold -= amount
    user.gold += amount

    db.updateUser(trader, traderUser)
    db.updateUser(m.sender, user)

    delete tradeData[m.chat][trader]

    let msg = `✅ *TRADE BERHASIL*\n\n`
    msg += `💰 @${trader.split('@')[0]} mengirim ${amount} gold ke @${m.sender.split('@')[0]}\n\n`
    msg += `Gold @${trader.split('@')[0]} sekarang: ${traderUser.gold}\n`
    msg += `Gold @${m.sender.split('@')[0]} sekarang: ${user.gold}`

    reply(msg, { mentions: [trader, m.sender] })
}

handler.help = ["tradeaccept"]
handler.tags = ["rpg"]
handler.command = ["tradeaccept", "terimatrade"]

module.exports = handler