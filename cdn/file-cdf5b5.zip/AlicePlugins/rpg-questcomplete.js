
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.activeQuest) return reply("❌ Kamu tidak punya quest aktif! Beli kompas dulu dengan .compass")

    if (Date.now() > user.questExpires) {
        delete user.activeQuest
        delete user.questExpires
        db.updateUser(m.sender, user)
        return reply("⏰ Waktu quest sudah habis! Beli kompas baru dengan .compass")
    }

    let quest = user.activeQuest

    user.gold += quest.rewardGold
    user.exp += quest.rewardExp

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    delete user.activeQuest
    delete user.questExpires

    db.updateUser(m.sender, user)

    let msg = `🎉 *QUEST COMPLETED* 🎉\n\n`
    msg += `✅ ${quest.name}\n`
    msg += `💰 Gold +${quest.rewardGold}\n`
    msg += `📈 EXP +${quest.rewardExp}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["questcomplete"]
handler.tags = ["rpg"]
handler.command = ["questcomplete"]

module.exports = handler