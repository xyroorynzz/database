const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
const DISCOUNT_FILE = path.join(STORE_DIR, 'discounts.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

let handler = async (m, { command, text, reply, prefix, isOwner }) => {
    const sender = m.sender;
    const ownerListPath = './AliceDatabase/owner.json';
    let ownerList = [];
    if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
    const isRealOwner = ownerList.includes(sender.split('@')[0]) || (global.owner && global.owner.includes(sender.split('@')[0]));
    if (!isRealOwner) return reply('❌ Khusus owner!');

    if (command === 'addproduk') {
        if (!text) return reply(`Contoh: ${prefix}addproduk nama|harga|stok`);
        let [name, price, stock] = text.split('|').map(v => v.trim());
        if (!name || !price || !stock) return reply('Format salah! Contoh: addproduk Indomie|5000|100');
        let products = loadJSON(PRODUCT_FILE);
        if (products.find(p => p.nama.toLowerCase() === name.toLowerCase())) {
            return reply(`Produk "${name}" sudah ada!`);
        }
        let newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
        products.push({
            id: newId,
            nama: name,
            harga: parseInt(price),
            stok: parseInt(stock),
            created: new Date().toISOString()
        });
        saveJSON(PRODUCT_FILE, products);
        reply(`✅ Produk "${name}" ditambahkan!\n💰 Harga: Rp${toRupiah(price)}\n📦 Stok: ${stock}`);
    }
    
    else if (command === 'listproduk') {
        let products = loadJSON(PRODUCT_FILE);
        let discounts = loadJSON(DISCOUNT_FILE);
        if (products.length === 0) return reply('📭 Belum ada produk.');
        let teks = `🛒 DAFTAR PRODUK\n━━━━━━━━━━━━━━━━━━\n📊 Total: ${products.length} produk\n\n`;
        products.forEach((p, i) => {
            let discount = discounts.find(d => d.produk.toLowerCase() === p.nama.toLowerCase());
            if (discount) {
                let persen = Math.round(((p.harga - discount.harga_diskon) / p.harga) * 100);
                teks += `${i+1}. ${p.nama}\n`;
                teks += `   💰 Harga: Rp${toRupiah(p.harga)} → Rp${toRupiah(discount.harga_diskon)} (${persen}% OFF)\n`;
                teks += `   📦 Stok: ${p.stok}\n`;
                teks += `   ⏰ Diskon sampai: ${discount.kadaluarsa}\n\n`;
            } else {
                teks += `${i+1}. ${p.nama}\n`;
                teks += `   💰 Harga: Rp${toRupiah(p.harga)}\n`;
                teks += `   📦 Stok: ${p.stok}\n\n`;
            }
        });
        reply(teks);
    }
    
    else if (command === 'delproduk') {
        if (!text) return reply(`Contoh: ${prefix}delproduk Indomie`);
        let products = loadJSON(PRODUCT_FILE);
        let newProducts = products.filter(p => p.nama.toLowerCase() !== text.toLowerCase());
        if (newProducts.length === products.length) return reply(`Produk "${text}" tidak ditemukan!`);
        saveJSON(PRODUCT_FILE, newProducts);
        reply(`🗑️ Produk "${text}" dihapus.`);
    }
    
    else if (command === 'updateproduk') {
        if (!text) return reply(`Contoh: ${prefix}updateproduk Indomie|6000|90`);
        let [name, price, stock] = text.split('|').map(v => v.trim());
        if (!name || !price || !stock) return reply('Format salah!');
        let products = loadJSON(PRODUCT_FILE);
        let index = products.findIndex(p => p.nama.toLowerCase() === name.toLowerCase());
        if (index === -1) return reply(`Produk "${name}" tidak ditemukan!`);
        products[index].harga = parseInt(price);
        products[index].stok = parseInt(stock);
        saveJSON(PRODUCT_FILE, products);
        reply(`✅ Produk "${name}" diupdate!\n💰 Harga: Rp${toRupiah(price)}\n📦 Stok: ${stock}`);
    }
    
    else if (command === 'restok') {
        if (!text) return reply(`Contoh: ${prefix}restok Indomie|50`);
        let [name, quantity] = text.split('|').map(v => v.trim());
        if (!name || !quantity) return reply('Format salah!');
        let products = loadJSON(PRODUCT_FILE);
        let index = products.findIndex(p => p.nama.toLowerCase() === name.toLowerCase());
        if (index === -1) return reply(`Produk "${name}" tidak ditemukan!`);
        products[index].stok += parseInt(quantity);
        saveJSON(PRODUCT_FILE, products);
        reply(`✅ Stok "${name}" +${quantity}!\n📦 Stok sekarang: ${products[index].stok}`);
    }
    
    else if (command === 'diskon') {
        if (!text) return reply(`Contoh: ${prefix}diskon Indomie|4000|31-12-2025`);
        let [name, discPrice, expired] = text.split('|').map(v => v.trim());
        if (!name || !discPrice || !expired) return reply('Format salah!');
        let products = loadJSON(PRODUCT_FILE);
        if (!products.find(p => p.nama.toLowerCase() === name.toLowerCase())) {
            return reply(`Produk "${name}" tidak ditemukan!`);
        }
        let discounts = loadJSON(DISCOUNT_FILE);
        let existingIndex = discounts.findIndex(d => d.produk.toLowerCase() === name.toLowerCase());
        if (existingIndex !== -1) {
            discounts[existingIndex] = {
                produk: name,
                harga_diskon: parseInt(discPrice),
                kadaluarsa: expired
            };
        } else {
            discounts.push({
                produk: name,
                harga_diskon: parseInt(discPrice),
                kadaluarsa: expired
            });
        }
        saveJSON(DISCOUNT_FILE, discounts);
        reply(`✅ Diskon untuk "${name}" ditambahkan!\n💰 Harga Diskon: Rp${toRupiah(discPrice)}\n⏰ Berlaku sampai: ${expired}`);
    }
    
    else if (command === 'hapusdiskon') {
        if (!text) return reply(`Contoh: ${prefix}hapusdiskon Indomie`);
        let discounts = loadJSON(DISCOUNT_FILE);
        let newDiscounts = discounts.filter(d => d.produk.toLowerCase() !== text.toLowerCase());
        if (newDiscounts.length === discounts.length) return reply(`Diskon untuk "${text}" tidak ditemukan!`);
        saveJSON(DISCOUNT_FILE, newDiscounts);
        reply(`🗑️ Diskon untuk "${text}" dihapus.`);
    }
};

handler.command = ['addproduk', 'listproduk', 'delproduk', 'updateproduk', 'restok', 'diskon', 'hapusdiskon'];
handler.tags = ['store'];

module.exports = handler;