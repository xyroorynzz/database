
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let travelCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (travelCooldown[m.sender] && now - travelCooldown[m.sender] < 1800000) {
        let remaining = Math.ceil((1800000 - (now - travelCooldown[m.sender])) / 60000)
        return reply(`⏰ Kamu baru saja bepergian! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina < 15) return reply("❤️ Stamina kurang! Butuh 15 stamina untuk bepergian.\nKetik .heal untuk istirahat.")

    let destinations = [
        { name: "🏝️ Pulau Tropis", minExp: 30, maxExp: 60, minGold: 40, maxGold: 90 },
        { name: "🏔️ Pegunungan", minExp: 35, maxExp: 65, minGold: 45, maxGold: 100 },
        { name: "🌆 Kota Besar", minExp: 40, maxExp: 70, minGold: 50, maxGold: 110 },
        { name: "🏯 Desa Kuno", minExp: 45, maxExp: 75, minGold: 55, maxGold: 120 },
        { name: "🌋 Tempat Angker", minExp: 50, maxExp: 80, minGold: 60, maxGold: 130 }
    ]

    let dest = destinations[Math.floor(Math.random() * destinations.length)]
    let expGain = Math.floor(Math.random() * (dest.maxExp - dest.minExp + 1) + dest.minExp)
    let goldGain = Math.floor(Math.random() * (dest.maxGold - dest.minGold + 1) + dest.minGold)

    user.stamina -= 15
    user.exp += expGain
    user.gold += goldGain

    if (!user.travelCount) user.travelCount = 0
    user.travelCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    travelCooldown[m.sender] = now

    let msg = `✈️ *BERPERGIAN* ✈️\n\n`
    msg += `📍 Tujuan: ${dest.name}\n\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `❤️ Stamina -15 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Perjalanan: ${user.travelCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .travel lagi setelah 30 menit!`

    reply(msg)
}

handler.help = ["travel"]
handler.tags = ["rpg"]
handler.command = ["travel", "bepergian"]

module.exports = handler