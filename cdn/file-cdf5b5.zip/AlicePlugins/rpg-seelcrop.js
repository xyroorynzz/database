
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let cropPrices = {
    "Wortel": 20,
    "Kentang": 25,
    "Tomat": 30,
    "Cabai": 40,
    "Bawang": 35
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🌱 *TOKO HASIL TANI* 🌱\n\n`
        for (let [crop, price] of Object.entries(cropPrices)) {
            msg += `• ${crop} = ${price} gold\n`
        }
        msg += `\nCara pakai: .sellcrop <sayuran> <jumlah>`
        return reply(msg)
    }

    let cropName = args.slice(0, -1).join(" ")
    let qty = parseInt(args[args.length - 1]) || 1

    if (!cropPrices[cropName]) return reply(`❌ Sayuran "${cropName}" tidak bisa dijual!`)

    let have = user.inventory[cropName] || 0
    if (have < qty) return reply(`❌ ${cropName} tidak cukup! Kamu punya ${have}`)

    let totalGold = cropPrices[cropName] * qty

    user.inventory[cropName] -= qty
    if (user.inventory[cropName] === 0) delete user.inventory[cropName]
    user.gold += totalGold

    db.updateUser(m.sender, user)

    reply(`🌱 *PENJUALAN HASIL TANI* 🌱\n\n✅ ${qty} ${cropName} terjual!\n💰 Gold +${totalGold}\n💵 Total gold: ${user.gold}`)
}

handler.help = ["sellcrop"]
handler.tags = ["rpg"]
handler.command = ["sellcrop"]

module.exports = handler