
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyMine && now - user.lastDailyMine < oneDay) {
        let remaining = oneDay - (now - user.lastDailyMine)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        return reply(`⏰ Tambang harian sudah diambil! Tunggu ${hours} jam lagi.`)
    }

    let targetMine = 10
    let currentMine = user.dailyMineProgress || 0

    if (currentMine < targetMine) {
        return reply(`📋 *TAMBANG HARIAN*\n\nTarget: ${targetMine} mine\nProgress: ${currentMine}/${targetMine}\n\nSelesaikan dengan melakukan .mine ${targetMine - currentMine} kali lagi!`)
    }

    let rewardGold = 3000
    let rewardExp = 500
    let rewardItem = "Bijih Besi"

    user.gold += rewardGold
    user.exp += rewardExp
    if (!user.inventory[rewardItem]) user.inventory[rewardItem] = 0
    user.inventory[rewardItem] += 5
    user.dailyMineProgress = 0
    user.lastDailyMine = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `⛏️ *TAMBANG HARIAN SELESAI* ⛏️\n\n`
    msg += `✅ ${targetMine} mine completed!\n`
    msg += `💰 Gold +${rewardGold}\n`
    msg += `📈 EXP +${rewardExp}\n`
    msg += `🔧 Bijih Besi +5\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["dailymine"]
handler.tags = ["rpg"]
handler.command = ["dailymine"]

module.exports = handler