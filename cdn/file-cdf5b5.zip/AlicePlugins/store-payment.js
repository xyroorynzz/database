const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const PAYMENT_FILE = path.join(STORE_DIR, 'payment.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadPayment() {
    ensureDir();
    if (!fs.existsSync(PAYMENT_FILE)) fs.writeFileSync(PAYMENT_FILE, JSON.stringify({}));
    return JSON.parse(fs.readFileSync(PAYMENT_FILE));
}

function savePayment(data) {
    ensureDir();
    fs.writeFileSync(PAYMENT_FILE, JSON.stringify(data, null, 2));
}

let handler = async (m, { command, text, reply, prefix, isOwner }) => {
    const sender = m.sender;
    const ownerListPath = './AliceDatabase/owner.json';
    let ownerList = [];
    if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
    const isRealOwner = ownerList.includes(sender.split('@')[0]) || (global.owner && global.owner.includes(sender.split('@')[0]));
    if (!isRealOwner) return reply('❌ Khusus owner!');
    
    if (command === 'setpayment') {
        if (!text) return reply(`Contoh: ${prefix}setpayment gopay|08123456789\n\nMethod: gopay, dana, qris, gopay_an, dana_an, qris_an`);
        let [method, value] = text.split('|').map(v => v.trim());
        if (!method || !value) return reply('Format salah! Contoh: setpayment gopay|08123456789');
        
        let allowed = ['gopay', 'dana', 'qris', 'gopay_an', 'dana_an', 'qris_an'];
        if (!allowed.includes(method.toLowerCase())) {
            return reply(`Method tidak valid!\nAllowed: ${allowed.join(', ')}`);
        }
        
        let payment = loadPayment();
        payment[method.toLowerCase()] = value;
        savePayment(payment);
        reply(`✅ Payment ${method} berhasil diubah menjadi: ${value}`);
    }
    
    else if (command === 'payment') {
        let payment = loadPayment();
        if (Object.keys(payment).length === 0) return reply('❌ Belum ada metode pembayaran yang diatur.');
        
        let teks = `💳 METODE PEMBAYARAN\n━━━━━━━━━━━━━━━━━━\n`;
        if (payment.gopay) teks += `🟢 GoPay: ${payment.gopay}\n`;
        if (payment.gopay_an) teks += `   a.n ${payment.gopay_an}\n`;
        if (payment.dana) teks += `🔵 Dana: ${payment.dana}\n`;
        if (payment.dana_an) teks += `   a.n ${payment.dana_an}\n`;
        if (payment.qris) teks += `📷 QRIS: ${payment.qris}\n`;
        if (payment.qris_an) teks += `   a.n ${payment.qris_an}\n`;
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `📌 Transfer sesuai total belanja ya kak!`;
        reply(teks);
    }
};

handler.command = ['setpayment', 'payment'];
handler.tags = ['store'];

module.exports = handler;