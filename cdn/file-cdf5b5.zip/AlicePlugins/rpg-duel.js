
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let duelData = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply pemain yang ingin ditantang!\nContoh: .duel @6285252512178")
    if (target === m.sender) return reply("❌ Tidak bisa duel dengan diri sendiri!")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    if (user.stamina < 25) return reply("❤️ Stamina kamu kurang! Butuh 25 stamina untuk duel.\nKetik .heal untuk istirahat.")
    if (targetUser.stamina < 25) return reply("❤️ Stamina target kurang! Target butuh istirahat dulu.")

    if (!duelData[m.chat]) duelData[m.chat] = {}

    if (duelData[m.chat][m.sender]) return reply("⚠️ Kamu sedang dalam sesi duel!")
    if (duelData[m.chat][target]) return reply("⚠️ Target sedang dalam sesi duel!")

    duelData[m.chat][m.sender] = { opponent: target, status: "pending", startTime: Date.now() }

    let msg = `⚔️ *DUEL CHALLENGE* ⚔️\n\n`
    msg += `@${m.sender.split('@')[0]} menantang @${target.split('@')[0]} untuk duel!\n\n`
    msg += `Taruhan: 100 gold\n\n`
    msg += `Ketik .accept untuk menerima\n`
    msg += `Ketik .reject untuk menolak\n\n`
    msg += `Waktu habis dalam 60 detik.`

    reply(msg, { mentions: [m.sender, target] })

    setTimeout(() => {
        if (duelData[m.chat][m.sender] && duelData[m.chat][m.sender].status === "pending") {
            delete duelData[m.chat][m.sender]
            reply(`⏰ Waktu habis! Duel antara @${m.sender.split('@')[0]} dan @${target.split('@')[0]} dibatalkan.`, { mentions: [m.sender, target] })
        }
    }, 60000)
}

handler.help = ["duel"]
handler.tags = ["rpg"]
handler.command = ["duel", "tantang"]

module.exports = handler