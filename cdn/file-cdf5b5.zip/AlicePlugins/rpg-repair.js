
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.weaponDurability) user.weaponDurability = 100
    if (!user.armorDurability) user.armorDurability = 100

    if (!args.length) {
        let msg = `🔨 *REPAIR EQUIPMENT* 🔨\n\n`
        msg += `.repair weapon - Perbaiki weapon (100 gold per 10 durability)\n`
        msg += `.repair armor - Perbaiki armor (100 gold per 10 durability)\n`
        msg += `.repair all - Perbaiki semua (200 gold per 10 durability)`
        return reply(msg)
    }

    let type = args[0].toLowerCase()
    let costPerTen = 100

    if (type === "weapon") {
        let need = 100 - user.weaponDurability
        if (need <= 0) return reply("⚔️ Weapon masih penuh! Tidak perlu repair.")
        let cost = Math.ceil(need / 10) * costPerTen
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold`)
        
        user.gold -= cost
        user.weaponDurability = 100
        reply(`⚔️ *REPAIR WEAPON BERHASIL*\n\n💰 Gold -${cost}\n⚔️ Weapon durability pulih ke 100!`)
    }
    else if (type === "armor") {
        let need = 100 - user.armorDurability
        if (need <= 0) return reply("🛡️ Armor masih penuh! Tidak perlu repair.")
        let cost = Math.ceil(need / 10) * costPerTen
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold`)
        
        user.gold -= cost
        user.armorDurability = 100
        reply(`🛡️ *REPAIR ARMOR BERHASIL*\n\n💰 Gold -${cost}\n🛡️ Armor durability pulih ke 100!`)
    }
    else if (type === "all") {
        let needWeapon = 100 - user.weaponDurability
        let needArmor = 100 - user.armorDurability
        let need = needWeapon + needArmor
        if (need <= 0) return reply("Semua equipment masih penuh!")
        
        let cost = Math.ceil(need / 10) * costPerTen
        if (user.gold < cost) return reply(`💰 Gold tidak cukup! Butuh ${cost} gold`)
        
        user.gold -= cost
        user.weaponDurability = 100
        user.armorDurability = 100
        reply(`🔧 *REPAIR ALL BERHASIL*\n\n💰 Gold -${cost}\n⚔️ Weapon & 🛡️ Armor pulih ke 100!`)
    }
    else {
        reply(`❌ Pilihan tidak valid!\n.repair weapon\n.repair armor\n.repair all`)
    }

    db.updateUser(m.sender, user)
}

handler.help = ["repair"]
handler.tags = ["rpg"]
handler.command = ["repair", "perbaiki"]

module.exports = handler