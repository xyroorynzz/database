
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyCheck && now - user.lastDailyCheck < oneDay) {
        let remaining = oneDay - (now - user.lastDailyCheck)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        let minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
        return reply(`⏰ Kamu sudah check-in hari ini! Tunggu ${hours} jam ${minutes} menit lagi.`)
    }

    let bonusGold = 100 + (user.level * 5)
    let bonusExp = 20 + (user.level * 2)
    let bonusStamina = 15

    user.gold += bonusGold
    user.exp += bonusExp
    user.stamina = Math.min(user.stamina + bonusStamina, user.maxStamina)
    user.lastDailyCheck = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `📅 *DAILY CHECK-IN* 📅\n\n`
    msg += `💰 Gold +${bonusGold}\n`
    msg += `📈 EXP +${bonusExp}\n`
    msg += `❤️ Stamina +${bonusStamina}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKembali besok untuk check-in lagi!`

    reply(msg)
}

handler.help = ["dailycheck"]
handler.tags = ["rpg"]
handler.command = ["dailycheck", "checkin"]

module.exports = handler