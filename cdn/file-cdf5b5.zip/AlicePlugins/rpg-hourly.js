
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let hourlyCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneHour = 60 * 60 * 1000

    if (hourlyCooldown[m.sender] && now - hourlyCooldown[m.sender] < oneHour) {
        let remaining = Math.ceil((oneHour - (now - hourlyCooldown[m.sender])) / 60000)
        return reply(`⏰ Bonus hourly sudah diambil! Tunggu ${remaining} menit lagi.`)
    }

    let bonusGold = 50 + (user.level * 2)
    let bonusExp = 10 + user.level

    user.gold += bonusGold
    user.exp += bonusExp
    hourlyCooldown[m.sender] = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `⏰ *HOURLY BONUS* ⏰\n\n`
    msg += `💰 Gold +${bonusGold}\n`
    msg += `📈 EXP +${bonusExp}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .hourly lagi setelah 1 jam!`

    reply(msg)
}

handler.help = ["hourly"]
handler.tags = ["rpg"]
handler.command = ["hourly"]

module.exports = handler