let handler = async (m, { Alice, reply }) => {

const fs = require("fs")
const path = require("path")

const root = process.cwd()

const clearCache = (dir) => {
let files = fs.readdirSync(dir)

for (let file of files) {

let lokasi = path.join(dir, file)
let stat = fs.statSync(lokasi)

if (stat.isDirectory()) {
clearCache(lokasi)
} else {

if (file.endsWith(".js")) {
try {
delete require.cache[require.resolve(lokasi)]
} catch {}
}

}

}
}

clearCache(root)

reply("✅ bot berhasil direload tanpa restart")

}

handler.help = ["reloadbot"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["reloadbot"]

module.exports = handler