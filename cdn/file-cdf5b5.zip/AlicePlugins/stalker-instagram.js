let { instagramStalker } = require("../AliceSystem/AliceScraper/alice-instagramStalker")

let handler = async (m, { args, reply }) => {
  if (!args[0]) return reply("contoh: .igstalk username")

  try {
    let res = await instagramStalker(args[0])
    let r = res.result

    reply(`
「 INSTAGRAM STALKER 」

Username   : ${r.username}
Name       : ${r.name}
Followers  : ${r.followers}
Posts      : ${r.uploads}
Engagement : ${r.engagement}
Avatar     : ${r.avatar}

Link       : ${r.profileUrl}
`)
  } catch (e) {
    reply("error: " + e)
  }
}

handler.help = ["igstalk", "instagramstalk"]
handler.tags = ["stalker"]
handler.command = ["igstalk", "instagramstalk"]

module.exports = handler