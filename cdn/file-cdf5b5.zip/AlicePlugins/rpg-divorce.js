const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.married || user.married === "tidak") return reply("❌ Kamu belum menikah!")

    let pasangan = user.married
    let pasanganUser = db.getUser(pasangan)

    if (user.gold < 1000) return reply(`💰 Gold tidak cukup! Butuh 1000 gold untuk biaya cerai\nGold kamu: ${user.gold}`)

    user.gold -= 1000
    user.married = "tidak"
    
    if (pasanganUser) {
        pasanganUser.married = "tidak"
        db.updateUser(pasangan, pasanganUser)
    }

    db.updateUser(m.sender, user)

    reply(`💔 *PERCERAIAN BERHASIL*\n\n@${m.sender.split('@')[0]} telah bercerai dari @${pasangan.split('@')[0]}\nBiaya cerai 1000 gold telah dipotong.\n\nSemoga hari-harimu tetap menyenangkan.`, { mentions: [m.sender, pasangan] })
}

handler.help = ["divorce"]
handler.tags = ["rpg"]
handler.command = ["divorce", "cerai"]

module.exports = handler