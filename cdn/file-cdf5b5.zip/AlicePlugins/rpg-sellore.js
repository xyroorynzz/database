
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let orePrices = {
    "Batu Biasa": 5,
    "Batu Bara": 10,
    "Bijih Besi": 20,
    "Bijih Emas": 40,
    "Kristal": 60,
    "Permata": 100,
    "Batu Bertuah": 250
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `⛏️ *TOKO BIJIH* ⛏️\n\n`
        for (let [ore, price] of Object.entries(orePrices)) {
            msg += `• ${ore} = ${price} gold\n`
        }
        msg += `\nCara pakai: .sellore <bijih> <jumlah>`
        return reply(msg)
    }

    let oreName = args.slice(0, -1).join(" ")
    let qty = parseInt(args[args.length - 1]) || 1

    if (!orePrices[oreName]) return reply(`❌ Bijih "${oreName}" tidak bisa dijual!`)

    let have = user.inventory[oreName] || 0
    if (have < qty) return reply(`❌ ${oreName} tidak cukup! Kamu punya ${have}`)

    let totalGold = orePrices[oreName] * qty

    user.inventory[oreName] -= qty
    if (user.inventory[oreName] === 0) delete user.inventory[oreName]
    user.gold += totalGold

    db.updateUser(m.sender, user)

    reply(`⛏️ *PENJUALAN BIJIH* ⛏️\n\n✅ ${qty} ${oreName} terjual!\n💰 Gold +${totalGold}\n💵 Total gold: ${user.gold}`)
}

handler.help = ["sellore"]
handler.tags = ["rpg"]
handler.command = ["sellore"]

module.exports = handler