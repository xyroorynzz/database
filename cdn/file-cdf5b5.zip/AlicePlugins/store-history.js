const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

let handler = async (m, { command, text, reply, prefix }) => {
    const sender = m.sender;
    
    if (command === 'pesananku' || command === 'myorder') {
        let history = loadJSON(HISTORY_FILE);
        if (!Array.isArray(history)) history = [];
        let myOrders = history.filter(t => t.buyer === sender);
        
        if (myOrders.length === 0) return reply('📭 Kamu belum pernah order.');
        
        let teks = `📋 PESANANKU\n━━━━━━━━━━━━━━━━━━\n`;
        myOrders.forEach((order, i) => {
            let statusIcon = order.status === 'success' ? '✅' : order.status === 'pending' ? '⏳' : '❌';
            let statusText = order.status === 'success' ? 'SUKSES' : order.status === 'pending' ? 'MENUNGGU' : 'BATAL';
            teks += `${i+1}. ${statusIcon} ${order.id}\n`;
            teks += `   📅 ${new Date(order.tanggal).toLocaleDateString('id-ID')}\n`;
            teks += `   💰 Total: Rp${toRupiah(order.total)}\n`;
            teks += `   📌 Status: ${statusText}\n\n`;
        });
        reply(teks);
    }
    
    else if (command === 'detailorder') {
        if (!text) return reply(`Contoh: ${prefix}detailorder TRX123456789`);
        let history = loadJSON(HISTORY_FILE);
        let order = history.find(t => t.id === text.trim());
        if (!order) return reply(`Transaksi "${text}" tidak ditemukan!`);
        if (order.buyer !== sender && !isOwner) return reply('❌ Bukan pesanan kamu!');
        
        let teks = `📦 DETAIL ORDER\n━━━━━━━━━━━━━━━━━━\n`;
        teks += `🆔 ID: ${order.id}\n`;
        teks += `📅 Tanggal: ${new Date(order.tanggal).toLocaleString('id-ID')}\n`;
        teks += `📌 Status: ${order.status.toUpperCase()}\n`;
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `🛒 ITEM:\n`;
        order.items.forEach(item => {
            teks += `   • ${item.nama} (${item.jumlah}x) = Rp${toRupiah(item.subtotal)}\n`;
        });
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `💰 TOTAL: Rp${toRupiah(order.total)}\n`;
        reply(teks);
    }
};

handler.command = ['pesananku', 'myorder', 'detailorder'];
handler.tags = ['store'];

module.exports = handler;