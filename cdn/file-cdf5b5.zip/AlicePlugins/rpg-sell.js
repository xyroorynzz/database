
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let sellPrices = {
    "Potion Kecil": 25,
    "Potion Sedang": 40,
    "Potion Besar": 75,
    "Elixir": 250,
    "Batu Biasa": 5,
    "Batu Bara": 10,
    "Bijih Besi": 20,
    "Bijih Emas": 40,
    "Kristal": 60,
    "Permata": 100,
    "Batu Bertuah": 250
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `💰 *JUAL ITEM* 💰\n\n`
        for (let [item, price] of Object.entries(sellPrices)) {
            msg += `• ${item} = ${price} gold\n`
        }
        msg += `\nCara pakai: .sell <item> <jumlah>\nContoh: .sell potion kecil 5`
        return reply(msg)
    }

    let itemName = args.slice(0, -1).join(" ")
    let qty = parseInt(args[args.length - 1]) || 1

    if (isNaN(qty) || qty < 1) return reply("❌ Jumlah tidak valid!")

    let price = sellPrices[itemName]
    if (!price) return reply(`❌ Item "${itemName}" tidak bisa dijual!`)

    let userQty = user.inventory[itemName] || 0
    if (userQty < qty) return reply(`❌ ${itemName} tidak cukup! Kamu punya ${userQty}`)

    let totalGold = price * qty

    user.inventory[itemName] -= qty
    if (user.inventory[itemName] === 0) delete user.inventory[itemName]
    user.gold += totalGold

    db.updateUser(m.sender, user)

    reply(`💰 *PENJUALAN BERHASIL* 💰\n\n📦 ${qty} ${itemName} terjual!\n💰 Gold +${totalGold}\n💵 Total gold: ${user.gold}`)
}

handler.help = ["sell"]
handler.tags = ["rpg"]
handler.command = ["sell", "jual"]

module.exports = handler