
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let expeditionCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (expeditionCooldown[m.sender] && now - expeditionCooldown[m.sender] < 86400000) {
        let remaining = Math.ceil((86400000 - (now - expeditionCooldown[m.sender])) / 3600000)
        return reply(`⏰ Ekspedisi sudah dilakukan! Tunggu ${remaining} jam lagi.`)
    }

    if (user.stamina < 50) return reply("❤️ Stamina kurang! Butuh 50 stamina untuk ekspedisi.\nKetik .heal untuk istirahat.")

    let islands = [
        { name: "🏝️ Pulau Misteri", minExp: 200, maxExp: 500, minGold: 300, maxGold: 800, minItem: 2, maxItem: 5 },
        { name: "🏔️ Pulau Es", minExp: 300, maxExp: 600, minGold: 400, maxGold: 1000, minItem: 3, maxItem: 7 },
        { name: "🌋 Pulau Api", minExp: 400, maxExp: 800, minGold: 500, maxGold: 1200, minItem: 4, maxItem: 10 }
    ]

    let island = islands[Math.floor(Math.random() * islands.length)]
    let expGain = Math.floor(Math.random() * (island.maxExp - island.minExp + 1) + island.minExp)
    let goldGain = Math.floor(Math.random() * (island.maxGold - island.minGold + 1) + island.minGold)
    let itemCount = Math.floor(Math.random() * (island.maxItem - island.minItem + 1) + island.minItem)

    user.stamina -= 50
    user.exp += expGain
    user.gold += goldGain

    let rareItems = ["Kristal", "Permata", "Batu Bertuah", "Elixir", "Potion Besar"]
    for (let i = 0; i < itemCount; i++) {
        let item = rareItems[Math.floor(Math.random() * rareItems.length)]
        if (!user.inventory[item]) user.inventory[item] = 0
        user.inventory[item] += 1
    }

    if (!user.expeditionCount) user.expeditionCount = 0
    user.expeditionCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    expeditionCooldown[m.sender] = now

    let msg = `🚢 *EKSPEDISI* 🚢\n\n`
    msg += `📍 Tujuan: ${island.name}\n\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📦 Item +${itemCount} item langka\n`
    msg += `❤️ Stamina -50 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Ekspedisi: ${user.expeditionCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .expedition lagi setelah 24 jam!`

    reply(msg)
}

handler.help = ["expedition"]
handler.tags = ["rpg"]
handler.command = ["expedition"]

module.exports = handler