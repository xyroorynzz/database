let { mobilelegendStalker } = require("../AliceSystem/AliceScraper/alice-mobilelegendStalker")

let handler = async (m, { args, reply }) => {
  if (args.length < 2) return reply("contoh: .mlstalk id zone")

  try {
    let res = await mobilelegendStalker(args[0], args[1])
    let r = res.result

    reply(`
「 MOBILE LEGENDS STALKER 」

Username : ${r.username}
Region   : ${r.region}
`)
  } catch (e) {
    reply("error: " + e)
  }
}

handler.help = ["mlstalk", "mobilelegendstalk"]
handler.tags = ["stalker"]
handler.command = ["mlstalk", "mobilelegendstalk"]

module.exports = handler