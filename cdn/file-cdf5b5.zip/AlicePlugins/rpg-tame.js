const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 20) return reply("❤️ Stamina kurang! Butuh 20 stamina untuk menjinakkan.\nKetik .heal untuk istirahat.")

    let animals = [
        { name: "🐺 Serigala", successRate: 30, minExp: 30, maxExp: 60, goldCost: 0 },
        { name: "🦅 Elang", successRate: 25, minExp: 40, maxExp: 70, goldCost: 0 },
        { name: "🐗 Babi Hutan", successRate: 50, minExp: 20, maxExp: 40, goldCost: 0 },
        { name: "🐉 Naga Kecil", successRate: 10, minExp: 100, maxExp: 200, goldCost: 5000 }
    ]

    let animal = animals[Math.floor(Math.random() * animals.length)]
    let success = Math.random() * 100 < animal.successRate

    user.stamina -= 20

    let msg = `🦴 *MENJINAKKAN HEWAN* 🦴\n\n`
    msg += `🐾 Hewan: ${animal.name}\n`

    if (success) {
        let expGain = Math.floor(Math.random() * (animal.maxExp - animal.minExp + 1) + animal.minExp)
        user.exp += expGain
        if (animal.goldCost > 0) user.gold -= animal.goldCost

        if (!user.tamedAnimals) user.tamedAnimals = []
        user.tamedAnimals.push(animal.name)

        msg += `✅ BERHASIL!\n📈 EXP +${expGain}\n🐾 Hewan berhasil dijinakkan!\n`
        if (animal.goldCost > 0) msg += `💰 Gold -${animal.goldCost}\n`
    } else {
        msg += `❌ GAGAL!\n💔 Hewan kabur! Coba lagi lain kali.\n`
    }

    msg += `❤️ Stamina -20 (${user.stamina}/${user.maxStamina})`

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    db.updateUser(m.sender, user)
    reply(msg)
}

handler.help = ["tame"]
handler.tags = ["rpg"]
handler.command = ["tame", "jinak"]

module.exports = handler