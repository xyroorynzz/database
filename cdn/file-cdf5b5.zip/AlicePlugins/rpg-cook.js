
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let recipes = {
    "ikan bakar": { need: { "Ikan Kecil": 1 }, result: { name: "Ikan Bakar", heal: 20, sell: 50 } },
    "sup ikan": { need: { "Ikan Mas": 2 }, result: { name: "Sup Ikan", heal: 35, sell: 80 } },
    "steak ikan": { need: { "Ikan Salmon": 1, "Batu Bara": 1 }, result: { name: "Steak Ikan", heal: 50, sell: 120 } },
    "sate ikan": { need: { "Ikan Lele": 2, "Kayu": 1 }, result: { name: "Sate Ikan", heal: 40, sell: 90 } }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🍳 *RESEP MASAKAN* 🍳\n\n`
        for (let [resep, data] of Object.entries(recipes)) {
            msg += `• ${resep}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Hasil: ${data.result.name} (heal +${data.result.heal})\n\n`
        }
        msg += `Cara pakai: .cook ikan bakar`
        return reply(msg)
    }

    let recipeName = args.join(" ").toLowerCase()
    let recipe = recipes[recipeName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    if (!user.inventory[recipe.result.name]) user.inventory[recipe.result.name] = 0
    user.inventory[recipe.result.name] += 1
    user.exp += 15

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🍳 *MEMASAK BERHASIL* 🍳\n\n`
    msg += `✅ ${recipe.result.name} berhasil dibuat!\n`
    msg += `📦 ${recipe.result.name} sekarang: ${user.inventory[recipe.result.name]}\n`
    msg += `📈 EXP +15\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["cook"]
handler.tags = ["rpg"]
handler.command = ["cook", "masak"]

module.exports = handler