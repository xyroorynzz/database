const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text, Alice }) => {

if (!text) return reply("contoh: .getp ping")

let name = text.endsWith(".js") ? text : text + ".js"

let dir = path.join(__dirname, name)

if (!fs.existsSync(dir)) return reply("plugin tidak ada")

let code = fs.readFileSync(dir,"utf8")

Alice.sendMessage(m.chat,{text:code},{quoted:m})

}

handler.help = ["getp"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["getp","getplugins"]

module.exports = handler