
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneWeek = 7 * 24 * 60 * 60 * 1000

    if (user.lastWeekly && now - user.lastWeekly < oneWeek) {
        let remaining = oneWeek - (now - user.lastWeekly)
        let days = Math.floor(remaining / (24 * 60 * 60 * 1000))
        let hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))
        return reply(`⏰ Hadiah mingguan sudah diambil!\nTunggu ${days} hari ${hours} jam lagi.`)
    }

    let bonusGold = 5000
    let bonusExp = 1000
    let bonusStamina = 100
    let bonusItem = "Potion Besar"

    user.gold += bonusGold
    user.exp += bonusExp
    user.stamina = Math.min(user.stamina + bonusStamina, user.maxStamina)

    if (!user.inventory[bonusItem]) user.inventory[bonusItem] = 0
    user.inventory[bonusItem] += 3

    user.lastWeekly = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎁 *HADIAH MINGGUAN* 🎁\n\n`
    msg += `💰 Gold +${bonusGold}\n`
    msg += `📈 EXP +${bonusExp}\n`
    msg += `❤️ Stamina +${bonusStamina}\n`
    msg += `🧪 Potion Besar +3\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKembali minggu depan untuk hadiah lagi!`

    reply(msg)
}

handler.help = ["weekly"]
handler.tags = ["rpg"]
handler.command = ["weekly"]

module.exports = handler