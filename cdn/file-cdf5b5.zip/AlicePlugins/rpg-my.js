
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.weaponDurability === undefined) user.weaponDurability = 100
    if (user.armorDurability === undefined) user.armorDurability = 100

    let progressBar = ''
    let progress = (user.exp / user.expNeeded) * 100
    let filled = Math.floor(progress / 5)
    for (let i = 0; i < 20; i++) {
        progressBar += i < filled ? '█' : '░'
    }

    let caption = `*━━━━━〔 STATUS PETUALANG 〕━━━━━*\n\n`
    caption += `👤 Nama: ${user.name}\n`
    caption += `⭐ Level: ${user.level}\n`
    caption += `📊 EXP: ${user.exp}/${user.expNeeded}\n`
    caption += `📈 [${progressBar}] ${Math.floor(progress)}%\n\n`
    caption += `❤️ Stamina: ${user.stamina}/${user.maxStamina}\n`
    caption += `💰 Gold: ${user.gold}\n`
    caption += `🏦 Bank: ${user.bank || 0}\n\n`
    caption += `⚔️ Weapon: ${user.weapon} (Durability: ${user.weaponDurability}/100)\n`
    if (user.weaponBonus) caption += `   ✨ Enchant: +${user.weaponBonus} damage\n`
    caption += `🛡️ Armor: ${user.armor} (Durability: ${user.armorDurability}/100)\n`
    if (user.armorBonus) caption += `   ✨ Enchant: +${user.armorBonus} defense\n\n`
    caption += `🏆 Total Hunt: ${user.totalHunt || 0}\n`
    caption += `⛏️ Mining: ${user.mining || 0}\n`
    caption += `🎣 Fishing: ${user.fishing || 0}\n`
    caption += `💼 Work: ${user.workCount || 0}\n`
    caption += `🧭 Adventure: ${user.adventureCount || 0}\n`
    caption += `🏟️ Arena: ${user.arenaWin || 0}W / ${user.arenaLose || 0}L\n\n`
    caption += `📦 Inventory:\n`
    
    if (user.inventory && typeof user.inventory === 'object') {
        for (let [item, qty] of Object.entries(user.inventory)) {
            if (qty > 0) caption += `   • ${item}: ${qty}\n`
        }
    } else {
        caption += `   • Kosong\n`
    }

    reply(caption)
}

handler.help = ["my"]
handler.tags = ["rpg"]
handler.command = ["my", "profil", "status"]

module.exports = handler