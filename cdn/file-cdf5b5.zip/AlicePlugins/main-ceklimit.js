const fs = require("fs")

global.limitDB = global.limitDB || {}

let handler = async (m, { reply, isOwner, isPrem }) => {

let user = global.limitDB[m.sender]

if (!user) {
  user = global.limitDB[m.sender] = {
    limit: global.limitawal.free,
    lastReset: Date.now(),
    lastClaim: 0
  }
}

let role = isOwner ? "owner" : isPrem ? "premium" : "free"

reply(`🎯 LIMIT INFO

👤 Role : ${role}
📊 Sisa : ${user.limit}
⚙️ Mode : ${global.limitSettings.enabled ? "ON" : "OFF"}
⏱ Reset: 24 jam

claim limit ketik .limitdaily`)

}

handler.help = ["limit","ceklimit"]
handler.tags = ["main"]
handler.command = ["limit","ceklimit"]

module.exports = handler