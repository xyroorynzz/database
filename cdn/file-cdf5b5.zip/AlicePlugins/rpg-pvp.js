
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let pvpData = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null
    let bet = null

    if (m.quoted) {
        target = m.quoted.sender
        bet = parseInt(args[0])
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
        bet = parseInt(args[1])
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                bet = parseInt(args[i+1])
                break
            }
        }
    }

    if (!target) return reply("⚠️ Tag/reply pemain yang ingin diajak PVP!\nContoh: .pvp @6285252512178 500")
    if (target === m.sender) return reply("❌ Tidak bisa PVP dengan diri sendiri!")

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    if (user.stamina < 30) return reply("❤️ Stamina kamu kurang! Butuh 30 stamina untuk PVP.\nKetik .heal untuk istirahat.")
    if (targetUser.stamina < 30) return reply("❤️ Stamina target kurang! Target butuh istirahat dulu.")

    if (isNaN(bet) || bet < 50) return reply("💰 Taruhan minimal 50 gold!")
    if (bet > 1000) return reply("💰 Taruhan maksimal 1000 gold!")

    if (user.gold < bet) return reply(`💰 Gold kamu tidak cukup untuk taruhan ${bet} gold!`)
    if (targetUser.gold < bet) return reply(`💰 Gold target tidak cukup untuk taruhan ${bet} gold!`)

    if (!pvpData[m.chat]) pvpData[m.chat] = {}

    if (pvpData[m.chat][m.sender]) return reply("⚠️ Kamu sedang dalam sesi PVP!")
    if (pvpData[m.chat][target]) return reply("⚠️ Target sedang dalam sesi PVP!")

    pvpData[m.chat][m.sender] = { opponent: target, bet: bet, status: "pending", startTime: Date.now() }

    let msg = `⚔️ *PVP CHALLENGE* ⚔️\n\n`
    msg += `@${m.sender.split('@')[0]} menantang @${target.split('@')[0]} untuk PVP!\n\n`
    msg += `💰 Taruhan: ${bet} gold\n\n`
    msg += `Ketik .pvpaccept untuk menerima\n`
    msg += `Ketik .pvpreject untuk menolak\n\n`
    msg += `Waktu habis dalam 60 detik.`

    reply(msg, { mentions: [m.sender, target] })

    setTimeout(() => {
        if (pvpData[m.chat][m.sender] && pvpData[m.chat][m.sender].status === "pending") {
            delete pvpData[m.chat][m.sender]
            reply(`⏰ Waktu habis! PVP antara @${m.sender.split('@')[0]} dan @${target.split('@')[0]} dibatalkan.`, { mentions: [m.sender, target] })
        }
    }, 60000)
}

handler.help = ["pvp"]
handler.tags = ["rpg"]
handler.command = ["pvp"]

module.exports = handler