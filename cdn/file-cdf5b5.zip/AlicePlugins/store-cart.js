const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const CART_FILE = path.join(STORE_DIR, 'cart.json');
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
const DISCOUNT_FILE = path.join(STORE_DIR, 'discounts.json');
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify({}));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

function getProducts() {
    ensureDir();
    if (!fs.existsSync(PRODUCT_FILE)) fs.writeFileSync(PRODUCT_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(PRODUCT_FILE));
}

function getDiscounts() {
    ensureDir();
    if (!fs.existsSync(DISCOUNT_FILE)) fs.writeFileSync(DISCOUNT_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(DISCOUNT_FILE));
}

let handler = async (m, { command, text, reply, prefix, Alice }) => {
    const sender = m.sender;
    let cart = loadJSON(CART_FILE);
    if (!cart[sender]) cart[sender] = [];

    if (command === 'addcart') {
        if (!text) return reply(`Contoh: ${prefix}addcart nama_produk|jumlah`);
        let [productName, quantity] = text.split('|').map(v => v.trim());
        let jumlah = parseInt(quantity);
        if (!productName || isNaN(jumlah) || jumlah < 1) {
            return reply(`Format salah! Contoh: ${prefix}addcart indomie|2`);
        }
        const products = getProducts();
        const product = products.find(p => p.nama.toLowerCase() === productName.toLowerCase());
        if (!product) return reply(`Produk "${productName}" tidak ditemukan!`);
        const discounts = getDiscounts();
        const discount = discounts.find(d => d.produk.toLowerCase() === product.nama.toLowerCase());
        const hargaSatuan = discount ? discount.harga_diskon : product.harga;
        const existingItem = cart[sender].find(item => item.nama.toLowerCase() === productName.toLowerCase());
        if (existingItem) {
            existingItem.jumlah += jumlah;
            existingItem.subtotal = existingItem.jumlah * hargaSatuan;
        } else {
            cart[sender].push({
                nama: product.nama,
                harga_satuan: hargaSatuan,
                jumlah: jumlah,
                subtotal: jumlah * hargaSatuan
            });
        }
        saveJSON(CART_FILE, cart);
        reply(`✅ ${jumlah}x ${product.nama} ditambahkan ke keranjang!\n💰 Subtotal: Rp${toRupiah(jumlah * hargaSatuan)}`);
    }
    
    else if (command === 'mycart') {
        if (cart[sender].length === 0) return reply('🛒 Keranjang belanja kamu kosong!\nGunakan .addcart untuk belanja.');
        let total = 0;
        let teks = `🛒 KERANJANG BELANJA\n━━━━━━━━━━━━━━━━━━\n`;
        cart[sender].forEach((item, i) => {
            teks += `${i+1}. ${item.nama}\n`;
            teks += `   Jumlah: ${item.jumlah} x Rp${toRupiah(item.harga_satuan)}\n`;
            teks += `   Subtotal: Rp${toRupiah(item.subtotal)}\n\n`;
            total += item.subtotal;
        });
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `💰 Total: Rp${toRupiah(total)}\n\n`;
        teks += `📌 Ketik ${prefix}checkout untuk memproses pesanan`;
        reply(teks);
    }
    
    else if (command === 'delcart') {
        if (!text) return reply(`Contoh: ${prefix}delcart 1`);
        const index = parseInt(text) - 1;
        if (isNaN(index) || index < 0 || index >= cart[sender].length) {
            return reply('Nomor item tidak valid! Lihat .mycart dulu.');
        }
        const removed = cart[sender].splice(index, 1);
        saveJSON(CART_FILE, cart);
        reply(`🗑️ ${removed[0].nama} dihapus dari keranjang.`);
    }
    
    else if (command === 'clearcart') {
        cart[sender] = [];
        saveJSON(CART_FILE, cart);
        reply('🗑️ Keranjang belanja berhasil dikosongkan!');
    }
    
    else if (command === 'checkout') {
        if (cart[sender].length === 0) return reply('🛒 Keranjang kosong!');
        let total = 0;
        let detail = '';
        cart[sender].forEach(item => {
            detail += `• ${item.nama} (${item.jumlah}x) = Rp${toRupiah(item.subtotal)}\n`;
            total += item.subtotal;
        });
        let diskon = 0;
        if (global.tempVoucher && global.tempVoucher[`voucher_${sender}`]) {
            diskon = global.tempVoucher[`voucher_${sender}`].diskon;
            total = total - diskon;
            if (total < 0) total = 0;
            delete global.tempVoucher[`voucher_${sender}`];
        }
        const transactionId = `TRX${Date.now()}${Math.floor(Math.random() * 1000)}`;
        let history = loadJSON(HISTORY_FILE);
        if (!Array.isArray(history)) history = [];
        history.push({
            id: transactionId,
            buyer: m.sender,
            items: cart[sender],
            total: total,
            status: 'pending',
            tanggal: new Date().toISOString()
        });
        saveJSON(HISTORY_FILE, history);
        let invoice = `🧾 INVOICE PEMBELIAN\n━━━━━━━━━━━━━━━━━━\n`;
        invoice += `📋 ID Transaksi: ${transactionId}\n`;
        invoice += `👤 Pembeli: @${m.sender.split('@')[0]}\n`;
        invoice += detail;
        if (diskon > 0) invoice += `🎁 Diskon: -Rp${toRupiah(diskon)}\n`;
        invoice += `━━━━━━━━━━━━━━━━━━\n`;
        invoice += `💰 Total Bayar: Rp${toRupiah(total)}\n\n`;
        invoice += `💳 Silakan transfer ke:\n`;
        const paymentFile = path.join(STORE_DIR, 'payment.json');
        let payment = {};
        if (fs.existsSync(paymentFile)) payment = JSON.parse(fs.readFileSync(paymentFile));
        invoice += `${payment.gopay ? `🟢 GoPay: ${payment.gopay}\n` : ''}`;
        invoice += `${payment.dana ? `🔵 Dana: ${payment.dana}\n` : ''}`;
        invoice += `📷 QRIS: ${payment.qris || '-'}\n\n`;
        invoice += `📌 Setelah transfer, konfirmasi dengan:\n`;
        invoice += `${prefix}confirm ${transactionId}`;
        cart[sender] = [];
        saveJSON(CART_FILE, cart);
        await Alice.sendMessage(m.chat, { text: invoice, mentions: [m.sender] }, { quoted: m });
    }
};

handler.command = ['addcart', 'mycart', 'delcart', 'clearcart', 'checkout'];
handler.tags = ['store'];

module.exports = handler;