const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const TRANS_FILE = path.join(STORE_DIR, 'transaksi.json');

function loadTrans() {
    if (!fs.existsSync(TRANS_FILE)) return {};
    return JSON.parse(fs.readFileSync(TRANS_FILE));
}

function saveTrans(data) {
    fs.writeFileSync(TRANS_FILE, JSON.stringify(data, null, 2));
}

function formatmoney(amount) {
    return new Intl.NumberFormat('id-ID').format(amount);
}

let handler = async (m, { command, reply, Alice }) => {
    let trans = loadTrans();
    let trx = trans[m.sender];
    
    if (!trx) return reply('❌ Tidak ada transaksi aktif.');
    
    try {
        if (trx.key) {
            await Alice.sendMessage(trx.key.remoteJid, {
                delete: {
                    remoteJid: trx.key.remoteJid,
                    fromMe: trx.key.fromMe,
                    id: trx.key.id,
                    participant: trx.key.participant
                }
            });
        }
    } catch (err) {
        console.log('Gagal hapus QRIS:', err.message);
    }
    
    delete trans[m.sender];
    saveTrans(trans);
    
    reply(`🚫 Transaksi ${trx.jenis} sebesar Rp${formatmoney(trx.harga)} telah dibatalkan.`);
};

handler.command = ['cancel-tr', 'batalkan'];
handler.tags = ['store'];

module.exports = handler;