
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let tournamentData = db.getTournamentData()

    if (!args.length) {
        let msg = `🏟️ *ARENA TURNAMEN* 🏟️\n\n`
        msg += `Command:\n`
        msg += `.arena2 join - Gabung turnamen (biaya 1000 gold)\n`
        msg += `.arena2 start - Mulai turnamen (hanya owner)\n`
        msg += `.arena2 status - Lihat status turnamen`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "join") {
        if (!tournamentData[m.chat]) tournamentData[m.chat] = { players: [], status: "waiting" }

        if (tournamentData[m.chat].players.includes(m.sender)) return reply("❌ Kamu sudah bergabung!")

        if (user.gold < 1000) return reply("💰 Gold tidak cukup! Butuh 1000 gold")

        user.gold -= 1000
        tournamentData[m.chat].players.push(m.sender)

        db.updateUser(m.sender, user)
        db.saveTournamentData(tournamentData)

        reply(`✅ @${m.sender.split('@')[0]} bergabung ke turnamen!\n👥 Total peserta: ${tournamentData[m.chat].players.length}`, { mentions: [m.sender] })
    }
    else if (action === "start") {
        if (!isOwner) return reply("❌ Hanya owner yang bisa memulai turnamen!")

        let players = tournamentData[m.chat]?.players
        if (!players || players.length < 2) return reply("❌ Minimal 2 peserta untuk memulai turnamen!")

        let winner = players[Math.floor(Math.random() * players.length)]
        let prize = players.length * 1000

        let winnerUser = db.getUser(winner)
        winnerUser.gold += prize
        db.updateUser(winner, winnerUser)

        reply(`🏆 *HASIL TURNAMEN* 🏆\n\n🥇 Pemenang: @${winner.split('@')[0]}\n💰 Hadiah: ${prize} gold\n\nTotal peserta: ${players.length}`, { mentions: [winner] })

        delete tournamentData[m.chat]
        db.saveTournamentData(tournamentData)
    }
    else if (action === "status") {
        let data = tournamentData[m.chat]
        if (!data) return reply("❌ Belum ada turnamen!")

        reply(`🏟️ *STATUS TURNAMEN*\n\n👥 Peserta: ${data.players.length}\n📌 Status: ${data.status}\n💰 Total hadiah: ${data.players.length * 1000} gold`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.arena2 join\n.arena2 start\n.arena2 status`)
    }
}

handler.help = ["arena2"]
handler.tags = ["rpg"]
handler.command = ["arena2"]

module.exports = handler