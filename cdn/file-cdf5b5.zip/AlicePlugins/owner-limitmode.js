let handler = async (m, { reply, isOwner, args }) => {

if (!isOwner) return reply("❌ Khusus owner")

if (!args[0]) {
  return reply(`⚙️ LIMIT MODE

Status : ${global.limitSettings.enabled ? "ON" : "OFF"}

Gunakan:
.limitmode on
.limitmode off`)
}

if (args[0].toLowerCase() === "on") {
  global.limitSettings.enabled = true
  global.saveLimitMode()
  return reply("✅ Limit berhasil diaktifkan")
}

if (args[0].toLowerCase() === "off") {
  global.limitSettings.enabled = false
  global.saveLimitMode()
  return reply("❌ Limit berhasil dimatikan")
}

reply("Gunakan: .limitmode on / off")

}

handler.help = ["limitmode"]
handler.tags = ["owner"]
handler.command = ["limitmode"]

module.exports = handler