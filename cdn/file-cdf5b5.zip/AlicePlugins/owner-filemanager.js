const fs = require("fs")
const path = require("path")

let handler = async (m, { Alice, command, text, quoted, reply }) => {

const root = process.cwd()

// upload file
if (command === "uploadfile") {

if (!quoted) return reply("reply file\ncontoh: .uploadfile plugins/menu.js")

let name = text ? text.trim() : quoted.fileName
if (!name) return reply("nama file tidak ada")

let lokasi = path.resolve(root, name)

let buffer = await quoted.download()

fs.mkdirSync(path.dirname(lokasi), { recursive: true })
fs.writeFileSync(lokasi, buffer)

return reply(`📤 file diupload\n${name}`)
}

// get file
if (command === "getfile") {

if (!text) return reply("contoh: .getfile plugins/menu.js")

let lokasi = path.join(root, text)

if (!fs.existsSync(lokasi)) return reply("file tidak ditemukan")

await Alice.sendMessage(m.chat, {
document: fs.readFileSync(lokasi),
fileName: path.basename(lokasi)
}, { quoted: m })

}

// delete file
if (command === "delfile") {

if (!text) return reply("contoh: .delfile menu.js")

let hasil = null

const scan = (dir) => {

let files = fs.readdirSync(dir)

for (let file of files) {

let lokasi = path.join(dir, file)
let stat = fs.statSync(lokasi)

if (stat.isDirectory()) {
scan(lokasi)
} else {
if (file === text) {
hasil = lokasi
}
}

}

}

scan(root)

if (!hasil) return reply("file tidak ditemukan")

fs.unlinkSync(hasil)

return reply(`🗑 file dihapus\n${text}`)

}

}

handler.help = [
"uploadfile",
"getfile",
"delfile"
]

handler.tags = ["owner"]
handler.owner = true

handler.command = [
"uploadfile",
"getfile",
"delfile"
]

module.exports = handler