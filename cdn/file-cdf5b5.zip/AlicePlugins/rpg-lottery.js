
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let lotteryData = {
    tickets: {},
    prizePool: 0,
    lastDraw: 0,
    nextDraw: 0
}

let lotteryPath = './AliceSystem/AliceDatabase/Rpg/lottery.json'
const fs = require('fs')

function loadLottery() {
    try {
        if (fs.existsSync(lotteryPath)) {
            let data = JSON.parse(fs.readFileSync(lotteryPath, 'utf-8'))
            lotteryData.tickets = data.tickets || {}
            lotteryData.prizePool = data.prizePool || 0
            lotteryData.lastDraw = data.lastDraw || 0
            lotteryData.nextDraw = data.nextDraw || 0
        }
    } catch (err) {}
}

function saveLottery() {
    fs.writeFileSync(lotteryPath, JSON.stringify(lotteryData, null, 2))
}

loadLottery()

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()

    if (!args.length) {
        let msg = `🎫 *LOTTERY RPG* 🎫\n\n`
        msg += `🎰 Hadiah: ${lotteryData.prizePool || 0} gold\n`
        msg += `🎫 Tiket terjual: ${Object.keys(lotteryData.tickets).length}\n`
        if (lotteryData.nextDraw > now) {
            let remaining = Math.ceil((lotteryData.nextDraw - now) / 60000)
            msg += `⏰ Pengundian dalam: ${remaining} menit\n\n`
        } else {
            msg += `⏰ Pengundian segera! Ketik .lottery draw untuk mengundi\n\n`
        }
        msg += `Command:\n.lottery buy <jumlah> - Beli tiket (1000 gold/tiket)\n.lottery draw - Lakukan pengundian (hanya owner)`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "buy") {
        let qty = parseInt(args[1]) || 1
        let price = 1000 * qty

        if (user.gold < price) return reply(`💰 Gold tidak cukup! Butuh ${price} gold untuk ${qty} tiket`)

        user.gold -= price
        lotteryData.prizePool += price

        for (let i = 0; i < qty; i++) {
            let ticketId = Date.now() + Math.random().toString(36)
            lotteryData.tickets[ticketId] = m.sender
        }

        db.updateUser(m.sender, user)
        saveLottery()

        reply(`✅ Kamu membeli ${qty} tiket lottery!\n💰 Total hadiah: ${lotteryData.prizePool} gold`)
    }
    else if (action === "draw") {
        if (!isOwner) return reply("❌ Hanya owner yang bisa mengundi lottery!")

        if (Object.keys(lotteryData.tickets).length === 0) {
            return reply("❌ Belum ada tiket yang terjual!")
        }

        let tickets = Object.entries(lotteryData.tickets)
        let winner = tickets[Math.floor(Math.random() * tickets.length)]
        let winnerId = winner[1]
        let prize = lotteryData.prizePool

        let winnerUser = db.getUser(winnerId)
        if (winnerUser) {
            winnerUser.gold += prize
            db.updateUser(winnerId, winnerUser)
        }

        reply(`🎉 *LOTTERY DRAW* 🎉\n\n🏆 Pemenang: @${winnerId.split('@')[0]}\n💰 Hadiah: ${prize} gold\n\nSelamat!`, { mentions: [winnerId] })

        lotteryData.tickets = {}
        lotteryData.prizePool = 0
        lotteryData.lastDraw = now
        lotteryData.nextDraw = now + (24 * 60 * 60 * 1000)
        saveLottery()
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.lottery buy <jumlah>\n.lottery draw`)
    }
}

handler.help = ["lottery"]
handler.tags = ["rpg"]
handler.command = ["lottery"]

module.exports = handler