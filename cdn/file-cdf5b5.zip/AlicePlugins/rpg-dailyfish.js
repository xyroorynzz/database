
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyFish && now - user.lastDailyFish < oneDay) {
        let remaining = oneDay - (now - user.lastDailyFish)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        return reply(`⏰ Mancing harian sudah diambil! Tunggu ${hours} jam lagi.`)
    }

    let targetFish = 10
    let currentFish = user.dailyFishProgress || 0

    if (currentFish < targetFish) {
        return reply(`📋 *MANCING HARIAN*\n\nTarget: ${targetFish} fish\nProgress: ${currentFish}/${targetFish}\n\nSelesaikan dengan melakukan .fish ${targetFish - currentFish} kali lagi!`)
    }

    let rewardGold = 2000
    let rewardExp = 400
    let rewardItem = "Ikan Salmon"

    user.gold += rewardGold
    user.exp += rewardExp
    if (!user.inventory[rewardItem]) user.inventory[rewardItem] = 0
    user.inventory[rewardItem] += 3
    user.dailyFishProgress = 0
    user.lastDailyFish = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎣 *MANCING HARIAN SELESAI* 🎣\n\n`
    msg += `✅ ${targetFish} fish completed!\n`
    msg += `💰 Gold +${rewardGold}\n`
    msg += `📈 EXP +${rewardExp}\n`
    msg += `🐟 Ikan Salmon +3\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["dailyfish"]
handler.tags = ["rpg"]
handler.command = ["dailyfish"]

module.exports = handler