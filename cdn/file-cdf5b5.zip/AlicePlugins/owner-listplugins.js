const fs = require("fs")

let handler = async (m, { reply }) => {

let files = fs.readdirSync(__dirname).filter(v => v.endsWith(".js"))

let txt = "📦 LIST PLUGINS\n\n"

files.forEach(v => {
txt += "• " + v + "\n"
})

reply(txt)

}

handler.help = ["listp"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["listp","listplugins"]

module.exports = handler