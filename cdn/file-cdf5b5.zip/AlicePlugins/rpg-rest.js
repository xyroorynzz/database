const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let cooldown = 10 * 60 * 1000

    if (user.lastRest && now - user.lastRest < cooldown) {
        let remaining = Math.ceil((cooldown - (now - user.lastRest)) / 60000)
        return reply(`⏰ Kamu baru saja istirahat panjang! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina >= user.maxStamina) {
        return reply(`❤️ Stamina sudah penuh! (${user.stamina}/${user.maxStamina})`)
    }

    let healAmount = Math.floor(user.maxStamina * 0.6)
    let oldStamina = user.stamina
    user.stamina = Math.min(user.stamina + healAmount, user.maxStamina)
    user.lastRest = now

    db.updateUser(m.sender, user)

    let actualHeal = user.stamina - oldStamina
    reply(`🛌 *ISTIRAHAT PANJANG*\n\n❤️ Stamina pulih +${actualHeal}\n💪 Stamina sekarang: ${user.stamina}/${user.maxStamina}\n⏰ Cooldown 10 menit\n\nKetik .hunt atau .adventure untuk lanjut!`)
}

handler.help = ["rest"]
handler.tags = ["rpg"]
handler.command = ["rest", "tidur"]

module.exports = handler