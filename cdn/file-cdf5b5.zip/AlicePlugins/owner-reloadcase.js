let handler = async (m, { Alice, reply }) => {

let file = require.resolve("../Alice.js")

delete require.cache[file]
require(file)

reply("✅ case berhasil direload")

}

handler.help = ["reloadcase"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["reloadcase"]

module.exports = handler