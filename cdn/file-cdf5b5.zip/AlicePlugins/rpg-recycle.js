
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let recycleValues = {
    "Ikan Kecil": { result: "Umpan", qty: 1 },
    "Ikan Mas": { result: "Umpan", qty: 2 },
    "Batu Biasa": { result: "Pasir", qty: 1 },
    "Batu Bara": { result: "Energi", qty: 1 },
    "Kayu Biasa": { result: "Serbuk Kayu", qty: 2 },
    "Kayu Jati": { result: "Serbuk Kayu", qty: 4 }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `♻️ *DAUR ULANG* ♻️\n\n`
        for (let [item, data] of Object.entries(recycleValues)) {
            msg += `• ${item} → ${data.result} x${data.qty}\n`
        }
        msg += `\nCara pakai: .recycle Ikan Kecil`
        return reply(msg)
    }

    let itemName = args.join(" ").toLowerCase()
    let recycle = Object.entries(recycleValues).find(([key]) => key.toLowerCase() === itemName)

    if (!recycle) return reply(`❌ Item "${args.join(" ")}" tidak bisa didaur ulang!`)

    let [originalItem, data] = recycle
    let have = user.inventory[originalItem] || 0

    if (have < 1) return reply(`❌ ${originalItem} tidak cukup! Kamu punya ${have}`)

    user.inventory[originalItem] -= 1
    if (user.inventory[originalItem] === 0) delete user.inventory[originalItem]

    if (!user.inventory[data.result]) user.inventory[data.result] = 0
    user.inventory[data.result] += data.qty

    db.updateUser(m.sender, user)

    reply(`♻️ *DAUR ULANG BERHASIL* ♻️\n\n📦 ${originalItem} → ${data.result} x${data.qty}\n📦 ${data.result} sekarang: ${user.inventory[data.result]}`)
}

handler.help = ["recycle"]
handler.tags = ["rpg"]
handler.command = ["recycle", "daurulang"]

module.exports = handler