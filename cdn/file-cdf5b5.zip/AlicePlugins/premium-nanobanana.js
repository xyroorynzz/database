const axios = require("axios")
const FormData = require("form-data")

async function uploadToAliceCdn(buffer, fileName) {
    if (!Buffer.isBuffer(buffer)) {
        throw new Error('File bukan buffer')
    }

    const form = new FormData()
    form.append('cdnFile', buffer, {
        filename: fileName,
        contentType: 'application/octet-stream'
    })

    try {
        const res = await axios.post(
            'https://aliceecdn.vercel.app/upload',
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Content-Length': form.getLengthSync()
                }
            }
        )

        if (res.data?.url) return res.data.url
        throw new Error('Upload gagal: ' + JSON.stringify(res.data))

    } catch (err) {
        throw new Error(
            `Upload error: ${err.response?.data?.message || err.message}`
        )
    }
}

let handler = async (m, { Alice, text, reply, prefix, command, XReaction }) => {
    if (!text) return reply(`Contoh: ${prefix + command} ubah rambut jadi merah`)

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""
    if (!mime) return reply("Reply gambar terlebih dahulu!")
    if (!/image/.test(mime)) return reply("Reply gambar!")
    XReaction()
    let prompt = text
    let imgBuffer = await q.download()
    
    let imageUrl = await uploadToAliceCdn(imgBuffer, "image.jpg")

    try {
        let res = await axios.get("https://api-faa.my.id/faa/editfoto", {
            params: {
                url: imageUrl,
                prompt: prompt
            },
            responseType: "arraybuffer"
        })

        await Alice.sendMessage(m.chat, { image: Buffer.from(res.data) }, { quoted: m })
    } catch (error) {
        reply("Error: " + (error.response?.status || error.message))
    }
}

handler.help = ["nanobanana *prompt*", "editfoto *prompt*"]
handler.tags = ["premium"]
handler.command = ["nanobanana", "editfoto"]
handler.premium = true

module.exports = handler