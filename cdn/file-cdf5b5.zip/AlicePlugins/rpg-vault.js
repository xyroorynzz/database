
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!user.vault) user.vault = {}

    if (!args.length) {
        let msg = `📦 *VAULT (Penyimpanan)* 📦\n\n`
        msg += `Isi vault:\n`
        let hasItem = false
        for (let [item, qty] of Object.entries(user.vault)) {
            if (qty > 0) {
                hasItem = true
                msg += `• ${item}: ${qty}\n`
            }
        }
        if (!hasItem) msg += `   Kosong\n\n`
        msg += `Command:\n`
        msg += `.vault store <item> <jumlah> - Simpan item ke vault\n`
        msg += `.vault take <item> <jumlah> - Ambil item dari vault`
        return reply(msg)
    }

    let action = args[0].toLowerCase()
    let itemName = args[1]
    let qty = parseInt(args[2]) || 1

    if (action === "store") {
        let have = user.inventory[itemName] || 0
        if (have < qty) return reply(`❌ ${itemName} tidak cukup! Kamu punya ${have}`)

        user.inventory[itemName] -= qty
        if (user.inventory[itemName] === 0) delete user.inventory[itemName]

        if (!user.vault[itemName]) user.vault[itemName] = 0
        user.vault[itemName] += qty

        db.updateUser(m.sender, user)
        reply(`📦 *MENYIMPAN KE VAULT*\n\n✅ ${qty} ${itemName} disimpan ke vault!`)
    }
    else if (action === "take") {
        let have = user.vault[itemName] || 0
        if (have < qty) return reply(`❌ ${itemName} tidak ada di vault! Ada ${have}`)

        user.vault[itemName] -= qty
        if (user.vault[itemName] === 0) delete user.vault[itemName]

        if (!user.inventory[itemName]) user.inventory[itemName] = 0
        user.inventory[itemName] += qty

        db.updateUser(m.sender, user)
        reply(`📦 *MENGAMBIL DARI VAULT*\n\n✅ ${qty} ${itemName} diambil dari vault!`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.vault store <item> <jumlah>\n.vault take <item> <jumlah>`)
    }
}

handler.help = ["vault"]
handler.tags = ["rpg"]
handler.command = ["vault"]

module.exports = handler