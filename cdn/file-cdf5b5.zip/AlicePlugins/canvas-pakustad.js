const axios = require('axios');

let handler = async (m, { Alice, text, args, reply, XReaction, prefix, command }) => {
    const input = text?.trim() || m.quoted?.text?.trim();
    
    if (!input) {
        return reply(
            `🕌 *PAK USTAD*\n\n` +
            `Gunakan perintah ini untuk bertanya pada pak ustad (gambar).\n\n` +
            `*Format:* ${prefix + command} pertanyaan\n\n` +
            `*Contoh:* ${prefix + command} kenapa aku ganteng`
        );
    }
    
    await XReaction('🕕');
    
    try {
        const apiUrl = `https://api.cuki.biz.id/api/canvas/ustadz?apikey=cuki-x&text=${encodeURIComponent(input)}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await Alice.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `🕌 *PAK USTAD*\n\n📝 ${input}`
        }, { quoted: m });
        
        await XReaction('✅');
        
    } catch (error) {
        await XReaction('❌');
        reply(`Error: ${error.message}`);
    }
};

handler.help = ['pakustad', 'pak-ustad', 'tanyaustad'];
handler.tags = ['canvas'];
handler.command = ['pakustad', 'pak-ustad', 'tanyaustad'];

module.exports = handler;