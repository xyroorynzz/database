const axios = require("axios")

let handler = async (m, { Alice, text, reply, prefix, command, XReaction }) => {
    if (!text) return reply(`Contoh: ${prefix + command} axios`)

    await XReaction()

    let packageName = text.trim()

    try {
        let res = await axios.get(`https://api-faa.my.id/faa/npmjs?npm=${encodeURIComponent(packageName)}`)

        let data = res.data
        let result = data?.result || data?.data || data

        let caption = `*📦 NPM Package Stalker*\n\n`
        caption += `*Nama:* ${result.name || packageName}\n`
        caption += `*Versi:* ${result.version || 'Tidak diketahui'}\n`
        caption += `*Lisensi:* ${result.license || 'Tidak diketahui'}\n`
        caption += `*Deskripsi:* ${result.description || 'Tidak ada deskripsi'}\n`
        
        if (result.author) {
            caption += `*Author:* ${typeof result.author === 'string' ? result.author : result.author.name || 'Tidak diketahui'}\n`
        }
        
        if (result.repository?.url) {
            caption += `*Repository:* ${result.repository.url}\n`
        }
        
        if (result.homepage) {
            caption += `*Homepage:* ${result.homepage}\n`
        }
        
        caption += `\n*Link:* https://npmjs.com/package/${packageName}`

        await Alice.sendMessage(m.chat, { text: caption }, { quoted: m })
    } catch (error) {
        if (error.response?.status === 400) {
            try {
                let res = await axios.get(`https://registry.npmjs.org/${packageName.toLowerCase()}`)
                let data = res.data
                let latest = data['dist-tags']?.latest
                let versionData = data.versions[latest]

                let caption = `*📦 NPM Package Stalker*\n\n`
                caption += `*Nama:* ${data.name || packageName}\n`
                caption += `*Versi:* ${latest || 'Tidak diketahui'}\n`
                caption += `*Lisensi:* ${versionData?.license || 'Tidak diketahui'}\n`
                caption += `*Deskripsi:* ${versionData?.description || 'Tidak ada deskripsi'}\n`
                
                if (versionData?.author) {
                    caption += `*Author:* ${typeof versionData.author === 'string' ? versionData.author : versionData.author.name || 'Tidak diketahui'}\n`
                }
                
                if (versionData?.repository?.url) {
                    caption += `*Repository:* ${versionData.repository.url}\n`
                }
                
                if (versionData?.homepage) {
                    caption += `*Homepage:* ${versionData.homepage}\n`
                }
                
                caption += `\n*Link:* https://npmjs.com/package/${packageName}`

                await Alice.sendMessage(m.chat, { text: caption }, { quoted: m })
            } catch (npmError) {
                reply(`Package "${packageName}" tidak ditemukan di NPM!`)
            }
        } else {
            reply("Error: " + (error.response?.status || error.message))
        }
    }
}

handler.help = ["npmstalk *package*"]
handler.tags = ["stalker"]
handler.command = ["npmstalk", "npmjs"]

module.exports = handler