const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const TRANS_FILE = path.join(STORE_DIR, 'transaksi.json');

function loadTrans() {
    if (!fs.existsSync(TRANS_FILE)) return {};
    return JSON.parse(fs.readFileSync(TRANS_FILE));
}

function formatmoney(amount) {
    return new Intl.NumberFormat('id-ID').format(amount);
}

let handler = async (m, { command, reply }) => {
    let trans = loadTrans();
    let data = trans[m.sender];
    
    if (!data) return reply('📭 Tidak ada transaksi aktif.');
    
    let info = `📋 STATUS TRANSAKSI\n━━━━━━━━━━━━━━━━━━\n`;
    info += `Jenis: ${data.jenis === 'buyprem' ? 'Premium' : 'Sewa Grup'}\n`;
    info += `Nominal: Rp${formatmoney(data.harga)}\n`;
    info += `Durasi: ${data.durasi || '-'}\n`;
    if (data.link) info += `Link Grup: ${data.link}\n`;
    info += `━━━━━━━━━━━━━━━━━━\n`;
    info += `Status: Menunggu pembayaran...\n\n`;
    info += `Ketik .cancel untuk membatalkan.`;
    
    reply(info);
};

handler.command = ['status'];
handler.tags = ['store'];

module.exports = handler;