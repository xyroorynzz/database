const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text }) => {

if (!text) return reply("contoh: .editp namaplugin")

if (!m.quoted) return reply("reply code baru")

let name = text.endsWith(".js") ? text : text + ".js"

let dir = path.join(__dirname,name)

if (!fs.existsSync(dir)) return reply("plugin tidak ditemukan")

fs.writeFileSync(dir,m.quoted.text)

reply(`✏️ plugin ${name} berhasil diedit`)

}

handler.help = ["editp"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["editp","editplugins"]

module.exports = handler