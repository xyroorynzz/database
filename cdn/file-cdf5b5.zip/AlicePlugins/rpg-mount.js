const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let mounts = {
    "kuda": { price: 5000, speed: 10, desc: "Meningkatkan stamina +10" },
    "serigala": { price: 10000, speed: 15, desc: "Meningkatkan stamina +15" },
    "naga": { price: 50000, speed: 30, desc: "Meningkatkan stamina +30" }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🐎 *KENDRAN* 🐎\n\n`
        msg += `Kendaraan saat ini: ${user.mount || "Tidak punya"}\n\n`
        for (let [name, data] of Object.entries(mounts)) {
            msg += `• ${name}\n`
            msg += `  💰 Harga: ${data.price} gold\n`
            msg += `  ✨ ${data.desc}\n\n`
        }
        msg += `Cara pakai: .mount beli kuda`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "beli") {
        let mountName = args[1]
        let mount = mounts[mountName]

        if (!mount) return reply(`❌ Kendaraan "${args[1]}" tidak ditemukan!`)

        if (user.gold < mount.price) return reply(`💰 Gold tidak cukup! Butuh ${mount.price} gold`)

        user.gold -= mount.price
        user.mount = mountName
        user.maxStamina += mount.speed

        db.updateUser(m.sender, user)

        reply(`🐎 *BELI KENDARAAN BERHASIL*\n\n✅ ${mountName} berhasil dibeli!\n💰 Sisa gold: ${user.gold}\n❤️ Stamina maks +${mount.speed}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n.mount beli <nama>`)
    }
}

handler.help = ["mount"]
handler.tags = ["rpg"]
handler.command = ["mount", "kendaraan"]

module.exports = handler