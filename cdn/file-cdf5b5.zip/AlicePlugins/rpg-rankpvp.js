const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let users = db.getAllUsers()
    
    if (Object.keys(users).length === 0) return reply("Belum ada pemain yang terdaftar!")

    let validUsers = []
    for (let id in users) {
        let user = users[id]
        if (user.name && typeof user.arenaWin === 'number') {
            validUsers.push(user)
        }
    }

    if (validUsers.length === 0) return reply("Belum ada data pemain yang valid!")

    validUsers.sort((a, b) => (b.arenaWin || 0) - (a.arenaWin || 0))

    let top10 = validUsers.slice(0, 10)
    let caption = `🏆 *RANKING PVP ARENA* 🏆\n\n`

    for (let i = 0; i < top10.length; i++) {
        let user = top10[i]
        let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
        let name = user.name || "Petualang"
        let win = user.arenaWin || 0
        caption += `${medal} ${i+1}. ${name}\n`
        caption += `   ⚔️ ${win} win\n\n`
    }

    caption += `Total pemain: ${validUsers.length} orang`

    reply(caption)
}

handler.help = ["rankpvp"]
handler.tags = ["rpg"]
handler.command = ["rankpvp", "pvprank"]

module.exports = handler