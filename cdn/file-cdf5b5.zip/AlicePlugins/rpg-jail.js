
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let jailData = db.getJailData()
    let now = Date.now()
    let jailTime = jailData[m.sender]

    if (jailTime && now < jailTime) {
        let remaining = Math.ceil((jailTime - now) / 60000)
        return reply(`🔒 Kamu sedang dipenjara! Tunggu ${remaining} menit lagi.`)
    } else if (jailTime) {
        delete jailData[m.sender]
        db.saveJailData(jailData)
    }

    if (!args.length) {
        let msg = `🔒 *SISTEM PENJARA* 🔒\n\n`
        msg += `Command:\n`
        msg += `.jail @user <menit> - Penjara user (admin/owner)\n`
        msg += `.jail release @user - Bebaskan user (admin/owner)\n`
        msg += `.jail status - Cek status penjara`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "jail" || action === "penjara") {
        if (!isAdmins && !isOwner) return reply("❌ Hanya admin/owner!")

        let target = null
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            target = m.mentionedJid[0]
        } else if (args[1]) {
            target = args[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        }

        if (!target) return reply("⚠️ Tag pemain yang ingin dipenjara!")

        let minutes = parseInt(args[2])
        if (isNaN(minutes) || minutes < 1) return reply("⏰ Masukkan durasi penjara (menit)!")

        let targetUser = db.getUser(target)
        if (!targetUser) return reply("❌ Target belum terdaftar!")

        jailData[target] = Date.now() + (minutes * 60 * 1000)
        db.saveJailData(jailData)

        reply(`🔒 @${target.split('@')[0]} dipenjara selama ${minutes} menit!\n⏰ Bebas pada: ${new Date(jailData[target]).toLocaleTimeString()}`, { mentions: [target] })
    }
    else if (action === "release") {
        if (!isAdmins && !isOwner) return reply("❌ Hanya admin/owner!")

        let target = null
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            target = m.mentionedJid[0]
        } else if (args[1]) {
            target = args[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        }

        if (!target) return reply("⚠️ Tag pemain yang ingin dibebaskan!")

        delete jailData[target]
        db.saveJailData(jailData)

        reply(`🔓 @${target.split('@')[0]} telah dibebaskan dari penjara!`, { mentions: [target] })
    }
    else if (action === "status") {
        let list = Object.entries(jailData).map(([id, time]) => {
            let remaining = Math.ceil((time - Date.now()) / 60000)
            return `• @${id.split('@')[0]}: ${remaining} menit lagi`
        }).join('\n')

        if (!list) list = "Tidak ada yang dipenjara"

        reply(`🔒 *STATUS PENJARA*\n\n${list}`, { mentions: Object.keys(jailData) })
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.jail @user <menit>\n.jail release @user\n.jail status`)
    }
}

handler.help = ["jail"]
handler.tags = ["rpg"]
handler.command = ["jail", "penjara"]

module.exports = handler