
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `✨ *ENCHANT ITEM* ✨\n\n`
        msg += `.enchantitem weapon - Enchant weapon (10000 gold + 5 Kristal)\n`
        msg += `.enchantitem armor - Enchant armor (10000 gold + 5 Kristal)\n\n`
        msg += `Enchant memberikan bonus acak +1 sampai +10`
        return reply(msg)
    }

    let type = args[0].toLowerCase()
    let costGold = 10000
    let needCrystal = 5

    let haveCrystal = user.inventory["Kristal"] || 0

    if (user.gold < costGold) return reply(`💰 Gold tidak cukup! Butuh ${costGold} gold`)
    if (haveCrystal < needCrystal) return reply(`❌ Kristal tidak cukup! Butuh ${needCrystal}, kamu punya ${haveCrystal}`)

    let bonus = Math.floor(Math.random() * 10) + 1

    user.gold -= costGold
    user.inventory["Kristal"] -= needCrystal
    if (user.inventory["Kristal"] === 0) delete user.inventory["Kristal"]

    if (type === "weapon") {
        user.weaponBonus = (user.weaponBonus || 0) + bonus
        reply(`✨ *ENCHANT WEAPON BERHASIL* ✨\n\n✅ Weapon mendapat +${bonus} damage!\n💰 Gold -${costGold}\n🔮 Kristal -${needCrystal}\n💪 Total bonus weapon: +${user.weaponBonus}`)
    } else if (type === "armor") {
        user.armorBonus = (user.armorBonus || 0) + bonus
        reply(`✨ *ENCHANT ARMOR BERHASIL* ✨\n\n✅ Armor mendapat +${bonus} defense!\n💰 Gold -${costGold}\n🔮 Kristal -${needCrystal}\n💪 Total bonus armor: +${user.armorBonus}`)
    } else {
        return reply(`❌ Pilihan tidak valid!\n.enchantitem weapon\n.enchantitem armor`)
    }

    db.updateUser(m.sender, user)
}

handler.help = ["enchantitem"]
handler.tags = ["rpg"]
handler.command = ["enchantitem"]

module.exports = handler