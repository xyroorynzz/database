
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let users = db.getAllUsers()
    let petRanks = []

    for (let id in users) {
        let user = users[id]
        if (user.pet && user.pet.name !== "tidak punya") {
            petRanks.push({
                name: user.name,
                petName: user.pet.name,
                petLevel: user.pet.level,
                id: id
            })
        }
    }

    petRanks.sort((a, b) => b.petLevel - a.petLevel)

    let top10 = petRanks.slice(0, 10)
    let msg = `🐾 *RANKING PELIHARAAN* 🐾\n\n`

    for (let i = 0; i < top10.length; i++) {
        let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
        msg += `${medal} ${i+1}. ${top10[i].name}\n`
        msg += `   🐕 ${top10[i].petName} (Lv.${top10[i].petLevel})\n\n`
    }

    reply(msg)
}

handler.help = ["petrank"]
handler.tags = ["rpg"]
handler.command = ["petrank"]

module.exports = handler