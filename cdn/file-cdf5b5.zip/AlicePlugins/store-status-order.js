const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');

function loadJSON(file) {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

let handler = async (m, { command, text, reply, isOwner }) => {
    const sender = m.sender;
    let history = loadJSON(HISTORY_FILE);
    if (!Array.isArray(history)) history = [];
    
    if (command === 'done' || command === 'selesai') {
        if (!isOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${command} TRX123456789`);
        
        let transaction = history.find(t => t.id === text.trim());
        if (!transaction) return reply(`Transaksi ${text} tidak ditemukan!`);
        if (transaction.status !== 'pending') return reply(`Transaksi sudah ${transaction.status}!`);
        
        transaction.status = 'success';
        fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
        
        reply(`✅ Transaksi ${transaction.id} telah diselesaikan.`);
        
        let invoice = `✅ PESANAN SELESAI\n━━━━━━━━━━━━━━━━━━\n`;
        invoice += `📋 ID: ${transaction.id}\n`;
        invoice += `💰 Total: Rp${toRupiah(transaction.total)}\n`;
        invoice += `📅 Tanggal: ${new Date(transaction.tanggal).toLocaleDateString('id-ID')}\n`;
        invoice += `━━━━━━━━━━━━━━━━━━\n`;
        invoice += `🎉 Terima kasih sudah berbelanja!`;
        
        await Alice.sendMessage(transaction.buyer, { text: invoice });
    }
    
    else if (command === 'proses') {
        if (!isOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${command} TRX123456789`);
        
        let transaction = history.find(t => t.id === text.trim());
        if (!transaction) return reply(`Transaksi ${text} tidak ditemukan!`);
        if (transaction.status !== 'pending') return reply(`Transaksi sudah ${transaction.status}!`);
        
        transaction.status = 'processing';
        fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
        
        reply(`✅ Transaksi ${transaction.id} sedang diproses.`);
        
        await Alice.sendMessage(transaction.buyer, { text: `⏳ Pesanan ${transaction.id} sedang diproses oleh admin. Mohon tunggu.` });
    }
    
    else if (command === 'tunda') {
        if (!isOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${command} TRX123456789`);
        
        let transaction = history.find(t => t.id === text.trim());
        if (!transaction) return reply(`Transaksi ${text} tidak ditemukan!`);
        if (transaction.status !== 'pending') return reply(`Transaksi sudah ${transaction.status}!`);
        
        transaction.status = 'delayed';
        fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
        
        reply(`⏸️ Transaksi ${transaction.id} ditunda.`);
        
        await Alice.sendMessage(transaction.buyer, { text: `⏸️ Pesanan ${transaction.id} ditunda. Hubungi admin untuk info lebih lanjut.` });
    }
    
    else if (command === 'batal') {
        if (!isOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${command} TRX123456789`);
        
        let transaction = history.find(t => t.id === text.trim());
        if (!transaction) return reply(`Transaksi ${text} tidak ditemukan!`);
        if (transaction.status !== 'pending') return reply(`Transaksi sudah ${transaction.status}!`);
        
        const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
        let products = [];
        if (fs.existsSync(PRODUCT_FILE)) products = JSON.parse(fs.readFileSync(PRODUCT_FILE));
        
        for (let item of transaction.items) {
            let product = products.find(p => p.nama.toLowerCase() === item.nama.toLowerCase());
            if (product) product.stok += item.jumlah;
        }
        fs.writeFileSync(PRODUCT_FILE, JSON.stringify(products, null, 2));
        
        transaction.status = 'cancelled';
        fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
        
        reply(`❌ Transaksi ${transaction.id} dibatalkan.`);
        
        await Alice.sendMessage(transaction.buyer, { text: `❌ Pesanan ${transaction.id} dibatalkan oleh admin. Stok dikembalikan.` });
    }
};

handler.command = ['done', 'selesai', 'proses', 'tunda', 'batal'];
handler.tags = ['owner'];

module.exports = handler;