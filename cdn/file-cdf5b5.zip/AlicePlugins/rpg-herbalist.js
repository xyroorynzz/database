const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let herbs = {
        "ramuan kesehatan": { need: { "Daun": 3, "Air": 1 }, result: { name: "Ramuan Kesehatan", heal: 30, sell: 80 } },
        "ramuan stamina": { need: { "Daun": 5, "Madu": 2 }, result: { name: "Ramuan Stamina", heal: 50, sell: 150 } },
        "ramuan kuat": { need: { "Daun": 8, "Madu": 3, "Kristal": 1 }, result: { name: "Ramuan Kuat", heal: 100, sell: 300 } }
    }

    if (!args.length) {
        let msg = `🌿 *HERBALIS* 🌿\n\n`
        for (let [ramuan, data] of Object.entries(herbs)) {
            msg += `• ${ramuan}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Hasil: ${data.result.name} (heal +${data.result.heal})\n\n`
        }
        msg += `Cara pakai: .herbal ramuan kesehatan`
        return reply(msg)
    }

    let recipeName = args.join(" ").toLowerCase()
    let recipe = herbs[recipeName]

    if (!recipe) return reply(`❌ Ramuan "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    if (!user.inventory[recipe.result.name]) user.inventory[recipe.result.name] = 0
    user.inventory[recipe.result.name] += 1

    db.updateUser(m.sender, user)

    reply(`🌿 *MERACIK RAMUAN*\n\n✅ ${recipe.result.name} berhasil dibuat!\n📦 ${recipe.result.name} sekarang: ${user.inventory[recipe.result.name]}`)
}

handler.help = ["herbal"]
handler.tags = ["rpg"]
handler.command = ["herbal", "herbalis", "ramuan"]

module.exports = handler