const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

let handler = async (m, { command, text, reply, prefix }) => {
    const transactionId = text.trim();
    if (!transactionId) return reply(`Contoh: ${prefix}cancel TRX123456789`);
    
    let history = loadJSON(HISTORY_FILE);
    if (!Array.isArray(history)) history = [];
    let transaction = history.find(t => t.id === transactionId);
    
    if (!transaction) return reply(`❌ Transaksi dengan ID "${transactionId}" tidak ditemukan.`);
    if (transaction.buyer !== m.sender) return reply('❌ Bukan pesanan kamu!');
    if (transaction.status !== 'pending') return reply(`❌ Transaksi sudah ${transaction.status}, tidak bisa dibatalkan.`);
    
    let products = loadJSON(PRODUCT_FILE);
    for (let item of transaction.items) {
        let product = products.find(p => p.nama.toLowerCase() === item.nama.toLowerCase());
        if (product) {
            product.stok += item.jumlah;
        }
    }
    saveJSON(PRODUCT_FILE, products);
    
    transaction.status = 'cancelled';
    saveJSON(HISTORY_FILE, history);
    
    reply(`✅ Transaksi ${transactionId} berhasil dibatalkan.\nStok produk dikembalikan.`);
};

handler.command = ['cancel', 'batalkan'];
handler.tags = ['store'];

module.exports = handler;