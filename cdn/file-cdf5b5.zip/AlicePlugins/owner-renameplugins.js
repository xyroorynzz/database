const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text }) => {

let args = text.split(" ")

if (args.length < 2) return reply("contoh: .renamep lama baru")

let oldName = args[0].endsWith(".js") ? args[0] : args[0] + ".js"
let newName = args[1].endsWith(".js") ? args[1] : args[1] + ".js"

let oldDir = path.join(__dirname,oldName)
let newDir = path.join(__dirname,newName)

if (!fs.existsSync(oldDir)) return reply("plugin lama tidak ada")

fs.renameSync(oldDir,newDir)

reply(`🔁 ${oldName} → ${newName}`)

}

handler.help = ["renamep"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["renamep","renameplugins"]

module.exports = handler