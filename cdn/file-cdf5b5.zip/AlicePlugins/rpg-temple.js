
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastPray && now - user.lastPray < oneDay) {
        let remaining = oneDay - (now - user.lastPray)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        return reply(`⏰ Kamu sudah berdoa! Tunggu ${hours} jam lagi.`)
    }

    let buffs = [
        { name: "✨ Berkah Keberuntungan", effect: "Gold +20% selama 1 jam", goldBonus: 1.2 },
        { name: "📈 Berkah Kebijaksanaan", effect: "EXP +20% selama 1 jam", expBonus: 1.2 },
        { name: "🛡️ Berkah Perlindungan", effect: "Damage masuk -20% selama 1 jam", defenseBonus: 0.8 },
        { name: "⚔️ Berkah Kekuatan", effect: "Damage keluar +20% selama 1 jam", attackBonus: 1.2 }
    ]

    let buff = buffs[Math.floor(Math.random() * buffs.length)]

    user.activeBuff = {
        name: buff.name,
        effect: buff.effect,
        goldBonus: buff.goldBonus || 1,
        expBonus: buff.expBonus || 1,
        defenseBonus: buff.defenseBonus || 1,
        attackBonus: buff.attackBonus || 1,
        expires: now + (60 * 60 * 1000)
    }
    user.lastPray = now

    db.updateUser(m.sender, user)

    let msg = `🛐 *BERDOA DI TEMPLE* 🛐\n\n`
    msg += `🙏 Kamu mendapatkan: ${buff.name}\n`
    msg += `📜 ${buff.effect}\n`
    msg += `⏰ Berlaku selama 1 jam\n\n`
    msg += `Kembali besok untuk berdoa lagi!`

    reply(msg)
}

handler.help = ["temple"]
handler.tags = ["rpg"]
handler.command = ["temple"]

module.exports = handler