
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let harvestCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (harvestCooldown[m.sender] && now - harvestCooldown[m.sender] < 7200000) {
        let remaining = Math.ceil((7200000 - (now - harvestCooldown[m.sender])) / 60000)
        return reply(`⏰ Ladang masih tumbuh! Tunggu ${remaining} menit lagi.`)
    }

    if (user.stamina < 10) return reply("❤️ Stamina kurang! Butuh 10 stamina untuk panen.\nKetik .heal untuk istirahat.")

    let crops = [
        { name: "🌾 Gandum", minGold: 30, maxGold: 70, exp: 10 },
        { name: "🥕 Wortel", minGold: 40, maxGold: 80, exp: 12 },
        { name: "🍅 Tomat", minGold: 50, maxGold: 90, exp: 15 },
        { name: "🥔 Kentang", minGold: 60, maxGold: 100, exp: 18 },
        { name: "🍓 Stroberi", minGold: 80, maxGold: 150, exp: 25 }
    ]

    let crop = crops[Math.floor(Math.random() * crops.length)]
    let goldGain = Math.floor(Math.random() * (crop.maxGold - crop.minGold + 1) + crop.minGold)

    user.stamina -= 10
    user.gold += goldGain
    user.exp += crop.exp

    if (!user.harvestCount) user.harvestCount = 0
    user.harvestCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    harvestCooldown[m.sender] = now

    let msg = `🌱 *PANEN HASIL LADANG* 🌱\n\n`
    msg += `📦 Hasil: ${crop.name}\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${crop.exp}\n`
    msg += `❤️ Stamina -10 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Panen: ${user.harvestCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .harvest lagi setelah 2 jam!`

    reply(msg)
}

handler.help = ["harvest"]
handler.tags = ["rpg"]
handler.command = ["harvest", "panen"]

module.exports = handler