const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const DIGITAL_FILE = path.join(STORE_DIR, 'digital.json');
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getProducts() {
    ensureDir();
    if (!fs.existsSync(PRODUCT_FILE)) fs.writeFileSync(PRODUCT_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(PRODUCT_FILE));
}

let handler = async (m, { command, text, reply, prefix, Alice }) => {
    const sender = m.sender;
    const ownerListPath = './AliceDatabase/owner.json';
    let ownerList = [];
    if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
    const isRealOwner = ownerList.includes(sender.split('@')[0]) || (global.owner && global.owner.includes(sender.split('@')[0]));
    if (!isRealOwner) return reply('❌ Khusus owner!');
    
    let digital = loadJSON(DIGITAL_FILE);

    if (command === 'adddigital') {
        if (!text) return reply(`Contoh: ${prefix}adddigital indomie|https://example.com/file.pdf`);
        let [productName, linkFile] = text.split('|').map(v => v.trim());
        const products = getProducts();
        const product = products.find(p => p.nama.toLowerCase() === productName.toLowerCase());
        if (!product) return reply(`Produk "${productName}" tidak ditemukan!`);
        const existing = digital.find(d => d.produk.toLowerCase() === productName.toLowerCase());
        if (existing) {
            existing.link = linkFile;
            reply(`✅ Link digital untuk "${productName}" berhasil diupdate!`);
        } else {
            digital.push({
                produk: product.nama,
                link: linkFile,
                created_at: new Date().toISOString()
            });
            reply(`✅ Produk digital "${productName}" berhasil ditambahkan!`);
        }
        saveJSON(DIGITAL_FILE, digital);
    }
    
    else if (command === 'listdigital') {
        if (digital.length === 0) return reply('❌ Belum ada produk digital.');
        let teks = `📱 PRODUK DIGITAL\n━━━━━━━━━━━━━━━━━━\n`;
        digital.forEach((d, i) => {
            teks += `${i+1}. ${d.produk}\n`;
            teks += `   🔗 Link: ${d.link}\n\n`;
        });
        reply(teks);
    }
    
    else if (command === 'hapusdigital') {
        if (!text) return reply(`Contoh: ${prefix}hapusdigital indomie`);
        const productName = text.trim().toLowerCase();
        const index = digital.findIndex(d => d.produk.toLowerCase() === productName);
        if (index === -1) return reply(`Produk digital "${text}" tidak ditemukan.`);
        digital.splice(index, 1);
        saveJSON(DIGITAL_FILE, digital);
        reply(`🗑️ Produk digital "${text}" berhasil dihapus.`);
    }
};

const monitorCheckout = async (m, Alice) => {
    const digital = loadJSON(DIGITAL_FILE);
    if (digital.length === 0) return;
    let history = loadJSON(HISTORY_FILE);
    if (!Array.isArray(history)) return;
    let changed = false;
    for (let i = 0; i < history.length; i++) {
        let trans = history[i];
        if (trans.status === 'pending') continue;
        if (trans.status === 'digital_sent') continue;
        if (trans.status !== 'success') continue;
        let hasDigital = false;
        let digitalItems = [];
        if (trans.items && Array.isArray(trans.items)) {
            for (let item of trans.items) {
                const digitalProduct = digital.find(d => d.produk.toLowerCase() === item.nama.toLowerCase());
                if (digitalProduct) {
                    hasDigital = true;
                    digitalItems.push({
                        nama: item.nama,
                        link: digitalProduct.link,
                        jumlah: item.jumlah
                    });
                }
            }
        }
        if (hasDigital && digitalItems.length > 0) {
            let teks = `🎁 PRODUK DIGITAL KAMU\n━━━━━━━━━━━━━━━━━━\n`;
            teks += `📋 ID Transaksi: ${trans.id}\n\n`;
            for (let item of digitalItems) {
                teks += `📦 ${item.nama} (${item.jumlah}x)\n`;
                teks += `🔗 Link: ${item.link}\n\n`;
            }
            teks += `⚠️ Simpan link dengan baik, jangan sampai hilang!`;
            try {
                await Alice.sendMessage(trans.buyer, { text: teks });
                history[i].status = 'digital_sent';
                changed = true;
            } catch (err) {
                console.log('Gagal kirim digital ke:', trans.buyer);
            }
        }
    }
    if (changed) {
        saveJSON(HISTORY_FILE, history);
    }
};

const originalHandler = handler;
handler = async (m, conn) => {
    await monitorCheckout(m, conn);
    return originalHandler(m, conn);
};

handler.command = ['adddigital', 'listdigital', 'hapusdigital'];
handler.tags = ['store'];

module.exports = handler;