
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🏦 *BANK SYSTEM* 🏦\n\n`
        msg += `💵 Cash: ${user.gold}\n`
        msg += `🏦 Bank: ${user.bank || 0}\n\n`
        msg += `Command:\n`
        msg += `.bank deposit <jumlah>\n`
        msg += `.bank withdraw <jumlah>\n`
        msg += `.bank interest`
        return reply(msg)
    }

    let action = args[0].toLowerCase()
    let amount = parseInt(args[1])

    if (action === "deposit") {
        if (isNaN(amount) || amount < 1) return reply("💰 Masukkan jumlah gold!")
        if (user.gold < amount) return reply(`💰 Cash tidak cukup! Punya ${user.gold} gold`)

        user.gold -= amount
        user.bank = (user.bank || 0) + amount

        db.updateUser(m.sender, user)
        reply(`🏦 *DEPOSIT*\n\n💰 Cash -${amount}\n🏦 Bank +${amount}\n💵 Cash: ${user.gold} | 🏦 Bank: ${user.bank}`)
    }
    else if (action === "withdraw") {
        if (isNaN(amount) || amount < 1) return reply("💰 Masukkan jumlah gold!")
        if ((user.bank || 0) < amount) return reply(`🏦 Bank tidak cukup! Punya ${user.bank || 0} gold`)

        user.gold += amount
        user.bank = (user.bank || 0) - amount

        db.updateUser(m.sender, user)
        reply(`🏦 *WITHDRAW*\n\n🏦 Bank -${amount}\n💰 Cash +${amount}\n💵 Cash: ${user.gold} | 🏦 Bank: ${user.bank}`)
    }
    else if (action === "interest") {
        let now = Date.now()
        let oneDay = 24 * 60 * 60 * 1000

        if (user.lastInterest && now - user.lastInterest < oneDay) {
            let remaining = oneDay - (now - user.lastInterest)
            let hours = Math.floor(remaining / (60 * 60 * 1000))
            return reply(`⏰ Bunga sudah diambil! Tunggu ${hours} jam lagi.`)
        }

        let interest = Math.floor((user.bank || 0) * 0.05)
        if (interest < 1) return reply("🏦 Bank kosong! Tidak ada bunga.")

        user.bank = (user.bank || 0) + interest
        user.lastInterest = now

        db.updateUser(m.sender, user)
        reply(`🏦 *BUNGA BANK*\n\n💰 +${interest} gold (5%)\n🏦 Bank: ${user.bank}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n.bank deposit <jumlah>\n.bank withdraw <jumlah>\n.bank interest`)
    }
}

handler.help = ["bank"]
handler.tags = ["rpg"]
handler.command = ["bank"]

module.exports = handler