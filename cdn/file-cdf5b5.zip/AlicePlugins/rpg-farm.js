
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 12) return reply("❤️ Stamina kurang! Butuh 12 stamina untuk bertani.\nKetik .heal untuk istirahat.")

    let crops = [
        { name: "Wortel", minGold: 20, maxGold: 40, exp: 8, chance: 35 },
        { name: "Kentang", minGold: 25, maxGold: 50, exp: 10, chance: 30 },
        { name: "Tomat", minGold: 30, maxGold: 60, exp: 12, chance: 20 },
        { name: "Cabai", minGold: 40, maxGold: 80, exp: 15, chance: 10 },
        { name: "Bawang", minGold: 35, maxGold: 70, exp: 13, chance: 5 }
    ]

    let totalChance = crops.reduce((sum, crop) => sum + crop.chance, 0)
    let random = Math.random() * totalChance
    let cumulative = 0
    let selectedCrop = crops[crops.length - 1]

    for (let crop of crops) {
        cumulative += crop.chance
        if (random <= cumulative) {
            selectedCrop = crop
            break
        }
    }

    let goldGain = Math.floor(Math.random() * (selectedCrop.maxGold - selectedCrop.minGold + 1) + selectedCrop.minGold)
    let expGain = selectedCrop.exp

    user.stamina -= 12
    user.gold += goldGain
    user.exp += expGain
    user.farming = (user.farming || 0) + 1

    if (!user.inventory[selectedCrop.name]) user.inventory[selectedCrop.name] = 0
    user.inventory[selectedCrop.name] += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🌱 *BERTANI* 🌱\n\n`
    msg += `✨ Kamu mendapatkan: *${selectedCrop.name}*\n`
    msg += `📦 +1 ${selectedCrop.name} (inventory)\n`
    msg += `💰 Gold +${goldGain}\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -12 (${user.stamina}/${user.maxStamina})\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["farm"]
handler.tags = ["rpg"]
handler.command = ["farm", "bercocoktanam"]

module.exports = handler