
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let dailyReward = {
    day1: { gold: 500, exp: 50, item: null },
    day2: { gold: 600, exp: 60, item: null },
    day3: { gold: 700, exp: 70, item: "Potion Kecil" },
    day4: { gold: 800, exp: 80, item: null },
    day5: { gold: 900, exp: 90, item: null },
    day6: { gold: 1000, exp: 100, item: "Potion Sedang" },
    day7: { gold: 1500, exp: 150, item: "Potion Besar" }
}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyReward && now - user.lastDailyReward < oneDay) {
        let remaining = oneDay - (now - user.lastDailyReward)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        let minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
        return reply(`⏰ Hadiah harian sudah diambil! Tunggu ${hours} jam ${minutes} menit lagi.`)
    }

    let streak = (user.dailyRewardStreak || 0) % 7 + 1
    let reward = dailyReward[`day${streak}`]

    user.gold += reward.gold
    user.exp += reward.exp

    if (reward.item) {
        if (!user.inventory[reward.item]) user.inventory[reward.item] = 0
        user.inventory[reward.item] += 1
    }

    user.lastDailyReward = now
    user.dailyRewardStreak = streak

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎁 *DAILY REWARD* 🎁\n\n`
    msg += `🔥 Streak hari ke-${streak}\n\n`
    msg += `💰 Gold +${reward.gold}\n`
    msg += `📈 EXP +${reward.exp}\n`
    if (reward.item) msg += `📦 Item +1 ${reward.item}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKembali besok untuk reward streak hari ke-${streak + 1}!`

    reply(msg)
}

handler.help = ["dailyreward"]
handler.tags = ["rpg"]
handler.command = ["dailyreward"]

module.exports = handler