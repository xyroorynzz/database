const { Client } = require("ssh2")

function generateRandomPassword() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*"
  let result = ""
  for (let i = 0; i < 10; i++) {
    result += chars[Math.floor(Math.random() * chars.length)]
  }
  return result
}

let handler = async (m, { text, command, reply }) => {

const cmd = command.toLowerCase()

// ================== INSTALL PANEL ==================
if (cmd === "installpanel") {

if (!text) return reply(`contoh:
.installpanel ipvps,password,domainpnl,domainnode,ramvps`)

let [ip, pass, domainPanel, domainNode, ram] = text.split(",")

if (!ip || !pass || !domainPanel || !domainNode || !ram) {
  return reply("❌ Format salah! cek kembali input lu")
}

let ssh = new Client()
let genPass = generateRandomPassword()

try {

ssh.on("ready", () => {

reply("🚀 INSTALL PANEL DIMULAI (5-10 menit)")

ssh.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
if (err) throw err

stream.on("close", () => {

reply("⚙️ LANJUT INSTALL WINGS...")

ssh.exec("bash <(curl -s https://pterodactyl-installer.se)", (err2, stream2) => {
if (err2) throw err2

stream2.on("close", () => {

reply("📦 CREATE NODE & LOCATION...")

ssh.exec("bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)", (err3, stream3) => {
if (err3) throw err3

stream3.on("close", () => {
ssh.end()

reply(`✅ INSTALL SELESAI

🌐 PANEL: ${domainPanel}
👤 USER: Rezadev
🔑 PASS: ${genPass}

⚠️ Selanjutnya:
- Buat allocation di node
- Ambil token
- Jalankan:
.startwings ipvps,password,token

Note: tunggu 1-5 menit biar web ready`)
})

stream3.on("data", () => {
stream3.write("Reza\n")
stream3.write("4\n")
stream3.write("SGP\n")
stream3.write("AutoNode\n")
stream3.write(domainNode.trim()+"\n")
stream3.write("NODES\n")
stream3.write(ram.trim()+"\n")
stream3.write(ram.trim()+"\n")
stream3.write("1\n")
})

})

})

stream2.on("data", (d) => {
let t = d.toString()
if (t.includes("Input")) {
stream2.write("1\n")
stream2.write("y\n")
stream2.write("y\n")
stream2.write("y\n")
stream2.write(genPass+"\n")
stream2.write("y\n")
stream2.write("user\n")
stream2.write("1248\n")
stream2.write("y\n")
stream2.write(domainPanel.trim()+"\n")
stream2.write("y\n")
stream2.write("admin@gmail.com\n")
stream2.write("y\n")
}
})

})

})

stream.on("data", (d) => {
let t = d.toString()
if (t.includes("Input")) {
stream.write("0\n")
stream.write("\n\n")
stream.write("1248\n")
stream.write("Asia/Jakarta\n")
stream.write("admin@gmail.com\n")
stream.write("admin@gmail.com\n")
stream.write("Admin\n")
stream.write("admin\n")
stream.write("panel\n")
stream.write(domainPanel.trim()+"\n")
stream.write(domainNode.trim()+"\n")
stream.write("y\ny\ny\ny\nyes\n\n1\n")
}
})

})

}).on("error", () => {
reply("❌ IP atau password salah")
}).connect({
host: ip.trim(),
port: 22,
username: "root",
password: pass.trim()
})

} catch (e) {
console.log(e)
reply("❌ Error saat install panel")
}

}

// ================== START WINGS ==================
if (cmd === "startwings") {

if (!text) return reply(`contoh:
.startwings ipvps,password,token`)

let [ip, pass, token] = text.split(",")

if (!ip || !pass || !token) {
  return reply("❌ Format salah!")
}

let ssh = new Client()

try {

ssh.on("ready", () => {

reply("⚙️ CONFIGURE WINGS...")

ssh.exec("bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)", (err, stream) => {
if (err) throw err

stream.on("close", () => {
ssh.end()
reply("✅ Wings berhasil dijalankan, cek panel udah hijau 💚")
})

stream.on("data", () => {
stream.write("Reza\n")
stream.write("3\n")
stream.write(token.trim()+"\n")
})

})

}).on("error", () => {
reply("❌ IP atau password salah")
}).connect({
host: ip.trim(),
port: 22,
username: "root",
password: pass.trim()
})

} catch (e) {
console.log(e)
reply("❌ Error saat start wings")
}

}

}

handler.help = ["installpanel", "startwings"]
handler.tags = ["owner"]
handler.command = ["installpanel", "startwings"]
handler.owner = true

module.exports = handler