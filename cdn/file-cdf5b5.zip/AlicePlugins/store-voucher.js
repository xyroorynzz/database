const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const VOUCHER_FILE = path.join(STORE_DIR, 'vouchers.json');
const CART_FILE = path.join(STORE_DIR, 'cart.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

let handler = async (m, { command, text, reply, prefix }) => {
    const sender = m.sender;
    let vouchers = loadJSON(VOUCHER_FILE);
    const ownerListPath = './AliceDatabase/owner.json';
    let ownerList = [];
    if (fs.existsSync(ownerListPath)) ownerList = JSON.parse(fs.readFileSync(ownerListPath));
    const isRealOwner = ownerList.includes(sender.split('@')[0]) || (global.owner && global.owner.includes(sender.split('@')[0]));

    if (command === 'buatvoucher') {
        if (!isRealOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${prefix}buatvoucher GEBYAR10|10000|50000|7`);
        let [kode, potongan, minBelanja, expiredHari] = text.split('|').map(v => v.trim());
        kode = kode.toUpperCase();
        let potonganRp = parseInt(potongan);
        let minRp = parseInt(minBelanja);
        let expired = parseInt(expiredHari);
        if (isNaN(potonganRp) || isNaN(minRp) || isNaN(expired)) {
            return reply('Format salah! Contoh: .buatvoucher GEBYAR10|10000|50000|7');
        }
        const expiredDate = new Date();
        expiredDate.setDate(expiredDate.getDate() + expired);
        vouchers.push({
            kode: kode,
            potongan: potonganRp,
            min_belanja: minRp,
            expired: expiredDate.toISOString(),
            used_by: [],
            aktif: true
        });
        saveJSON(VOUCHER_FILE, vouchers);
        reply(`✅ Voucher ${kode} berhasil dibuat!\n🎁 Potongan: Rp${toRupiah(potonganRp)}\n🛒 Min. Belanja: Rp${toRupiah(minRp)}\n⏰ Berlaku ${expired} hari`);
    }
    
    else if (command === 'listvoucher') {
        const now = new Date();
        const activeVouchers = vouchers.filter(v => v.aktif && new Date(v.expired) > now);
        if (activeVouchers.length === 0) return reply('❌ Tidak ada voucher aktif saat ini.');
        let teks = `🎫 VOUCHER AKTIF\n━━━━━━━━━━━━━━━━━━\n`;
        activeVouchers.forEach((v, i) => {
            teks += `${i+1}. ${v.kode}\n`;
            teks += `   Potongan: Rp${toRupiah(v.potongan)}\n`;
            teks += `   Min. Belanja: Rp${toRupiah(v.min_belanja)}\n`;
            teks += `   ⏰ Expired: ${new Date(v.expired).toLocaleDateString('id-ID')}\n`;
            teks += `   🎟️ Digunakan: ${v.used_by.length}x\n\n`;
        });
        reply(teks);
    }
    
    else if (command === 'pakai') {
        if (!text) return reply(`Contoh: ${prefix}pakai GEBYAR10`);
        const kode = text.toUpperCase().trim();
        const now = new Date();
        const voucher = vouchers.find(v => v.kode === kode && v.aktif && new Date(v.expired) > now);
        if (!voucher) return reply(`❌ Voucher ${kode} tidak valid atau sudah expired!`);
        if (voucher.used_by.includes(sender)) return reply(`❌ Voucher ${kode} sudah pernah kamu gunakan!`);
        let cart = {};
        if (fs.existsSync(CART_FILE)) cart = JSON.parse(fs.readFileSync(CART_FILE));
        let userCart = cart[sender] || [];
        if (userCart.length === 0) return reply('🛒 Keranjang kosong! Tambahkan produk dulu.');
        let total = 0;
        userCart.forEach(item => total += item.subtotal);
        if (total < voucher.min_belanja) {
            return reply(`❌ Minimal belanja Rp${toRupiah(voucher.min_belanja)} untuk pakai voucher ini.\n💰 Total belanja kamu: Rp${toRupiah(total)}`);
        }
        voucher.used_by.push(sender);
        saveJSON(VOUCHER_FILE, vouchers);
        let diskon = voucher.potongan;
        let totalBaru = total - diskon;
        if (totalBaru < 0) totalBaru = 0;
        if (!global.tempVoucher) global.tempVoucher = {};
        global.tempVoucher[`voucher_${sender}`] = {
            kode: kode,
            diskon: diskon,
            total_awal: total,
            total_akhir: totalBaru
        };
        reply(`🎉 Voucher ${kode} berhasil digunakan!\n\n💰 Total belanja: Rp${toRupiah(total)}\n🎁 Potongan: -Rp${toRupiah(diskon)}\n━━━━━━━━━━━━━━━━━━\n💵 Total Bayar: Rp${toRupiah(totalBaru)}\n\n✅ Lanjutkan checkout dengan ${prefix}checkout`);
    }
    
    else if (command === 'hapusvoucher') {
        if (!isRealOwner) return reply('❌ Khusus owner!');
        if (!text) return reply(`Contoh: ${prefix}hapusvoucher GEBYAR10`);
        const kode = text.toUpperCase().trim();
        const index = vouchers.findIndex(v => v.kode === kode);
        if (index === -1) return reply(`Voucher ${kode} tidak ditemukan.`);
        vouchers.splice(index, 1);
        saveJSON(VOUCHER_FILE, vouchers);
        reply(`🗑️ Voucher ${kode} berhasil dihapus.`);
    }
};

handler.command = ['buatvoucher', 'listvoucher', 'pakai', 'hapusvoucher'];
handler.tags = ['store'];

module.exports = handler;