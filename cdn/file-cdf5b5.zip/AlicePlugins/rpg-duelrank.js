
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let users = db.getAllUsers()
    let duelRanks = []

    for (let id in users) {
        let user = users[id]
        if (user.duelWin || user.duelLose) {
            let total = (user.duelWin || 0) + (user.duelLose || 0)
            let winrate = total > 0 ? ((user.duelWin || 0) / total * 100).toFixed(1) : 0
            duelRanks.push({
                name: user.name,
                win: user.duelWin || 0,
                lose: user.duelLose || 0,
                winrate: winrate,
                id: id
            })
        }
    }

    duelRanks.sort((a, b) => b.win - a.win)

    let top10 = duelRanks.slice(0, 10)
    let msg = `⚔️ *RANKING DUEL* ⚔️\n\n`

    for (let i = 0; i < top10.length; i++) {
        let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
        msg += `${medal} ${i+1}. ${top10[i].name}\n`
        msg += `   🏆 ${top10[i].win}W/${top10[i].lose}L (${top10[i].winrate}%)\n\n`
    }

    reply(msg)
}

handler.help = ["duelrank"]
handler.tags = ["rpg"]
handler.command = ["duelrank"]

module.exports = handler