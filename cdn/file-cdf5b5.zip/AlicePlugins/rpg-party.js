
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let partyData = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let party = partyData[m.chat]
        if (!party || party.members.length === 0) {
            return reply(`👥 *PARTY SYSTEM* 👥\n\nBelum ada party di grup ini.\n\n.party create - Buat party\n.party join - Gabung party\n.party leave - Keluar party\n.party info - Info party`)
        }

        let msg = `👥 *PARTY ${m.chat}* 👥\n\n`
        msg += `👑 Leader: @${party.leader.split('@')[0]}\n`
        msg += `👥 Member: ${party.members.length} orang\n\n`
        for (let member of party.members) {
            let memberUser = db.getUser(member)
            if (memberUser) msg += `• @${member.split('@')[0]} (Lv.${memberUser.level})\n`
        }
        msg += `\n.party hunt - Berburu bersama (bonus EXP +20%)`
        return reply(msg, { mentions: [party.leader, ...party.members] })
    }

    let action = args[0].toLowerCase()

    if (action === "create") {
        if (partyData[m.chat]) return reply("❌ Sudah ada party di grup ini!")

        partyData[m.chat] = {
            leader: m.sender,
            members: [m.sender],
            created: Date.now()
        }
        reply(`✅ Party berhasil dibuat! @${m.sender.split('@')[0]} adalah leader.`, { mentions: [m.sender] })
    }
    else if (action === "join") {
        let party = partyData[m.chat]
        if (!party) return reply("❌ Belum ada party di grup ini! Ketik .party create untuk membuat.")

        if (party.members.includes(m.sender)) return reply("❌ Kamu sudah bergabung di party ini!")

        party.members.push(m.sender)
        reply(`✅ @${m.sender.split('@')[0]} bergabung ke party!`, { mentions: [m.sender] })
    }
    else if (action === "leave") {
        let party = partyData[m.chat]
        if (!party) return reply("❌ Belum ada party di grup ini!")

        if (!party.members.includes(m.sender)) return reply("❌ Kamu tidak bergabung di party ini!")

        if (party.leader === m.sender && party.members.length > 1) {
            party.leader = party.members.find(m => m !== m.sender)
            reply(`👑 @${m.sender.split('@')[0]} meninggalkan party. Leader sekarang: @${party.leader.split('@')[0]}`, { mentions: [m.sender, party.leader] })
        }

        party.members = party.members.filter(m => m !== m.sender)

        if (party.members.length === 0) {
            delete partyData[m.chat]
            reply(`✅ Party dibubarkan karena tidak ada member.`)
        } else {
            reply(`👋 @${m.sender.split('@')[0]} meninggalkan party.`, { mentions: [m.sender] })
        }
    }
    else if (action === "hunt") {
        let party = partyData[m.chat]
        if (!party) return reply("❌ Belum ada party di grup ini!")

        if (!party.members.includes(m.sender)) return reply("❌ Kamu tidak bergabung di party ini!")

        let expBonus = 0.2
        let totalExp = 0
        let totalGold = 0

        for (let member of party.members) {
            let memberUser = db.getUser(member)
            if (memberUser && memberUser.stamina >= 10) {
                let expGain = Math.floor(Math.random() * 30) + 20
                let goldGain = Math.floor(Math.random() * 50) + 30

                expGain = Math.floor(expGain * (1 + expBonus))
                memberUser.exp += expGain
                memberUser.gold += goldGain
                memberUser.stamina -= 10
                memberUser.totalHunt = (memberUser.totalHunt || 0) + 1

                totalExp += expGain
                totalGold += goldGain

                db.updateUser(member, memberUser)
            }
        }

        reply(`⚔️ *PARTY HUNT* ⚔️\n\n👥 Total member: ${party.members.length}\n📈 Total EXP: +${totalExp}\n💰 Total Gold: +${totalGold}\n✨ Bonus party +20% EXP!`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.party create\n.party join\n.party leave\n.party info\n.party hunt`)
    }
}

handler.help = ["party"]
handler.tags = ["rpg"]
handler.command = ["party"]

module.exports = handler