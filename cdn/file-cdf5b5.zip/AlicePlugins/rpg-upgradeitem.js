
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `⬆️ *UPGRADE ITEM* ⬆️\n\n`
        msg += `.upgradeitem weapon - Upgrade weapon (5000 gold + 10 Bijih Besi)\n`
        msg += `.upgradeitem armor - Upgrade armor (5000 gold + 10 Bijih Besi)\n`
        msg += `.upgradeitem tool - Upgrade tool (3000 gold + 5 Bijih Besi)\n\n`
        msg += `Setiap upgrade menambah level item +1`
        return reply(msg)
    }

    let type = args[0].toLowerCase()
    let costGold = 5000
    let needOre = 10

    if (type === "tool") {
        costGold = 3000
        needOre = 5
    }

    let haveOre = user.inventory["Bijih Besi"] || 0

    if (user.gold < costGold) return reply(`💰 Gold tidak cukup! Butuh ${costGold} gold`)
    if (haveOre < needOre) return reply(`❌ Bijih Besi tidak cukup! Butuh ${needOre}, kamu punya ${haveOre}`)

    user.gold -= costGold
    user.inventory["Bijih Besi"] -= needOre
    if (user.inventory["Bijih Besi"] === 0) delete user.inventory["Bijih Besi"]

    if (type === "weapon") {
        user.weaponLevel = (user.weaponLevel || 1) + 1
        reply(`⚔️ *UPGRADE WEAPON BERHASIL* ⚔️\n\n✅ Weapon level sekarang: ${user.weaponLevel}\n💰 Gold -${costGold}\n🔧 Bijih Besi -${needOre}`)
    } else if (type === "armor") {
        user.armorLevel = (user.armorLevel || 1) + 1
        reply(`🛡️ *UPGRADE ARMOR BERHASIL* 🛡️\n\n✅ Armor level sekarang: ${user.armorLevel}\n💰 Gold -${costGold}\n🔧 Bijih Besi -${needOre}`)
    } else if (type === "tool") {
        user.toolLevel = (user.toolLevel || 1) + 1
        reply(`🔨 *UPGRADE TOOL BERHASIL* 🔨\n\n✅ Tool level sekarang: ${user.toolLevel}\n💰 Gold -${costGold}\n🔧 Bijih Besi -${needOre}`)
    } else {
        return reply(`❌ Pilihan tidak valid!\n.upgradeitem weapon\n.upgradeitem armor\n.upgradeitem tool`)
    }

    db.updateUser(m.sender, user)
}

handler.help = ["upgradeitem"]
handler.tags = ["rpg"]
handler.command = ["upgradeitem"]

module.exports = handler