
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let guildData = db.getGuildData()

    if (!args.length) {
        let msg = `🏰 *GUILD SYSTEM* 🏰\n\n`
        msg += `Guild kamu: ${user.guild || "Tidak bergabung"}\n\n`
        msg += `Command:\n`
        msg += `.guild create <nama> - Buat guild (10000 gold)\n`
        msg += `.guild join <nama> - Gabung guild (5000 gold)\n`
        msg += `.guild info - Info guild\n`
        msg += `.guild donate <jumlah> - Donasi ke guild\n`
        msg += `.guild shop - Beli item guild`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "create") {
        let guildName = args[1]
        if (!guildName) return reply("Masukkan nama guild!")

        if (guildData[guildName]) return reply("❌ Guild sudah ada!")

        if (user.gold < 10000) return reply("💰 Gold tidak cukup! Butuh 10000 gold")

        user.gold -= 10000
        user.guild = guildName
        guildData[guildName] = { owner: m.sender, members: [m.sender], level: 1, exp: 0, gold: 0 }

        db.updateUser(m.sender, user)
        db.saveGuildData(guildData)

        reply(`🏰 *GUILD ${guildName} BERHASIL DIBUAT!*\n\n👑 Owner: @${m.sender.split('@')[0]}`, { mentions: [m.sender] })
    }
    else if (action === "join") {
        let guildName = args[1]
        if (!guildName) return reply("Masukkan nama guild!")

        let guild = guildData[guildName]
        if (!guild) return reply("❌ Guild tidak ditemukan!")

        if (user.guild) return reply("❌ Kamu sudah bergabung guild lain!")

        if (user.gold < 5000) return reply("💰 Gold tidak cukup! Butuh 5000 gold")

        user.gold -= 5000
        user.guild = guildName
        guild.members.push(m.sender)

        db.updateUser(m.sender, user)
        db.saveGuildData(guildData)

        reply(`🏰 *BERHASIL BERGABUNG KE GUILD ${guildName}!*\n\n👑 Owner: @${guild.owner.split('@')[0]}`, { mentions: [guild.owner] })
    }
    else if (action === "info") {
        if (!user.guild) return reply("❌ Kamu belum bergabung guild!")

        let guild = guildData[user.guild]
        if (!guild) return reply("❌ Guild tidak ditemukan!")

        let msg = `🏰 *INFO GUILD ${user.guild}* 🏰\n\n`
        msg += `👑 Owner: @${guild.owner.split('@')[0]}\n`
        msg += `👥 Member: ${guild.members.length} orang\n`
        msg += `⭐ Level: ${guild.level}\n`
        msg += `📊 EXP: ${guild.exp}/${guild.level * 1000}\n`
        msg += `💰 Kas Guild: ${guild.gold} gold\n`

        reply(msg, { mentions: [guild.owner] })
    }
    else if (action === "donate") {
        let amount = parseInt(args[1])
        if (isNaN(amount) || amount < 100) return reply("💰 Minimal donasi 100 gold!")

        if (user.gold < amount) return reply(`💰 Gold tidak cukup! Kamu punya ${user.gold} gold`)

        user.gold -= amount
        guildData[user.guild].gold += amount

        db.updateUser(m.sender, user)
        db.saveGuildData(guildData)

        reply(`💸 *DONASI BERHASIL*\n\n💰 +${amount} gold ke guild ${user.guild}\n💵 Sisa gold: ${user.gold}`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.guild create <nama>\n.guild join <nama>\n.guild info\n.guild donate <jumlah>`)
    }
}

handler.help = ["guild"]
handler.tags = ["rpg"]
handler.command = ["guild"]

module.exports = handler