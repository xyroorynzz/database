const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let recipes = {
    "pedang batu": { need: { gold: 100 }, result: { type: "weapon", name: "⚔️ Pedang Batu", desc: "Serangan +3" } },
    "pedang besi": { need: { gold: 300 }, result: { type: "weapon", name: "⚔️ Pedang Besi", desc: "Serangan +5" } },
    "baju kulit": { need: { gold: 150 }, result: { type: "armor", name: "🛡️ Baju Kulit", desc: "Pertahanan +3" } },
    "baju besi": { need: { gold: 400 }, result: { type: "armor", name: "⚔️ Baju Besi", desc: "Pertahanan +7" } },
    "potion agung": { need: { gold: 200 }, result: { type: "consumable", name: "Potion Agung", heal: 150, desc: "Pulihkan 150 stamina" } }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let list = `🔨 *RESEP CRAFTING*\n\n`
        for (let [item, data] of Object.entries(recipes)) {
            list += `• *${item}*\n  💰 ${data.need.gold} gold\n  📦 Hasil: ${data.result.desc}\n\n`
        }
        list += `Cara pakai: .craft pedang besi`
        return reply(list)
    }

    let itemName = args.join(" ").toLowerCase()
    let recipe = recipes[itemName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!\nKetik .craft untuk lihat daftar resep.`)

    if (user.gold < recipe.need.gold) return reply(`💰 Gold tidak cukup! Butuh ${recipe.need.gold} gold\nGold kamu: ${user.gold}`)

    user.gold -= recipe.need.gold
    user.crafting = (user.crafting || 0) + 1
    user.exp += 20

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    let result = recipe.result

    if (result.type === "weapon") {
        user.weapon = result.name
        db.updateUser(m.sender, user)
        reply(`🔨 *CRAFTING BERHASIL*\n\nKamu membuat ${result.name}\n${result.desc}\nGold terpakai: ${recipe.need.gold}\n📈 EXP +20\nGold tersisa: ${user.gold}`)
    } else if (result.type === "armor") {
        user.armor = result.name
        db.updateUser(m.sender, user)
        reply(`🔨 *CRAFTING BERHASIL*\n\nKamu membuat ${result.name}\n${result.desc}\nGold terpakai: ${recipe.need.gold}\n📈 EXP +20\nGold tersisa: ${user.gold}`)
    } else if (result.type === "consumable") {
        if (!user.inventory[result.name]) user.inventory[result.name] = 0
        user.inventory[result.name] += 1
        db.updateUser(m.sender, user)
        reply(`🔨 *CRAFTING BERHASIL*\n\nKamu membuat ${result.name}\n${result.desc}\nGold terpakai: ${recipe.need.gold}\n📈 EXP +20\nGold tersisa: ${user.gold}\n\nItem masuk ke inventory.`)
    }

    if (levelUp) reply(`\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`)
}

handler.help = ["craft"]
handler.tags = ["rpg"]
handler.command = ["craft", "buat"]

module.exports = handler