
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let cooldown = 5 * 60 * 1000

    if (user.lastHeal && now - user.lastHeal < cooldown) {
        let remaining = Math.ceil((cooldown - (now - user.lastHeal)) / 1000)
        let minutes = Math.floor(remaining / 60)
        let seconds = remaining % 60
        return reply(`⏰ Masih dalam masa pemulihan! Coba lagi dalam ${minutes} menit ${seconds} detik.`)
    }

    if (user.stamina >= user.maxStamina) {
        return reply(`❤️ Stamina sudah penuh! (${user.stamina}/${user.maxStamina})`)
    }

    let healBonus = 1
    if (user.skills && user.skills.healer) healBonus = 1 + (user.skills.healer * 0.05)
    let healAmount = Math.floor(50 * healBonus)
    
    let oldStamina = user.stamina
    user.stamina = Math.min(user.stamina + healAmount, user.maxStamina)
    user.lastHeal = now

    db.updateUser(m.sender, user)

    let actualHeal = user.stamina - oldStamina
    let bonusText = user.skills && user.skills.healer ? `\n✨ Bonus skill healer +${Math.floor((actualHeal - 50) / 50 * 100)}%` : ""
    
    reply(`🍖 *ISTIRAHAT SEBENTAR*\n\n❤️ Stamina pulih +${actualHeal}${bonusText}\n💪 Stamina sekarang: ${user.stamina}/${user.maxStamina}\n\nKetik .hunt untuk berkelahi lagi!`)
}

handler.help = ["heal"]
handler.tags = ["rpg"]
handler.command = ["heal", "istirahat", "regen"]

module.exports = handler