
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🍺 *TAVERN* 🍺\n\n`
        msg += `❤️ Stamina: ${user.stamina}/${user.maxStamina}\n\n`
        msg += `Command:\n`
        msg += `.tavern rest - Istirahat (pulihkan 50 stamina, 200 gold)\n`
        msg += `.tavern mission - Ambil misi harian\n`
        msg += `.tavern food - Beli makanan (pulihkan stamina)`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "rest") {
        if (user.gold < 200) return reply(`💰 Gold tidak cukup! Butuh 200 gold`)

        if (user.stamina >= user.maxStamina) {
            return reply(`❤️ Stamina sudah penuh! (${user.stamina}/${user.maxStamina})`)
        }

        let healAmount = 50
        user.stamina = Math.min(user.stamina + healAmount, user.maxStamina)
        user.gold -= 200

        db.updateUser(m.sender, user)
        reply(`🍺 *ISTIRAHAT DI TAVERN*\n\n❤️ Stamina +${healAmount}\n💰 Gold -200\n💪 Stamina: ${user.stamina}/${user.maxStamina}`)
    }
    else if (action === "mission") {
        let now = Date.now()
        let oneDay = 24 * 60 * 60 * 1000

        if (user.lastMission && now - user.lastMission < oneDay) {
            let remaining = oneDay - (now - user.lastMission)
            let hours = Math.floor(remaining / (60 * 60 * 1000))
            return reply(`⏰ Misi harian sudah diambil! Tunggu ${hours} jam lagi.`)
        }

        let missions = [
            { desc: "Kalahkan 5 monster", rewardGold: 500, rewardExp: 100, target: 5, type: "hunt" },
            { desc: "Kumpulkan 10 bijih besi", rewardGold: 800, rewardExp: 150, target: 10, type: "mine" },
            { desc: "Dapatkan 5 ikan salmon", rewardGold: 600, rewardExp: 120, target: 5, type: "fish" }
        ]

        let mission = missions[Math.floor(Math.random() * missions.length)]
        user.activeMission = mission
        user.lastMission = now

        db.updateUser(m.sender, user)

        reply(`📜 *MISI HARIAN* 📜\n\n${mission.desc}\n🎁 Reward: ${mission.rewardGold} gold, ${mission.rewardExp} EXP\n\nSelesaikan misi dengan melakukan aktivitas yang diminta!`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.tavern rest\n.tavern mission`)
    }
}

handler.help = ["tavern"]
handler.tags = ["rpg"]
handler.command = ["tavern"]

module.exports = handler