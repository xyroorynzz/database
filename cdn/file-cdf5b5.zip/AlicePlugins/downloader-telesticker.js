const axios = require("axios")
const { Sticker } = require("wa-sticker-formatter")

let handler = async (m, { Alice, text, command, reply }) => {

if (!text) return reply(`Cara pakai:\n.${command} https://t.me/addstickers/namapack`)

let input = text.trim()
if (!/https:\/\/t\.me\/addstickers\//i.test(input)) {
return reply("Link pack Telegram tidak valid.")
}

try {

let pack = input.split("addstickers/")[1].replace(/\?.*/g,"")

let res = await axios.get(`https://api.telegram.org/bot8472244520:AAEVw0ZppdmN_3kzPgPoe0Wt29y0zsSBKvM/getStickerSet?name=${encodeURIComponent(pack)}`)
if (!res.data.ok) return reply("Pack sticker tidak ditemukan.")

let list = res.data.result.stickers
if (!list || list.length === 0) return reply("Sticker pack ini kosong.")

await reply(`📦 Pack terdeteksi\nNama: ${pack}\nJumlah: ${list.length}\n\nSedang diproses...`)

for (let s of list) {
try {

let fileId = s.file_id

let file = await axios.get(`https://api.telegram.org/bot8472244520:AAEVw0ZppdmN_3kzPgPoe0Wt29y0zsSBKvM/getFile?file_id=${fileId}`)
let filePath = file.data.result.file_path

let url = `https://api.telegram.org/file/bot8472244520:AAEVw0ZppdmN_3kzPgPoe0Wt29y0zsSBKvM/${filePath}`

let img = await axios.get(url,{responseType:"arraybuffer"})

let st = new Sticker(img.data,{
pack: packname,
author: author,
type: "full"
})

let buff = await st.toBuffer()

await Alice.sendMessage(m.chat,{sticker: buff},{quoted:m})

await new Promise(r=>setTimeout(r,1200))

} catch {}
}

reply(`✔️ Semua sticker dari pack "${pack}" sudah dikirim.`)

} catch (err) {
console.log(err)
reply("Terjadi kesalahan saat mengambil sticker dari Telegram.")
}

}

handler.help = ["telesticker <url>"]
handler.tags = ["sticker"]
handler.command = ["telesticker","telestick","stickertele","stele"]

module.exports = handler