
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    } else {
        for (let i = 0; i < args.length; i++) {
            let match = args[i].match(/@(\d+)/)
            if (match) {
                target = match[1] + '@s.whatsapp.net'
                break
            }
        }
    }

    if (!target) target = m.sender

    let targetUser = db.getUser(target)
    if (!targetUser) return reply("❌ Target belum terdaftar di RPG!")

    let progressBar = ''
    let progress = (targetUser.exp / targetUser.expNeeded) * 100
    let filled = Math.floor(progress / 5)
    for (let i = 0; i < 20; i++) {
        progressBar += i < filled ? '█' : '░'
    }

    let caption = `🔍 *INSPECT PLAYER* 🔍\n\n`
    caption += `👤 Nama: ${targetUser.name}\n`
    caption += `⭐ Level: ${targetUser.level}\n`
    caption += `📊 EXP: ${targetUser.exp}/${targetUser.expNeeded}\n`
    caption += `📈 [${progressBar}] ${Math.floor(progress)}%\n\n`
    caption += `❤️ Stamina: ${targetUser.stamina}/${targetUser.maxStamina}\n`
    caption += `💰 Gold: ${targetUser.gold}\n\n`
    caption += `⚔️ Weapon: ${targetUser.weapon}\n`
    caption += `🛡️ Armor: ${targetUser.armor}\n`
    caption += `🏆 Total Hunt: ${targetUser.totalHunt || 0}\n`
    caption += `🏟️ Arena: ${targetUser.arenaWin || 0}W / ${targetUser.arenaLose || 0}L\n`
    caption += `⛏️ Mining: ${targetUser.mining || 0}\n`
    caption += `🎣 Fishing: ${targetUser.fishing || 0}\n`
    caption += `💼 Work: ${targetUser.workCount || 0}\n`
    caption += `🧭 Adventure: ${targetUser.adventureCount || 0}\n`
    
    if (targetUser.married && targetUser.married !== "tidak") {
        caption += `💍 Menikah dengan: @${targetUser.married.split('@')[0]}\n`
    }
    if (targetUser.pet && targetUser.pet.name !== "tidak punya") {
        caption += `🐾 Peliharaan: ${targetUser.pet.name} (Level ${targetUser.pet.level})\n`
    }

    await reply(caption, { mentions: [target] })
}

handler.help = ["inspect"]
handler.tags = ["rpg"]
handler.command = ["inspect", "intip", "lihat"]

module.exports = handler