
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let tradingPost = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🏪 *POS PERDAGANGAN* 🏪\n\n`
        msg += `Command:\n`
        msg += `.tradeoffer <item> <jumlah> <harga> - Jual item (100 gold fee)\n`
        msg += `.tradebuy <id> - Beli item dari pos\n`
        msg += `.tradelist - Lihat daftar item dijual\n`
        msg += `.tradecancel <id> - Batalkan jual (owner only)`
        return reply(msg)
    }

    let action = args[0].toLowerCase()

    if (action === "offer" || action === "jual") {
        let itemName = args[1]
        let qty = parseInt(args[2]) || 1
        let price = parseInt(args[3]) || 0

        if (!itemName || price < 1) return reply("Cara pakai: .tradeoffer <item> <jumlah> <harga>\nContoh: .tradeoffer 'Potion Kecil' 5 500")

        let have = user.inventory[itemName] || 0
        if (have < qty) return reply(`❌ ${itemName} tidak cukup! Kamu punya ${have}`)

        let fee = 100
        if (user.gold < fee) return reply(`💰 Gold tidak cukup untuk biaya admin! Butuh ${fee} gold`)

        user.gold -= fee
        user.inventory[itemName] -= qty
        if (user.inventory[itemName] === 0) delete user.inventory[itemName]

        let id = Date.now() + Math.random().toString(36)
        tradingPost[id] = {
            item: itemName,
            qty: qty,
            price: price,
            seller: m.sender,
            createdAt: Date.now()
        }

        db.updateUser(m.sender, user)

        reply(`✅ Item ditawarkan!\n🆔 ID: ${id}\n📦 ${qty} ${itemName}\n💰 Harga: ${price} gold\n💸 Biaya admin: ${fee} gold`)
    }
    else if (action === "buy" || action === "beli") {
        let id = args[1]
        let offer = tradingPost[id]

        if (!offer) return reply("❌ ID item tidak ditemukan!")

        if (offer.seller === m.sender) return reply("❌ Tidak bisa membeli item sendiri!")

        if (user.gold < offer.price) return reply(`💰 Gold tidak cukup! Butuh ${offer.price} gold`)

        let seller = db.getUser(offer.seller)
        if (!seller) {
            delete tradingPost[id]
            return reply("❌ Penjual tidak ditemukan!")
        }

        user.gold -= offer.price
        seller.gold += offer.price

        if (!user.inventory[offer.item]) user.inventory[offer.item] = 0
        user.inventory[offer.item] += offer.qty

        db.updateUser(m.sender, user)
        db.updateUser(offer.seller, seller)
        delete tradingPost[id]

        reply(`✅ *PEMBELIAN BERHASIL*\n\n📦 ${offer.qty} ${offer.item}\n💰 Harga: ${offer.price} gold\n👤 Penjual: @${offer.seller.split('@')[0]}`, { mentions: [offer.seller] })
    }
    else if (action === "list") {
        let items = Object.entries(tradingPost)
        if (items.length === 0) return reply("🏪 Tidak ada item yang dijual.")

        let msg = `🏪 *DAFTAR ITEM DIJUAL* 🏪\n\n`
        for (let [id, offer] of items) {
            msg += `🆔 ${id}\n`
            msg += `📦 ${offer.qty} ${offer.item}\n`
            msg += `💰 ${offer.price} gold\n`
            msg += `👤 Penjual: @${offer.seller.split('@')[0]}\n\n`
        }
        msg += `Cara beli: .tradebuy <id>`
        reply(msg, { mentions: Object.values(tradingPost).map(o => o.seller) })
    }
    else if (action === "cancel") {
        if (!isOwner) return reply("❌ Hanya owner yang bisa membatalkan!")
        let id = args[1]
        let offer = tradingPost[id]
        if (!offer) return reply("❌ ID tidak ditemukan!")
        delete tradingPost[id]
        reply(`✅ Item dengan ID ${id} telah dibatalkan.`)
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.tradeoffer <item> <jumlah> <harga>\n.tradebuy <id>\n.tradelist\n.tradecancel <id>`)
    }
}

handler.help = ["tradingpost"]
handler.tags = ["rpg"]
handler.command = ["tradingpost", "tp"]

module.exports = handler