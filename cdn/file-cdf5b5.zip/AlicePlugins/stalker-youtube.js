let { youtubeStalker } = require("../AliceSystem/AliceScraper/alice-youtubeStalker")

let handler = async (m, { args, reply }) => {
  if (!args[0]) return reply("contoh: .ytstalk username")

  try {
    let res = await youtubeStalker(args[0])
    let r = res.result

    reply(`
「 YOUTUBE STALKER 」

Channel     : ${r.name}
Subscribers : ${r.subscribers}
Views       : ${r.views}
Videos      : ${r.videos}
Created     : ${r.createdAt}

Description :
${r.description || "-"}

Avatar      : ${r.profile}
Link        : ${r.channelUrl}
`)
  } catch (e) {
    reply("error: " + e)
  }
}

handler.help = ["ytstalk", "youtubestalk"]
handler.tags = ["stalker"]
handler.command = ["ytstalk", "youtubestalk"]

module.exports = handler