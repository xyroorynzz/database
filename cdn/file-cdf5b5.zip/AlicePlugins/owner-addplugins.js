const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text }) => {

if (!text) return reply("nama plugin?")

if (!m.quoted) return reply("reply code plugin")

let name = text.endsWith(".js") ? text : text + ".js"

let code = m.quoted.text

let dir = path.join(__dirname, name)

fs.writeFileSync(dir, code)

reply(`plugin ${name} berhasil ditambahkan`)

}

handler.help = ["addplugins"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["addplugins","+plugins","addp"]

module.exports = handler