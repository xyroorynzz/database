const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 15) return reply("❤️ Stamina kurang! Butuh 15 stamina untuk berlatih.\nKetik .heal untuk istirahat.")

    let expGain = Math.floor(Math.random() * 40) + 20
    let staminaCost = 15

    user.stamina -= staminaCost
    user.exp += expGain

    if (!user.trainCount) user.trainCount = 0
    user.trainCount += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🏋️ *BERLATIH* 🏋️\n\n`
    msg += `💪 Kamu berlatih dengan giat!\n\n`
    msg += `📈 EXP +${expGain}\n`
    msg += `❤️ Stamina -${staminaCost} (${user.stamina}/${user.maxStamina})\n`
    msg += `📊 Total Latihan: ${user.trainCount}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["train"]
handler.tags = ["rpg"]
handler.command = ["train", "latih"]

module.exports = handler