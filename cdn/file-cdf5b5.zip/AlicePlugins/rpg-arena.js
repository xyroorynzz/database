
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let arenaData = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 25) return reply("❤️ Stamina kurang! Butuh 25 stamina untuk masuk arena.\nKetik .heal untuk istirahat.")

    let now = Date.now()
    if (arenaData[m.sender] && now - arenaData[m.sender] < 1800000) {
        let remaining = Math.ceil((1800000 - (now - arenaData[m.sender])) / 60000)
        return reply(`⏰ Arena masih dalam cooldown! Tunggu ${remaining} menit lagi.`)
    }

    let enemies = [
        { name: "Gladiator Pemula", level: 1, minExp: 40, maxExp: 70, minGold: 50, maxGold: 100, minDamage: 15, maxDamage: 30 },
        { name: "Prajurit Tangguh", level: 2, minExp: 60, maxExp: 100, minGold: 80, maxGold: 150, minDamage: 25, maxDamage: 45 },
        { name: "Kapten Perang", level: 3, minExp: 80, maxExp: 130, minGold: 100, maxGold: 200, minDamage: 35, maxDamage: 60 },
        { name: "Jenderal Legendaris", level: 4, minExp: 100, maxExp: 160, minGold: 150, maxGold: 250, minDamage: 45, maxDamage: 75 },
        { name: "Champion Arena", level: 5, minExp: 130, maxExp: 200, minGold: 200, maxGold: 350, minDamage: 55, maxDamage: 90 }
    ]

    let availableEnemies = enemies.filter(e => user.level >= e.level)
    let enemy = availableEnemies.length > 0 ? availableEnemies[availableEnemies.length - 1] : enemies[0]
    
    let weaponBonus = 0
    let armorBonus = 0
    
    if (user.weapon === "🗡️ Pedang Kayu") weaponBonus = 3
    else if (user.weapon === "⚔️ Pedang Besi") weaponBonus = 6
    else if (user.weapon === "🗡️ Pedang Baja") weaponBonus = 10
    else if (user.weapon === "⚔️ Excalibur") weaponBonus = 15
    
    if (user.armor === "👕 Baju Biasa") armorBonus = 2
    else if (user.armor === "🛡️ Baju Kulit") armorBonus = 5
    else if (user.armor === "⚔️ Baju Besi") armorBonus = 8
    else if (user.armor === "🛡️ Armor Dewa") armorBonus = 12
    
    let userPower = (user.level * 8) + weaponBonus + armorBonus
    let enemyPower = (enemy.level * 8) + 20
    
    let winChance = (userPower / (userPower + enemyPower)) * 100
    let random = Math.random() * 100
    
    let expGain, goldGain, damage, win
    let defenseBonus = 1
    if (user.skills && user.skills.defender) defenseBonus = 1 - (user.skills.defender * 0.05)
    
    if (random < winChance) {
        expGain = Math.floor(Math.random() * (enemy.maxExp - enemy.minExp + 1) + enemy.minExp)
        goldGain = Math.floor(Math.random() * (enemy.maxGold - enemy.minGold + 1) + enemy.minGold)
        damage = Math.floor(Math.random() * (enemy.maxDamage - enemy.minDamage + 1) + enemy.minDamage)
        win = true
        
        user.exp += expGain
        user.gold += goldGain
        user.arenaWin = (user.arenaWin || 0) + 1
    } else {
        expGain = Math.floor(Math.random() * 30) + 15
        goldGain = Math.floor(Math.random() * 50) + 25
        damage = Math.floor(Math.random() * (enemy.maxDamage - enemy.minDamage + 1) + enemy.minDamage) * 1.2
        win = false
        
        user.exp += expGain
        user.gold -= Math.floor(goldGain / 2)
        if (user.gold < 0) user.gold = 0
        user.arenaLose = (user.arenaLose || 0) + 1
    }
    
    damage = Math.floor(damage * defenseBonus)
    
    user.stamina -= 25
    if (user.stamina < 0) user.stamina = 0

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    arenaData[m.sender] = now

    let msg = `🏟️ *ARENA PVP* 🏟️\n\n`
    msg += `⚔️ Lawan: ${enemy.name} (Level ${enemy.level})\n`
    
    if (win) {
        msg += `✨ KAMU MENANG!\n\n`
        msg += `📈 EXP +${expGain}\n`
        msg += `💰 Gold +${goldGain}\n`
    } else {
        msg += `💀 KAMU KALAH!\n\n`
        msg += `📈 EXP +${expGain} (hiburan)\n`
        msg += `💰 Gold -${Math.floor(goldGain / 2)}\n`
    }
    
    msg += `💔 Damage diterima: ${Math.floor(damage)}`
    if (user.skills && user.skills.defender) msg += ` (tereduksi ${user.skills.defender * 5}%)`
    msg += `\n❤️ Stamina -25 (${user.stamina}/${user.maxStamina})\n`
    msg += `🏆 Total Kemenangan Arena: ${user.arenaWin || 0}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .arena lagi setelah 30 menit!`

    reply(msg)
}

handler.help = ["arena"]
handler.tags = ["rpg"]
handler.command = ["arena"]

module.exports = handler