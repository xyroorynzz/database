
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let tradeData = {}

let handler = async (m, { reply }) => {
    let trader = null

    for (let [id, data] of Object.entries(tradeData[m.chat] || {})) {
        if (data.target === m.sender && data.status === "pending") {
            trader = id
            break
        }
    }

    if (!trader) return reply("❌ Tidak ada trade request untukmu!")

    delete tradeData[m.chat][trader]

    reply(`❌ @${m.sender.split('@')[0]} menolak trade request!`, { mentions: [m.sender, trader] })
}

handler.help = ["tradereject"]
handler.tags = ["rpg"]
handler.command = ["tradereject", "tolaktrade"]

module.exports = handler