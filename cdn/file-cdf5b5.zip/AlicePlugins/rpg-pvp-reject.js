
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let pvpData = {}

let handler = async (m, { reply }) => {
    let challenger = null

    for (let [id, data] of Object.entries(pvpData[m.chat] || {})) {
        if (data.opponent === m.sender && data.status === "pending") {
            challenger = id
            break
        }
    }

    if (!challenger) return reply("❌ Tidak ada tantangan PVP untukmu!")

    delete pvpData[m.chat][challenger]

    reply(`❌ @${m.sender.split('@')[0]} menolak tantangan PVP!`, { mentions: [m.sender, challenger] })
}

handler.help = ["pvpreject"]
handler.tags = ["rpg"]
handler.command = ["pvpreject", "pvptolak"]

module.exports = handler