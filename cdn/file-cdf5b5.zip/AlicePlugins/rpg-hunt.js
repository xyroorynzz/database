
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (user.stamina < 10) return reply("❤️ Stamina kurang! Istirahat dulu dengan .heal")

    let weaponBonus = 0
    let armorBonus = 0
    
    if (user.weapon === "🗡️ Pedang Kayu") weaponBonus = 2
    else if (user.weapon === "⚔️ Pedang Besi") weaponBonus = 5
    else if (user.weapon === "🗡️ Pedang Baja") weaponBonus = 10
    else if (user.weapon === "⚔️ Excalibur") weaponBonus = 20
    
    if (user.armor === "👕 Baju Biasa") armorBonus = 1
    else if (user.armor === "🛡️ Baju Kulit") armorBonus = 3
    else if (user.armor === "⚔️ Baju Besi") armorBonus = 7
    else if (user.armor === "🛡️ Armor Dewa") armorBonus = 15

    let monsters = [
        { name: "Goblin", minExp: 15, maxExp: 35, minGold: 20, maxGold: 50, minDamage: 5, maxDamage: 15, level: 1 },
        { name: "Slime", minExp: 10, maxExp: 25, minGold: 10, maxGold: 30, minDamage: 3, maxDamage: 10, level: 1 },
        { name: "Bandit", minExp: 20, maxExp: 45, minGold: 30, maxGold: 70, minDamage: 8, maxDamage: 20, level: 2 },
        { name: "Serigala", minExp: 25, maxExp: 50, minGold: 25, maxGold: 60, minDamage: 10, maxDamage: 25, level: 2 },
        { name: "Orc", minExp: 30, maxExp: 60, minGold: 40, maxGold: 90, minDamage: 12, maxDamage: 30, level: 3 },
        { name: "Naga Muda", minExp: 50, maxExp: 100, minGold: 80, maxGold: 150, minDamage: 20, maxDamage: 40, level: 4 }
    ]

    let monster = monsters[Math.floor(Math.random() * monsters.length)]
    
    let userPower = (user.level * 5) + weaponBonus + armorBonus
    let monsterPower = (monster.level * 5) + (Math.floor(Math.random() * 10) + 5)
    
    let winChance = (userPower / (userPower + monsterPower)) * 100
    let random = Math.random() * 100
    
    let expGain, goldGain, damage, win
    let skillBonus = 1
    let critMsg = ""
    
    if (user.skills && user.skills.hunter) skillBonus = 1 + (user.skills.hunter * 0.1)
    
    if (random < winChance) {
        expGain = Math.floor(Math.random() * (monster.maxExp - monster.minExp + 1) + monster.minExp) + weaponBonus
        goldGain = Math.floor(Math.random() * (monster.maxGold - monster.minGold + 1) + monster.minGold)
        damage = Math.floor(Math.random() * (monster.maxDamage - monster.minDamage + 1) + monster.minDamage)
        win = true
        
        if (user.skills && user.skills.kritikal && Math.random() < 0.2) {
            expGain = expGain * 2
            goldGain = goldGain * 2
            critMsg = "✨ *KRITIKAL STRIKE!* ✨\n"
        }
        
        expGain = Math.floor(expGain * skillBonus)
        
        user.exp += expGain
        user.gold += goldGain
        user.totalHunt = (user.totalHunt || 0) + 1
    } else {
        expGain = Math.floor(Math.random() * (monster.minExp / 2)) + 5
        goldGain = Math.floor(Math.random() * (monster.minGold / 2)) + 5
        damage = Math.floor(Math.random() * (monster.maxDamage - monster.minDamage + 1) + monster.minDamage) * 1.5
        win = false
        
        expGain = Math.floor(expGain * skillBonus)
        
        user.exp += expGain
        user.gold -= Math.floor(goldGain / 2)
        if (user.gold < 0) user.gold = 0
        user.totalHunt = (user.totalHunt || 0) + 1
    }
    
    user.stamina -= 10
    if (user.stamina < 0) user.stamina = 0

    if (!user.dailyHuntProgress) user.dailyHuntProgress = 0
    user.dailyHuntProgress += 1

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `⚔️ *BERTARUNG MELAWAN ${monster.name.toUpperCase()}* ⚔️\n\n`
    
    if (win) {
        msg += `✨ KAMU MENANG!\n`
        if (critMsg) msg += critMsg
        msg += `\n📈 EXP +${expGain}\n`
        msg += `💰 GOLD +${goldGain}\n`
    } else {
        msg += `💀 KAMU KALAH!\n\n`
        msg += `📈 EXP +${expGain} (hiburan)\n`
        msg += `💰 GOLD -${Math.floor(goldGain / 2)}\n`
    }
    
    msg += `💔 Damage diterima: ${Math.floor(damage)}\n`
    msg += `❤️ Stamina -10 (${user.stamina}/${user.maxStamina})\n`
    msg += `📊 Daily Hunt Progress: ${user.dailyHuntProgress}/10\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .my untuk lihat status terbaru`

    reply(msg)
}

handler.help = ["hunt"]
handler.tags = ["rpg"]
handler.command = ["hunt", "berburu", "fight"]

module.exports = handler