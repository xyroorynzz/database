
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let alchemyRecipes = {
    "kristal ajaib": { need: { "Kristal": 3, "Permata": 2 }, result: { name: "Kristal Ajaib", sell: 500 } },
    "batu bertuah": { need: { "Batu Bertuah": 2, "Kristal": 5 }, result: { name: "Batu Bertuah+", sell: 1000 } },
    "elixir kehidupan": { need: { "Ramuan Sayur": 2, "Kristal Ajaib": 1 }, result: { name: "Elixir Kehidupan", heal: 200, sell: 800 } }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `⚗️ *RESEP ALCHEMY* ⚗️\n\n`
        for (let [item, data] of Object.entries(alchemyRecipes)) {
            msg += `• ${item}\n`
            msg += `  Bahan: ${Object.entries(data.need).map(([b, j]) => `${j} ${b}`).join(', ')}\n`
            msg += `  Hasil: ${data.result.name}\n\n`
        }
        msg += `Cara pakai: .alchemy kristal ajaib`
        return reply(msg)
    }

    let itemName = args.join(" ").toLowerCase()
    let recipe = alchemyRecipes[itemName]

    if (!recipe) return reply(`❌ Resep "${args.join(" ")}" tidak ditemukan!`)

    for (let [item, need] of Object.entries(recipe.need)) {
        let have = user.inventory[item] || 0
        if (have < need) return reply(`❌ ${item} tidak cukup! Butuh ${need}, kamu punya ${have}`)
    }

    for (let [item, need] of Object.entries(recipe.need)) {
        user.inventory[item] -= need
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    if (!user.inventory[recipe.result.name]) user.inventory[recipe.result.name] = 0
    user.inventory[recipe.result.name] += 1
    user.exp += 50

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `⚗️ *ALCHEMY* ⚗️\n\n`
    msg += `✅ ${recipe.result.name} berhasil dibuat!\n`
    msg += `📦 ${recipe.result.name} sekarang: ${user.inventory[recipe.result.name]}\n`
    msg += `📈 EXP +50\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["alchemy"]
handler.tags = ["rpg"]
handler.command = ["alchemy", "alkimia"]

module.exports = handler