const fs = require("fs")
const path = require("path")
const axios = require("axios")
const FormData = require("form-data")

const filePath = path.join(process.cwd(), "AliceSet.js")

async function uploadToAliceCdn(buffer, fileName) {

const form = new FormData()

form.append("cdnFile", buffer, {
filename: fileName,
contentType: "application/octet-stream"
})

const { data } = await axios.post(
"https://aliceecdn.vercel.app/upload",
form,
{
headers: {
...form.getHeaders(),
"Content-Length": form.getLengthSync()
}
}
)

if (!data?.url) throw "upload gagal"

return data.url
}

function setGlobal(file, key, value) {

const regex = new RegExp(
`global\\.${key}\\s*=\\s*['"\`](.*?)['"\`]`
)

if (!regex.test(file)) return null

return file.replace(regex, `global.${key} = '${value}'`)
}

function setObject(file, object, key, value) {

const regex = new RegExp(
`(${key}:\\s*)['"\`](.*?)['"\`]`
)

return file.replace(regex, `$1'${value}'`)
}

let handler = async (m, { text, command, reply }) => {

if (!fs.existsSync(filePath)) {
return reply("file AliceSet.js tidak ditemukan")
}

if (!text) {
return reply(`
📌 LIST RENAME

botname
ownername
version
packname
author
thumb
thumbnailreply
gmail
web
groupbot
channel
idch

telegram
whatsapp
instagram
youtube
tiktok

qris
qris_an
dana
dana_an
gopay
gopay_an

📖 CONTOH
.renamebot botname Alice Assistant

📖 IMAGE
reply image + .renamebot thumb
reply image + .renamebot thumbnailreply
`)
}

let [type, ...args] = text.split(" ")

type = type?.toLowerCase()

let value = args.join(" ")

if (
["thumb", "thumbnailreply"].includes(type) &&
m.quoted &&
/image/.test(m.quoted.mimetype || "")
) {

let media = await m.quoted.download()

value = await uploadToAliceCdn(
media,
`alice_${Date.now()}.jpg`
)

}

if (!value) {
return reply("value tidak ditemukan")
}

let file = fs.readFileSync(filePath, "utf8")

const globals = {
botname: "botname",
ownername: "ownername",
version: "version",
packname: "packname",
author: "author",
thumb: "thumb",
thumbnailreply: "thumbnailReply",
gmail: "gmail",
web: "web",
groupbot: "groupbot",
channel: "channel",
idch: "idch"
}

const socials = [
"telegram",
"whatsapp",
"instagram",
"youtube",
"tiktok"
]

const payments = [
"qris",
"qris_an",
"dana",
"dana_an",
"gopay",
"gopay_an"
]

if (globals[type]) {
file = setGlobal(file, globals[type], value)
}

if (socials.includes(type)) {
file = setObject(file, "sosialmedia", type, value)
}

if (payments.includes(type)) {
file = setObject(file, "payment", type, value)
}

if (!file) {
return reply("opsi tidak ditemukan")
}

fs.writeFileSync(filePath, file)

reply(`
✅ berhasil rename

📌 type : ${type}
📝 value : ${value}
`)
}

handler.help = ["renamebot"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["renamebot"]

module.exports = handler