
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let transmuteRecipes = {
    "5 batu biasa": { need: { "Batu Biasa": 5 }, result: { name: "Batu Bara", qty: 1 }, cost: 100 },
    "5 batu bara": { need: { "Batu Bara": 5 }, result: { name: "Bijih Besi", qty: 1 }, cost: 200 },
    "5 bijih besi": { need: { "Bijih Besi": 5 }, result: { name: "Bijih Emas", qty: 1 }, cost: 500 },
    "5 bijih emas": { need: { "Bijih Emas": 5 }, result: { name: "Kristal", qty: 1 }, cost: 1000 },
    "5 kristal": { need: { "Kristal": 5 }, result: { name: "Permata", qty: 1 }, cost: 2000 },
    "5 permata": { need: { "Permata": 5 }, result: { name: "Batu Bertuah", qty: 1 }, cost: 5000 }
}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let msg = `🔄 *TRANSMUTASI* 🔄\n\n`
        for (let [recipe, data] of Object.entries(transmuteRecipes)) {
            msg += `• ${recipe} → ${data.result.name} x${data.result.qty}\n`
            msg += `  💰 Biaya: ${data.cost} gold\n\n`
        }
        msg += `Cara pakai: .transmute 5 batu biasa`
        return reply(msg)
    }

    let input = args.join(" ")
    let recipe = transmuteRecipes[input]

    if (!recipe) return reply(`❌ Resep "${input}" tidak ditemukan!`)

    for (let [item, needQty] of Object.entries(recipe.need)) {
        let haveQty = user.inventory[item] || 0
        if (haveQty < needQty) return reply(`❌ ${item} tidak cukup! Butuh ${needQty}, kamu punya ${haveQty}`)
    }

    if (user.gold < recipe.cost) return reply(`💰 Gold tidak cukup! Butuh ${recipe.cost} gold`)

    for (let [item, needQty] of Object.entries(recipe.need)) {
        user.inventory[item] -= needQty
        if (user.inventory[item] === 0) delete user.inventory[item]
    }

    user.gold -= recipe.cost

    if (!user.inventory[recipe.result.name]) user.inventory[recipe.result.name] = 0
    user.inventory[recipe.result.name] += recipe.result.qty

    db.updateUser(m.sender, user)

    reply(`🔄 *TRANSMUTASI BERHASIL* 🔄\n\n✅ ${input} → ${recipe.result.name} x${recipe.result.qty}\n💰 Gold -${recipe.cost}\n📦 ${recipe.result.name} sekarang: ${user.inventory[recipe.result.name]}`)
}

handler.help = ["transmute"]
handler.tags = ["rpg"]
handler.command = ["transmute", "transmutasi"]

module.exports = handler