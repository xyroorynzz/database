const fs = require('fs');
const path = require('path');

const STORE_DIR = './AliceDatabase/store-db/';
const HISTORY_FILE = path.join(STORE_DIR, 'history.json');
const PRODUCT_FILE = path.join(STORE_DIR, 'products.json');
const CART_FILE = path.join(STORE_DIR, 'cart.json');
const PAYMENT_FILE = path.join(STORE_DIR, 'payment.json');

function ensureDir() {
    if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });
}

function loadJSON(file) {
    ensureDir();
    if (!fs.existsSync(file)) {
        if (file === HISTORY_FILE) fs.writeFileSync(file, JSON.stringify([]));
        else if (file === PAYMENT_FILE) fs.writeFileSync(file, JSON.stringify({}));
        else fs.writeFileSync(file, JSON.stringify([]));
    }
    return JSON.parse(fs.readFileSync(file));
}

function saveJSON(file, data) {
    ensureDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function toRupiah(angka) {
    return new Intl.NumberFormat('id-ID').format(angka);
}

let handler = async (m, { command, text, reply, prefix, Alice }) => {
    const transactionId = text.trim();
    if (!transactionId) return reply(`Contoh: ${prefix}confirm TRX123456789`);
    
    let history = loadJSON(HISTORY_FILE);
    if (!Array.isArray(history)) history = [];
    let transaction = history.find(t => t.id === transactionId);
    
    if (!transaction) return reply(`❌ Transaksi dengan ID "${transactionId}" tidak ditemukan.`);
    if (transaction.status !== 'pending') return reply(`❌ Transaksi sudah ${transaction.status}.`);
    
    let products = loadJSON(PRODUCT_FILE);
    if (!Array.isArray(products)) products = [];
    
    for (let item of transaction.items) {
        let product = products.find(p => p.nama.toLowerCase() === item.nama.toLowerCase());
        if (product) {
            product.stok -= item.jumlah;
        }
    }
    saveJSON(PRODUCT_FILE, products);
    
    transaction.status = 'success';
    saveJSON(HISTORY_FILE, history);
    
    let invoice = `✅ KONFIRMASI BERHASIL\n━━━━━━━━━━━━━━━━━━\n`;
    invoice += `📋 ID Transaksi: ${transactionId}\n`;
    invoice += `👤 Pembeli: @${transaction.buyer.split('@')[0]}\n`;
    invoice += `💰 Total: Rp${toRupiah(transaction.total)}\n`;
    invoice += `📅 Tanggal: ${new Date(transaction.tanggal).toLocaleDateString('id-ID')}\n`;
    invoice += `━━━━━━━━━━━━━━━━━━\n`;
    invoice += `🎉 Pesanan kamu sudah kami proses!\n`;
    invoice += `Terima kasih sudah berbelanja 🙏`;
    
    await Alice.sendMessage(m.chat, { text: invoice, mentions: [transaction.buyer] }, { quoted: m });
    
    let cart = loadJSON(CART_FILE);
    if (cart[transaction.buyer]) {
        cart[transaction.buyer] = [];
        saveJSON(CART_FILE, cart);
    }
};

handler.command = ['confirm'];
handler.tags = ['store'];

module.exports = handler;