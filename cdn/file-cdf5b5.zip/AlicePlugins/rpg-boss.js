
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let bossCooldown = {}

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    if (bossCooldown[m.sender] && now - bossCooldown[m.sender] < 3600000) {
        let remaining = Math.ceil((3600000 - (now - bossCooldown[m.sender])) / 60000)
        return reply(`⏰ Bos sudah dikalahkan! Tunggu ${remaining} menit untuk melawan lagi.`)
    }

    if (user.stamina < 30) return reply("❤️ Stamina kurang! Butuh 30 stamina untuk melawan bos.\nKetik .heal untuk istirahat.")

    let bosses = [
        { name: "🔥 Raja Goblin", level: 5, minExp: 80, maxExp: 150, minGold: 100, maxGold: 250, minDamage: 30, maxDamage: 50 },
        { name: "🐉 Naga Tua", level: 10, minExp: 150, maxExp: 300, minGold: 200, maxGold: 500, minDamage: 50, maxDamage: 80 },
        { name: "👹 Demon Lord", level: 15, minExp: 200, maxExp: 500, minGold: 300, maxGold: 800, minDamage: 70, maxDamage: 120 },
        { name: "🧙‍♂️ Dark Wizard", level: 8, minExp: 100, maxExp: 200, minGold: 150, maxGold: 350, minDamage: 40, maxDamage: 65 },
        { name: "🦇 Vampire King", level: 12, minExp: 180, maxExp: 350, minGold: 250, maxGold: 600, minDamage: 60, maxDamage: 100 }
    ]

    let availableBosses = bosses.filter(b => user.level >= b.level)
    let boss = availableBosses.length > 0 ? availableBosses[availableBosses.length - 1] : bosses[0]
    
    let weaponBonus = 0
    let armorBonus = 0
    
    if (user.weapon === "🗡️ Pedang Kayu") weaponBonus = 5
    else if (user.weapon === "⚔️ Pedang Besi") weaponBonus = 10
    else if (user.weapon === "🗡️ Pedang Baja") weaponBonus = 15
    else if (user.weapon === "⚔️ Excalibur") weaponBonus = 25
    
    if (user.armor === "👕 Baju Biasa") armorBonus = 3
    else if (user.armor === "🛡️ Baju Kulit") armorBonus = 6
    else if (user.armor === "⚔️ Baju Besi") armorBonus = 12
    else if (user.armor === "🛡️ Armor Dewa") armorBonus = 20
    
    let userPower = (user.level * 8) + weaponBonus + armorBonus
    let bossPower = (boss.level * 10) + 40
    
    let winChance = (userPower / (userPower + bossPower)) * 100
    let random = Math.random() * 100
    
    let expGain, goldGain, damage, win
    
    if (random < winChance) {
        expGain = Math.floor(Math.random() * (boss.maxExp - boss.minExp + 1) + boss.minExp)
        goldGain = Math.floor(Math.random() * (boss.maxGold - boss.minGold + 1) + boss.minGold)
        damage = Math.floor(Math.random() * (boss.maxDamage - boss.minDamage + 1) + boss.minDamage)
        win = true
        
        user.exp += expGain
        user.gold += goldGain
        user.totalHunt = (user.totalHunt || 0) + 1
        user.bossKill = (user.bossKill || 0) + 1
    } else {
        expGain = Math.floor(Math.random() * 40) + 20
        goldGain = Math.floor(Math.random() * 80) + 40
        damage = Math.floor(Math.random() * (boss.maxDamage - boss.minDamage + 1) + boss.minDamage) * 1.5
        win = false
        
        user.exp += expGain
        user.gold -= Math.floor(goldGain / 2)
        if (user.gold < 0) user.gold = 0
        user.totalHunt = (user.totalHunt || 0) + 1
    }
    
    user.stamina -= 30
    if (user.stamina < 0) user.stamina = 0

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)
    bossCooldown[m.sender] = now

    let msg = `⚔️ *BERTARUNG MELAWAN ${boss.name}* ⚔️\n\n`
    
    if (win) {
        msg += `✨ KAMU MENANG!\n\n`
        msg += `📈 EXP +${expGain}\n`
        msg += `💰 GOLD +${goldGain}\n`
        msg += `👹 Total Boss Kill: ${user.bossKill || 0}\n`
    } else {
        msg += `💀 KAMU KALAH!\n\n`
        msg += `📈 EXP +${expGain} (hiburan)\n`
        msg += `💰 GOLD -${Math.floor(goldGain / 2)}\n`
    }
    
    msg += `💔 Damage diterima: ${Math.floor(damage)}\n`
    msg += `❤️ Stamina -30 (${user.stamina}/${user.maxStamina})\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKetik .boss lagi setelah 1 jam!`

    reply(msg)
}

handler.help = ["boss"]
handler.tags = ["rpg"]
handler.command = ["boss"]

module.exports = handler