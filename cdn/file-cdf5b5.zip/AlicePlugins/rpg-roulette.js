
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let rouletteCooldown = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let amount = parseInt(args[0])
    if (isNaN(amount) || amount < 100) return reply("💰 Masukkan jumlah taruhan minimal 100 gold!\nContoh: .roulette 500")

    if (amount > user.gold) return reply(`💰 Gold tidak cukup! Kamu hanya punya ${user.gold} gold`)

    let now = Date.now()
    if (rouletteCooldown[m.sender] && now - rouletteCooldown[m.sender] < 30000) {
        let remaining = Math.ceil((30000 - (now - rouletteCooldown[m.sender])) / 1000)
        return reply(`⏰ Tunggu ${remaining} detik lagi untuk bermain roulette lagi!`)
    }

    let numbers = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26]
    let colors = ["🔴", "⚫", "🟢"]
    
    let result = numbers[Math.floor(Math.random() * numbers.length)]
    let color = result === 0 ? "🟢 Hijau" : (result % 2 === 0 ? "⚫ Hitam" : "🔴 Merah")
    
    let winAmount = 0
    let win = false

    if (args[1] === "merah" && color === "🔴 Merah") {
        winAmount = amount * 2
        win = true
    } else if (args[1] === "hitam" && color === "⚫ Hitam") {
        winAmount = amount * 2
        win = true
    } else if (args[1] === "hijau" && color === "🟢 Hijau") {
        winAmount = amount * 35
        win = true
    } else if (!isNaN(parseInt(args[1])) && parseInt(args[1]) === result) {
        winAmount = amount * 36
        win = true
    }

    if (win) {
        user.gold += winAmount
        let msg = `🎰 *ROULETTE* 🎰\n\n`
        msg += `🎲 Hasil: ${result} ${color}\n`
        msg += `✅ KAMU MENANG!\n`
        msg += `💰 Menang: ${winAmount} gold\n`
        msg += `💰 Total gold: ${user.gold}`
        reply(msg)
    } else {
        user.gold -= amount
        let msg = `🎰 *ROULETTE* 🎰\n\n`
        msg += `🎲 Hasil: ${result} ${color}\n`
        msg += `💀 KAMU KALAH!\n`
        msg += `💰 Kalah: ${amount} gold\n`
        msg += `💰 Sisa gold: ${user.gold}`
        reply(msg)
    }

    rouletteCooldown[m.sender] = now
    db.updateUser(m.sender, user)
}

handler.help = ["roulette"]
handler.tags = ["rpg"]
handler.command = ["roulette"]

module.exports = handler