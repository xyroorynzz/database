
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let caption = `📊 *STATISTIK PEMAIN* 📊\n\n`
    caption += `┌─── *PERTEMPURAN* ───┐\n`
    caption += `│ 🏆 Total Hunt: ${user.totalHunt || 0}\n`
    caption += `│ ⚔️ Arena: ${user.arenaWin || 0}W/${user.arenaLose || 0}L\n`
    caption += `│ 🤺 Duel: ${user.duelWin || 0}W/${user.duelLose || 0}L\n`
    caption += `│ 👹 Boss: ${user.bossKill || 0}\n`
    caption += `│ 🏯 Dungeon: ${user.dungeonCount || 0}\n`
    caption += `└─────────────────┘\n\n`

    caption += `┌─── *PEKERJAAN* ───┐\n`
    caption += `│ ⛏️ Mining: ${user.mining || 0}\n`
    caption += `│ 🎣 Fishing: ${user.fishing || 0}\n`
    caption += `│ 🪵 Woodcutting: ${user.woodcutting || 0}\n`
    caption += `│ 🌱 Farming: ${user.farming || 0}\n`
    caption += `│ 💼 Work: ${user.workCount || 0}\n`
    caption += `│ 🔨 Crafting: ${user.crafting || 0}\n`
    caption += `│ 🧭 Adventure: ${user.adventureCount || 0}\n`
    caption += `└─────────────────┘\n\n`

    caption += `┌─── *EKONOMI* ───┐\n`
    caption += `│ 💰 Gold: ${user.gold}\n`
    caption += `│ 🏦 Bank: ${user.bank || 0}\n`
    caption += `│ 💳 Debt: ${user.debt || 0}\n`
    caption += `│ 🎰 Gamble: ${user.gambleCount || 0}\n`
    caption += `│ 🦹 Steal: ${user.stealSuccess || 0}\n`
    caption += `└─────────────────┘\n\n`

    caption += `┌─── *LAINNYA* ───┐\n`
    caption += `│ 🐾 Pet Level: ${user.pet?.level || 0}\n`
    caption += `│ ✨ Prestige: ${user.prestige || 0}\n`
    caption += `│ 📜 Quest: ${user.questCompleted || 0}\n`
    caption += `│ 🎁 Daily Streak: ${user.dailyStreak || 0}\n`
    caption += `└─────────────────┘`

    reply(caption)
}

handler.help = ["stats"]
handler.tags = ["rpg"]
handler.command = ["stats"]

module.exports = handler