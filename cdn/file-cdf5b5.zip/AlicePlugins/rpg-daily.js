
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDaily && now - user.lastDaily < oneDay) {
        let remaining = oneDay - (now - user.lastDaily)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        let minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
        return reply(`⏰ Hadiah harian sudah diambil!\nTunggu ${hours} jam ${minutes} menit lagi.`)
    }

    let bonusGold = 500
    let bonusExp = 100
    let bonusStamina = 50

    user.gold += bonusGold
    user.exp += bonusExp
    user.stamina = Math.min(user.stamina + bonusStamina, user.maxStamina)
    user.lastDaily = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎁 *HADIAH HARIAN* 🎁\n\n`
    msg += `💰 Gold +${bonusGold}\n`
    msg += `📈 EXP +${bonusExp}\n`
    msg += `❤️ Stamina +${bonusStamina}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉\n`
    msg += `\nKembali besok untuk hadiah lagi!`

    reply(msg)
}

handler.help = ["daily"]
handler.tags = ["rpg"]
handler.command = ["daily"]

module.exports = handler