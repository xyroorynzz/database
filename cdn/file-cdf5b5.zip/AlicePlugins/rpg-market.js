
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let marketItems = {}

let handler = async (m, { reply, args }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    if (!args.length) {
        let items = Object.entries(marketItems)
        if (items.length === 0) {
            return reply(`🏪 *PASAR RPG* 🏪\n\nTidak ada item yang dijual.\n\nKetik .market jual <item> <harga> - Jual item dari inventory\nKetik .market beli <id> - Beli item dari pasar`)
        }

        let msg = `🏪 *PASAR RPG* 🏪\n\n`
        for (let [id, item] of items) {
            msg += `ID: ${id}\n📦 ${item.name} | 💰 ${item.price} gold\n👤 Penjual: @${item.seller.split('@')[0]}\n\n`
        }
        msg += `Ketik .market beli <id> untuk membeli`
        return reply(msg, { mentions: items.map(i => i[1].seller) })
    }

    let action = args[0].toLowerCase()

    if (action === "jual") {
        let itemName = args.slice(1, -1).join(" ")
        let price = parseInt(args[args.length - 1])

        if (!itemName || isNaN(price)) return reply("Cara pakai: .market jual <item> <harga>\nContoh: .market jual Potion Kecil 500")

        let itemQty = user.inventory[itemName]
        if (!itemQty || itemQty <= 0) return reply(`❌ Item "${itemName}" tidak ada di inventory!`)

        let id = Date.now() + Math.floor(Math.random() * 1000)
        marketItems[id] = {
            name: itemName,
            price: price,
            seller: m.sender,
            qty: 1
        }

        user.inventory[itemName] -= 1
        if (user.inventory[itemName] === 0) delete user.inventory[itemName]

        db.updateUser(m.sender, user)
        reply(`✅ Item "${itemName}" berhasil dijual dengan harga ${price} gold!\nID: ${id}`)
    }
    else if (action === "beli") {
        let id = parseInt(args[1])
        let item = marketItems[id]

        if (!item) return reply("❌ ID item tidak ditemukan!")

        if (user.gold < item.price) return reply(`💰 Gold tidak cukup! Butuh ${item.price} gold`)

        let seller = db.getUser(item.seller)
        if (!seller) {
            delete marketItems[id]
            return reply("❌ Penjual tidak ditemukan!")
        }

        user.gold -= item.price
        seller.gold += item.price

        if (!user.inventory[item.name]) user.inventory[item.name] = 0
        user.inventory[item.name] += item.qty

        db.updateUser(m.sender, user)
        db.updateUser(item.seller, seller)
        delete marketItems[id]

        reply(`✅ *PEMBELIAN BERHASIL*\n\n📦 ${item.name} x${item.qty}\n💰 Harga: ${item.price} gold\n👤 Penjual: @${item.seller.split('@')[0]}`, { mentions: [item.seller] })
    }
    else {
        reply(`❌ Perintah tidak dikenal!\n\n.market jual <item> <harga>\n.market beli <id>`)
    }
}

handler.help = ["market"]
handler.tags = ["rpg"]
handler.command = ["market", "pasar"]

module.exports = handler