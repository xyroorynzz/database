
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let sender = m.sender

    let existingUser = db.getUser(sender)
    if (existingUser) return reply("✅ Kamu sudah terdaftar!")

    let name = m.pushName || m.name || sender.split('@')[0]

    let newUser = {
        id: sender,
        name: name,
        registeredAt: Date.now(),
        level: 1,
        exp: 0,
        expNeeded: 100,
        stamina: 100,
        maxStamina: 100,
        gold: 500,
        bank: 0,
        totalHunt: 0,
        mining: 0,
        fishing: 0,
        workCount: 0,
        adventureCount: 0,
        arenaWin: 0,
        arenaLose: 0,
        achHunt: false,
        achHunt2: false,
        achHunt3: false,
        achMine: false,
        achMine2: false,
        achFish: false,
        achFish2: false,
        achWork: false,
        achArena: false,
        achArena2: false,
        weapon: "🗡️ Pedang Kayu",
        armor: "👕 Baju Biasa",
        lastDaily: 0,
        lastWork: 0,
        lastAdventure: 0,
        lastHeal: 0,
        inventory: {
            "Potion Kecil": 3,
            "Potion Sedang": 0,
            "Potion Besar": 0
        }
    }

    db.createUser(sender, newUser)

    let msg = `🎮 *REGISTRASI BERHASIL!* 🎮\n\n`
    msg += `Selamat datang, *${name}*!\n`
    msg += `Kamu mendapatkan:\n`
    msg += `💰 500 Gold\n`
    msg += `❤️ 100 Stamina\n`
    msg += `🗡️ Pedang Kayu\n`
    msg += `👕 Baju Biasa\n`
    msg += `🧪 3 Potion Kecil\n\n`
    msg += `Ketik .my untuk melihat statusmu!`

    reply(msg)
}

handler.help = ["rpgregister"]
handler.tags = ["rpg"]
handler.command = ["rpgregister", "regrpg", "rpgdaftar", "rpggabung"]

module.exports = handler