const axios = require('axios');
const FormData = require('form-data');

async function uploadToAliceCdn(buffer, fileName) {
    if (!Buffer.isBuffer(buffer)) {
        throw new Error('File bukan buffer');
    }

    const form = new FormData();
    form.append('cdnFile', buffer, {
        filename: fileName,
        contentType: 'application/octet-stream'
    });

    try {
        const res = await axios.post(
            'https://aliceecdn.vercel.app/upload',
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Content-Length': form.getLengthSync()
                }
            }
        );

        if (res.data?.url) return res.data.url;
        throw new Error('Upload gagal: ' + JSON.stringify(res.data));
    } catch (err) {
        throw new Error(`Upload error: ${err.response?.data?.message || err.message}`);
    }
}

let handler = async (m, { Alice, text, args, reply, XReaction, prefix, command }) => {
    if (!text || !text.includes('|')) {
        return reply(
            `📞 *FAKE CALL*\n\n` +
            `Gunakan perintah ini untuk membuat gambar fake call WhatsApp.\n\n` +
            `*Format:* ${prefix + command} nama | durasi\n\n` +
            `*Contoh:* ${prefix + command} Zann | 19.00\n\n` +
            `💡 *Tips:* Reply gambar untuk custom avatar`
        );
    }
    
    const [nama, durasi] = text.split('|').map(s => s.trim());
    
    if (!nama) {
        return reply(`❌ Nama tidak boleh kosong!`);
    }
    
    await XReaction('🕕');
    
    try {
        let avatar = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
        
        if (m.type === "imageMessage") {
            try {
                const buffer = await m.download();
                const uploadedUrl = await uploadToAliceCdn(buffer, 'avatar.jpg');
                if (uploadedUrl) avatar = uploadedUrl;
            } catch {}
        } 
        else if (m.quoted && (m.quoted.type === "imageMessage" || m.quoted.mtype === "imageMessage")) {
            try {
                const buffer = await m.quoted.download();
                const uploadedUrl = await uploadToAliceCdn(buffer, 'avatar.jpg');
                if (uploadedUrl) avatar = uploadedUrl;
            } catch {}
        }
        else {
            try {
                avatar = await Alice.profilePictureUrl(m.sender, 'image');
            } catch {}
        }
        
        const apiUrl = `https://api.zenzxz.my.id/maker/fakecall?nama=${encodeURIComponent(nama)}&durasi=${encodeURIComponent(durasi || '')}&avatar=${encodeURIComponent(avatar)}`;
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await Alice.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `📞 *FAKE CALL*\n👤 ${nama}\n⏰ ${durasi || '-'}`
        }, { quoted: m });
        
        await XReaction('✅');
        
    } catch (error) {
        await XReaction('❌');
        reply(`Error: ${error.message}`);
    }
};

handler.help = ['fakecall', 'fakecallwa'];
handler.tags = ['canvas'];
handler.command = ['fakecall', 'fakecallwa'];

module.exports = handler;