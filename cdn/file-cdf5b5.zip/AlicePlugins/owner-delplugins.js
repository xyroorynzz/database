const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text }) => {

if (!text) return reply("contoh: .delp tools-ping.js")

let name = text.endsWith(".js") ? text : text + ".js"

let dir = path.join(__dirname, name)

if (!fs.existsSync(dir)) return reply("plugin tidak ditemukan")

fs.unlinkSync(dir)

reply(`🗑 plugin ${name} dihapus`)

}

handler.help = ["delp"]
handler.tags = ["owner"]
handler.owner = true
handler.command = ["delp","delplugins","-plugins"]

module.exports = handler