const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let users = db.getAllUsers()
    
    if (Object.keys(users).length === 0) return reply("Belum ada pemain yang terdaftar!")

    let validUsers = []
    for (let id in users) {
        let user = users[id]
        if (user.name && typeof user.level === 'number' && user.name !== undefined) {
            validUsers.push(user)
        }
    }

    if (validUsers.length === 0) return reply("Belum ada data pemain yang valid!")

    validUsers.sort((a, b) => b.level - a.level || b.gold - a.gold)

    let top10 = validUsers.slice(0, 10)
    let caption = `🏆 *LEADERBOARD PETUALANG* 🏆\n\n`

    for (let i = 0; i < top10.length; i++) {
        let user = top10[i]
        let medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "📌"
        let name = user.name || "Petualang"
        let level = user.level || 1
        let gold = user.gold || 0
        caption += `${medal} ${i+1}. ${name}\n`
        caption += `   ⭐ Level ${level} | 💰 ${gold} gold\n\n`
    }

    caption += `Total pemain: ${validUsers.length} orang`

    reply(caption)
}

handler.help = ["leaderboard"]
handler.tags = ["rpg"]
handler.command = ["leaderboard", "rpgrank", "top", "peringkat"]

module.exports = handler