
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let progressBar = ''
    let progress = (user.exp / user.expNeeded) * 100
    let filled = Math.floor(progress / 5)
    for (let i = 0; i < 20; i++) {
        progressBar += i < filled ? '█' : '░'
    }

    let caption = `┌─── *「 PROFIL PETUALANG 」* ───┐\n`
    caption += `│\n`
    caption += `│ 👤 Nama: ${user.name}\n`
    caption += `│ 🏆 Gelar: ${user.title || "Tidak ada"}\n`
    caption += `│ ⭐ Level: ${user.level}\n`
    caption += `│ 📊 EXP: ${user.exp}/${user.expNeeded}\n`
    caption += `│ 📈 [${progressBar}] ${Math.floor(progress)}%\n`
    caption += `│\n`
    caption += `│ ❤️ Stamina: ${user.stamina}/${user.maxStamina}\n`
    caption += `│ 💰 Gold: ${user.gold}\n`
    caption += `│ 🏦 Bank: ${user.bank || 0}\n`
    caption += `│\n`
    caption += `│ ⚔️ Weapon: ${user.weapon} (Lv.${user.weaponLevel || 1})\n`
    caption += `│ 🛡️ Armor: ${user.armor} (Lv.${user.armorLevel || 1})\n`
    caption += `│\n`
    caption += `│ 🏆 Total Hunt: ${user.totalHunt || 0}\n`
    caption += `│ ⛏️ Mining: ${user.mining || 0}\n`
    caption += `│ 🎣 Fishing: ${user.fishing || 0}\n`
    caption += `│ 🪵 Woodcutting: ${user.woodcutting || 0}\n`
    caption += `│ 🌱 Farming: ${user.farming || 0}\n`
    caption += `│ 💼 Work: ${user.workCount || 0}\n`
    caption += `│ 🧭 Adventure: ${user.adventureCount || 0}\n`
    caption += `│ 🏟️ Arena: ${user.arenaWin || 0}W/${user.arenaLose || 0}L\n`
    caption += `│ ⚔️ Duel: ${user.duelWin || 0}W/${user.duelLose || 0}L\n`
    caption += `│\n`
    caption += `│ 🐾 Peliharaan: ${user.pet?.name || "Tidak punya"} (Lv.${user.pet?.level || 0})\n`
    if (user.married && user.married !== "tidak") {
        caption += `│ 💍 Pasangan: @${user.married.split('@')[0]}\n`
    }
    if (user.guild) {
        caption += `│ 🏰 Guild: ${user.guild}\n`
    }
    caption += `│\n`
    caption += `└─── *「 ${global.botname} 」* ───┘`

    await reply(caption)
}

handler.help = ["profilecard"]
handler.tags = ["rpg"]
handler.command = ["profilecard", "pcard"]

module.exports = handler