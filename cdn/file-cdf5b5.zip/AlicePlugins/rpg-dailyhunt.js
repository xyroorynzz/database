
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let handler = async (m, { reply }) => {
    let user = db.getUser(m.sender)
    if (!user) return reply("❌ Kamu belum terdaftar!\nKetik .rpgregister untuk daftar.")

    let now = Date.now()
    let oneDay = 24 * 60 * 60 * 1000

    if (user.lastDailyHunt && now - user.lastDailyHunt < oneDay) {
        let remaining = oneDay - (now - user.lastDailyHunt)
        let hours = Math.floor(remaining / (60 * 60 * 1000))
        return reply(`⏰ Buruan harian sudah diambil! Tunggu ${hours} jam lagi.`)
    }

    let targetHunt = 10
    let currentHunt = user.dailyHuntProgress || 0

    if (currentHunt < targetHunt) {
        return reply(`📋 *BURUAN HARIAN*\n\nTarget: ${targetHunt} hunt\nProgress: ${currentHunt}/${targetHunt}\n\nSelesaikan dengan melakukan .hunt ${targetHunt - currentHunt} kali lagi!`)
    }

    let rewardGold = 5000
    let rewardExp = 1000

    user.gold += rewardGold
    user.exp += rewardExp
    user.dailyHuntProgress = 0
    user.lastDailyHunt = now

    let levelUp = false
    while (user.exp >= user.expNeeded) {
        user.exp -= user.expNeeded
        user.level++
        user.expNeeded = Math.floor(user.expNeeded * 1.5)
        user.maxStamina += 10
        user.stamina = user.maxStamina
        levelUp = true
    }

    db.updateUser(m.sender, user)

    let msg = `🎯 *BURUAN HARIAN SELESAI* 🎯\n\n`
    msg += `✅ ${targetHunt} hunt completed!\n`
    msg += `💰 Gold +${rewardGold}\n`
    msg += `📈 EXP +${rewardExp}\n`
    if (levelUp) msg += `\n🎉 *LEVEL UP! Level ${user.level}!* 🎉`

    reply(msg)
}

handler.help = ["dailyhunt"]
handler.tags = ["rpg"]
handler.command = ["dailyhunt"]

module.exports = handler