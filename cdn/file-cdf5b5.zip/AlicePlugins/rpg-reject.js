
const db = require('../AliceSystem/AliceDatabase/Rpg/database')

let duelData = {}

let handler = async (m, { reply }) => {
    let challenger = null

    for (let [id, data] of Object.entries(duelData[m.chat] || {})) {
        if (data.opponent === m.sender && data.status === "pending") {
            challenger = id
            break
        }
    }

    if (!challenger) return reply("❌ Tidak ada tantangan duel untukmu!")

    delete duelData[m.chat][challenger]

    reply(`❌ @${m.sender.split('@')[0]} menolak tantangan duel!`, { mentions: [m.sender, challenger] })
}

handler.help = ["reject"]
handler.tags = ["rpg"]
handler.command = ["reject", "tolak"]

module.exports = handler