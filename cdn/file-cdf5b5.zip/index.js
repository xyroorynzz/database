//═══════════════════════════════════════════════//
//           🚀 Alice Assistent GEN 2 - Bot WhatsApp Canggih           //
//═══════════════════════════════════════════════//
//
//   🤖 Powered By XyrooRynzz
//   © XyrooRynzz 2022 - 2026
//
//   📌 Source & Official Contact:
//   ➤ Telegram : t.me/XyrooRynzz
//   ➤ Gmail    : xyroorynzz@gmail.com
//   ➤ Github   : github.com/xyroorynzz
//
//   📢 Telegram Channels:
//   ➤ Utama : t.me/xyrooinformations
//   ➤ Testi : t.me/xyrootestimoni
//
//───────────────────────────────────────────────//
// 📖 PANDUAN MEMBACA FILE README.MD
//───────────────────────────────────────────────//
//
//   📂 File readme.md berisi panduan lengkap:
//   • Cara menjalankan script Alice Assistent
//   • Aturan & informasi penting
//   • File yang boleh/tidak boleh diubah
//   • Kontak & promo resmi dari XyrooRynzz
//
//   💡 Cara membacanya:
//   1. Buka panel / file manager kalian
//   2. Masuk ke direktori utama script
//   3. Klik file "readme.md"
//   4. Pilih "View" atau "Edit" untuk melihat isi panduan
//
//   🧠 Disarankan membaca readme.md terlebih dahulu
//   sebelum menjalankan atau mengedit script.
//
//───────────────────────────────────────────────//
//
//   ⚡ Fast • Secure • Automated • Stylish ⚡
//
//═══════════════════════════════════════════════//
//
// 📈━━━━━━━━━━━━━━━━━━━ [ © XyrooRynzz ] ━━━━━━━━━━━━━━━━━━━📉//
// ! jangan edit file ini sedikit pun ! \\
require('./AliceSet');
require('./AliceLibray/notiftelegram');

const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateForwardMessageContent, 
    prepareWAMessageMedia, 
    generateWAMessageFromContent, 
    downloadContentFromMessage, 
    makeInMemoryStore, 
    jidDecode, 
    makeCacheableSignalKeyStore, 
    proto, 
    delay, 
    getDevice 
} = require("@aliceassistent/baileys");

const fs = require('fs');
const pino = require('pino');
const chalk = require('chalk');
const path = require('path');
const axios = require('axios');
const os = require('os');
const yargs = require('yargs/yargs')
const FileType = require('file-type');
const { say } = require('cfonts');
const _ = require('lodash');
const { Boom } = require('@hapi/boom');
const moment = require('moment-timezone');
const PhoneNumber = require('awesome-phonenumber');

const handlerconnect = require('./AliceLibray/handler.js');
const { imageToWebp, imageToWebp3, videoToWebp, writeExifImg, writeExifImgAV, writeExifVid } = require('./AliceLibray/exif');
const { smsg, getBuffer, getSizeMedia, fetchJson, sleep, reSize, question } = require('./AliceLibray/alice-function');

const usePairingCode = global.usePairingCode;

let low;
try {
    low = require('lowdb');
} catch (e) {
    low = require('./AliceLibray/lowdb');
}

const { Low, JSONFile } = low;
const mongoDB = require('./AliceLibray/mongoDB');
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
global.db = new Low(
    /https?:\/\//.test(opts['db'] || '') ? new cloudDBAdapter(opts['db']) : 
    /mongodb/.test(opts['db']) ? new mongoDB(opts['db']) : 
    new JSONFile(`./src/database.json`)
);

global.DATABASE = global.db;
global.loadDatabase = async function loadDatabase() {
    if (global.db.READ) return new Promise((resolve) => setInterval(function() { 
        (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) 
    }, 1000));
    if (global.db.data !== null) return;
    global.db.READ = true;
    await global.db.read();
    global.db.READ = false;
    global.db.data = {
        users: {},
        chats: {},
        game: {},
        database: {},
        settings: {},
        setting: {},
        others: {},
        sticker: {},
        ...(global.db.data || {})
    };
    global.db.chain = _.chain(global.db.data);
};
loadDatabase();

function createTmpFolder() {
    const folderName = "tmp";
    const folderPath = path.join(__dirname, folderName);
    if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath);
        console.log(chalk.green.bold(`[ Success ] Folder '${folderName}' berhasil dibuat.\nMengkoneksikan Otomatis ...`));
    }
}
createTmpFolder();

async function AliceConnect() {
    const { state, saveCreds } = await useMultiFileAuthState(`./AliceSessions`);
    const { version } = await fetchLatestBaileysVersion();

    const Alice = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairingCode,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: "silent", stream: "store" })),
        },
        version,
        browser: ["Ubuntu", "Chrome", "20.0.00"],
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
    });

    require("./AliceLibray/welcomeleft")(Alice);

    if (usePairingCode && !Alice.authState.creds.registered) {
        const code = await Alice.requestPairingCodes(global.AliceBot, global.pairing);
        console.log(`Your pairing code: ${code}`);
    }

    say(`${global.botname}`, {
        font: 'block',
        align: 'center',
        gradient: ['red', 'yellow']
    });

    console.log(chalk.blue.bold(`
✰      [ BOT MULTIDEVICE ]      ✰

▧ 📂 information servers
│ » • platform: ${os.platform()}
│ » • architecture: ${os.arch()}
│ » • cpu model: ${os.cpus()[0].model}
│ » • total memory: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
│ » • free memory: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
└───···

[ ${global.botname} ]
menghubungkan ke whatsapp ....`));

    let aliceSessDir = path.join(__dirname, "AliceSessions");
    let maxSess = 300;

    function autoClearAliceSessions() {
        try {
            let files = fs.readdirSync(aliceSessDir).filter(n => n.startsWith("session-"));
            if (files.length <= maxSess) return;
            let arr = files.map(n => {
                let p = path.join(aliceSessDir, n);
                let t = fs.statSync(p).mtimeMs;
                return { n, t };
            }).sort((a, b) => a.t - b.t);
            let del = arr.length - maxSess;
            for (let i = 0; i < del; i++) {
                let p = path.join(aliceSessDir, arr[i].n);
                try { fs.unlinkSync(p); } catch (e) {}
            }
            console.log("AutoClear AliceSessions:", del, "file session-user dihapus.");
        } catch (e) {}
    }
    setInterval(autoClearAliceSessions, 60 * 1000);

    const WHITELIST = [
        "AliceDatabase", "AliceLibray", "AliceMedia", "AlicePlugins", "AliceSystem",
        ".©alice-xyroorynzz", "Alice_js", "Alice.js", "Alice2uberg.txt", 
        "index.js", "package.json", "readme.md"
    ];

    setInterval(() => {
        const pathsToClean = [path.join(__dirname), path.join(__dirname, 'tmp')];
        const tmpPath = path.join(__dirname, 'tmp');
        if (!fs.existsSync(tmpPath)) fs.mkdirSync(tmpPath, { recursive: true });

        pathsToClean.forEach(dir => {
            fs.readdir(dir, (err, items) => {
                if (err) return console.error(`Gagal membaca folder ${dir}:`, err);
                const filtered = items.filter(item => {
                    if (WHITELIST.includes(item)) return false;
                    return (/\.(gif|png|mp3|mp4|opus|jpg|webp|webm|zip|tar\.gz)$/i.test(item) ||
                        item.startsWith('.cache') || item.startsWith('.npm'));
                });
                if (filtered.length > 0) {
                    console.log(`[ Auto-Cleaner System ]\n› Lokasi scan : ${dir}\n› Terdeteksi: ${filtered.length} file / folder sampah\n› Pembersihan otomatis dimulai dalam 15 detik...`);
                    setTimeout(() => {
                        filtered.forEach(item => {
                            const fullPath = path.join(dir, item);
                            try {
                                if (!fs.existsSync(fullPath)) return;
                                const stats = fs.statSync(fullPath);
                                if (stats.isDirectory()) fs.rmSync(fullPath, { recursive: true, force: true });
                                else fs.unlinkSync(fullPath);
                                console.log(`• ${stats.isDirectory() ? 'Folder' : 'File'} dihapus : ${fullPath}`);
                            } catch (err) { console.error(`Gagal menghapus ${fullPath}:`, err); }
                        });
                        console.log("✔ Selesai dibersihkan.\n");
                    }, 15000);
                }
            });
        });
    }, 30000);

    // ==================== FUNCTIONS ====================
    Alice.sendButtonProto = async (jid, title, footer, buttons = [], quoted = '', options = {}) => {
        let msg = generateWAMessageFromContent(jid, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        ...options,
                        body: proto.Message.InteractiveMessage.Body.create({ text: title }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: footer || "puqi" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: buttons })
                    })
                }
            }
        }, { quoted });
        return await Alice.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    };

    Alice.sendInteractive = async (jid, btn, Img = null, footer, title, quoted = "", options = {}) => {
        let header = Img ? proto.Message.InteractiveMessage.Header.create({
            title: "",
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: Img } }, { upload: Alice.waUploadToServer }))
        }) : proto.Message.InteractiveMessage.Header.create({ title: "", hasMediaAttachment: false });
        
        let msg = generateWAMessageFromContent(jid, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        ...options,
                        body: proto.Message.InteractiveMessage.Body.create({ text: title }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                        header,
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: btn })
                    })
                }
            }
        }, { quoted });
        await Alice.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    };

    Alice.sendStatusMention = async (content, jids = []) => {
        let users;
        for (let id of jids) {
            let userId = await Alice.groupMetadata(id);
            users = await userId.participants.map(u => Alice.decodeJid(u.id));
        }
        let message = await Alice.sendMessage("status@broadcast", content, {
            backgroundColor: "F54242",
            font: Math.floor(Math.random() * 9),
            statusJidList: users,
            additionalNodes: [{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: jids.map((jid) => ({ tag: "to", attrs: { jid }, content: undefined })) }] }]
        });
        jids.forEach(id => {
            Alice.relayMessage(id, { groupStatusMentionMessage: { message: { protocolMessage: { key: message.key, type: 25 } } } }, { userJid: Alice.user.jid, additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }] });
            delay(2500);
        });
        return message;
    };

    Alice.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
        let type = await Alice.getFile(path, true);
        let { res, data: file, filename: pathFile } = type;
        if (res && res.status !== 200 || file.length <= 65536) {
            try { throw { json: JSON.parse(file.toString()) }; } catch (e) { if (e.json) throw e.json; }
        }
        let opt = { filename };
        if (quoted) opt.quoted = quoted;
        if (!type) options.asDocument = true;
        let mtype = '', mimetype = type.mime;
        if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
        else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
        else if (/video/.test(type.mime)) mtype = 'video';
        else if (/audio/.test(type.mime)) mtype = 'audio';
        else mtype = 'document';
        if (options.asDocument) mtype = 'document';
        let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
        let m;
        try {
            m = await Alice.sendMessage(jid, message, { ...opt, ...options });
        } catch (e) {
            console.error(e);
            m = null;
        } finally {
            if (!m) m = await Alice.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
            return m;
        }
    };

    Alice.sendIAMessage = async (jid, btns = [], quoted, options = {}, properties = {}) => {
        let buffer = options.media, file;
        const mention = teks => [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net');
        const IsAndro = await getDevice(quoted?.id) === 'android';
        try {
            if (buffer) {
                file = await Alice.getFile(buffer);
                if (!IsAndro) return Alice.sendFile(jid, buffer, '', options.content, quoted, false, options).catch(() => Alice.reply(jid, options.content, quoted, false, options));
                buffer = await prepareWAMessageMedia({ [/image/.test(file.mime) ? 'image' : 'video']: file.data }, { upload: Alice.waUploadToServer });
            } else if (!IsAndro) {
                return Alice.reply(jid, options.content, quoted);
            }
        } catch (e) {
            console.error(e);
            file = buffer = null;
        }
        const mime = /image/.test(file?.mime || '') ? 'imageMessage' : 'videoMessage';
        const baseHeader = { title: options.header || '', hasMediaAttachment: !!buffer, [mime]: buffer?.[mime] };
        const baseContext = { mentionedJid: mention(options.content || ''), ...properties };
        const msgs = generateWAMessageFromContent(jid, options.hydrated ? {
            interactiveMessage: {
                header: { ...baseHeader, title: options.header || '', subtitle: options.subTitle || '' },
                body: { text: options.content || '' },
                footer: { text: options.footer || '' },
                nativeFlowMessage: { buttons: btns, messageParamsJson: JSON.stringify({ bottom_sheet: { in_thread_buttons_limit: 1, divider_indices: btns.map((_, i) => i + 1), list_title: options.listTitle || 'All Options', button_title: options.buttonTitle || 'See all options' } }) },
                contextInfo: baseContext
            }
        } : {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: baseHeader,
                        body: { text: options.content || '' },
                        footer: { text: options.footer || '' },
                        nativeFlowMessage: { buttons: btns, messageParamsJson: '' },
                        contextInfo: baseContext
                    }
                }
            }
        }, { quoted });
        await Alice.sendPresenceUpdate('composing', jid);
        Alice.relayMessage(jid, msgs.message, { messageId: msgs.key.id });
        return msgs;
    };

    Alice.sendButtonImg = async (jid, buttons = [], text, image, footer, quoted = '', options = {}) => {
        const buttonMessage = {
            image: { url: image },
            caption: text,
            footer: footer,
            buttons: buttons.map(button => ({ buttonId: button.id || '', buttonText: { displayText: button.text || 'Button' }, type: button.type || 1 })),
            headerType: 1,
            viewOnce: options.viewOnce || false,
        };
        Alice.sendMessage(jid, buttonMessage, { quoted });
    };

    Alice.sendPollResult = async (jid, content, options = {}) => {
        const quoted = options.quoted || null;
        if (!content?.pollResultMessage) throw new TypeError("pollResultMessage tidak ditemukan");
        const pollData = content.pollResultMessage;
        const msg = await generateWAMessageFromContent(jid, {
            pollResultSnapshotMessage: {
                name: pollData.name,
                pollVotes: pollData.pollVotes.map(vote => ({ optionName: vote.optionName, optionVoteCount: typeof vote.optionVoteCount === "number" ? vote.optionVoteCount.toString() : vote.optionVoteCount }))
            }
        }, { userJid: Alice.authState.creds.me.id, quoted });
        await Alice.relayMessage(jid, msg.message, { messageId: msg.key.id });
        return msg;
    };

    Alice.sendReact = async (jid, emoticon, keys = {}) => {
        return await Alice.sendMessage(jid, { react: { text: emoticon, key: keys } });
    };

    Alice.deleteMessage = async (chatId, key) => {
        try {
            await Alice.sendMessage(chatId, { delete: key });
            console.log(`Pesan dihapus: ${key.id}`);
        } catch (error) {
            console.error('Gagal menghapus pesan:', error);
        }
    };

    Alice.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    Alice.imgToSticker = async (from, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer;
        if (options && (options.packname || options.author)) buffer = await writeExifImg(buff, options);
        else buffer = await imageToWebp(buff);
        await Alice.sendMessage(from, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Alice.getName = (jid, withoutContact = false) => {
        let id = Alice.decodeJid(jid);
        withoutContact = Alice.withoutContact || withoutContact;
        let v;
        if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
            v = store.contacts[id] || {};
            if (!(v.name || v.subject)) v = Alice.groupMetadata(id) || {};
            resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
        });
        else v = id === '0@s.whatsapp.net' ? { id, name: 'WhatsApp' } : id === Alice.decodeJid(Alice.user.id) ? Alice.user : (store.contacts[id] || {});
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
    };

    Alice.sendContact = async (jid, kon, quoted = '', opts = {}) => {
        let list = [];
        for (let i of kon) {
            list.push({
                displayName: await Alice.getName(i + '@s.whatsapp.net'),
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await Alice.getName(i + '@s.whatsapp.net')}\nFN:${await Alice.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:aplusscell@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://chat.whatsapp.com/HbCl8qf3KQK1MEp3ZBBpSf\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
            });
        }
        Alice.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted });
    };

    Alice.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
        return buffer;
    };

    Alice.sendImage = async (jid, path, caption = '', quoted = '', options) => {
        let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        return await Alice.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted });
    };

    Alice.sendText = (jid, text, quoted = '', options) => Alice.sendMessage(jid, { text: text, ...options }, { quoted });

    Alice.sendTextWithMentions = async (jid, text, quoted, options = {}) => Alice.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted });

    Alice.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = (options && (options.packname || options.author)) ? await writeExifImg(buff, options) : await imageToWebp(buff);
        await Alice.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Alice.sendImageAsStickerAV = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = (options && (options.packname || options.author)) ? await writeExifImgAV(buff, options) : await imageToWebp3(buff);
        await Alice.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Alice.sendImageAsStickerAvatar = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = (options && (options.packname || options.author)) ? await writeExifImg(buff, options) : await imageToWebp3(buff);
        await Alice.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Alice.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = (options && (options.packname || options.author)) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await Alice.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Alice.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    Alice.cMod = (jid, copy, text = '', sender = Alice.user.id, options = {}) => {
        let mtype = Object.keys(copy.message)[0];
        let isEphemeral = mtype === 'ephemeralMessage';
        if (isEphemeral) mtype = Object.keys(copy.message.ephemeralMessage.message)[0];
        let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message;
        let content = msg[mtype];
        if (typeof content === 'string') msg[mtype] = text || content;
        else if (content.caption) content.caption = text || content.caption;
        else if (content.text) content.text = text || content.text;
        if (typeof content !== 'string') msg[mtype] = { ...content, ...options };
        if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant;
        if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid;
        else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid;
        copy.key.remoteJid = jid;
        copy.key.fromMe = sender === Alice.user.id;
        return proto.WebMessageInfo.fromObject(copy);
    };

    Alice.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        let filename = path.join(__dirname, 'src/' + new Date() * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    Alice.parseMention = async (text) => {
        return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net');
    };

    Alice.copyNForward = async (jid, message, forceForward = false, options = {}) => {
        if (options.readViewOnce) {
            message.message = message.message?.ephemeralMessage?.message || message.message;
            let vtype = Object.keys(message.message.viewOnceMessage.message)[0];
            delete message.message.viewOnceMessage.message[vtype].viewOnce;
            message.message = { ...message.message.viewOnceMessage.message };
        }
        let mtype = Object.keys(message.message)[0];
        let content = await generateForwardMessageContent(message, forceForward);
        let ctype = Object.keys(content)[0];
        let context = {};
        if (mtype != "conversation") context = message.message[mtype].contextInfo;
        content[ctype].contextInfo = { ...context, ...content[ctype].contextInfo };
        const waMessage = await generateWAMessageFromContent(jid, content, options ? { ...content[ctype], ...options, ...(options.contextInfo ? { contextInfo: { ...content[ctype].contextInfo, ...options.contextInfo } } : {}) } : {});
        await Alice.relayMessage(jid, waMessage.message, { messageId: waMessage.key.id });
        return waMessage;
    };

    Alice.serializeM = (m) => smsg(Alice, m, store);
    Alice.public = true;

      // ==================== EVENTS ====================
      Alice.ev.on('messages.upsert', async chatUpdate => {
        if (global.autoswview) {
       try {
           if (!chatUpdate.messages || chatUpdate.messages.length === 0) return;
           const mek = chatUpdate.messages[0];
           if (!mek.message) return;
           mek.message = Object.keys(mek.message)[0] === 'ephemeralMessage' ? mek.message.ephemeralMessage.message : mek.message;
           if (mek.key && mek.key.remoteJid === 'status@broadcast') {
               let emoji = [`${global.lz2}`];
               let sigma = emoji[Math.floor(Math.random() * emoji.length)];
               await Alice.readMessages([mek.key]);
               Alice.sendMessage('status@broadcast', { react: { text: sigma, key: mek.key } }, { statusJidList: [mek.key.participant] });
           }
       } catch (err) {
           console.error(err);
         }
      }
   });

      Alice.ev.on('messages.upsert', async chatUpdate => {
      try {
       let mek = chatUpdate.messages[0];
       if (!mek.message) return;
       mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
       if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
       if (!Alice.public && !mek.key.fromMe && !mek.key.isOwner && chatUpdate.type === 'notify') return;
       if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
       
       let m = smsg(Alice, mek, store);
       
       require("./Alice")(Alice, m, chatUpdate, store);
       } catch (err) {
       console.log(err);
       }
    });

    if (!global.anticallDB) global.anticallDB = {};
    if (!global._antiCallCache) global._antiCallCache = new Set();

    Alice.ev.on('call', async (calls) => {
        if (global.anticall !== true) return;
        try {
            const list = Array.isArray(calls) ? calls : [calls];
            for (const c of list) {
                if (!c || c.status !== "offer" || c.isGroup === true) continue;
                const callId = c.id;
                if (!callId || global._antiCallCache.has(callId)) continue;
                global._antiCallCache.add(callId);
                const from = c.from || c.chatId;
                if (!from) continue;
                const callerNumber = from.replace(/@.+/, "");
                const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
                await Alice.rejectCall(callId, from);
                global.anticallDB[from] = (global.anticallDB[from] || 0) + 1;
                const total = global.anticallDB[from];
                await global.sendToTelegramV2(`📞 ANTI CALL REPORT\n\n📱 Nomor Penelpon: ${callerNumber}\n📊 Total Call: ${total}x\n🕒 Waktu: ${time}`, { parse_mode: "HTML" });
                if (total >= 3) {
                    await Alice.updateBlockStatus(from, "block");
                    await global.sendToTelegramV2(`🚫 AUTO BLOCK EXECUTED\n\n📱 Nomor: ${callerNumber}\n📞 Total Call: ${total}x\n⛔ Alasan: Spam Call`, { parse_mode: "HTML" });
                }
                setTimeout(() => global._antiCallCache.delete(callId), 60000);
            }
        } catch (e) {
            console.error("❌ AntiCall Error:", e);
        }
    });

    Alice.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = Alice.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });

    Alice.ev.on('creds.update', saveCreds);
    Alice.ev.on("connection.update", (update) => handlerconnect(update, AliceConnect, Alice));

    return Alice;
}

AliceConnect();