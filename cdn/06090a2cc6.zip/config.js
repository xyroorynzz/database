//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283198132455"] 
global.namabot = 'WIDS'
//======================
global.mess = { 
owner: '*Bang!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done*'
}
//======================