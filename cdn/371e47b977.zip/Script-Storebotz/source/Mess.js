global.mess = {
owner: "Fitur ini hanya untuk ownerbot.", 
group: "Fitur ini hanya dapat digunakan ketika bot berada di dalam grup.", 
private: "Fitur ini hanya dapat digunakan ketika bot berada di private chat.", 
admin: "Fitur ini hanya dapat digunakan admin grup.", 
botadmin: "Fitur ini hanya dapat digunakan ketika bot menjadi admin grup.", 
}