/*═══════════════════════════════════════════════

   ███████╗  ██████╗██████╗ ██╗██████╗ ████████╗
   ██╔════╝ ██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝
   █████╗   ██║     ██████╔╝██║██████╔╝   ██║   
   ██╔══╝   ██║     ██╔═══╝ ██║██╔═══╝    ██║   
   ███████╗ ╚██████╗██║     ██║██║        ██║   
   ╚══════╝  ╚═════╝╚═╝     ╚═╝╚═╝        ╚═╝   
              🚀 SCRIPT By Fyxzpedia 🚀
   
═══════════════════════════════════════════════

👨‍💻 Developer:
   • Fyxzpedia (https://t.me/Fyxzpedia)

📢 Follow Channel Developer:
   • https://chat.whatsapp.com/J2Bau7vaI6t7l24t8gN2zr?mode=ems_copy_t

♻️ Recode:
   • Isi namamu (sosmed)

⚠️ Penting:
   Jangan hapus credits atau nama developer ❗
   Hargai pembuat script ini ✨

═══════════════════════════════════════════════*/