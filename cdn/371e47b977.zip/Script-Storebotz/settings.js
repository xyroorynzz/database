/*═══════════════════════════════════════════════

   ███████╗  ██████╗██████╗ ██╗██████╗ ████████╗
   ██╔════╝ ██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝
   █████╗   ██║     ██████╔╝██║██████╔╝   ██║   
   ██╔══╝   ██║     ██╔═══╝ ██║██╔═══╝    ██║   
   ███████╗ ╚██████╗██║     ██║██║        ██║   
   ╚══════╝  ╚═════╝╚═╝     ╚═╝╚═╝        ╚═╝   
              🚀 SCRIPT By Fyxzpedia 🚀
   
═══════════════════════════════════════════════

👨‍💻 Developer:
   • Fyxzpedia (https://t.me/Fyxzpedia)

📢 Follow Channel Developer:
   • https://chat.whatsapp.com/J2Bau7vaI6t7l24t8gN2zr?mode=ems_copy_t

♻️ Recode:
   • Isi namamu (sosmed)

⚠️ Penting:
   Jangan hapus credits atau nama developer ❗
   Hargai pembuat script ini ✨

═══════════════════════════════════════════════*/

const chalk = require("chalk");
const fs = require("fs");

global.owner = "6283193211556"
global.namaOwner = "Fyxzpedia"
global.mode_public = false

global.linkChannel = "https://whatsapp.com/channel/0029VbBouHp0rGiGXagM0f2e"
global.idChannel = "120363402625644245@newsletter"
global.linkGrup = "https://chat.whatsapp.com/J2Bau7vaI6t7l24t8gN2zr?mode=ems_copy_t"
global.thumbnail = "https://files.catbox.moe/jbkl6w.jpg"

global.dana = "083193211556"
global.ovo = "Tidak tersedia"
global.gopay = "Tidak tersedia"
global.qris = "https://files.catbox.moe/jbkl6w.jpg"

global.JedaPushkontak = 7000
global.JedaJpm = 5000

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://server.ricotasya.my.id"
global.apikey = "ptla_xZZxSITraBdGqPT0Ge4nRb3HxLOZW9yX0oDM82J3" // Isi api ptla
global.capikey = "ptlc_TroIQEI72IEJRtMD2ZomZ1CV7Oeoi0ufEyWSWedle" // Isi api ptlc


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`))
delete require.cache[file]
require(file)
})