const axios = require("axios");

async function createdQris(harga, config) {
  try {
    const amount = Number(harga)
    const url = `https://skyzopedia-api.vercel.app/orderkuota/createpayment?apikey=${config.apikey}&amount=${amount}&username=${config.username}&token=${config.token}`;
    const { data } = await axios.get(url);

    if (!data.result) throw new Error("Gagal membuat QRIS.");

    return {
      idtransaksi: data.result.idtransaksi,
      jumlah: data.result.jumlah,
      imageqris: data.result.imageqris?.url || "",
      nominal: amount
    };
  } catch (err) {
    console.error("[createdQris Error]", err.message);
    throw new Error("Gagal membuat QRIS.");
  }
}

async function cekStatus(sock, sender, config) {
  try {
    const url = `https://skyzopedia-api.vercel.app/orderkuota/mutasiqr?apikey=${config.apikey}&username=${config.username}&token=${config.token}`;
    const { data } = await axios.get(url);

    const req = data?.result;
    if (!req || !sock[sender]?.amount) return false;

    const amount = await toRupiah(sock[sender].amount);
    const found = req.find(i => i.kredit === amount);
    return !!found;
  } catch (err) {
    console.error("[cekStatus Error]", err.message);
    return false;
  }
}


module.exports = { createdQris, cekStatus }