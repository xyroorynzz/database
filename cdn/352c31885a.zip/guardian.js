
setInterval(()=>{
 if(global.gc) global.gc()
 const mem = process.memoryUsage().rss/1024/1024
 if(mem>500){
  console.log("MEMORY LIMIT RESTART:",mem)
  process.exit()
 }
},60000)
