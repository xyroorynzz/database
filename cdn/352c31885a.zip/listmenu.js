const chalk = require("chalk");
const fs = require("fs");


global.mainmenu = `
 ─ *Main - Menu*
 ⌯ .my
 ⌯ .cn
 ⌯ .getpp
 ⌯ .ceklimit
 ⌯ .buylimit
 ⌯ .topglobal
 ⌯ .tflimit
 ⌯ .tfbalance
`

global.creatormenu = `
 ─ *Creator - Menu*
 ⌯ .emojimix
 ⌯ .sticker
 ⌯ .swm
 ⌯ .rvo
 ⌯ .togif
 ⌯ .tohd
 ⌯ .toghibli
 ⌯ .tobugil
 ⌯ .tohitam
 ⌯ .tozombie
 ⌯ .remini
 ⌯ .hdvid
 ⌯ .jadianime
 ⌯ .iqc
 ⌯ .brat
 ⌯ .bratvid
`

global.downloadmenu = `
 ─ *Download - Menu*
 ⌯ .facebook
 ⌯ .instagram
 ⌯ .tiktok
 ⌯ .ytmp3
 ⌯ .ytmp4
 ⌯ .npmdl
 ⌯ .gitclone
 ⌯ .spotifydl
 ⌯ .mediafire
 ⌯ .xnxxdl
 ⌯ .play
`

global.searchmenu = `
 ─ *Search - Menu*
 ⌯ .bokep
 ⌯ .npm
 ⌯ .yts
 ⌯ .happymod
 ⌯ .sfile
 ⌯ .spotify
 ⌯ .pinterest
 ⌯ .nsfw
 ⌯ .cosplay
 ⌯ .xnxx
 ⌯ .xhamster
 ⌯ .gimage
`

global.toolsmenu = `
 ─ *Tools - Menu*
 ⌯ .ai
 ⌯ .translate
 ⌯ .tourl
 ⌯ .tourl2
 ⌯ .ttstalk
 ⌯ .igstalk
 ⌯ .tts
 ⌯ .ocr
`

global.funmenu = `
 ─ *Fun - Menu*
 ⌯ .artinama
 ⌯ .cekganteng
 ⌯ .cekcantik
 ⌯ .cektolol
 ⌯ .cekidiot
 ⌯ .cekkontol
 ⌯ .cekmemek
`

global.gamemenu = `
 ─ *Game - Menu*
 ⌯ .kuis
 ⌯ .siapakahaku
 ⌯ .family100
 ⌯ .tebaktebakan
 ⌯ .tebakhero
 ⌯ .tebakflag
 ⌯ .tictactoe
 ⌯ .tebakboom
 ⌯ .tebakgambar
`

global.storemenu = `
 ─ *Store - Menu*
 ⌯ .addlist
 ⌯ .dellist
 ⌯ .list
 ⌯ .payment
 ⌯ .proses
 ⌯ .done
 ⌯ .pushkontak
 ⌯ .jpm
`

global.grupmenu = `
 ─ *Grup - Menu*
 ⌯ .addsewa
 ⌯ .delsewa
 ⌯ .ceksewa
 ⌯ .listsewa
 ⌯ .afk
 ⌯ .antilink
 ⌯ .welcome
 ⌯ .statusgrup
 ⌯ .promote
 ⌯ .demote
 ⌯ .open
 ⌯ .close
 ⌯ .kick
 ⌯ .tagall
 ⌯ .hidetag
`

global.obfmenu = `
 ─ *Obfuscator - Menu*
 ⌯ .enc
 ⌯ .enc2
 ⌯ .enc3
 ⌯ .minify
`

global.channelmenu = `
 ─ *Channel - Menu*
 ⌯ .cekidch
 ⌯ .buatch
 ⌯ .stalkch
 ⌯ .listch
 ⌯ .jpmch
`

global.panelmenu = `
 ─ *Panel - Menu*
 ⌯ .1gb - .unlimited
 ⌯ .listpanel
 ⌯ .delpanel
 ⌯ .cadmin
 ⌯ .listadmin
 ⌯ .deladmin
 ⌯ .subdomain
 ⌯ .installpanel
 ⌯ .uninstallpanel
`

global.domenu = `
 ─ *DigitalOcean - Menu*
 ⌯ .cvps
 ⌯ .listdroplet
 ⌯ .deldroplet
`

global.setbotmenu = `
 ─ *Setbot - Menu*
 ⌯ .autoread
 ⌯ .gconly
 ⌯ .pconly
 ⌯ .sewaonly
 ⌯ .setthumbnail
 ⌯ .setthumbnail2
 ⌯ .statusbot
`

global.ownermenu = `
 ─ *Owner - Menu*
 ⌯ .addlimit
 ⌯ .dellimit
 ⌯ .addbalance
 ⌯ .delbalance
 ⌯ .backup
 ⌯ .bljpm
 ⌯ .delbljpm
 ⌯ .resetdb
 ⌯ .setwelcome
 ⌯ .setleave
 ⌯ .tagsw
 ⌯ .tagsw2
 ⌯ .getcase
 ⌯ x
 ⌯ $
`

global.allmenu = `${global.mainmenu} ${global.creatormenu} ${global.downloadmenu} ${global.searchmenu} ${global.toolsmenu} ${global.funmenu} ${global.gamemenu} ${global.storemenu} ${global.grupmenu} ${global.obfmenu} ${global.channelmenu} ${global.panelmenu} ${global.domenu} ${global.setbotmenu} ${global.ownermenu}`



let file = require.resolve(__filename) 
fs.watch(file, () => {
fs.unwatch(file)
console.log(chalk.white("• Update"), chalk.white(`${__filename}\n`))
delete require.cache[file]
require(file)
})
