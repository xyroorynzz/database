#!/bin/bash
while true
do
node --expose-gc --max-old-space-size=512 main.js
sleep 3
done
