
const { spawn } = require("child_process")

let reconnectCount=0

function start(){
 const p = spawn("node",["main.js"])

 p.stdout.on("data",(d)=>{
  const t=d.toString()
  process.stdout.write(t)

  if(t.includes("Bot Berhasil Tersambung")){
   reconnectCount++
   if(reconnectCount>=5){
    console.log("RECONNECT LOOP DETECTED → RESTARTING SAFE MODE")
    p.kill()
   }
  }
 })

 p.stderr.on("data",(d)=>process.stderr.write(d))

 p.on("exit",()=>{
  reconnectCount=0
  setTimeout(start,7000)
 })
}

start()
