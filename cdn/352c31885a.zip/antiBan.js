
module.exports = async function antiBan(){
 return new Promise(r=>{
  const delay = Math.floor(Math.random()*4000)+2000
  setTimeout(r,delay)
 })
}
