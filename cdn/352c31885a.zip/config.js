const chalk = require("chalk");
const fs = require("fs");

//######## Setting Nomor Pairing ##########//
global.pairingNumber = "62895396301312"

//############# Setting Bot #############//
global.owner = "6287751632535"
global.ownername = "Wlobob"
global.botname = "Wlobot Multidevice"
global.versibot = "v1.0.0"
global.thumb = "https://files.catbox.moe/bxdalk.jpg"
global.thumbnailReply = "https://files.catbox.moe/bxdalk.jpg"
global.selfmode = true
global.idchannel = "120363406391901455@newsletter"
global.linkchannel = "https://whatsapp.com/channel/0029Vb7Y7Lc6BIEq74dG2a0H"
global.telegram = "https://t.me/wlobob2"
global.linkyt = "https://youtube.com/@wlobot"
global.linkgroup = "https://t.me/wlobob"
global.jedaPushkontak = 5000
global.jedaJpm = 4000

//########### Setting Payment ##########//
global.dana = "ON"
global.ovo = "Tidak tersedia"
global.gopay = "Tidak tersedia"
global.qris = "https://files.catbox.moe/s157rr.jpg"

global.apikeyDigitalocean = "xxxxxx"

//########## Setting VPS ##########//
global.settingVps = {
  "1gb": {
    ram: "1GB",
    cpu: "1 Core",
    disk: "25GB SSD",
    size: "s-1vcpu-1gb"
  },
  "2gb": {
    ram: "2GB",
    cpu: "1 Core",
    disk: "50GB SSD",
    size: "s-1vcpu-2gb"
  },
  "4gb": {
    ram: "4GB",
    cpu: "2 Core",
    disk: "80GB SSD",
    size: "s-2vcpu-4gb"
  },
  "8gb": {
    ram: "8GB",
    cpu: "4 Core",
    disk: "160GB SSD",
    size: "s-4vcpu-8gb"
  }
}

//########## Setting Api Panel ##########//
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://skyy.zpr0.com"
global.apikey = "ptla_A7jtHfNSG9xTmLC9ktnIDWxaDNVItregHSFnshD3Ptf" // Isi api ptla
global.capikey = "ptlc_57V554HeVxR4kxpL29Y1RGQVqY8KToKBPBsci8FHwo8" // Isi api ptlc

//########### Setting Game ###########//
global.balanceDefault = 500
global.limitDefault = 5
global.hargaLimit = 200
global.hadiahGame = 400

//######## Setting Api Subdomain #######//
global.subdomain = {
  "skypedia.qzz.io": {
    "zone": "59c189ec8c067f57269c8e057f832c74",
    "apitoken": "mZd-PC7t7PmAgjJQfFvukRStcoWDqjDvvLHAJzHF"
  }, 
  "pteroweb.my.id": {
    "zone": "714e0f2e54a90875426f8a6819f782d0",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  },
  "panelwebsite.biz.id": {
    "zone": "2d6aab40136299392d66eed44a7b1122",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  },
  "privatserver.my.id": {
    "zone": "699bb9eb65046a886399c91daacb1968",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  },
  "serverku.biz.id": {
    "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  },
  "vipserver.web.id": {
    "zone": "e305b750127749c9b80f41a9cf4a3a53",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  }, 
  "mypanelstore.web.id": {
    "zone": "c61c442d70392500611499c5af816532",
    "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
  }
}

let file = require.resolve(__filename) 
fs.watch(file, () => {
fs.unwatch(file)
console.log(chalk.white("• Update"), chalk.white(`${__filename}\n`))
delete require.cache[file]
require(file)
})