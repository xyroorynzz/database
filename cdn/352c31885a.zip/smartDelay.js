
module.exports = function smartDelay(){
 return Math.floor(Math.random()*3000)+1500
}
