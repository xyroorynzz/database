
const { spawn } = require("child_process")

function run(){
 const p = spawn("node",["main.js"],{stdio:"inherit"})

 p.on("exit",(code)=>{
  console.log("BOT EXITED RESTARTING...",code)
  setTimeout(run,3000)
 })

 p.on("error",(err)=>{
  console.log("SPAWN ERROR",err)
  setTimeout(run,5000)
 })
}

run()
