#Script Mikasa Ai
*Base By Kyami Silence*
*Pengembang Script Zion Dev*
*Baileys By Kiuur*

#Script ini gratis Dari Zion
#Dilarang Menjual Belikan

#jika ingin membeli sesuatu buat bot bisa chat https://t.me/Zionn2009

#Sumber
#https://whatsapp.com/channel/0029Vb2K7scK0IBkPoAGgk28
